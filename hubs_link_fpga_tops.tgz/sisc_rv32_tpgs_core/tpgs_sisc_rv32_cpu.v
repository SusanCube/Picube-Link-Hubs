
`include "tpgs_sisc32_core_params.v"

module	tpgs_sisc_rv32_cpu(
	output								rv32_tpgs_csen	,
	output								rv32_tpgs_wrcs	,
	output		[11: 0]					rv32_tpgs_addr	,
	output		[31: 0]					rv32_tpgs_wdata	,
	input		[31: 0]					rv32_tpgs_rdata	,

	input								tpgs_cram_wrcs	,
	input		[11: 0]					tpgs_cram_addr	,

	input                       		mclk        	,
    input                       		rstn       		);
//----------------------------------	------------------------------------
	wire								rv32_dmem_csen	;	
	wire		[31: 0]					rv32_dmem_addr	;	
	wire								rv32_dmem_wrcs	;		
	wire		[31: 0]					rv32_dmem_wdata	;
	wire		[31: 0]					rv32_dmem_rdata	;

	wire		[31: 0]					rv32_imem_addr	;
	wire		[31: 0]					rv32_imem_rdata	;
//----------------------------------	------------------------------------
	reg									rv32_tpgs_rden	;	
	reg									rv32_dram_rden	;	
	reg									rv32_crom_rden	;
	reg									rv32_cram_rden	;

	wire								rv32_crom_csen	;
	wire								rv32_cram_csen	;
	wire								rv32_dram_csen	;
	wire								mixs_cram_csen	;

	wire	[ 29: 0]					rv32_imem_hadd	=	rv32_imem_addr[31: 2]	;
	wire	[ 29: 0]					rv32_dmem_hadd	=	rv32_dmem_addr[31: 2]	;

	assign		rv32_crom_csen	=		rv32_imem_hadd[29:12] == 18'H0	;
	assign		rv32_cram_csen	=		rv32_imem_hadd[29:12] == 18'H1	;

	assign		rv32_dram_csen	=  		rv32_dmem_csen &( rv32_dmem_hadd[29:12] == 18'H2 );
	assign		rv32_tpgs_csen	=  		rv32_dmem_csen &( rv32_dmem_hadd[29:12] == 18'H3 );

	assign		mixs_cram_csen	= |{	rv32_cram_csen	,	tpgs_cram_wrcs};
	assign		rv32_tpgs_addr	=		rv32_dmem_addr[13: 2]	;

	wire		[11: 0]					rv32_dram_addr	=	rv32_dmem_addr[13: 2]	;
	wire		[11: 0]					rv32_crom_addr	=	rv32_imem_addr[13: 2]	;
	wire		[11: 0]					rv32_cram_addr	=	rv32_imem_addr[13: 2]	;

	wire		[11: 0]					mixs_cram_addr	=	tpgs_cram_wrcs	?	tpgs_cram_addr	:
															rv32_cram_csen	?	rv32_cram_addr	:	12'H0	;


	assign		rv32_tpgs_wrcs	= 		rv32_dmem_wrcs	&	rv32_tpgs_csen	;
	assign		rv32_tpgs_wdata	=		rv32_dmem_wdata	;	

	wire		[31: 0]					rv32_crom_rdata	;
	wire		[31: 0]					rv32_cram_rdata	;
	wire		[31: 0]					rv32_dram_rdata	;
	
	
	assign		rv32_imem_rdata	=		rv32_cram_rden	?	rv32_cram_rdata	:	rv32_crom_rdata	;
	
	assign		rv32_dmem_rdata	=		rv32_tpgs_rden	?	rv32_tpgs_rdata	:
										rv32_dram_rden	?	rv32_dram_rdata	:	32'H0	;


	tpgs_sisc_rv32_core				u_sisc_rv32_core(
		.dmem_men 						(rv32_dmem_csen			),		
		.dmem_madr						(rv32_dmem_addr			),		
		.dmem_mwes						(rv32_dmem_wrcs			),			
		.dmem_mwdt						(rv32_dmem_wdata		),	
		.dmem_mrdt						(rv32_dmem_rdata		),	

		.imem_madr						(rv32_imem_addr			),		
		.imem_mrdt						(rv32_imem_rdata		),			

		.clk							(mclk					),	
		.rstn							(rstn					));

	rv32_boot_crom 					u_rv32_boot_crom(			//4K WORD
  		.ena							(rv32_crom_csen			),
  		.addra							(rv32_crom_addr			),	
  		.douta							(rv32_crom_rdata		),
  		.clka							(mclk					));

	sole_port_bram	#(	
		.ADDR_BITS	(	12	),
		.DATA_BITS	(	32	))		u_rv32_code_ram(

		.bram_csen						(mixs_cram_csen			),		
    	.bram_wrcs						(tpgs_cram_wrcs			),			
    	.bram_addr						(mixs_cram_addr			),			
    	.bram_wdata						(rv32_dmem_wdata		),			
    	.bram_rdata						(rv32_cram_rdata		),
		.bram_clki						(mclk					));				

	sole_port_bram	#(		
		.ADDR_BITS	(	12	),	
		.DATA_BITS	(	32	))		u_rv32_data_ram(

		.bram_csen						(rv32_dram_csen			),		
    	.bram_wrcs						(rv32_dmem_wrcs			),			
    	.bram_addr						(rv32_dram_addr			),			
    	.bram_wdata						(rv32_dmem_wdata		),			
    	.bram_rdata						(rv32_dram_rdata		),
		.bram_clki						(mclk					));				

	always@(posedge mclk or negedge rstn)
	if(!rstn) 	begin
		rv32_tpgs_rden	<=	0	;
		rv32_dram_rden	<=	0	;	
		rv32_crom_rden	<=	0	;	
		rv32_cram_rden	<=	0	;	
	end else 	begin
		rv32_tpgs_rden	<=	rv32_tpgs_csen	;
		rv32_dram_rden	<=	rv32_dram_csen	;	
		rv32_crom_rden	<=	rv32_crom_csen	;	
		rv32_cram_rden	<=	rv32_cram_csen	;	
	end



endmodule 
