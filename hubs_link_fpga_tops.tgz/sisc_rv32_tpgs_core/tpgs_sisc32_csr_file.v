`include "tpgs_sisc32_core_params.v"
module	tpgs_sisc32_csr_file(
`ifdef RV_TRACE
                       output [63:0]                cycle,
`endif
                       input 			            mstatus_mip,
//                       output reg [31:0][31:0]      mmpu,
                       output reg [31:0]            mrac,
                       output 			            mstatus_mip_set,
                       output 			            mstatus_mip_clr,
                       output 			            intmask_set,
                       output 			            intmask_clr,
                       output 			            step_int_en,
                       input                        step_DX_done,
                       input                        WB_is_compress,
                       input                        int_return,
                       input                        dbg_return,
                       output                       debug,
                       input [`RV_XLEN-1:0]         PC_IF,
                       input                        dbg_hit,
                       input                        dpc_hit,
                       input                        dbg_irq,
                       input                        dbg_ndreset,
                       input                        dbg_fullreset,
                       output reg [`RV_XLEN-1:0]    dpc,
                       input                        handler_hit,
                       input                        kill_DX,
                       input                        stall_WB,
                       input                        clk,
                       input [`N_EXT_INTS-1:0]      ext_interrupts, 
                       input                        reset,
                       input [`CSR_ADDR_WIDTH-1:0]  addr,
                       input [`CSR_CMD_WIDTH-1:0]   cmd,
                       input [`RV_XLEN-1:0]         wdata,
                       output wire [`PRV_WIDTH-1:0] prv,
                       output                       illegal_access,
                       output reg [`RV_XLEN-1:0]    rdata,
                       input                        retired_WB,
                       input                        exception_WB,
                       input [`ECODE_WIDTH-1:0]     exception_code,
                       input                        eret,
                       input [`RV_XLEN-1:0]         PC_WB,
                       input                        jump_WB,
                       input                        dmem_en,
                       input                        interrupt_mask,
                       output                       interrupt_taken_WB,
                       output reg                   interrupt_taken_ext_WB,
                       output reg                   interrupt_taken_irq_WB,
                       output reg                   interrupt_taken_stp_WB,
                       input                        active_wfi_WB,
                       output [`RV_XLEN-1:0]        handler_PC,
                       output [`RV_XLEN-1:0]        handler_PCR,
                       output [`RV_XLEN-1:0]        epc
                       );

     reg [`CSR_COUNTER_WIDTH-1:0]                     time_full;
     reg [`RV_XLEN-1:0]                               mtimecmp;
     wire                                             mtimer_expired;
     reg [`CSR_COUNTER_WIDTH-1:0]                     cycle_full;
     reg [5:0]                                        priv_stack;
     reg [`RV_XLEN-1:0]                               mtvec;
     reg [`RV_XLEN-1:0]                               mie;
     reg                                              mtip;
     reg                                              msip;
     reg [`RV_XLEN-1:0]                               mepc;
     reg [`ECODE_WIDTH-1:0]                           mecode;
     reg                                              mint;
     reg [`RV_XLEN-1:0]                               dscratch;
     wire                                             ie;
     wire [4:0]                                       lsb1;
     reg  [4:0]                                       mlsb;
     reg  [4:0]                                       plsb;
     wire [`RV_XLEN-1:0]                              mstatus;
     wire [`RV_XLEN-1:0]                              intOn;
     wire [`RV_XLEN-1:0]                              intSt;
     wire [`RV_XLEN-1:0]                              mcause;
     wire [`RV_XLEN-1:0]                              dcsr;
     wire                                             wen_internal;
     reg                                              defined;
     reg [`RV_XLEN-1:0]                               wdata_internal;
     wire                                             minterrupt;
     assign prv = 2'b11;
     assign ie = 1'b1;

     assign system_en = cmd[2];
     assign system_wen = cmd[1] || cmd[0];
     assign wen_internal = system_wen && (!kill_DX) && (!interrupt_taken_WB);
     assign illegal_access = 1'b0;
     always @(*) begin
        wdata_internal = wdata;
        if (system_wen&&(!kill_DX)) begin
           case (cmd)
             `CSR_SET : wdata_internal = rdata | wdata;
             `CSR_CLEAR : wdata_internal = rdata & ~wdata;
             default : wdata_internal = wdata;
           endcase // case (cmd)
        end
     end // always @ begin

   assign minterrupt = |(mie & intOn);

   reg    interrupt_taken_irq_DX;
   wire   interrupt_taken_stp_DX;
   wire   interrupt_taken_ext_DX = ie && minterrupt;

   wire   step_window;

   assign interrupt_taken_WB = interrupt_taken_ext_WB || interrupt_taken_irq_WB || interrupt_taken_stp_WB;

   assign step_int_en = step_window && step_DX_done;
   wire interrupt_enable = (~stall_WB || active_wfi_WB) && (~dmem_en || step_int_en) && ~interrupt_mask && ~debug;
   wire interrupt_irq_en = (~stall_WB || active_wfi_WB) && (~dmem_en || step_int_en) && ~interrupt_mask && ~debug;
   wire interrupt_stp_en = (~stall_WB || active_wfi_WB) && (~dmem_en || step_int_en) && ~debug;

   always @(posedge clk)
   if(reset)
     interrupt_taken_ext_WB <= 1'b0;
   else if(interrupt_taken_ext_WB)
     interrupt_taken_ext_WB <= 1'b0;
   else if(interrupt_taken_ext_DX && interrupt_enable)
     interrupt_taken_ext_WB <= 1'b1;


   always @(posedge clk)
   if(reset)
     interrupt_taken_irq_WB <= 1'b0;
   else if(interrupt_taken_irq_WB)
     interrupt_taken_irq_WB <= 1'b0;
   else if(interrupt_taken_irq_DX && interrupt_irq_en)
     interrupt_taken_irq_WB <= 1'b1;

   always @(posedge clk)
   if(reset)
     interrupt_taken_stp_WB <= 1'b0;
   else if(interrupt_taken_stp_WB)
     interrupt_taken_stp_WB <= 1'b0;
   else if(interrupt_taken_stp_DX && interrupt_stp_en)
     interrupt_taken_stp_WB <= 1'b1;




   reg t_debug;
   assign debug = t_debug;
   always @(posedge clk)
   if(reset)
     t_debug <= 1'b0 ;
   else if(dpc_hit&& t_debug)
     t_debug <= 1'b0 ;
   else if(dbg_hit&&~t_debug)
     t_debug <= 1'b1 ;
 

   reg dbg_irq_r1;
   reg dbg_irq_r2;
   always @(posedge clk)
   if(reset) begin
     dbg_irq_r1 <= 1'b0 ;
     dbg_irq_r2 <= 1'b0 ;
   end
   else begin
     dbg_irq_r1 <= dbg_irq ;
     dbg_irq_r2 <= dbg_irq_r1 ;
   end

   assign dbg_irq_pulse = dbg_irq_r1 && ~dbg_irq_r2 && ~debug;

   always @(posedge clk)
   if(reset)
     interrupt_taken_irq_DX <= 1'b0 ;
   else if(interrupt_taken_irq_WB)
     interrupt_taken_irq_DX <= 1'b0 ;
   else if(dbg_irq_pulse)
     interrupt_taken_irq_DX <= 1'b1 ;



   assign epc = mepc;

   wire   mstatus_mie = ~interrupt_mask;
   assign mstatus = {24'h00, mstatus_mip, 3'b000, mstatus_mie, 3'b000};

   assign mtimer_expired = (mtimecmp <= time_full[0+:`RV_XLEN]);

   always @(posedge clk) begin
      if (reset) begin
         mtip <= 0;
         msip <= 0;
      end else begin
	 if (wen_internal && addr == `CSR_ADDR_MTIMECMP) begin
           mtip <= 0;
         end else if (wen_internal && addr == `CSR_ADDR_MIP) begin
           mtip <= wdata_internal[7];
           msip <= wdata_internal[3];
	 end else if (mtimer_expired) begin
           mtip <= 1;
         end
      end // else: !if(reset)
   end // always @ (posedge clk)

  reg handler_hit_r;
  wire handler_hit_rise = handler_hit && ~handler_hit_r;
  always @(posedge clk)
  if(reset)
    handler_hit_r <= 0;
  else
    handler_hit_r <= handler_hit;

  reg  [`N_EXT_INTS-1:0] mip_status;
  reg  [`N_EXT_INTS-1:0] ext_interrupts_st;
  wire [`N_EXT_INTS-1:0] lsb1_fb;
  reg  [`N_EXT_INTS-1:0] mlsb_lock;
  wire  [`N_EXT_INTS-1:0] mie_shifted = {mie[`RV_XLEN-1:9], 1'b0}; // reverve interrupt 0 only for exception
  wire  [`N_EXT_INTS-1:0] ext_interrupts_in = ext_interrupts & mie_shifted;

  always @(posedge clk)
  if(reset)
    ext_interrupts_st <= 0;
  else if(~interrupt_mask)
    ext_interrupts_st <= (ext_interrupts_st | ext_interrupts_in) & (mie_shifted);

  assign intOn = {ext_interrupts_in, mtip&mie[7] ,3'b0,msip,3'b0};
  assign intSt = {ext_interrupts_st, mtip&mie[7] ,3'b0,msip,3'b0};

  `ifdef LSB1_EN
    lsb1 u_lsb1(.data(ext_interrupts_st), .lsb1(lsb1) ,.lsb1_o(lsb1_fb));
  `else // No interrupt priority
    assign  lsb1    = 5'b0;
    assign  lsb1_fb = {(`N_EXT_INTS){1'b0}};
  `endif

  `define INTCFG_LEN 3
  reg  [`INTCFG_LEN-1:0] intcfg;
  wire [`INTCFG_LEN-1:0] int_entry_size = {intcfg[`INTCFG_LEN-1:1], 1'b0};
  wire                   time_loop_mode =  intcfg[0];


  assign handler_PC = mtvec + (lsb1*int_entry_size);
  assign handler_PCR= mtvec + (mlsb*int_entry_size);

  wire issued = active_wfi_WB || retired_WB;

  always @(posedge clk)
  if (reset) begin
    mlsb <= 5'h1f;
    plsb <= 5'h1f;
    mlsb_lock <= {`N_EXT_INTS{1'b0}};
  end else if (interrupt_taken_ext_WB || (exception_WB && (exception_code != `ECODE_BREAKPOINT))) begin
    if (interrupt_taken_ext_WB && (|lsb1)) begin
      mlsb <= lsb1;
      plsb <= mlsb;
      mlsb_lock <= mlsb_lock | lsb1_fb;
    end else begin
      mlsb <= 5'h0;
      plsb <= mlsb;
      mlsb_lock <= {`N_EXT_INTS{1'b0}};
    end
  end else if (wen_internal && (addr==`CSR_ADDR_MLSB)) begin
    mlsb <= plsb;
    mlsb_lock <= mlsb_lock & (~(1<<mlsb));
  end else if (wen_internal && (addr==`CSR_ADDR_PLSB)) begin
    plsb <= wdata_internal;
  end

  always @(posedge clk)
  if (reset)
    mip_status <= 'h8;
  else if (interrupt_taken_ext_WB)
    mip_status <= mie_shifted;

  always @(posedge clk) begin
  if (reset) begin
     mie <= 0;
   end else if (wen_internal && addr == `CSR_ADDR_MIE) begin
     mie <= wdata_internal;
   end else if (interrupt_taken_ext_WB) begin
     mie <= {24'h00, mie[7:0]};
   end else if (int_return) begin
     mie <= {mip_status, mie[7:0]};
   end
  end
////////////////////////////////////////

// mepc //////////////////////////////////
     always @(posedge clk) begin
      if (interrupt_taken_WB) begin
        if (jump_WB) begin
          if (interrupt_taken_ext_WB)
            mepc <=  PC_WB & {{31{1'b1}},1'b0};
        end
        else begin
          if (interrupt_taken_ext_WB)
            mepc <= (PC_WB & {{31{1'b1}},1'b0}) + (issued ? (WB_is_compress ? `RV_XLEN'h2 : `RV_XLEN'h4) : `RV_XLEN'h0);
        end
      end
      else
      if (exception_WB) begin
        if (exception_code != `ECODE_BREAKPOINT)
          mepc <= PC_WB & {{31{1'b1}},1'b0};
      end else if (wen_internal && addr == `CSR_ADDR_MEPC)
        mepc <= wdata_internal & {{31{1'b1}},1'b0};
     end
////////////////////////////////////////

// dpc /////////////////////////////////
     always @(posedge clk) begin
      if (exception_WB) begin
        if (wen_internal && addr == `CSR_ADDR_DPC)
          dpc <= wdata_internal;
        if (exception_code == `ECODE_BREAKPOINT)
          dpc  <= PC_WB & {{31{1'b1}},1'b0};
      end else if (interrupt_taken_WB) begin
        if (wen_internal && addr == `CSR_ADDR_DPC)
          dpc <= wdata_internal;
        if (jump_WB) begin
          if (interrupt_taken_ext_WB)
            dpc <=  dpc;
          else if (interrupt_taken_stp_WB)
            dpc <= issued ? PC_IF : PC_WB;
          else /* interrupt_taken_dbg_WB */
            dpc  <= (PC_WB & {{31{1'b1}},1'b0});
        end
        else begin
          if (interrupt_taken_ext_WB)
            dpc <= dpc;
          else if (interrupt_taken_stp_WB)
            dpc  <= (PC_WB & {{31{1'b1}},1'b0}) + (issued ? (WB_is_compress ? `RV_XLEN'h2 : `RV_XLEN'h4) : `RV_XLEN'h0);
          else
            dpc  <= (PC_WB & {{31{1'b1}},1'b0}) + (issued ? (WB_is_compress ? `RV_XLEN'h2 : `RV_XLEN'h4) : `RV_XLEN'h0);
        end
      end else if (wen_internal && addr == `CSR_ADDR_DPC)
        dpc <= wdata_internal;
     end
////////////////////////////////////////

// mecode //////////////////////////////
     always @(posedge clk) begin
        if (reset) begin
           mecode <= 0;
        end else if (wen_internal && addr == `CSR_ADDR_MCAUSE) begin
           mecode <= wdata_internal[3:0];
        end else begin
           if (interrupt_taken_WB) begin
              if(interrupt_taken_ext_WB) begin
                if(msip&&mie[3]) 
                  mecode <= 4'h3;
                else if(mtip&&mie[7])
                  mecode <= 4'h7;
                else
                  mecode <= 4'hb;
              end else if(interrupt_taken_irq_WB)
                mecode <= 4'hd;
           end else if (exception_WB || interrupt_taken_ext_WB) begin
              mecode <= exception_code;
           end
        end // else: !if(reset)
     end // always @ (posedge clk)

// mint ////////////////////////////////
     always @(posedge clk) begin
        if (reset) begin
           mint <= 0;
        end else if (wen_internal && addr == `CSR_ADDR_MCAUSE) begin
           mint <= wdata_internal[31];
        end else begin
           if (interrupt_taken_WB) begin
              mint <= 1'b1;
           end else
           if (exception_WB || interrupt_taken_ext_WB) begin
              mint <= 1'b0;
           end
        end // else: !if(reset)
     end // always @ (posedge clk)
////////////////////////////////////////

     assign mcause = {mint,27'b0,mecode};

                                    // -1-- ---- X--U -S-- ---M ---I ---- -C-A
   wire [31:0] misa = 32'h40801104; // 0100 0000 1000 0000 0001 0001 0000 0100
 //wire [31:0] misa = 32'h40941105; // 0100 0000 1001 0100 0001 0001 0000 0101

     always @(*) begin
        case (addr)
          `CSR_ADDR_INTCFG    : begin rdata = intcfg; defined = 1'b1; end
          `CSR_ADDR_MISA      : begin rdata = misa; defined = 1'b1; end
          `CSR_ADDR_INFO_DC   : begin rdata = 32'h00024004; defined = 1'b1; end
          `CSR_ADDR_INFO_IC   : begin rdata = 32'h00024004; defined = 1'b1; end
          `CSR_ADDR_CPUTYPE   : begin rdata = 32'h01200007; defined = 1'b1; end
          `CSR_ADDR_VERSION   : begin rdata = 32'd2022062300; defined = 1'b1; end
          `CSR_ADDR_MLSB      : begin rdata = mlsb; defined = 1'b1; end
          `CSR_ADDR_PLSB      : begin rdata = plsb; defined = 1'b1; end
          `CSR_ADDR_MRAC      : begin rdata = mrac; defined = 1'b1; end
          `CSR_ADDR_DPC       : begin rdata = dpc; defined = 1'b1; end
          `CSR_ADDR_DCSR      : begin rdata = dcsr; defined = 1'b1; end
          `CSR_ADDR_DSCRATCH  : begin rdata = dscratch; defined = 1'b1; end
          `CSR_ADDR_CYCLE     : begin rdata = cycle_full[0+:`RV_XLEN]; defined = 1'b1; end
          `CSR_ADDR_CYCLEH    : begin rdata = cycle_full[`RV_XLEN+:`RV_XLEN]; defined = 1'b1; end
          `CSR_ADDR_MSTATUS   : begin rdata = mstatus; defined = 1'b1; end
          `CSR_ADDR_MTVEC     : begin rdata = mtvec; defined = 1'b1; end
          `CSR_ADDR_MIE       : begin rdata = mie; defined = 1'b1; end
          `CSR_ADDR_MEPC      : begin rdata = mepc; defined = 1'b1; end
          `CSR_ADDR_MCAUSE    : begin rdata = mcause; defined = 1'b1; end
          `CSR_ADDR_MIP       : begin rdata = mip_status; defined = 1'b1; end
          `CSR_ADDR_TIME      : begin rdata = time_full[0+:`RV_XLEN]; defined = 1'b1; end
          `CSR_ADDR_TIMEH     : begin rdata = time_full[`RV_XLEN+:`RV_XLEN]; defined = 1'b1; end
          `CSR_ADDR_MTIMECMP  : begin rdata = mtimecmp; defined = 1'b1; end
          default             : begin rdata = /*({addr[11:5], 5'b0} == `CSR_ADDR_MPU_BASE) ?  mmpu[addr[4:0]] :*/ 32'h00; defined = 1'b1; end
        endcase // case (addr)
     end // always @ (*)
  
     reg  [31:0] i_dcsr;
     wire [1:0] dcsr_xdebugver = 2'h1 ;
     wire       dcsr_ebreakm   = i_dcsr[15] ;
     wire       dcsr_ebreakh   = 1'b0       ;
     wire       dcsr_ebreaks   = i_dcsr[13] ;
     wire       dcsr_ebreaku   = i_dcsr[12] ;
     wire       dcsr_stopcycle = 1'b0 ;
     wire       dcsr_stoptime  = 1'b0 ;
     wire       dcsr_halt      = i_dcsr[3] ;
     wire       dcsr_step      = i_dcsr[2] ;
     wire       trigger        = 1'b0 ;
     wire       is_break       = dcsr_ebreakm | dcsr_ebreakh | dcsr_ebreaks | dcsr_ebreaku ;
     wire       temp_halt      = 1'b0 ; // why dcsr_halt cause error?
     wire [2:0] dcause         = temp_halt ? 5 :
                                 dcsr_step ? 4 :
                                 dbg_irq   ? 3 :
                                 trigger   ? 2 :
                                 is_break  ? 1 :
                                             0 ;
     reg [2:0] dcsr_cause;
     always @(posedge clk)
     if(~debug)
       dcsr_cause <= dcause;
  
     assign step_window = dcsr_step & ~debug ;

     reg  r_step_window;
     assign req_stp_DX = step_window && ~r_step_window;

     always @(posedge clk or posedge reset)
     if(reset)
       r_step_window <= 1'b0;
     else
       r_step_window <= step_window;

     reg t_interrupt_taken_stp_DX;
     assign interrupt_taken_stp_DX = req_stp_DX || t_interrupt_taken_stp_DX;

     always @(posedge clk or posedge reset)
     if(reset)
       t_interrupt_taken_stp_DX <= 1'b0;
     else if(interrupt_taken_stp_WB)
       t_interrupt_taken_stp_DX <= 1'b0;
     else if(req_stp_DX)
       t_interrupt_taken_stp_DX <= 1'b1;
  
     assign dcsr = {
                    dcsr_xdebugver, // [31:30]
                    dbg_ndreset,    // [29]
                    dbg_fullreset,  // [28]
                    12'h000,        // [27:16]
                    dcsr_ebreakm,   // [15]
                    dcsr_ebreakh,   // [14]
                    dcsr_ebreaks,   // [13]
                    dcsr_ebreaku,   // [12]
                    1'b0,           // [11]
                    dcsr_stopcycle, // [10]
                    dcsr_stoptime,  // [9]
                    dcsr_cause,     // [8:6]
                    dbg_irq,        // debugint
                    1'b0,           // [4]
                    dcsr_halt,      // [3]
                    dcsr_step,      // [2]
                    prv             // [1:0]
                   };

     assign intmask_clr = wen_internal && (addr==`CSR_ADDR_MSTATUS) &&  wdata_internal[3];
     assign intmask_set = wen_internal && (addr==`CSR_ADDR_MSTATUS) && ~wdata_internal[3];
     assign mstatus_mip_clr = wen_internal && (addr==`CSR_ADDR_MSTATUS) && ~wdata_internal[7];
     assign mstatus_mip_set = wen_internal && (addr==`CSR_ADDR_MSTATUS) &&  wdata_internal[7];

     always @(posedge clk)
        if (reset)
           time_full <= 0;
        else if (wen_internal & (addr == `CSR_ADDR_TIME))
           time_full[0+:`RV_XLEN] <= wdata_internal;
        else if (wen_internal & (addr == `CSR_ADDR_TIMEH))
           time_full[`RV_XLEN+:`RV_XLEN] <= wdata_internal;
        else if (wen_internal & (addr == `CSR_ADDR_MTIMECMP))
           time_full <= 64'h00;
        else if(time_loop_mode & mtimer_expired)
           time_full <= 64'h00;
        else
           time_full <= time_full + 1;

     always @(posedge clk) begin
        if (reset) begin
           cycle_full <= 0;
           mtvec <= `CUSTOM_INIT_MEPC;
           mrac <= 32'h00000000;
           intcfg   <= 32'h00000001;
           mtimecmp <= 0;
           dscratch <= 0;
           i_dcsr <= 0;
        end else begin
           cycle_full <= cycle_full + 1;
           if (wen_internal && ({addr[11:5], 5'b0} == `CSR_ADDR_MPU_BASE)) begin
//               mmpu[addr[4:0]] <= wdata_internal;
           end else if (wen_internal) begin
              case (addr)
                `CSR_ADDR_INTCFG    : intcfg <= wdata_internal[`INTCFG_LEN-1:0];
                `CSR_ADDR_MRAC      : mrac <= wdata_internal;
                `CSR_ADDR_DCSR      : i_dcsr <= wdata_internal;
                `CSR_ADDR_DSCRATCH  : dscratch <= wdata_internal;
                `CSR_ADDR_MTVEC     : mtvec <= wdata_internal & {{31{1'b1}},1'b0};
                `CSR_ADDR_MTIMECMP  : begin
                                        mtimecmp <= wdata_internal;
                                      end
                default : ;
              endcase // case (addr)
           end // if (wen_internal)
        end // else: !if(reset)
     end // always @ (posedge clk)

`ifdef RV_TRACE
     assign cycle = cycle_full;
`endif

endmodule // sisc32_csr_file
