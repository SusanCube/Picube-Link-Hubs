`include "tpgs_sisc32_core_params.v"
module tpgs_sisc32_imm_gen(
                      input [`RV_XLEN-1:0]        inst,
                      input [`IMM_TYPE_WIDTH-1:0] imm_type,
                      output reg [`RV_XLEN-1:0]   imm
                      );

   always @(*) begin
      case (imm_type)
        `IMM_I : imm = { {21{inst[31]}}, inst[30:25], inst[24:21], inst[20] };
        `IMM_S : imm = { {21{inst[31]}}, inst[30:25], inst[11:8], inst[7] };
        `IMM_U : imm = { inst[31], inst[30:20], inst[19:12], 12'b0 };
        `IMM_J : imm = { {12{inst[31]}}, inst[19:12], inst[20], inst[30:25], inst[24:21], 1'b0 };
        `IMM_O : imm = 0;
        `IMM_M : imm = { {16{inst[30]}}, inst[30:20], inst[11:7] };
        `IMM_T : imm = { {23{inst[31]}}, inst[30:27], inst[24:20] };
        default : imm = { {21{inst[31]}}, inst[30:25], inst[24:21], inst[20] };
      endcase // case (imm_type)
   end

endmodule // sisc32_imm_gen
