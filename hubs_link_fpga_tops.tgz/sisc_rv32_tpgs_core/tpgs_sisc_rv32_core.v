
`include "tpgs_sisc32_core_params.v"

module	tpgs_sisc_rv32_core #(
  parameter PC_SIZE = 32  ,
  parameter HART_NUM = 1
) (
	output                        dmem_men   ,
	output [31:0]                 dmem_madr  ,
	output                        dmem_mwes  ,
	output [31:0]                 dmem_mwdt  ,
	input  [31:0]                 dmem_mrdt  ,
	
	output [31:0]                 imem_madr  ,
	input  [31:0]                 imem_mrdt  ,
	input                         clk        ,
	input                         rstn       );

	reg		[31:0]					dmem_rdata	;

(* keep_hierarchy = "yes" *)
	tpgs_sisc32_pipeline 	u_pipeline(
`ifdef RV_TRACE
		.inst_WB      ( inst_WB       ),
		.cycle        ( cycle         ),
		.trace_int    ( trace_int     ),
		.pc_reg0      ( pc_reg0       ),
		.sp_reg0      ( sp_reg0       ),
		.ras          ( ras           ),
`endif
		.mmpu         (               ),
		.mrac         (               ),
		.dc_wr_stall  ( 1'b0          ),
		.fence_line   (               ),
		.fence_rwrw   (               ),
		.fence_iorw   (               ),
		.cacheable    ( 1'b0          ),
		.fence_i      (               ),
		.redirect     (               ),
		
		.inst_DX      (               ),
		
		.clk            (clk          ),
		.ext_interrupts ({(`N_EXT_INTS){1'b0}}),
		.reset          (~rstn        ),
		.imem_wait      (~rstn        ),
		.imem_miss      (1'b0         ),
		.imem_addr      (imem_madr    ),
		.imem_rdata     (imem_mrdt    ),
		.imem_badmem_e  (1'b0         ),
		.dmem_wait      (1'b0         ),
		.dmem_en        (dmem_men     ),
		.dmem_wen       (dmem_mwes    ),
		.dmem_size      (             ),
		.dmem_addr      (dmem_madr    ),
		.dmem_wdata_delayed(          ),
		.dmem_wdata     (dmem_mwdt    ),
		.dmem_rdata     (dmem_mrdt    ),
		.dmem_badmem_e  (1'b0         ),
		.dbg_ndreset    (1'b0         ),
		.dbg_fullreset  (1'b0         ),
		.dbg_irq        (1'b0         ),
		.debug          (             ) 
		);



endmodule 
