`include 	"tpgs_sisc32_core_params.v"

module tpgs_sisc32_ctrl(
`ifdef RV_TRACE
                   input                              trace_int,
`endif
                   output                             retire_WB,
                   output reg                         sel_ctm,
                   input 			                  dc_wr_stall,
                   output reg                         fence_line,
                   output reg                         fence_rwrw,
                   output reg                         fence_iorw,
                   output reg                         step_DX_done,
                   input 			                  step_int_en,
                   input                              cacheable,
                   output reg		                  mstatus_mip,
                   input 			                  mstatus_mip_set,
                   input 			                  mstatus_mip_clr,
                   input 			                  intmask_set,
                   input 			                  intmask_clr,
                   output                             int_return,
                   output                             dbg_return,
                   output reg                         fence_i,
                   output reg [`LSU_TYPE_WIDTH-1:0]   lsu_type,
                   output wire                        jump_DX,
                   input                              clk,
                   input                              reset,
                   input [`INST_WIDTH-1:0]            inst_DX,
                   input                              imem_miss,
                   input                              imem_wait,
                   input                              imem_badmem_e,
                   input                              dmem_wait,
                   input                              dmem_badmem_e,
                   input                              cmp_true,
                   input [`PRV_WIDTH-1:0]             prv,
                   output reg [`PC_SRC_SEL_WIDTH-1:0] PC_src_sel,
                   output reg [`IMM_TYPE_WIDTH-1:0]   imm_type,
                   output                             bypass_rs1,
                   output                             bypass_rs2,
                   output                             bypass_rs3,
                   output reg [`SRC_A_SEL_WIDTH-1:0]  src_a_sel,
                   output reg [`SRC_B_SEL_WIDTH-1:0]  src_b_sel,
                   output reg [`ALU_OP_WIDTH-1:0]     alu_op,
                   output wire                        dmem_en,
                   output wire                        dmem_wen,
                   output wire [2:0]                  dmem_size,
                   output wire [`MEM_TYPE_WIDTH-1:0]  dmem_type,
                   output                             md_req_valid,
                   input                              md_req_ready,
                   output reg                         md_req_in_1_signed,
                   output reg                         md_req_in_2_signed,
                   output reg [`MD_OP_WIDTH-1:0]      md_req_op,
                   output reg [`MD_OUT_SEL_WIDTH-1:0] md_req_out_sel,
                   input                              md_resp_valid,
                   output wire                        eret,
                   input                              debug,
                   output [`CSR_CMD_WIDTH-1:0]        csr_cmd,
                   output reg                         csr_imm_sel,
                   input                              illegal_csr_access,
                   input                              interrupt_taken_ext_WB,
                   input                              interrupt_taken_irq_WB,
                   input                              interrupt_taken_stp_WB,
                   input                              interrupt_taken_WB,
                   output                             active_wfi_WB,
                   output                             interrupt_mask,
                   output wire                        wr_reg_WB,
                   output reg [`REG_ADDR_WIDTH-1:0]   reg_to_wr_WB,
                   output reg [`WB_SRC_SEL_WIDTH-1:0] wb_src_sel_WB,
                   output wire                        redirect,
                   output wire                        stall_IF,
                   output wire                        kill_IF,
                   output wire                        stall_DX,
                   output wire                        kill_DX,
                   output wire                        stall_WB,
                   output wire                        kill_WB,
                   output wire                        exception_WB,
                   output wire [`ECODE_WIDTH-1:0]     exception_code_WB,
                   input [`REG_ADDR_WIDTH-1:0]        reg_ra1,
                   input [`REG_ADDR_WIDTH-1:0]        reg_ra2,
                   input [`REG_ADDR_WIDTH-1:0]        reg_ra3,
                   input [`REG_ADDR_WIDTH-1:0]        reg_wa,
                   input                              reg_wen,
                   input                              uses_rs3,
                   output reg                         retired_WB,
                   input                              handler_hit,
                   input                              dbg_hit,
                   input                              dpc_hit,
                   input                              epc_hit 
                   );

   wire                                               dret;
   reg                                                ebreak;

   wire                                               replay_miss;
   wire                                               replay_IF;

   wire                                               ex_IF;

   reg                                                had_ex_DX;
   reg                                                prev_killed_DX;

   wire [6:0]                                         opcode = inst_DX[6:0];
   wire [6:0]                                         funct7 = inst_DX[31:25];
   wire [11:0]                                        funct12 = inst_DX[31:20];
   wire [2:0]                                         funct3 = inst_DX[14:12];
   wire [`REG_ADDR_WIDTH-1:0]                         rs1_addr = inst_DX[19:15];
   wire [`REG_ADDR_WIDTH-1:0]                         rs2_addr = inst_DX[24:20];
   wire [`REG_ADDR_WIDTH-1:0]                         reg_to_wr_DX = inst_DX[11:7];
   reg                                                illegal_instruction;
   reg                                                ecall;
   reg                                                eret_unkilled;
   reg                                                dret_unkilled;
   wire [`ALU_OP_WIDTH-1:0]                           add_or_sub;
   wire [`ALU_OP_WIDTH-1:0]                           srl_or_sra;
   reg [`ALU_OP_WIDTH-1:0]                            alu_op_arith;
   reg                                                branch_unkilled;
   reg                                                branch_taken_unkilled;
   wire                                               branch_taken;
   reg                                                dmem_en_unkilled;
   reg                                                dmem_wen_unkilled;
   reg                                                jal_unkilled;
   wire                                               jal;
   reg                                                jalr_unkilled;
   wire                                               jalr;
   reg                                                wr_reg_unkilled_DX;
   wire                                               wr_reg_DX;
   reg [`WB_SRC_SEL_WIDTH-1:0]                        wb_src_sel_DX;
   wire                                               new_ex_DX;
   wire                                               ex_DX;
   reg [`ECODE_WIDTH-1:0]                             ex_code_DX;
   wire                                               killed_DX;
   reg                                                uses_md_unkilled;
   wire                                               uses_md;
   reg                                                wfi_unkilled_DX;
   wire                                               wfi_DX;
   reg [`CSR_CMD_WIDTH-1:0]                           csr_cmd_unkilled;
   
   reg                                                wr_reg_unkilled_WB;
   reg                                                had_ex_WB;
   reg [`ECODE_WIDTH-1:0]                             prev_ex_code_WB;
   reg                                                store_in_WB;
   reg                                                dmem_en_WB;
   reg                                                prev_killed_WB;
   reg                                                uses_md_WB;
   reg                                                wfi_unkilled_WB;
   
   reg [`ECODE_WIDTH-1:0]                             ex_code_WB;
   wire                                               dmem_access_exception;
   wire                                               killed_WB;
   wire                                               load_in_WB;
   
   wire                                               load_use;
   reg                                                uses_rs1;
   reg                                                uses_rs2;
   wire                                               raw_rs1;
   wire                                               raw_rs2;
   wire                                               raw_on_busy_md;

// wire retire_WB;



   assign jump_DX = jal_unkilled || jalr_unkilled || branch_unkilled || eret_unkilled;



   reg r_redirect;
   always @(posedge clk)
   if(reset)
     r_redirect <= 1'b1;
   else if(redirect)
     r_redirect <= 1'b1;
   else if(~imem_wait)
     r_redirect <= 1'b0;

   wire   interrupt_kill_IF;
   assign replay_miss = (imem_miss && !redirect);
   assign replay_IF =  replay_miss || (r_redirect&&imem_wait);
   assign kill_IF = interrupt_kill_IF || stall_IF || ex_IF || ex_DX || exception_WB || interrupt_taken_WB || redirect || replay_IF;
   assign stall_IF = stall_DX || ((imem_wait  && !redirect) && !exception_WB && !interrupt_taken_WB) ;
   assign ex_IF = imem_badmem_e && !imem_wait && !redirect && !replay_IF;


   always @(posedge clk) begin
      if (reset) begin
         had_ex_DX <= 0;
         prev_killed_DX <= 0;
      end else if (!stall_DX) begin
         had_ex_DX <= ex_IF;
         prev_killed_DX <= kill_IF;
      end
   end

   wire dc_stall = dc_wr_stall && (
                                    (dmem_en_unkilled && ~dmem_wen_unkilled)
                                );

   assign kill_DX = stall_DX || ex_DX || exception_WB || interrupt_taken_WB;
   assign stall_DX =    stall_WB ||
                     (( // internal hazards
                        (dmem_wait&& dmem_en_unkilled) ||
                        dc_stall ||
                        load_use ||
                        raw_on_busy_md ||
                        (fence_i && store_in_WB) ||
                        (uses_md_unkilled && !md_req_ready)
                        ) && !(ex_DX || exception_WB || interrupt_taken_WB));
   assign new_ex_DX = ebreak || ecall || illegal_instruction || illegal_csr_access;
   assign ex_DX = had_ex_DX || new_ex_DX; // TODO: add causes
   assign killed_DX = prev_killed_DX || kill_DX;

   always @(*) begin
      ex_code_DX = `ECODE_INST_ADDR_MISALIGNED;
      if (had_ex_DX) begin
         ex_code_DX = `ECODE_INST_ADDR_MISALIGNED;
      end else if (illegal_instruction) begin
         ex_code_DX = `ECODE_ILLEGAL_INST;
      end else if (illegal_csr_access) begin
         ex_code_DX = `ECODE_ILLEGAL_INST;
      end else if (ebreak) begin
         ex_code_DX = `ECODE_BREAKPOINT;
      end else if (ecall) begin
         ex_code_DX = `ECODE_ECALL_FROM_U + prv;
      end
   end // always @ begin



 
   reg difference;

   always @(posedge clk)
   if(reset) begin
     difference <= 1'b0;
     retired_WB <= 1'b0;
   end else begin
     if (~stall_DX && ~kill_IF) begin
       difference <= 1'b1;
     end else if(~stall_WB) begin
       difference <= 1'b0;
     end
     if (difference) begin
       if (~stall_WB) begin
         retired_WB <= 1'b0;
       end else if(retire_WB) begin
         retired_WB <= 1'b1;
       end
     end else begin
       if (retire_WB) begin
         retired_WB <= 1'b1;
       end
     end
   end

   assign dmem_size = {1'b0,funct3[1:0]};
   assign dmem_type = funct3;

   always @(*) begin
      sel_ctm = 1'b0;
      lsu_type = `LSU_TYPE_NONE;
      illegal_instruction = 1'b0;
      csr_cmd_unkilled = `CSR_IDLE;
      csr_imm_sel = funct3[2];
      ecall = 1'b0;
      ebreak = 1'b0;
      eret_unkilled = 1'b0;
      dret_unkilled = 1'b0;
      fence_i = 1'b0;
      fence_line = 1'b0;
      fence_rwrw = 1'b0;
      fence_iorw = 1'b0;
      branch_unkilled = 1'b0;
      branch_taken_unkilled = 1'b0;
      jal_unkilled = 1'b0;
      jalr_unkilled = 1'b0;
      uses_rs1 = 1'b1;
      uses_rs2 = 1'b0;
      imm_type = `IMM_I;
      src_a_sel = `SRC_A_RS1;
      src_b_sel = `SRC_B_IMM;
      alu_op = `ALU_OP_ADD;
      dmem_en_unkilled = 1'b0;
      dmem_wen_unkilled = 1'b0;
      wr_reg_unkilled_DX = 1'b0;
      wb_src_sel_DX = `WB_SRC_ALU;
      uses_md_unkilled = 1'b0;
      wfi_unkilled_DX = 1'b0;
      case (opcode)
        `RV32_LOAD : begin
           dmem_en_unkilled = 1'b1;
           wr_reg_unkilled_DX = 1'b1;
           wb_src_sel_DX = `WB_SRC_MEM;
        end
        `RV32_STORE : begin
           uses_rs2 = 1'b1;
           imm_type = `IMM_S;
           dmem_en_unkilled = 1'b1;
           dmem_wen_unkilled = 1'b1;
        end
        `RV32_BRANCH : begin
           uses_rs2 = 1'b1;
           branch_unkilled = 1'b1;
           branch_taken_unkilled = cmp_true;
           src_b_sel = `SRC_B_RS2;
           case (funct3)
             `RV32_FUNCT3_BEQ : alu_op = `ALU_OP_SEQ;
             `RV32_FUNCT3_BNE : alu_op = `ALU_OP_SNE;
             `RV32_FUNCT3_BLT : alu_op = `ALU_OP_SLT;
             `RV32_FUNCT3_BLTU : alu_op = `ALU_OP_SLTU;
             `RV32_FUNCT3_BGE : alu_op = `ALU_OP_SGE;
             `RV32_FUNCT3_BGEU : alu_op = `ALU_OP_SGEU;
             default : illegal_instruction = 1'b1;
           endcase // case (funct3)
        end
        `RV32_JAL : begin
           jal_unkilled = 1'b1;
           uses_rs1 = 1'b0;
           src_a_sel = `SRC_A_PC;
           src_b_sel = `SRC_B_FOUR;
           wr_reg_unkilled_DX = 1'b1;
        end
        `RV32_JALR : begin
           illegal_instruction = (funct3 != 0);
           jalr_unkilled = 1'b1;
           src_a_sel = `SRC_A_PC;
           src_b_sel = `SRC_B_FOUR;
           wr_reg_unkilled_DX = 1'b1;
        end
        `RV32_MISC_MEM : begin // xxxxxxx_xxxxx_xxxxx_xxx_xxxxx_0001111 (7+5+5+3+5+7)
           case (funct3)
             `RV32_FUNCT3_FENCE : begin // xxxxxxx_xxxxx_xxxxx_000_xxxxx_0001111
                if ((inst_DX[31:28] == 0) && (rs1_addr == 0) && (reg_to_wr_DX == 0)) begin // 0000xxx_xxxxx_00000_000_00000_0001111
                  fence_rwrw = (inst_DX[27:20] == 8'h33); // 0000001_10011_00000_000_00000_0001111 (0x0330000F)
                  fence_iorw = (inst_DX[27:20] == 8'hFF); // 0000111_11111_00000_000_00000_0001111 (0x0FF0000F)
                  dmem_en_unkilled = 1'b1;
                end else if ((funct7 == 0) && (rs1_addr != 0)) begin // 0000000_xxxxx_xxxx1_000_xxxxx_0001111 (0x0000800F)
                  fence_line = 1'b1;
                  dmem_en_unkilled = 1'b1;
                end else
                  illegal_instruction = 1'b1;
             end
             `RV32_FUNCT3_FENCE_I : begin // xxxxxxx_xxxxx_xxxxx_001_xxxxx_0001111
                if ((inst_DX[31:20] == 0) && (rs1_addr == 0) && (reg_to_wr_DX == 0)) begin // 0000000_00000_00000_001_00000_0001111 (0x0000100F)
                  fence_i = 1'b1;
                end else
                  illegal_instruction = 1'b1;
             end
             default : illegal_instruction = 1'b1;
           endcase // case (funct3)
        end
        `RV32_OP_IMM : begin
           alu_op = alu_op_arith;
           wr_reg_unkilled_DX = 1'b1;
        end
        `RV32_OP  : begin
           uses_rs2 = 1'b1;
           src_b_sel = `SRC_B_RS2;
           alu_op = alu_op_arith;
           wr_reg_unkilled_DX = 1'b1;
           if (funct7 == `RV32_FUNCT7_MUL_DIV) begin
              uses_md_unkilled = 1'b1;
              wb_src_sel_DX = `WB_SRC_MD;
           end
        end
        `RV32_SYSTEM : begin
           wb_src_sel_DX = `WB_SRC_CSR;
           wr_reg_unkilled_DX = (funct3 != `RV32_FUNCT3_PRIV);
           case (funct3)
             `RV32_FUNCT3_PRIV : begin
                if ((rs1_addr == 0) && (reg_to_wr_DX == 0)) begin
                   case (funct12)
                     `RV32_FUNCT12_ECALL : ecall = 1'b1;
                     `RV32_FUNCT12_EBREAK : ebreak = 1'b1;
                     `RV32_FUNCT12_MRET,
                     `RV32_FUNCT12_ERET : begin
                        if (prv == 0)
                          illegal_instruction = 1'b1;
                        else 
                          eret_unkilled = 1'b1;
                     end
                     `RV32_FUNCT12_DRET : begin
                        if (prv == 0)
                          illegal_instruction = 1'b1;
                        else 
                          dret_unkilled = 1'b1;
                     end
         `RV32_FUNCT12_WFI : wfi_unkilled_DX = 1'b1;
                     default : illegal_instruction = 1'b1;
                   endcase // case (funct12)
                end // if ((rs1_addr == 0) && (reg_to_wr_DX == 0))
             end // case: `RV32_FUNCT3_PRIV
             `RV32_FUNCT3_CSRRW  : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_WRITE;
             `RV32_FUNCT3_CSRRS  : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_SET;
             `RV32_FUNCT3_CSRRC  : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_CLEAR;
             `RV32_FUNCT3_CSRRWI : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_WRITE;
             `RV32_FUNCT3_CSRRSI : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_SET;
             `RV32_FUNCT3_CSRRCI : csr_cmd_unkilled = (rs1_addr == 0) ? `CSR_READ : `CSR_CLEAR;
             default : illegal_instruction = 1'b1;
           endcase // case (funct3)
        end
        `RV32_AUIPC : begin
           uses_rs1 = 1'b0;
           src_a_sel = `SRC_A_PC;
           imm_type = `IMM_U;
           wr_reg_unkilled_DX = 1'b1;
        end
        `RV32_LUI : begin
           uses_rs1 = 1'b0;
           src_a_sel = `SRC_A_ZERO;
           imm_type = `IMM_U;
           wr_reg_unkilled_DX = 1'b1;
        end
        `RV32_CUSTOM_1 : begin
             if(funct3[2:0] == 3'b110) begin
               imm_type = `IMM_O;
               dmem_en_unkilled = 1'b1;
               wb_src_sel_DX = `LSU_MW;
               lsu_type = `LSU_TYPE_LDMARK;
             end else if(funct3[2:0] == 3'b010) begin
               imm_type = `IMM_O;
               dmem_en_unkilled = 1'b1;
               dmem_wen_unkilled = 1'b1;
               wb_src_sel_DX = `LSU_MW;
               lsu_type = `LSU_TYPE_STMARK;
             end else begin
               illegal_instruction = 1'b1;
             end
        end
        `RV32_CUSTOM_3 : begin
           sel_ctm = 1'b1;
             if(funct3[2:0] == 3'b100) begin
               alu_op = `CTM_OP_RNG;
               wr_reg_unkilled_DX = 1'b1;
               uses_rs1 = 1'b0;
             end else if(funct3[2:0] == 3'b110) begin
               alu_op = `CTM_OP_CLZ;
               wr_reg_unkilled_DX = 1'b1;
             end else begin
               illegal_instruction = 1'b1;
             end
        end
        default : begin
           illegal_instruction = 1'b1;
        end
      endcase // case (opcode)
   end // always @ (*)

   assign add_or_sub = ((opcode == `RV32_OP) && (funct7[5])) ? `ALU_OP_SUB : `ALU_OP_ADD;
   assign srl_or_sra = (funct7[5]) ? `ALU_OP_SRA : `ALU_OP_SRL;

   assign md_req_valid = uses_md;

   always @(*) begin
      md_req_op = `MD_OP_MUL;
      md_req_in_1_signed = 0;
      md_req_in_2_signed = 0;
      md_req_out_sel = `MD_OUT_LO;
      case (funct3)
        `RV32_FUNCT3_MUL : begin
        end
        `RV32_FUNCT3_MULH : begin
           md_req_in_1_signed = 1;
           md_req_in_2_signed = 1;
           md_req_out_sel = `MD_OUT_HI;
        end
        `RV32_FUNCT3_MULHSU : begin
           md_req_in_1_signed = 1;
           md_req_out_sel = `MD_OUT_HI;
        end
        `RV32_FUNCT3_MULHU : begin
           md_req_out_sel = `MD_OUT_HI;
        end
        `RV32_FUNCT3_DIV : begin
           md_req_op = `MD_OP_DIV;
           md_req_in_1_signed = 1;
           md_req_in_2_signed = 1;
        end
        `RV32_FUNCT3_DIVU : begin
           md_req_op = `MD_OP_DIV;
        end
        `RV32_FUNCT3_REM : begin
           md_req_op = `MD_OP_REM;
           md_req_in_1_signed = 1;
           md_req_in_2_signed = 1;
           md_req_out_sel = `MD_OUT_REM;
        end
        `RV32_FUNCT3_REMU : begin
           md_req_op = `MD_OP_REM;
           md_req_out_sel = `MD_OUT_REM;
        end
      endcase
   end

   always @(*) begin
      case (funct3)
        `RV32_FUNCT3_ADD_SUB : alu_op_arith = add_or_sub;
        `RV32_FUNCT3_SLL : alu_op_arith = `ALU_OP_SLL;
        `RV32_FUNCT3_SLT : alu_op_arith = `ALU_OP_SLT;
        `RV32_FUNCT3_SLTU : alu_op_arith = `ALU_OP_SLTU;
        `RV32_FUNCT3_XOR : alu_op_arith = `ALU_OP_XOR;
        `RV32_FUNCT3_SRA_SRL : alu_op_arith = srl_or_sra;
        `RV32_FUNCT3_OR : alu_op_arith = `ALU_OP_OR;
        `RV32_FUNCT3_AND : alu_op_arith = `ALU_OP_AND;
        default : alu_op_arith = `ALU_OP_ADD;
      endcase // case (funct3)
   end // always @ begin

   assign branch_taken = branch_taken_unkilled && !kill_DX;
   assign jal = jal_unkilled && !kill_DX;
   assign jalr = jalr_unkilled && !kill_DX;
   assign eret = eret_unkilled && !kill_DX;
   assign dret = dret_unkilled && !kill_DX;
   assign dmem_en = dmem_en_unkilled && !kill_DX && ~step_int_en;
   assign dmem_wen = dmem_wen_unkilled && !kill_DX;
   assign wr_reg_DX = wr_reg_unkilled_DX && !kill_DX;
   assign uses_md = uses_md_unkilled && !kill_DX;
   assign wfi_DX = wfi_unkilled_DX && !kill_DX;
   assign csr_cmd = csr_cmd_unkilled;
   assign redirect = branch_taken || jal || jalr || eret || dret || exception_WB || interrupt_taken_WB;

   reg dret_t;

   always@(posedge clk) 
   if(reset)
    dret_t <= 1'b0;
   else if(dret)
    dret_t <= 1'b1;
   else if(dret_t & dpc_hit)
    dret_t <= 1'b0;

   reg eret_t;

   always@(posedge clk) 
   if(reset)
    eret_t <= 1'b0;
   else if(eret)
    eret_t <= 1'b1;
   else if(eret_t & epc_hit)
    eret_t <= 1'b0;

   assign int_return = eret_t & epc_hit;
   assign dbg_return = dret_t & dpc_hit;

   always @(posedge clk)
   if(reset)
     step_DX_done <= 1'b0 ;
   else if(interrupt_taken_WB)
     step_DX_done <= 1'b0 ;
   else if((debug && dpc_hit || ~debug) && ~stall_DX && ~kill_IF)
     step_DX_done <= 1'b1 ;

   wire cause_is_break;

   wire int_hit;
   reg  t_interrupt_mask;
   always@(posedge clk) 
   if(reset)
      t_interrupt_mask <= 1'b0;
   else if(interrupt_taken_ext_WB||(exception_WB&&~cause_is_break))
      t_interrupt_mask <= 1'b1;
   else if(intmask_set)
      t_interrupt_mask <= 1'b1;
   else if(intmask_clr)
      t_interrupt_mask <= 1'b0;
   else if(int_return)
      t_interrupt_mask <= ~mstatus_mip;

   always@(posedge clk) 
   if(reset)
      mstatus_mip <= 1'b0;
   else if(interrupt_taken_ext_WB||(exception_WB&&~cause_is_break))
      mstatus_mip <= ~t_interrupt_mask;
   else if(mstatus_mip_clr)
      mstatus_mip <= 1'b0;
   else if(mstatus_mip_set)
      mstatus_mip <= 1'b1;

   assign interrupt_mask = t_interrupt_mask && ~int_return;
   assign interrupt_kill_IF  = interrupt_taken_WB && ~interrupt_mask;



   assign int_hit    = handler_hit | dbg_hit ;



   assign cause_is_break = (exception_code_WB == `ECODE_BREAKPOINT) ;

   always @(*) begin
      if (exception_WB||interrupt_taken_WB) begin
         PC_src_sel =
                      debug                  ? `PC_DBG_E   :
                      cause_is_break         ? `PC_DBG     :
                      interrupt_taken_stp_WB ? `PC_DBG     :
                      interrupt_taken_irq_WB ? `PC_DBG     :
                                               `PC_HANDLER ;
      end else if (replay_IF || (stall_IF && !imem_wait)) begin
         PC_src_sel = `PC_REPLAY;
      end else if (eret) begin
         PC_src_sel = `PC_EPC;
      end else if (dret) begin
         PC_src_sel = `PC_DPC;
      end else if (branch_taken) begin
         PC_src_sel = `PC_BRANCH_TARGET;
      end else if (jal) begin
         PC_src_sel = `PC_JAL_TARGET;
      end else if (jalr) begin
         PC_src_sel = `PC_JALR_TARGET;
      end else if (replay_miss) begin
         PC_src_sel = `PC_REPLAY;
      end else begin
         PC_src_sel = `PC_PLUS_FOUR;
      end
   end // always @ begin


   always @(posedge clk) begin
      if (reset) begin
         prev_killed_WB <= 0;
         had_ex_WB <= 0;
         wr_reg_unkilled_WB <= 0;
         store_in_WB <= 0;
         dmem_en_WB <= 0;
         uses_md_WB <= 0;
         wfi_unkilled_WB <= 0;
      end else if (!stall_WB) begin
         prev_killed_WB <= killed_DX;
         had_ex_WB <= ex_DX;
         wr_reg_unkilled_WB <= wr_reg_DX;
         wb_src_sel_WB <= wb_src_sel_DX;
         prev_ex_code_WB <= ex_code_DX;
         reg_to_wr_WB <= reg_to_wr_DX;
         store_in_WB <= dmem_wen;
         dmem_en_WB <= dmem_en;
         uses_md_WB <= uses_md;
         wfi_unkilled_WB <= wfi_DX;
      end
   end

   assign active_wfi_WB = !prev_killed_WB && wfi_unkilled_WB;


   assign kill_WB = stall_WB || exception_WB || interrupt_taken_WB;

   assign stall_WB = ((dmem_wait&& dmem_en_WB) || (uses_md_WB && !md_resp_valid) || active_wfi_WB ) && !exception_WB && !interrupt_taken_WB;
   assign dmem_access_exception = dmem_badmem_e;
`ifdef RV_TRACE
   reg stk_int_r;
   always @(posedge clk)
   if (reset)
     stk_int_r <= 0;
   else
     stk_int_r <= trace_int;
   assign exception_WB = had_ex_WB || dmem_access_exception || (trace_int&~stk_int_r);
`else
   assign exception_WB = had_ex_WB || dmem_access_exception ;
`endif
   assign killed_WB = prev_killed_WB || kill_WB;

   always @(*) begin
      ex_code_WB = prev_ex_code_WB;
      if (!had_ex_WB) begin
`ifdef RV_TRACE
         if (trace_int)
            ex_code_WB = `ECODE_STACK_OVERFLOW ;
         else
`endif
         if (dmem_access_exception) begin
            ex_code_WB = wr_reg_unkilled_WB ?
                         `ECODE_LOAD_ADDR_MISALIGNED :
                         `ECODE_STORE_AMO_ADDR_MISALIGNED;
         end
      end
   end

   assign exception_code_WB = ex_code_WB;
   assign wr_reg_WB = wr_reg_unkilled_WB && !kill_WB;
   assign retire_WB = !(kill_WB || killed_WB);


   assign load_in_WB = dmem_en_WB && !store_in_WB;


   assign raw_rs1 = (reg_wen && (reg_ra1 == reg_wa)) && (reg_ra1 != 0) && uses_rs1 ;
   assign raw_rs2 = (reg_wen && (reg_ra2 == reg_wa)) && (reg_ra2 != 0) && uses_rs2 ;
   assign raw_rs3 = (reg_wen && (reg_ra3 == reg_wa)) && (reg_ra3 != 0) && uses_rs3 ;

   assign bypass_rs1 = !load_in_WB && raw_rs1;
   assign bypass_rs2 = !load_in_WB && raw_rs2;
   assign bypass_rs3 = !load_in_WB && raw_rs3;

   assign raw_on_busy_md = uses_md_WB && (raw_rs1 || raw_rs2) && !md_resp_valid;
   assign load_use = load_in_WB && (raw_rs1 || raw_rs2 || raw_rs3);

endmodule // sisc32_ctrl

