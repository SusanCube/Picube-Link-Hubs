`include "tpgs_sisc32_core_params.v"

module	tpgs_sisc32_regfile(
`ifdef RV_TRACE
                      input                        ras_keep,
                      input                        pc_push,
                      input                        pc_pop ,
                      output     [31:0]            sp_reg0,
                      output reg [12:0][31:0]      ras    ,
                      input      [31:0]            PC_WB  ,
`endif
                      input                        pre_int,
                      input                        spr_en,
                      input                        spr_sync_sp,
                      input                        spr_sync_all,
                      input                        reset,
                      input                        clk,
                      input  [`REG_ADDR_WIDTH-1:0] ra1,
                      output [`RV_XLEN-1:0]        rd1,
                      input  [`REG_ADDR_WIDTH-1:0] ra2,
                      output [`RV_XLEN-1:0]        rd2,
                      input  [`REG_ADDR_WIDTH-1:0] ra3,
                      output [`RV_XLEN-1:0]        rd3,
                      input                        wen,
                      input  [1:0]                 bwen,
                      input  [`REG_ADDR_WIDTH-1:0] wa,
                      input  [`RV_XLEN-1:0]        wd,
                      output [`RV_XLEN*16-1:0]     mon
                      );


   reg [`RV_XLEN-1:0]                             data [31:0];
   wire                                           wen_internal;

   assign wen_internal = wen && |wa;


   assign rd1 = |ra1 ? (data[ra1]) : 0 ;
   assign rd2 = |ra2 ? (data[ra2]) : 0 ;
   assign rd3 = |ra3 ? (data[ra3]) : 0 ;

`ifdef RV_TRACE
   assign sp_reg0 = data[2];

   always @(posedge clk or posedge reset)
   if (reset)
     ras[0] <= 32'h00;
   else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
     ras[0] <= wd ;
   else if (~ras_keep && pc_pop)
     ras[0] <= ras[1];

   always @(posedge clk or posedge reset)
   if (reset)
     ras[12] <= 32'h00;
   else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
     ras[12] <= ras[11] ;
   else if (~ras_keep && pc_pop)
     ras[12] <= 32'h00;

generate 
for (genvar i=1; i<12; i++) begin
   always @(posedge clk or posedge reset)
   if (reset)
     ras[i] <= 32'h00;
   else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
     ras[i] <= ras[i-1];
   else if (~ras_keep && pc_pop)
     ras[i] <= ras[i+1];
end
endgenerate
`endif

   always @(posedge clk or posedge reset) begin
      if (reset) begin
        data[0] <= 32'h00;
        data[1] <= 32'h00;
        data[2] <= 32'h00;
        data[3] <= 32'h00;
        data[4] <= 32'h00;
        data[5] <= 32'h00;
        data[6] <= 32'h00;
        data[7] <= 32'h00;
        data[8] <= 32'h00;
        data[9] <= 32'h00;
        data[10] <= 32'h00;
        data[11] <= 32'h00;
        data[12] <= 32'h00;
        data[13] <= 32'h00;
        data[14] <= 32'h00;
        data[15] <= 32'h00;
        data[16] <= 32'h00;
        data[17] <= 32'h00;
        data[18] <= 32'h00;
        data[19] <= 32'h00;
        data[20] <= 32'h00;
        data[21] <= 32'h00;
        data[22] <= 32'h00;
        data[23] <= 32'h00;
        data[24] <= 32'h00;
        data[25] <= 32'h00;
        data[26] <= 32'h00;
        data[27] <= 32'h00;
        data[28] <= 32'h00;
        data[29] <= 32'h00;
        data[30] <= 32'h00;
        data[31] <= 32'h00;
      end else if (wen_internal) begin 
        data[wa][15: 0] <= bwen[0] ? wd[15: 0] : data[wa][15: 0];
        data[wa][31:16] <= bwen[1] ? wd[31:16] : data[wa][31:16];
      end 
   end


   assign mon = { {`RV_XLEN{1'b0}},
                  data[15][`RV_XLEN-1:0],
                  data[14][`RV_XLEN-1:0],
                  data[13][`RV_XLEN-1:0],
                  data[12][`RV_XLEN-1:0],
                  data[11][`RV_XLEN-1:0],
                  data[10][`RV_XLEN-1:0],
                  data[ 9][`RV_XLEN-1:0],
                  data[ 8][`RV_XLEN-1:0],
                  data[ 7][`RV_XLEN-1:0],
                  data[ 6][`RV_XLEN-1:0],
                  data[ 5][`RV_XLEN-1:0],
                  data[ 4][`RV_XLEN-1:0],
                  data[ 3][`RV_XLEN-1:0],
                  data[ 2][`RV_XLEN-1:0],
                  data[ 1][`RV_XLEN-1:0]
   };


`ifdef CPU_DEBUG
reg [31:0] reg_name [31:0];
initial begin
  reg_name[00] = "zero" ;
  reg_name[01] = "ra"   ;
  reg_name[02] = "sp"   ;
  reg_name[03] = "gp"   ;
  reg_name[04] = "tp"   ;
  reg_name[05] = "t0"   ;
  reg_name[06] = "t1"   ;
  reg_name[07] = "t2"   ;
  reg_name[08] = "s0"   ;
  reg_name[09] = "s1"   ;
  reg_name[10] = "a0"   ;
  reg_name[11] = "a1"   ;
  reg_name[12] = "a2"   ;
  reg_name[13] = "a3"   ;
  reg_name[14] = "a4"   ;
  reg_name[15] = "a5"   ;
  reg_name[16] = "a6"   ;
  reg_name[17] = "a7"   ;
  reg_name[18] = "s2"   ;
  reg_name[19] = "s3"   ;
  reg_name[20] = "s4"   ;
  reg_name[21] = "s5"   ;
  reg_name[22] = "s6"   ;
  reg_name[23] = "s7"   ;
  reg_name[24] = "s8"   ;
  reg_name[25] = "s9"   ;
  reg_name[26] = "s10"  ;
  reg_name[27] = "s11"  ;
  reg_name[28] = "t3"   ;
  reg_name[29] = "t4"   ;
  reg_name[30] = "t5"   ;
  reg_name[31] = "t6"   ;
end
`endif


wire [31:0] data00     = data[00];
wire [31:0] data01_ra  = data[01];
wire [31:0] data02_sp  = data[02];
wire [31:0] data03_gp  = data[03];
wire [31:0] data04_tp  = data[04];
wire [31:0] data05_t0  = data[05];
wire [31:0] data06_t1  = data[06];
wire [31:0] data07_t2  = data[07];
wire [31:0] data08_s0  = data[08];
wire [31:0] data09_s1  = data[09];
wire [31:0] data10_a0  = data[10];
wire [31:0] data11_a1  = data[11];
wire [31:0] data12_a2  = data[12];
wire [31:0] data13_a3  = data[13];
wire [31:0] data14_a4  = data[14];
wire [31:0] data15_a5  = data[15];
wire [31:0] data16_a6  = data[16];
wire [31:0] data17_a7  = data[17];
wire [31:0] data18_s2  = data[18];
wire [31:0] data19_s3  = data[19];
wire [31:0] data20_s4  = data[20];
wire [31:0] data21_s5  = data[21];
wire [31:0] data22_s6  = data[22];
wire [31:0] data23_s7  = data[23];
wire [31:0] data24_s8  = data[24];
wire [31:0] data25_s9  = data[25];
wire [31:0] data26_s10 = data[26];
wire [31:0] data27_s11 = data[27];
wire [31:0] data28_t3  = data[28];
wire [31:0] data29_t4  = data[29];
wire [31:0] data30_t5  = data[30];
wire [31:0] data31_t6  = data[31];

endmodule // sisc32_regfile
