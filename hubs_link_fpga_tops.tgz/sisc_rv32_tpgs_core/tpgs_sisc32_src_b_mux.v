`include	"tpgs_sisc32_core_params.v"
module	tpgs_sisc32_src_b_mux(
                        input DX_is_compress,
                        input [`SRC_B_SEL_WIDTH-1:0] src_b_sel,
                        input [`RV_XLEN-1:0]         imm,
                        input [`RV_XLEN-1:0]         rs2_data,
                        output reg [`RV_XLEN-1:0]    alu_src_b
                        );


   always @(*) begin
      case (src_b_sel)
        `SRC_B_RS2 : alu_src_b = rs2_data;
        `SRC_B_IMM : alu_src_b = imm;
        `SRC_B_FOUR : alu_src_b = DX_is_compress ? 2 : 4;
        default : alu_src_b = 0;
      endcase // case (src_b_sel)
   end

endmodule // sisc32_src_b_mux
