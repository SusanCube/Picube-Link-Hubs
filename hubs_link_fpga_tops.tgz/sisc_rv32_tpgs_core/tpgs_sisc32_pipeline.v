`include "tpgs_sisc32_core_params.v"

module	tpgs_sisc32_pipeline #(
  parameter PC_SIZE = 32,
  parameter HART_NUM = 1
) (
`ifdef RV_TRACE
                       output [63:0]                 cycle,
                       output reg [31:0]             inst_WB,
                       input                         trace_int,
                       output [31:0]                 pc_reg0,
                       output [31:0]                 sp_reg0,
                       output [12:0][31:0]           ras,
`endif
                       output [31:0][31:0]           mmpu,
                       output [31:0]                 mrac,
                       input                         dc_wr_stall,
                       output                        fence_iorw,
                       output                        fence_line,
                       output                        fence_rwrw,
                       input                         cacheable,
                       output                        fence_i,
                       output                        redirect,

                       output [`INST_WIDTH-1:0]      inst_DX,

                       input                         clk,
                       input [`N_EXT_INTS-1:0]       ext_interrupts, 
                       input                         reset,
                       input                         imem_miss,
                       input                         imem_wait,
                       output [`RV_XLEN-1:0]         imem_addr,
                       input [`RV_XLEN-1:0]          imem_rdata,
                       input                         imem_badmem_e,
                       input                         dmem_wait,
                       output                        dmem_en,
                       output                        dmem_wen,
                       output [`MEM_TYPE_WIDTH-1:0]  dmem_size,
                       output [`RV_XLEN-1:0]         dmem_addr,
                       output [`RV_XLEN-1:0]         dmem_wdata_delayed,
                       output [`RV_XLEN-1:0]         dmem_wdata,
                       input [`RV_XLEN-1:0]          dmem_rdata,
                       input                         dmem_badmem_e,
                       input                         dbg_ndreset,
                       input                         dbg_fullreset,
                       input [HART_NUM-1:0]          dbg_irq      ,
                       output                        debug         
                       );

   wire [`LSU_TYPE_WIDTH-1:0]   lsu_type               ;
   wire [`RV_XLEN-1:0]          lsu_reg_rdata          ;

   function [`RV_XLEN-1:0] store_data;
      input [`RV_XLEN-1:0]                          addr;
      input [`RV_XLEN-1:0]                          data;
      input [`MEM_TYPE_WIDTH-1:0]                   mem_type;
      begin
         case (mem_type)
           `MEM_TYPE_SB : store_data = {4{data[7:0]}};
           `MEM_TYPE_SH : store_data = {2{data[15:0]}};
           default : store_data = data;
         endcase // case (mem_type)
      end
   endfunction // case

   function [`RV_XLEN-1:0] load_data;
      input [`RV_XLEN-1:0]                      addr;
      input [`RV_XLEN-1:0]                      data;
      input [`MEM_TYPE_WIDTH-1:0]               mem_type;
      reg [`RV_XLEN-1:0]                        shifted_data;
      reg [`RV_XLEN-1:0]                        b_extend;
      reg [`RV_XLEN-1:0]                        h_extend;
      begin
         shifted_data = data >> {addr[1:0],3'b0};
         b_extend = {{24{shifted_data[7]}},8'b0};
         h_extend = {{16{shifted_data[15]}},16'b0};
         case (mem_type)
           `MEM_TYPE_LB : load_data = (shifted_data & `RV_XLEN'hff) | b_extend;
           `MEM_TYPE_LH : load_data = (shifted_data & `RV_XLEN'hffff) | h_extend;
           `MEM_TYPE_LBU : load_data = (shifted_data & `RV_XLEN'hff);
           `MEM_TYPE_LHU : load_data = (shifted_data & `RV_XLEN'hffff);
           default : load_data = shifted_data;
         endcase // case (mem_type)
      end
   endfunction // case

   wire [`PC_SRC_SEL_WIDTH-1:0]                 PC_src_sel;
   wire [`RV_XLEN-1:0]                          PC_PIF;


   reg [`RV_XLEN-1:0]                           PC_IF;

   wire                                         kill_IF;
   wire                                         stall_IF;


   reg [`RV_XLEN-1:0]                           PC_DX;

   wire                                         kill_DX;
   wire                                         stall_DX;
   wire [`IMM_TYPE_WIDTH-1:0]                   imm_type;
   wire [`RV_XLEN-1:0]                          imm;
   wire [`SRC_A_SEL_WIDTH-1:0]                  src_a_sel;
   wire [`SRC_B_SEL_WIDTH-1:0]                  src_b_sel;
   wire [`REG_ADDR_WIDTH-1:0]                   rs1_addr;
   wire [`REG_ADDR_WIDTH-1:0]                   rs2_addr;
   wire [`ALU_OP_WIDTH-1:0]                     alu_op;
   wire [`RV_XLEN-1:0]                          alu_src_a;
   wire [`RV_XLEN-1:0]                          alu_src_b;
   wire [`RV_XLEN-1:0]                          org_out;
   wire [`RV_XLEN-1:0]                          alu_out;
   wire [`RV_XLEN-1:0]                          ctm_out;
   wire                                         sel_ctm;
   wire                                         cmp_true;
   wire                                         bypass_rs1;
   wire                                         bypass_rs2;
   wire [`MEM_TYPE_WIDTH-1:0]                   dmem_type;

   wire                                         md_req_valid;
   wire                                         md_req_ready;
   wire                                         md_req_in_1_signed;
   wire                                         md_req_in_2_signed;
   wire [`MD_OUT_SEL_WIDTH-1:0]                 md_req_out_sel;
   wire [`MD_OP_WIDTH-1:0]                      md_req_op;
   wire                                         md_resp_valid;
   wire [`RV_XLEN-1:0]                          md_resp_result;

   reg [`RV_XLEN-1:0]                           PC_WB;
   reg [`RV_XLEN-1:0]                           alu_out_WB;
   reg [`RV_XLEN-1:0]                           csr_rdata_WB;
   reg [`RV_XLEN-1:0]                           store_data_WB;

   wire                                         kill_WB;
   wire                                         stall_WB;
   reg [`RV_XLEN-1:0]                           bypass_data_WB;
   wire [`RV_XLEN-1:0]                          load_data_WB;
   reg [`RV_XLEN-1:0]                           wb_data_WB;
   wire [`REG_ADDR_WIDTH-1:0]                   reg_to_wr_WB;
   wire                                         wr_reg_WB;
   wire [`WB_SRC_SEL_WIDTH-1:0]                 wb_src_sel_WB;
   reg [`MEM_TYPE_WIDTH-1:0]                    dmem_type_WB;

   wire [`CSR_ADDR_WIDTH-1:0]                   csr_addr;
   wire [`CSR_CMD_WIDTH-1:0]                    csr_cmd;
   wire                                         csr_imm_sel;
   wire [`PRV_WIDTH-1:0]                        prv;
   wire                                         illegal_csr_access;
   wire [`RV_XLEN-1:0]                          csr_wdata;
   wire [`RV_XLEN-1:0]                          csr_rdata;
   wire                                         exception_WB;
   wire [`ECODE_WIDTH-1:0]                      exception_code_WB;
   wire [`RV_XLEN-1:0]                          handler_PC;
   wire [`RV_XLEN-1:0]                          handler_PCR;
   wire                                         eret;
   wire [`RV_XLEN-1:0]                          epc;
   wire [`RV_XLEN-1:0]                          dpc;

   reg pc_push_WB;
   reg pc_pop_WB;

   wire          uses_rs3;
   wire jump_DX;
   reg  jump_FLAG;
   reg  jump_WB;
   reg  kill_IF_NOP;

   wire dpc_hit;
   wire epc_hit;
   wire dbg_hit_IF;
   wire handler_hit_IF;
   reg  dbg_hit;
   reg  handler_hit;

  ////////////////////////////////////////
  // Defination of signal
  ////////////////////////////////////////


  // signal connect with gpr
   wire        gpr_wen      ;
   wire [ 1:0] gpr_bwen     ;
   wire [ 4:0] gpr_ra1      ;
   wire [ 4:0] gpr_ra2      ;
   wire [ 4:0] gpr_ra3      ;
   wire [ 4:0] gpr_wa       ;
   wire [31:0] gpr_wd       ;
   wire [31:0] gpr_rd1      ;
   wire [31:0] gpr_rd2      ;
   wire [31:0] gpr_rd3      ;


  // signal connect lsu and gpr
   wire [31:0] lsu_gpr_rd3  ;


  // signal bypass to gpr
   wire [31:0] gpr_rd1_bypassed ;
   wire [31:0] gpr_rd2_bypassed ;
   wire [31:0] gpr_rd3_bypassed ;
   wire [31:0] bypass_gpr       ;
   wire        bypass_rs3       ;

   wire        b_gpr_wen    ;
   wire [ 4:0] b_gpr_wa     ;
   wire [31:0] b_gpr_wd     ;


  ////////////////////////////////////////


   wire fence_i_DX;
   assign fence_i = fence_i_DX && ~dmem_wait;

   wire fence_line_DX;
   wire fence_rwrw_DX;
   wire fence_iorw_DX;
   assign fence_line = dmem_en && fence_line_DX;
   assign fence_rwrw = dmem_en && fence_rwrw_DX;
   assign fence_iorw = dmem_en && fence_iorw_DX;

   tpgs_sisc32_ctrl ctrl(
`ifdef RV_TRACE
                    .trace_int(trace_int),
`endif
                    .retire_WB(retire_WB),
                    .sel_ctm(sel_ctm),
                    .dc_wr_stall(dc_wr_stall),
                    .fence_line(fence_line_DX),
                    .fence_rwrw(fence_rwrw_DX),
                    .fence_iorw(fence_iorw_DX),
                    .step_int_en(step_int_en),
                    .step_DX_done(step_DX_done),
                    .cacheable(cacheable),
                    .int_return  ( int_return   ),
                    .dbg_return  ( dbg_return   ),
                    .mstatus_mip(mstatus_mip),
                    .mstatus_mip_set(mstatus_mip_set),
                    .mstatus_mip_clr(mstatus_mip_clr),
                    .intmask_set(intmask_set),
                    .intmask_clr(intmask_clr),
                    .lsu_type( lsu_type),
                    .jump_DX(jump_DX),
                    .clk(clk),
                    .reset(reset),
                    .inst_DX(inst_DX),
                    .imem_miss(imem_miss),
                    .imem_wait(imem_wait),
                    .imem_badmem_e(imem_badmem_e),
                    .dmem_wait(dmem_wait),
                    .dmem_badmem_e(dmem_badmem_e),
                    .cmp_true(cmp_true),
                    .PC_src_sel(PC_src_sel),
                    .imm_type(imm_type),
                    .src_a_sel(src_a_sel),
                    .src_b_sel(src_b_sel),
                    .bypass_rs1(bypass_rs1),
                    .bypass_rs2(bypass_rs2),
                    .bypass_rs3(bypass_rs3),
                    .alu_op(alu_op),
                    .dmem_en(dmem_en),
                    .dmem_wen(dmem_wen),
                    .dmem_size(dmem_size),
                    .dmem_type(dmem_type),
                    .md_req_valid(md_req_valid),
                    .md_req_ready(md_req_ready),
                    .md_req_op(md_req_op),
                    .md_req_in_1_signed(md_req_in_1_signed),
                    .md_req_in_2_signed(md_req_in_2_signed),
                    .md_req_out_sel(md_req_out_sel),
                    .md_resp_valid(md_resp_valid),
                    .wr_reg_WB(wr_reg_WB),
                    .reg_to_wr_WB(reg_to_wr_WB),
                    .wb_src_sel_WB(wb_src_sel_WB),
                    .fence_i(fence_i_DX),
                    .redirect(redirect),
                    .stall_IF(stall_IF),
                    .kill_IF(kill_IF),
                    .stall_DX(stall_DX),
                    .kill_DX(kill_DX),
                    .stall_WB(stall_WB),
                    .kill_WB(kill_WB),
                    .exception_WB(exception_WB),
                    .exception_code_WB(exception_code_WB),
                    .retired_WB(retired_WB),
                    .csr_cmd(csr_cmd),
                    .csr_imm_sel(csr_imm_sel),
                    .illegal_csr_access(illegal_csr_access),
                    .reg_ra1 ( gpr_ra1  ),
                    .reg_ra2 ( gpr_ra2  ),
                    .reg_ra3 ( gpr_ra3  ),
                    .reg_wa  ( b_gpr_wa  ),
                    .reg_wen ( b_gpr_wen ),
                    .uses_rs3 ( uses_rs3  ),

                    .interrupt_taken_WB(interrupt_taken_WB),
                    .interrupt_mask(interrupt_mask),
                    .interrupt_taken_ext_WB(interrupt_taken_ext_WB),
                    .interrupt_taken_irq_WB(interrupt_taken_irq_WB),
                    .interrupt_taken_stp_WB(interrupt_taken_stp_WB),
                    .active_wfi_WB(active_wfi_WB),

                    .prv(prv),
                    .eret(eret),
                    .debug(debug),
                    .handler_hit(handler_hit),
                    .dbg_hit(dbg_hit),
                    .dpc_hit(dpc_hit),
                    .epc_hit(epc_hit)
                    );

   wire IF_is_compress;
   wire w_IF_is_compress;
   reg  r_IF_is_compress;
   assign IF_is_compress = imem_wait ? r_IF_is_compress : w_IF_is_compress;
   always @(posedge clk or posedge reset)
   if(reset)
     r_IF_is_compress <= 1'b0;
   else if(~imem_wait)
     r_IF_is_compress <= w_IF_is_compress;

   tpgs_sisc32_PC_mux PCmux(
                       .IF_is_compress(IF_is_compress),
                       .PC_src_sel(PC_src_sel),
                       .inst_DX(inst_DX),
                       .rs1_data(gpr_rd1_bypassed),
                       .PC_IF(PC_IF),
                       .PC_DX(PC_DX),
                       .handler_PC(handler_PC),
                       .epc(epc),
                       .dpc(dpc),
                       .PC_PIF(PC_PIF)
                       );

   assign dpc_hit = (dpc == PC_DX);
   assign epc_hit = (epc == PC_DX);
   assign dbg_hit_IF = (`CUSTOM_DBG_PC == PC_IF);
   assign handler_hit_IF = (handler_PCR== PC_IF);

   assign imem_addr = {PC_PIF[31:1], 1'b0};

   reg DX_is_compress;
   always @(posedge clk) begin
      if (reset) begin
         PC_IF <= `CUSTOM_INIT_PC;
      end else if (~stall_IF) begin
         PC_IF <= PC_PIF;
      end else begin
      end
   end

   reg WB_is_compress;

   reg  [`INST_WIDTH-1:0] IB;
   reg  [`INST_WIDTH-1:0] imem_rdata_ff;

   wire [15:0] i16;
   wire [31:0] i32;
   tpgs_cdec u_cdec( 
	   .din(i16), 
	   .dout(i32), 
	   .legal() );

   assign  w_IF_is_compress = (i16[1:0] != 2'b11);
   assign  i16 = imem_rdata[15:0];
   assign inst_DX = kill_IF_NOP ? `RV_NOP : IB;

   always @(posedge clk) begin
      if (reset) begin
         IB <= `RV_NOP;
         DX_is_compress <= 0;
      end else if (~stall_DX) begin
         if (kill_IF) begin
         end else begin
            IB <= IF_is_compress ? i32 : imem_rdata;
            DX_is_compress <= IF_is_compress;
         end
      end
   end


   always @(posedge clk)
   if(reset)
     jump_FLAG <= 1'b0;
   else if(~stall_DX && ~kill_IF)
     jump_FLAG <= 1'b0;
   else if(jump_DX)
     jump_FLAG <= 1'b1;

   always @(posedge clk) begin
      if (reset) begin
         dbg_hit <= 0;
         handler_hit <= 0;
         PC_DX <= 0;
         kill_IF_NOP <= 1'b0;
      end else if (~stall_DX) begin
         if (kill_IF) begin
            kill_IF_NOP <= 1'b1;
         end else begin
            dbg_hit <= dbg_hit_IF;
            handler_hit <= handler_hit_IF;
            PC_DX <= PC_IF;
            kill_IF_NOP <= 1'b0;
         end
      end
   end // always @ (posedge hclk)

   assign rs1_addr = inst_DX[19:15];
   assign rs2_addr = inst_DX[24:20];

  ////////////////////////////////////////
  // Connection of signal
  ////////////////////////////////////////

  // signal connect lsu and gpr
   assign      lsu_gpr_rd3  = gpr_rd3_bypassed;


  // signal bypass
   assign      uses_rs3 = 0;

   assign gpr_rd1_bypassed  = bypass_rs1     ? bypass_gpr : gpr_rd1;
   assign gpr_rd2_bypassed  = bypass_rs2     ? bypass_gpr : gpr_rd2;
   assign gpr_rd3_bypassed  = bypass_rs3     ? bypass_gpr : gpr_rd3;


  // signal route
   wire [1:0] reg_to_bwen = {2{wr_reg_WB}};


   assign b_gpr_wen  = wr_reg_WB   ;
   assign b_gpr_wa   = reg_to_wr_WB    ;
   assign b_gpr_wd   = wb_data_WB    ;


   assign lsu_reg_rdata = lsu_gpr_rd3 ;


   assign gpr_bwen = reg_to_bwen ;
   assign gpr_wen  = wr_reg_WB  ;
   assign gpr_wa   = reg_to_wr_WB   ;
   assign gpr_wd   = wb_data_WB   ;
   assign gpr_ra1  = rs1_addr  ;
   assign gpr_ra2  = rs2_addr  ;
   assign gpr_ra3  = 0  ;

   assign bypass_gpr = bypass_data_WB     ;


   wire  xxx_wen = gpr_wen;

   wire pc_push = pc_push_WB && retire_WB;
   wire pc_pop  = pc_pop_WB && retire_WB;
   tpgs_sisc32_regfile regfile(
`ifdef RV_TRACE
                          .ras_keep ( trace_int  ),
                          .pc_push ( pc_push  ),
                          .pc_pop  ( pc_pop   ),
                          .sp_reg0 ( sp_reg0  ),
                          .ras     ( ras      ),
                          .PC_WB   ( PC_WB    ),
`endif
                          .pre_int     ( 1'b0 ),
                          .spr_en      ( 1'b0 ),
                          .spr_sync_sp ( 1'b0 ),
                          .spr_sync_all( 1'b0 ),
                          .reset ( reset      ),
                          .clk ( clk      ),
                          .ra1 ( gpr_ra1  ),
                          .rd1 ( gpr_rd1  ),
                          .ra2 ( gpr_ra2  ),
                          .rd2 ( gpr_rd2  ),
                          .ra3 ( gpr_ra3  ),
                          .rd3 ( gpr_rd3  ),
                          .wen ( xxx_wen  ),
                          .bwen( gpr_bwen ),
                          .wa  ( gpr_wa   ),
                          .wd  ( gpr_wd   ),
                          .mon (          )
                          );


	tpgs_sisc32_imm_gen 	imm_gen(
		.inst						(inst_DX),
		.imm_type					(imm_type),
		.imm						(imm));

   	tpgs_sisc32_src_a_mux 	src_a_mux(
		.src_a_sel					(src_a_sel),
		.PC_DX						(PC_DX),
		.rs1_data					(gpr_rd1_bypassed),
		.alu_src_a					(alu_src_a)	);

   	tpgs_sisc32_src_b_mux 	src_b_mux(
		.DX_is_compress				(DX_is_compress),
		.src_b_sel					(src_b_sel),
		.imm						(imm),
		.rs2_data					(gpr_rd2_bypassed),
		.alu_src_b					(alu_src_b)	);

   assign alu_out = org_out;
   // CTM: custom OP is removed
// assign alu_out = sel_ctm ? ctm_out : org_out;

// sisc32_ctm ctm(
//                .clk(clk),
//                .reset(reset),
//                .op(alu_op),
//                .in1(alu_src_a),
//                .in2(alu_src_b),
//                .out(ctm_out)
//                );

(* keep_hierarchy = "yes" *)

	tpgs_sisc32_alu alu(
		.op							(alu_op),
		.in1						(alu_src_a),
		.in2						(alu_src_b),
		.out						(org_out));

    `ifdef MULDIV_EN
       `MULDIV md(
                     .clk(clk),
                     .reset(reset),
                     .req_valid(md_req_valid),
                     .req_ready(md_req_ready),
                     .req_in_1_signed(md_req_in_1_signed),
                     .req_in_2_signed(md_req_in_2_signed),
                     .req_out_sel(md_req_out_sel),
                     .req_op(md_req_op),
                     .req_in_1(gpr_rd1_bypassed),
                     .req_in_2(gpr_rd2_bypassed),
                     .resp_valid(md_resp_valid),
                     .resp_result(md_resp_result)
                     );
    `else // No hardware instr for MUL/DIV
      assign  md_req_ready  = 1'b1;
      assign  resp_valid    = 1'b1;
      assign  resp_result   = 32'b0;
    `endif

   assign cmp_true = alu_out[0];


   assign dmem_addr = alu_out;


   wire jump_DX_FLAG = jump_DX || jump_FLAG;
   always @(posedge clk or posedge reset) begin
      if (reset) begin
         pc_push_WB <= 0;
         pc_pop_WB  <= 0;
         WB_is_compress <= 1'b0;
         PC_WB <= 0;
         store_data_WB <= 0;
         alu_out_WB <= 0;
         jump_WB <= 0;
         csr_rdata_WB <= 0;
         dmem_type_WB <= 0;
      end else if (~stall_WB) begin
         pc_push_WB <= (IB[11:0]==12'h0e7) || (IB[11:0]==12'h0ef);
         pc_pop_WB  <= (IB==32'h8067);
         jump_WB <= jump_DX_FLAG;
         PC_WB <= PC_DX;
         WB_is_compress <= DX_is_compress;
         store_data_WB <= gpr_rd2_bypassed;
         alu_out_WB <= alu_out;
         csr_rdata_WB <= csr_rdata;
         dmem_type_WB <= dmem_type;
      end
   end

`ifdef PC_DUMP
   always @(posedge clk) if (~stall_DX && ~kill_IF)       $fdisplay(monitor.Debug_Handle,"CPU_DUMP PC_DX %t\t=> %08x", $time, PC_DX);
   always @(posedge clk) if (~stall_WB && (PC_WB!=PC_DX)) $fdisplay(monitor.Debug_Handle,"CPU_DUMP PC_WB %t\t=> %08x", $time, PC_WB);
`endif

   always @(*) begin
      case (wb_src_sel_WB)
        `WB_SRC_CSR : bypass_data_WB = csr_rdata_WB;
        `WB_SRC_MD : bypass_data_WB = md_resp_result;
        default : bypass_data_WB = alu_out_WB;
      endcase // case (wb_src_sel_WB)
   end

   assign load_data_WB = load_data(alu_out_WB,dmem_rdata,dmem_type_WB);

   always @(*) begin
      case (wb_src_sel_WB)
        `WB_SRC_ALU : wb_data_WB = bypass_data_WB;
        `WB_SRC_MEM : wb_data_WB = load_data_WB;
        `WB_SRC_CSR : wb_data_WB = bypass_data_WB;
        `WB_SRC_MD : wb_data_WB = bypass_data_WB;
        default : wb_data_WB = bypass_data_WB;
      endcase
   end

   assign dmem_wdata = store_data(alu_out,gpr_rd2_bypassed,dmem_type);
   assign dmem_wdata_delayed = store_data(alu_out_WB,store_data_WB,dmem_type_WB);

   assign csr_addr = inst_DX[31:20];
   assign csr_wdata = (csr_imm_sel) ? inst_DX[19:15] : gpr_rd1_bypassed;
(* keep_hierarchy = "yes" *)
   tpgs_sisc32_csr_file csr(
`ifdef RV_TRACE
                       .cycle(cycle),
`endif
//                       .mmpu(mmpu),
                       .mrac(mrac),
                       .mstatus_mip(mstatus_mip),
                       .mstatus_mip_set(mstatus_mip_set),
                       .mstatus_mip_clr(mstatus_mip_clr),
                       .intmask_set(intmask_set),
                       .intmask_clr(intmask_clr),
                       .step_DX_done(step_DX_done),
                       .step_int_en(step_int_en),
                       .WB_is_compress(WB_is_compress),
                       .int_return  ( int_return   ),
                       .dbg_return  ( dbg_return   ),
                       .handler_hit(handler_hit),
                       .kill_DX(kill_DX),
                       .stall_WB(stall_WB),
                       .clk(clk),
                       .ext_interrupts(ext_interrupts),
                       .reset(reset),
                       .addr(csr_addr),
                       .cmd(csr_cmd),
                       .wdata(csr_wdata),
                       .prv(prv),
                       .illegal_access(illegal_csr_access),
                       .rdata(csr_rdata),
                       .retired_WB(retired_WB),
                       .exception_WB(exception_WB),
                       .exception_code(exception_code_WB),
                       .PC_WB(PC_WB),
                       .jump_WB(jump_WB),
                       .dmem_en(dmem_en),
                       .PC_IF(PC_IF),
                       .dpc(dpc),
                       .eret(eret),
                       .debug(debug),
                       .interrupt_taken_WB(interrupt_taken_WB),
                       .interrupt_mask(interrupt_mask),
                       .interrupt_taken_ext_WB(interrupt_taken_ext_WB),
                       .interrupt_taken_irq_WB(interrupt_taken_irq_WB),
                       .interrupt_taken_stp_WB(interrupt_taken_stp_WB),
                       .active_wfi_WB(active_wfi_WB),
                       .dpc_hit(dpc_hit),
                       .dbg_hit(dbg_hit),
                       .dbg_irq(dbg_irq),
                       .dbg_ndreset(dbg_ndreset),
                       .dbg_fullreset(dbg_fullreset),
                       .handler_PC(handler_PC),
                       .handler_PCR(handler_PCR),
                       .epc(epc)
                       );

`ifdef RV_TRACE
   assign pc_reg0 = PC_WB;
   always @(posedge clk or posedge reset)
   if (reset)
      inst_WB <= 0;
   else if (~stall_WB)
      inst_WB <= IB;
`endif

endmodule // sisc32_pipeline
