//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2006-2009 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//------------------------------------------------------------------------------
//  Version and Release Control Information:
//
//  Checked In          :  2011-04-19 13:33:14 +0100 (Tue, 19 Apr 2011)
//
//  Revision            : 109495
//
//  Release Information : PL401-r0p1-00eac0
//------------------------------------------------------------------------------

// Standard Names
// ==============
`undef AHB_TRANS_IDLE
`undef AHB_TRANS_BUSY
`undef AHB_TRANS_NONSEQ
`undef AHB_TRANS_SEQ
//
`undef AHB_BURST_SINGLE
`undef AHB_BURST_INCR
`undef AHB_BURST_WRAP4
`undef AHB_BURST_INCR4
`undef AHB_BURST_WRAP8
`undef AHB_BURST_INCR8
`undef AHB_BURST_WRAP16
`undef AHB_BURST_INCR16
//
`undef AHB_RESP_OKAY
`undef AHB_RESP_ERROR
`undef AHB_RESP_RETRY
`undef AHB_RESP_SPLIT
//
`undef AHB_SIZE_8
`undef AHB_SIZE_16
`undef AHB_SIZE_32
`undef AHB_SIZE_64
`undef AHB_SIZE_128
`undef AHB_SIZE_256
`undef AHB_SIZE_512
`undef AHB_SIZE_1024


// Useful Aliases
// ==============
`undef AHB_TRANS_NSEQ
//
`undef AHB_RESP_OK
`undef AHB_RESP_ERR
//
`undef AHB_SIZE_BYTE
`undef AHB_SIZE_HALFWORD
`undef AHB_SIZE_HALF_WORD
`undef AHB_SIZE_WORD

