/*----author edward------*/
module	mgth_isde_link_wdma(
	input								ubus_isde_mgth_enab	,
	output	reg							ubus_isde_mgth_done	,

	input								ubus_isde_rxdi_vlid	,
	input		[255:0]					ubus_isde_rxdi_data	,
	
	input		[24: 0]					ubus_isde_ddrs_base	,
	input		[24: 0]					ubus_isde_ddrs_size	,
	input		[15: 0]					ubus_isde_meta_cols	,
	input		[15: 0]					ubus_isde_part_cols	,

	output								ubus_isde_wdma_csen	,
	output		[ 24: 0]				ubus_isde_wdma_addr	,
	output		[255: 0]				ubus_isde_wdma_data	,
	input								ubus_isde_wdma_trdy	,
	input								ubus_isde_wdma_wrdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	reg			[24: 0]					ubus_isde_rows_skip	;
	reg			[24: 0]					ubus_isde_rxdi_addr	;
	reg			[24: 0]					ubus_isde_push_cnts	;
	reg			[15: 0]					ubus_isde_page_cnts	;
	reg									ubus_isde_wdma_samp	;
	
	wire		[15: 0]					ubus_isde_page_inc1	;
	wire								ubus_isde_page_last	;
	wire		[ 9: 0]					ubus_isde_push_dptr	;	
	
	assign	ubus_isde_page_inc1	=		ubus_isde_page_cnts + 1		;
	assign	ubus_isde_page_last	=	&{	ubus_isde_rxdi_vlid	,	ubus_isde_page_inc1 == ubus_isde_part_cols	};
	assign	ubus_isde_push_dptr	=		ubus_isde_push_cnts[ 9: 0]	;		
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_isde_wdma_samp	<=	0	;	
	else 								ubus_isde_wdma_samp	<=	ubus_isde_mgth_enab	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_isde_page_cnts	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_page_cnts	<=	0	;
	else if( ubus_isde_page_last)		ubus_isde_page_cnts	<=	0	;
	else 								ubus_isde_page_cnts	<=	ubus_isde_page_cnts + ubus_isde_rxdi_vlid	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_isde_rows_skip	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_rows_skip	<=	ubus_isde_meta_cols	;
	else if( ubus_isde_page_last)		ubus_isde_rows_skip	<=	ubus_isde_rows_skip + ubus_isde_meta_cols	;
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_isde_rxdi_addr	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_rxdi_addr	<=	ubus_isde_ddrs_base	;
	else if( ubus_isde_page_last)		ubus_isde_rxdi_addr	<=	ubus_isde_ddrs_base	+ ubus_isde_rows_skip 	;
	else 								ubus_isde_rxdi_addr	<=	ubus_isde_rxdi_addr + ubus_isde_rxdi_vlid	;	
//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_isde_push_cnts	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_push_cnts	<=	0	;
	else 								ubus_isde_push_cnts	<=	ubus_isde_push_cnts	+ ubus_isde_rxdi_vlid 	;
/**********************************************************************************************************************/
	reg			[ 1: 0]					ubus_isde_mgth_mfsm 	;

	parameter	UBUS_ISDE_MFSM_IDLE	=	2'H0	;
	parameter	UBUS_ISDE_MFSM_SEEK	=	2'H1	;
	parameter	UBUS_ISDE_MFSM_REQS	=	2'H2	;
	parameter	UBUS_ISDE_MFSM_WDMA	=	2'H3	;

	wire								ubus_isde_wdma_vlid	;
	wire								ubus_isde_wdma_beok	;
	wire								ubus_isde_wdma_reqs	;

	assign	ubus_isde_wdma_reqs	=		ubus_isde_mgth_mfsm	==	UBUS_ISDE_MFSM_REQS	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_isde_mgth_mfsm	<=	UBUS_ISDE_MFSM_IDLE	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_mgth_mfsm	<=	UBUS_ISDE_MFSM_IDLE	;
	else begin	
		case(ubus_isde_mgth_mfsm)		
			UBUS_ISDE_MFSM_IDLE	:		ubus_isde_mgth_mfsm	<=							UBUS_ISDE_MFSM_SEEK	;
			UBUS_ISDE_MFSM_SEEK	:		ubus_isde_mgth_mfsm	<=	ubus_isde_wdma_vlid	?	UBUS_ISDE_MFSM_REQS	:	UBUS_ISDE_MFSM_SEEK	;
			UBUS_ISDE_MFSM_REQS	:		ubus_isde_mgth_mfsm	<=							UBUS_ISDE_MFSM_WDMA	;
			UBUS_ISDE_MFSM_WDMA	:		ubus_isde_mgth_mfsm	<=	ubus_isde_wdma_beok	?	UBUS_ISDE_MFSM_SEEK	:	UBUS_ISDE_MFSM_WDMA	;
		endcase
	end
/***********************************************************************************************************************/
	reg									ubus_isde_beat_csen	;
	reg			[ 1: 0]					ubus_isde_beat_cnts	;
	wire		[ 1: 0]					ubus_isde_beat_nxt1	;

	reg			[ 24: 0]				ubus_isde_wdma_cnts	;
	wire								ubus_isde_wdma_last	;
	wire		[ 24: 0]				ubus_isde_wdma_nxt1	;
	wire		[ 24: 0]				ubus_isde_wdma_nxt4	;

	assign	ubus_isde_beat_nxt1	=		ubus_isde_beat_cnts	+ 1	;
	assign	ubus_isde_wdma_nxt1	=		ubus_isde_wdma_cnts	+ 1	;
	assign	ubus_isde_wdma_nxt4	=		ubus_isde_wdma_cnts	+ 4	;
	assign	ubus_isde_wdma_last	= &{	ubus_isde_wdma_csen	,	ubus_isde_wdma_nxt1 ==	ubus_isde_ddrs_size	};
	assign	ubus_isde_wdma_csen	= &{	ubus_isde_beat_csen	,	ubus_isde_wdma_trdy	,	ubus_isde_wdma_wrdy	};

	assign	ubus_isde_wdma_vlid	= &{	ubus_isde_mgth_enab	,	ubus_isde_push_cnts	>=	ubus_isde_wdma_nxt4	};
	assign	ubus_isde_wdma_beok	= &{	ubus_isde_wdma_csen	,	ubus_isde_beat_cnts	};

	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_isde_beat_csen	<=	0	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_beat_csen	<=	0	;
	else if( ubus_isde_wdma_reqs)		ubus_isde_beat_csen	<=	1	;
	else if( ubus_isde_wdma_beok)		ubus_isde_beat_csen	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_isde_beat_cnts	<=	0	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_beat_cnts	<=	0	;
	else if( ubus_isde_wdma_reqs)		ubus_isde_beat_cnts	<=	0	;
	else if( ubus_isde_wdma_csen)		ubus_isde_beat_cnts	<=	ubus_isde_beat_nxt1	;
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_isde_wdma_cnts	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_wdma_cnts	<=	0	;	
	else 								ubus_isde_wdma_cnts	<=	ubus_isde_wdma_cnts + ubus_isde_wdma_csen	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)						ubus_isde_mgth_done	<=	0	;	
	else if(~ubus_isde_mgth_enab)		ubus_isde_mgth_done	<=	0	;	
	else if( ubus_isde_wdma_last)		ubus_isde_mgth_done	<=	1	;	
/**********************************************************************************************************************/
	wire		[  9: 0]				ubus_isde_pops_lsba	;
	wire		[  9: 0]				ubus_isde_pops_nxta	;
	wire		[  9: 0]				ubus_isde_pops_dptr	;

	assign	ubus_isde_pops_lsba	=		ubus_isde_wdma_cnts[ 9: 0 ]	;
	assign	ubus_isde_pops_nxta	=		ubus_isde_pops_lsba + 1	;
	assign	ubus_isde_pops_dptr	=		ubus_isde_wdma_csen	?	ubus_isde_pops_nxta	:	ubus_isde_pops_lsba	;
/**********************************************************************************************************************/
	wire		[ 24:0]					ubus_isde_pops_addr	;
	wire		[255:0]					ubus_isde_pops_data	;

	assign	ubus_isde_wdma_addr	=		ubus_isde_beat_csen	?	ubus_isde_pops_addr	: 0	;
	assign	ubus_isde_wdma_data	=		ubus_isde_beat_csen	?	ubus_isde_pops_data	: 0	;


	dual_port_bram	#(	
		.ADDR_BITS	( 10 ),	.DATA_BITS	( 256 ))	
									u_isde_wdma_beat_data (
		.wport_csen						(ubus_isde_rxdi_vlid	),//input  				 		
		.wport_data						(ubus_isde_rxdi_data	),//input		[DATA_BITS-1:0]
		.wport_addr						(ubus_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(ubus_clki				),//input						

		.rport_addr						(ubus_isde_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_isde_pops_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 10 ),	.DATA_BITS	( 25 ))	
									u_isde_wdma_beat_addr (
		.wport_csen						(ubus_isde_rxdi_vlid	),//input  				 		
		.wport_data						(ubus_isde_rxdi_addr	),//input		[DATA_BITS-1:0]
		.wport_addr						(ubus_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(ubus_clki				),//input						

		.rport_addr						(ubus_isde_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_isde_pops_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						
/**********************************************************************************************************/
endmodule 
 