/*----author edward------*/
module	mgth_isde_link_muxs(
	input								mgt1_isde_link_enab	,
	input								mgt1_isde_rxdi_drdy	,
	input		[255:0]					mgt1_isde_rxdi_data	,
	input								mgt1_clki			,
	input								mgt1_rstn			,

	input								mgt2_isde_link_enab	,
	input								mgt2_isde_rxdi_drdy	,
	input		[255:0]					mgt2_isde_rxdi_data	,
	input								mgt2_clki			,
	input								mgt2_rstn			,

	input								mgt3_isde_link_enab	,
	input								mgt3_isde_rxdi_drdy	,
	input		[255:0]					mgt3_isde_rxdi_data	,
	input								mgt3_clki			,
	input								mgt3_rstn			,

	input								ubus_isde_mgth_enab	,
	input								ubus_isde_mgt1_enab	,
	input								ubus_isde_mgt2_enab	,
	input								ubus_isde_mgt3_enab	,
	
	output	reg							ubus_isde_rxdi_vlid	,
	output	reg	[255: 0]				ubus_isde_rxdi_data	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**GENS MGTX PUSH DPTR**************************************************************************************************/
	reg			[24: 0]					mgt1_isde_push_cnts	;
	reg			[24: 0]					mgt2_isde_push_cnts	;
	reg			[24: 0]					mgt3_isde_push_cnts	;

	wire		[ 7: 0]					mgt1_isde_push_dptr	;
	wire		[ 7: 0]					mgt2_isde_push_dptr	;
	wire		[ 7: 0]					mgt3_isde_push_dptr	;

	assign	mgt1_isde_push_dptr	=		mgt1_isde_push_cnts[ 7: 0]	;
	assign	mgt2_isde_push_dptr	=		mgt2_isde_push_cnts[ 7: 0]	;
	assign	mgt3_isde_push_dptr	=		mgt3_isde_push_cnts[ 7: 0]	;
//-----------------------------------------------------------------------------
	always@(posedge mgt1_clki or negedge mgt1_rstn )
	if(~mgt1_rstn)						mgt1_isde_push_cnts	<=	0	;
	else if(~mgt1_isde_link_enab)		mgt1_isde_push_cnts	<=	0	;
	else if( mgt1_isde_rxdi_drdy)		mgt1_isde_push_cnts	<=	mgt1_isde_push_cnts + 1	;
//-----------------------------------------------------------------------------
	always@(posedge mgt2_clki or negedge mgt2_rstn )
	if(~mgt2_rstn)						mgt2_isde_push_cnts	<=	0	;
	else if(~mgt2_isde_link_enab)		mgt2_isde_push_cnts	<=	0	;
	else if( mgt2_isde_rxdi_drdy)		mgt2_isde_push_cnts	<=	mgt2_isde_push_cnts + 1	;
//-----------------------------------------------------------------------------
	always@(posedge mgt3_clki or negedge mgt3_rstn )
	if(~mgt3_rstn)						mgt3_isde_push_cnts	<=	0	;
	else if(~mgt3_isde_link_enab)		mgt3_isde_push_cnts	<=	0	;
	else if( mgt3_isde_rxdi_drdy)		mgt3_isde_push_cnts	<=	mgt3_isde_push_cnts + 1	;
/**GENS MGTX PUSH GRAY DPTR *******************************************************************************************/
	wire		[24: 0]					mgt1_gray_push_cnts	;
	wire		[24: 0]					mgt2_gray_push_cnts	;
	wire		[24: 0]					mgt3_gray_push_cnts	;

	gens_sync_gray	#( .MSB(24) )	u_ubus_cnts_sync_mgt1(
		.data_asyn						(mgt1_isde_push_cnts	),//input	[24: 0]	
		.data_sync						(mgt1_gray_push_cnts	),//output	[24: 0]	
		.scki							(mgt1_clki				),
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(24) )	u_ubus_cnts_sync_mgt2(
		.data_asyn						(mgt2_isde_push_cnts	),//input	[24: 0]	
		.data_sync						(mgt2_gray_push_cnts	),//output	[24: 0]	
		.scki							(mgt2_clki				),
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(24) )	u_ubus_cnts_sync_mgt3(
		.data_asyn						(mgt3_isde_push_cnts	),//input	[24: 0]	
		.data_sync						(mgt3_gray_push_cnts	),//output	[24: 0]	
		.scki							(mgt3_clki				),
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			
//------------------------------------------------------------------------------	
	reg			[24: 0]					ubus_isde_pops_cnts	;

	wire								ubus_mgt1_push_vlid	;
	wire								ubus_mgt2_push_vlid	;
	wire								ubus_mgt3_push_vlid	;
	wire								ubus_mgth_push_vlid	;
	
	assign	ubus_mgt1_push_vlid	=	&{	ubus_isde_mgt1_enab	,	mgt1_gray_push_cnts	>=	ubus_isde_pops_cnts	+ 1	};
	assign	ubus_mgt2_push_vlid	=	&{	ubus_isde_mgt2_enab	,	mgt2_gray_push_cnts	>=	ubus_isde_pops_cnts	+ 1	};
	assign	ubus_mgt3_push_vlid	=	&{	ubus_isde_mgt3_enab	,	mgt3_gray_push_cnts	>=	ubus_isde_pops_cnts	+ 1	};	
	assign	ubus_mgth_push_vlid	=	|{	ubus_mgt1_push_vlid	,	ubus_mgt2_push_vlid	,	ubus_mgt3_push_vlid		};

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(~ubus_rstn)						ubus_isde_pops_cnts	<=	0	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_pops_cnts	<=	0	;
	else if( ubus_mgth_push_vlid)		ubus_isde_pops_cnts	<=	ubus_isde_pops_cnts + 1	;
/**GENS ASYN FIFO CONTROL SIGNAL****************************************************************************************/
	wire		[ 7: 0]					ubus_isde_pops_lsba	;
	wire		[ 7: 0]					ubus_isde_pops_nxta	;
	wire		[ 7: 0]					ubus_isde_pops_dptr	;

	wire		[255:0]					mgt1_ubus_pops_data	;
	wire		[255:0]					mgt2_ubus_pops_data	;
	wire		[255:0]					mgt3_ubus_pops_data	;
	
	assign	ubus_isde_pops_lsba	=		ubus_isde_pops_cnts[ 7: 0]	;
	assign	ubus_isde_pops_nxta	=		ubus_isde_pops_lsba	+	1	;
	assign	ubus_isde_pops_dptr	=		ubus_mgth_push_vlid	?	ubus_isde_pops_nxta	:	ubus_isde_pops_lsba;
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 8 ),	.DATA_BITS	( 256 ))	
									u_mgt1_isde_data_fifo (
		.wport_csen						(mgt1_isde_rxdi_drdy	),//input  				 		
		.wport_data						(mgt1_isde_rxdi_data	),//input		[DATA_BITS-1:0]
		.wport_addr						(mgt1_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(mgt1_clki				),//input						
		.rport_data						(mgt1_ubus_pops_data	),//output	reg	[DATA_BITS-1:0]
		.rport_addr						(ubus_isde_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 8 ),	.DATA_BITS	( 256 ))	
									u_mgt2_isde_data_fifo (
		.wport_csen						(mgt2_isde_rxdi_drdy	),//input  				 		
		.wport_data						(mgt2_isde_rxdi_data	),//input		[DATA_BITS-1:0]
		.wport_addr						(mgt2_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(mgt2_clki				),//input						
		.rport_data						(mgt2_ubus_pops_data	),//output	reg	[DATA_BITS-1:0]
		.rport_addr						(ubus_isde_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 8 ),	.DATA_BITS	( 256 ))	
									u_mgt3_isde_data_fifo (
		.wport_csen						(mgt3_isde_rxdi_drdy	),//input  				 		
		.wport_data						(mgt3_isde_rxdi_data	),//input		[DATA_BITS-1:0]
		.wport_addr						(mgt3_isde_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(mgt3_clki				),//input						
		.rport_data						(mgt3_ubus_pops_data	),//output	reg	[DATA_BITS-1:0]
		.rport_addr						(ubus_isde_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						
/**GENS ASYN FIFO OUTPUT MIXS******************************************************************************************/
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(~ubus_rstn)						ubus_isde_rxdi_vlid	<=	0	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_rxdi_vlid	<=	0	;
	else 								ubus_isde_rxdi_vlid	<=	ubus_mgth_push_vlid	;

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(~ubus_rstn)						ubus_isde_rxdi_data	<=	0	;
	else if(~ubus_isde_mgth_enab)		ubus_isde_rxdi_data	<=	0	;
	else if( ubus_isde_mgt1_enab) 		ubus_isde_rxdi_data	<=	mgt1_ubus_pops_data	;
	else if( ubus_isde_mgt2_enab) 		ubus_isde_rxdi_data	<=	mgt2_ubus_pops_data	;
	else if( ubus_isde_mgt3_enab) 		ubus_isde_rxdi_data	<=	mgt3_ubus_pops_data	;
	


/**********************************************************************************************************************/
//   uila_w108d01kp5					u_ilas_ubus_mgth_fifo
//   (
//       .clk							    (ubus_clki			),
//       .probe0							({
//                						ubus_mgt1_push_vlid	,
//                						ubus_mgt2_push_vlid	,
//                						ubus_mgt3_push_vlid	,
//                						ubus_mgth_push_vlid	,
//                                        ubus_isde_mgth_enab ,
//                                        ubus_isde_mgt1_enab	,
//                                        ubus_isde_mgt2_enab	,
//                                        ubus_isde_mgt3_enab	,
//                                        mgt1_gray_push_cnts ,
//                                        mgt2_gray_push_cnts ,
//                                        mgt3_gray_push_cnts ,
//                                        ubus_isde_pops_cnts }));	

endmodule 
 