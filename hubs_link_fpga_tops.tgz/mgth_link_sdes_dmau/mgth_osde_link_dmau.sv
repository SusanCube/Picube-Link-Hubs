/*----author edward------*/
module	mgth_osde_link_dmau(
    output								sdes_link_osde_done ,
	input								sdes_link_osde_enab ,
	input		[24: 0]					sdes_link_ddrs_size ,
	input		[24 :0]					sdes_hubs_ddrs_base ,
    input       [15: 0]                 sdes_hubs_cols_dims ,
    input       [15: 0]                 sdes_hubs_cols_dumy ,
	input								link_sclk			,
	input								link_rstn			,

	input								mgth_osde_rdma_trdy	,
	output								mgth_osde_rdma_drdy	,
	output		[255: 0]				mgth_osde_rdma_data	,
	input								mgth_clki			,
	input								mgth_rstn			,
    
	output								ubus_osde_rdma_csen	,
	output		[ 24: 0]				ubus_osde_rdma_addr	,
	input								ubus_osde_rdma_trdy	,
	input		[255: 0]				ubus_osde_rdma_data	,
	input								ubus_osde_rdma_drdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	wire		[24: 0]					ubus_osde_ddrs_base	;
	wire		[24: 0]					ubus_osde_ddrs_size	;
	wire		[15: 0]					ubus_osde_part_cols	;
	wire		[15: 0]					ubus_osde_part_dumy	;


    mgth_osde_argu_gens             u_mgth_osde_argu_gens(
		.sdes_link_osde_done            (sdes_link_osde_done    ),//output				
		.sdes_link_osde_enab            (sdes_link_osde_enab    ),//input				
		.sdes_link_ddrs_size            (sdes_link_ddrs_size    ),//input		[24: 0]	
		.sdes_hubs_ddrs_base            (sdes_hubs_ddrs_base    ),//input		[24: 0]	
		.sdes_hubs_cols_dims            (sdes_hubs_cols_dims    ),//input		[15: 0]	
		.sdes_hubs_cols_dumy            (sdes_hubs_cols_dumy    ),//input		[15: 0]	
		.link_sclk			            (link_sclk			    ),//input				
		.link_rstn			            (link_rstn			    ),//input				

        .ubus_osde_mgth_done	        (ubus_osde_mgth_done	),//input					
        .ubus_osde_mgth_enab	        (ubus_osde_mgth_enab	),//output					
        .ubus_osde_ddrs_base	        (ubus_osde_ddrs_base	),//input		[24: 0]		
        .ubus_osde_ddrs_size	        (ubus_osde_ddrs_size	),//input		[24 :0]		
        .ubus_osde_part_cols	        (ubus_osde_part_cols	),//input       [15: 0]     
        .ubus_osde_part_dumy	        (ubus_osde_part_dumy	),//input       [15: 0]     
        .ubus_clki			            (ubus_clki			    ),//input					
        .ubus_rstn			            (ubus_rstn			    ));//input					


    mgth_osde_link_rdma             u_mgth_osde_link_rdma(
		.mgth_osde_rdma_trdy            (mgth_osde_rdma_trdy    ),//input				
		.mgth_osde_rdma_drdy            (mgth_osde_rdma_drdy    ),//output				
		.mgth_osde_rdma_data            (mgth_osde_rdma_data    ),//output	reg	[255: 0]
		.mgth_clki			            (mgth_clki			    ),//input				
		.mgth_rstn			            (mgth_rstn			    ),//input				

    	.ubus_osde_mgth_done	        (ubus_osde_mgth_done    ),//ubus_osde_mgth_done	,
		.ubus_osde_mgth_enab	        (ubus_osde_mgth_enab    ),//ubus_osde_mgth_enab	,//write enable

        .ubus_osde_ddrs_base	        (ubus_osde_ddrs_base    ),//input		[24: 0]	
        .ubus_osde_ddrs_size	        (ubus_osde_ddrs_size    ),//input		[24 :0]	
        .ubus_osde_part_cols	        (ubus_osde_part_cols    ),//input       [15: 0] 
        .ubus_osde_part_dumy	        (ubus_osde_part_dumy    ),//input       [15: 0] 
    
		.ubus_osde_rdma_csen	        (ubus_osde_rdma_csen    ),//output				
		.ubus_osde_rdma_addr	        (ubus_osde_rdma_addr    ),//output	reg	[ 24: 0]
		.ubus_osde_rdma_trdy	        (ubus_osde_rdma_trdy    ),//input				
		.ubus_osde_rdma_data	        (ubus_osde_rdma_data    ),//input		[255: 0]
		.ubus_osde_rdma_drdy	        (ubus_osde_rdma_drdy    ),//input				

		.ubus_clki			            (ubus_clki              ),//input
		.ubus_rstn			            (ubus_rstn              ));//input



endmodule 


 