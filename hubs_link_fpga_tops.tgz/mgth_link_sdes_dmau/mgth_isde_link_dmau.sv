/*----author edward------*/
module	mgth_isde_link_dmau(
	output								sdes_link_isde_done	,	
	input								sdes_link_isde_enab	,
	input		[ 3: 0]					sdes_link_isde_csid	,
	input		[24: 0]					sdes_link_ddrs_size	,
	input		[24: 0]					sdes_meta_ddrs_base	,
	input		[15: 0]					sdes_meta_cols_dims	,
	input		[15: 0]					sdes_hubs_cols_dims	,
	input								link_clki			,
	input								link_rstn			,
//--------------------------------------
	input								mgt1_isde_rxdi_drdy	,
	input		[255:0]					mgt1_isde_rxdi_data	,
	input								mgt1_clki			,
	input								mgt1_rstn			,
//--------------------------------------
	input								mgt2_isde_rxdi_drdy	,
	input		[255:0]					mgt2_isde_rxdi_data	,
	input								mgt2_clki			,
	input								mgt2_rstn			,
//--------------------------------------
	input								mgt3_isde_rxdi_drdy	,
	input		[255:0]					mgt3_isde_rxdi_data	,
	input								mgt3_clki			,
	input								mgt3_rstn			,
//--------------------------------------	
	output								ubus_isde_wdma_csen,
	output		[ 24: 0]				ubus_isde_wdma_addr,
	output		[255: 0]				ubus_isde_wdma_data,
	input								ubus_isde_wdma_trdy,
	input								ubus_isde_wdma_wrdy,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								ubus_isde_link_enab	;
	wire								ubus_isde_link_done	;

	wire		[24: 0]					ubus_isde_ddrs_base	;
	wire		[24: 0]					ubus_isde_ddrs_size	;
	wire		[15: 0]					ubus_isde_meta_cols	;
	wire		[15: 0]					ubus_isde_part_cols	;

	wire								mgt1_isde_link_enab	;
	wire								mgt2_isde_link_enab	;
	wire								mgt3_isde_link_enab	;

	wire								ubus_isde_mgth_enab	;
	wire								ubus_isde_mgt1_enab	;
	wire								ubus_isde_mgt2_enab	;
	wire								ubus_isde_mgt3_enab	;
	
	mgth_isde_argu_gens				u_mgth_isde_argu_gens(
		.sdes_link_isde_done			(sdes_link_isde_done	),//output				
		.sdes_link_isde_enab			(sdes_link_isde_enab	),//input				
		.sdes_link_isde_csid			(sdes_link_isde_csid	),//input		[ 3: 0]	
		.sdes_link_ddrs_size			(sdes_link_ddrs_size	),//input		[24: 0]	
		.sdes_meta_ddrs_base			(sdes_meta_ddrs_base	),//input		[24: 0]	
		.sdes_meta_cols_dims			(sdes_meta_cols_dims	),//input		[15: 0]	
		.sdes_hubs_cols_dims			(sdes_hubs_cols_dims	),//input		[15: 0]	
		.link_clki						(link_clki				),//input				
		.link_rstn						(link_rstn				),//input				

		.mgt1_isde_link_enab			(mgt1_isde_link_enab	),//output	
		.mgt1_clki						(mgt1_clki				),//input	
		.mgt1_rstn						(mgt1_rstn				),//input	

		.mgt2_isde_link_enab			(mgt2_isde_link_enab	),//output	
		.mgt2_clki						(mgt2_clki				),//input	
		.mgt2_rstn						(mgt2_rstn				),//input	
		
		.mgt3_isde_link_enab			(mgt3_isde_link_enab	),//output	
		.mgt3_clki						(mgt3_clki				),//input	
		.mgt3_rstn						(mgt3_rstn				),//input	

		.ubus_isde_mgth_done			(ubus_isde_mgth_done	),//input
		.ubus_isde_mgth_enab			(ubus_isde_mgth_enab	),//output
		.ubus_isde_mgt1_enab			(ubus_isde_mgt1_enab	),//output
		.ubus_isde_mgt2_enab			(ubus_isde_mgt2_enab	),//output
		.ubus_isde_mgt3_enab			(ubus_isde_mgt3_enab	),//output
				
		.ubus_isde_ddrs_base			(ubus_isde_ddrs_base	),//output		[24: 0]
		.ubus_isde_ddrs_size			(ubus_isde_ddrs_size	),//output		[24: 0]
		.ubus_isde_meta_cols			(ubus_isde_meta_cols	),//output		[15: 0]
		.ubus_isde_part_cols			(ubus_isde_part_cols	),//output		[15: 0]
		.ubus_clki						(ubus_clki				),//input
		.ubus_rstn						(ubus_rstn				));//input
/**********************************************************************************************************/
	wire								ubus_isde_rxdi_enab	;
	wire								ubus_isde_rxdi_vlid	;
	wire		[255: 0]				ubus_isde_rxdi_data	;

	mgth_isde_link_muxs				u_mgth_isde_link_muxs(
		.mgt1_isde_link_enab			(mgt1_isde_link_enab	),//input		
		.mgt1_isde_rxdi_drdy			(mgt1_isde_rxdi_drdy	),//input				
		.mgt1_isde_rxdi_data			(mgt1_isde_rxdi_data	),//input		[255:0]	
		.mgt1_clki						(mgt1_clki				),//input				
		.mgt1_rstn						(mgt1_rstn				),//input				

		.mgt2_isde_link_enab			(mgt2_isde_link_enab	),//input		
		.mgt2_isde_rxdi_drdy			(mgt2_isde_rxdi_drdy	),//input				
		.mgt2_isde_rxdi_data			(mgt2_isde_rxdi_data	),//input		[255:0]	
		.mgt2_clki						(mgt2_clki				),//input				
		.mgt2_rstn						(mgt2_rstn				),//input				
		
		.mgt3_isde_link_enab			(mgt3_isde_link_enab	),//input		
		.mgt3_isde_rxdi_drdy			(mgt3_isde_rxdi_drdy	),//input				
		.mgt3_isde_rxdi_data			(mgt3_isde_rxdi_data	),//input		[255:0]	
		.mgt3_clki						(mgt3_clki				),//input				
		.mgt3_rstn						(mgt3_rstn				),//input				
		
		.ubus_isde_mgth_enab			(ubus_isde_mgth_enab	),//input		[ 1: 3]	
		.ubus_isde_mgt1_enab			(ubus_isde_mgt1_enab	),//input		[ 1: 3]	
		.ubus_isde_mgt2_enab			(ubus_isde_mgt2_enab	),//input		[ 1: 3]	
		.ubus_isde_mgt3_enab			(ubus_isde_mgt3_enab	),//input		[ 1: 3]	
		
		.ubus_isde_rxdi_vlid			(ubus_isde_rxdi_vlid	),//output	reg			
		.ubus_isde_rxdi_data			(ubus_isde_rxdi_data	),//output	reg	[255: 0]
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));	 //input				
/**********************************************************************************************************/
	mgth_isde_link_wdma				u_hubs_mgth_isde_wdma(
		.ubus_isde_mgth_enab			(ubus_isde_mgth_enab	),//output		
		.ubus_isde_mgth_done			(ubus_isde_mgth_done	),//output		
		
		.ubus_isde_rxdi_vlid			(ubus_isde_rxdi_vlid	),//input				
		.ubus_isde_rxdi_data			(ubus_isde_rxdi_data	),//input		[255:0]	

		.ubus_isde_ddrs_base			(ubus_isde_ddrs_base	),//input		[24: 0]	
		.ubus_isde_ddrs_size			(ubus_isde_ddrs_size	),//input		[15: 0]	
		.ubus_isde_meta_cols			(ubus_isde_meta_cols	),//input		[24: 0]	
		.ubus_isde_part_cols			(ubus_isde_part_cols	),//input		[15: 0]	
		
		.ubus_isde_wdma_csen			(ubus_isde_wdma_csen	),//output				
		.ubus_isde_wdma_addr			(ubus_isde_wdma_addr	),//output		[ 24: 0]
		.ubus_isde_wdma_data			(ubus_isde_wdma_data	),//output		[255: 0]
		.ubus_isde_wdma_trdy			(ubus_isde_wdma_trdy	),//input				
		.ubus_isde_wdma_wrdy			(ubus_isde_wdma_wrdy	),//input				
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input				
/**********************************************************************************************************************/
//	uila_w091d01kp5					u_ilas_ubus_mgth_ctrl
//    (
//        .clk							(ubus_clki				),
//        .probe0							({
//                                        ubus_isde_mgth_done	,
//                                        ubus_isde_mgth_enab	,
//                                        ubus_isde_mgt1_enab	,
//                                        ubus_isde_mgt2_enab	,
//                                        ubus_isde_mgt3_enab	,
//                                        sdes_link_isde_csid ,
//                                        ubus_isde_ddrs_base	,
//                                        ubus_isde_ddrs_size	,
//                                        ubus_isde_meta_cols	,
//                                        ubus_isde_part_cols	}));	
//

endmodule 

 