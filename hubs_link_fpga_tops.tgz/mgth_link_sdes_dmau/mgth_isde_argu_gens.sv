//**********************************************************************************************************
module	mgth_isde_argu_gens(
	output								sdes_link_isde_done	,	
	input								sdes_link_isde_enab	,
	input		[ 3: 0]					sdes_link_isde_csid	,
	input		[24: 0]					sdes_link_ddrs_size	,
	input		[24: 0]					sdes_meta_ddrs_base	,
	input		[15: 0]					sdes_meta_cols_dims	,
	input		[15: 0]					sdes_hubs_cols_dims	,
	input								link_clki			,
	input								link_rstn			,

	output								mgt1_isde_link_enab	,
	input								mgt1_clki			,
	input								mgt1_rstn			,
	
	output								mgt2_isde_link_enab	,
	input								mgt2_clki			,
	input								mgt2_rstn			,

	output								mgt3_isde_link_enab	,
	input								mgt3_clki			,
	input								mgt3_rstn			,

	input								ubus_isde_mgth_done	,
	output								ubus_isde_mgth_enab	,
	output								ubus_isde_mgt1_enab	,
	output								ubus_isde_mgt2_enab	,
	output								ubus_isde_mgt3_enab	,
	
	output		[24: 0]					ubus_isde_ddrs_base	,
	output		[24: 0]					ubus_isde_ddrs_size	,
	output		[15: 0]					ubus_isde_meta_cols	,
	output		[15: 0]					ubus_isde_part_cols	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire	mgt1_isde_link_csen	=	&{	sdes_link_isde_enab	,	sdes_link_isde_csid == 4'H1	};
	wire	mgt2_isde_link_csen	=	&{	sdes_link_isde_enab	,	sdes_link_isde_csid == 4'H2	};
	wire	mgt3_isde_link_csen	=	&{	sdes_link_isde_enab	,	sdes_link_isde_csid == 4'H3	};
	assign	ubus_isde_mgth_enab	=	|{	ubus_isde_mgt1_enab	,	ubus_isde_mgt2_enab	,	ubus_isde_mgt3_enab	};
	
	gens_sign_fast_slow #( .EXTN( 5 ))
									u_ubus_isde_done_gens(	
		.slow_sign						(sdes_link_isde_done 	),//output	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_isde_mgth_done	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_ubus_isde_mgt1_enab(	
		.slow_sign						(mgt1_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_isde_mgt1_enab	),//output
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_ubus_isde_mgt2_enab(	
		.slow_sign						(mgt2_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_isde_mgt2_enab	),//output
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_ubus_isde_mgt3_enab(	
		.slow_sign						(mgt3_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(ubus_isde_mgt3_enab	),//output
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_mgt1_isde_enab_gens(	
		.slow_sign						(mgt1_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(mgt1_isde_link_enab	),//output
		.fast_clki						(mgt1_clki				),//input
		.fast_rstn						(mgt1_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_mgt2_isde_enab_gens(	
		.slow_sign						(mgt2_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(mgt2_isde_link_enab	),//output
		.fast_clki						(mgt2_clki				),//input
		.fast_rstn						(mgt2_rstn				));//input

	gens_sign_slow_fast #( .EXTN( 2 ))	
									u_mgt3_isde_enab_gens(	
		.slow_sign						(mgt3_isde_link_csen 	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign  					(mgt3_isde_link_enab	),//output
		.fast_clki						(mgt3_clki				),//input
		.fast_rstn						(mgt3_rstn				));//input
/**********************************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )	u_ddrs_base_sync_ubus(
		.data_asyn						(sdes_meta_ddrs_base	),//input	[24: 0]	
		.scki							(link_clki				),
		.data_sync						(ubus_isde_ddrs_base	),//output	[24: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(24) )	u_ddrs_size_sync_ubus(
		.data_asyn						(sdes_link_ddrs_size	),//input	[24: 0]	
		.scki							(link_clki				),
		.data_sync						(ubus_isde_ddrs_size	),//output	[24: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(15) )	u_meta_cols_sync_ubus(
		.data_asyn						(sdes_meta_cols_dims	),//input	[15: 0]	
		.scki							(link_clki				),
		.data_sync						(ubus_isde_meta_cols	),//output	[15: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(15) )	u_part_cols_sync_ubus(
		.data_asyn						(sdes_hubs_cols_dims	),//input	[15: 0]	
		.scki							(link_clki				),
		.data_sync						(ubus_isde_part_cols	),//output	[15: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			






endmodule

