
module  gens_edge_fast_slow #(	parameter EXTN = 5	)
(	
	output								slow_edge	,
	input								slow_clki	,
	input								slow_rstn	,

	input								fast_sign   ,
	input								fast_clki	,
	input								fast_rstn	);
//----------------------------------------------------------------------
	reg		[EXTN:0]					fast_extn_samp	;
	reg									fast_extn_mark	;

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      				fast_extn_samp	<=	0     ;
	else								fast_extn_samp	<={	fast_sign ,	fast_extn_samp[EXTN:1]	};

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      				fast_extn_mark	<=	1'B0     ;
	else								fast_extn_mark	<=|{fast_sign ,	fast_extn_samp	};
//----------------------------------------------------------------------
	reg		[2:0]						slow_mark_samp	;
		
	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      			    slow_mark_samp  <= 3'B0     ;
	else 								slow_mark_samp 	<={fast_extn_mark	, slow_mark_samp[2:1]	};

	assign	slow_edge	=	slow_mark_samp[1:0]	==	2'B10	;
	
endmodule