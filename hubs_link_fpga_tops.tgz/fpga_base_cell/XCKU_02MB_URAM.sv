

module XCKU_02MB_URAM (
	output 								uram_trdy	,	
	output 								uram_wrdy	,	

    input  		                 		uram_wrcs	,
    input  		[15 :0] 				uram_wadd	,
    input  		[255:0] 				uram_wdat	,

    input  		                  		uram_rdcs	,
    input  		[15 :0] 				uram_radd	,
    output 		[255:0] 				uram_rdat	,
    output reg                  		uram_drdy	,   
	
	input  		                 		uram_clki	,
    input  		                 		uram_rstn	);
//------------------------------------------------------------------------------
	SDPT_02MB_URAM			 		U_SDPT_02MB_URAM(
	  	.wea							(uram_wrcs	), // input wire [0:0] wea
	  	.addra							(uram_wadd	), // input wire [15:0] addra
	  	.dina							(uram_wdat	), // input wire [255:0] dina
		.clka							(uram_clki	), // input wire clka
	  
	  	.addrb							(uram_radd	), // input wire [15:0] addrb
	  	.doutb							(uram_rdat	),// output wire [255:0] doutb
	  	.clkb							(uram_clki	));
//------------------------------------------------------------------------------
	parameter	DDRO_TIME			=	4	;
	reg		   [DDRO_TIME: 0]			uram_rden	;

	always@(posedge uram_clki or negedge uram_rstn)
	if(~uram_rstn)						uram_rden	<=	0	;
	else 								uram_rden	<={	uram_rdcs	,	uram_rden[DDRO_TIME:1]	};

	assign	uram_drdy	=	uram_rden[0];
	assign	uram_trdy	=	1			;
	assign	uram_wrdy	=	1			;
		
		

endmodule