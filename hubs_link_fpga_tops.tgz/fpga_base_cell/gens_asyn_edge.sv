
module	gens_asyn_edge (
	output							data_edge	,
	input							data_inpp	,
	input							edge_mode	,

	input							clki		,
	input							rstn		);

	reg		[2:0]					data_samp	;

	always@(posedge clki or negedge rstn)
	if(~rstn)	data_samp	<=	0			;
	else		data_samp	<={	data_inpp	,	data_samp[2:1] }	;

	assign		data_edge	=	edge_mode	? data_samp[1:0] == 2'B01	:
											  data_samp[1:0] == 2'B10	;
	
endmodule
  