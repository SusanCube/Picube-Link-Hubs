module	xcku_sysdna	(
	output	reg	[95: 0]				    fdna_code	,
    
	input							    link_cclk	,
	input							    init_rstn	);	
//----------------------------------------------------------------------	
	wire						    	fdna_sout	;
	reg							    	fdna_rdcs	;
	reg							    	fdna_shft	;
	reg			[ 7: 0]			    	fdna_cnts	;
//----------------------------------------------------------------------	
	DNA_PORTE2 	#(
    			.SIM_DNA_VALUE		(96'h123456789ABCDEF012345678))
    							    u_FDNA_READER (
        .DIN					    	(	1'b0			),
        .DOUT					    	(	fdna_sout		),
        .READ					    	(	fdna_rdcs		),
        .SHIFT					    	(	fdna_shft		),
		.CLK					    	(	link_cclk		));
//----------------------------------------------------------------------	
	wire	cnts_maxi	=           	fdna_cnts	==	8'D255	;
	wire	read_rise	=           	fdna_cnts	==	8'D050	;
	wire	read_fall	=           	fdna_cnts	==	8'D051	;
	wire	shft_rise	=           	fdna_cnts	==	8'D060	;
	wire	shft_fall	=           	fdna_cnts	==	8'D156	;
	
	always @(posedge link_cclk or negedge init_rstn) 
	if(~init_rstn)			            fdna_cnts <= 0	;
	else if(~cnts_maxi)		            fdna_cnts <= 1+	fdna_cnts	;
	
	always @(posedge link_cclk or negedge init_rstn) 
	if(~init_rstn)			            fdna_rdcs <= 0	;
	else if( read_rise)		            fdna_rdcs <= 1	;
	else if( read_fall)		            fdna_rdcs <= 0	;

	always @(posedge link_cclk or negedge init_rstn) 
	if(~init_rstn)			            fdna_shft <= 0	;
	else if( shft_rise)		            fdna_shft <= 1	;
	else if( shft_fall)		            fdna_shft <= 0	;
	
	always @(posedge link_cclk or negedge init_rstn) 
	if(~init_rstn)			            fdna_code <= 0	;
	else if( fdna_shft)		            fdna_code <={fdna_sout, fdna_code[95:1]}; 

endmodule