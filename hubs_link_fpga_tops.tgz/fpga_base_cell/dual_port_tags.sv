module	dual_port_tags	 (
	input  				 			wport_csen	,
	input		[ 2: 0]				wport_addr	,
	input		[39: 0]				wport_data	,
	input							wport_clki	,

	input		[ 2: 0] 			rport_addr	,
	output	reg	[39: 0] 			rport_data	,
	input							rport_clki	);

(* ram_style="block" *)	reg [39:0] 	memo[7:0]	;

	always@(posedge wport_clki)
	if(wport_csen)
		memo[wport_addr]	<=	wport_data		;

	always@(posedge rport_clki)
		rport_data			<=	memo[rport_addr];
		


endmodule