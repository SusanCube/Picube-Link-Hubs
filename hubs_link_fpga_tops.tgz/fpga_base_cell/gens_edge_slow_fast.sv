
module  gens_edge_slow_fast (	
	output								fast_edge   ,
	input								fast_clki	,
	input								fast_rstn	,

	input								slow_sign	,
	input								slow_clki	,
	input								slow_rstn	);
//------------------------------------------------------------------------------
	reg									slow_extn_samp	;
	reg									slow_extn_mark	;

	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      				slow_extn_samp	<= 	0	;
	else								slow_extn_samp	<=	slow_sign	;

	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      				slow_extn_mark	<= 	1'B0     ;
	else								slow_extn_mark	<=	slow_extn_samp | slow_sign	;
//----------------------------------------------------------------------
	reg		[2:0]						fast_mark_samp	;
		
	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)						fast_mark_samp	<=	3'B0     ;
	else 								fast_mark_samp	<= {slow_extn_mark	, fast_mark_samp[2:1]	};

	assign	fast_edge	=	fast_mark_samp[1:0]	==	2'B10	;
	
endmodule