/***********************************************************************************************************
//--reduce the number of filter taps from 5 to 4
***********************************************************************************************************/
module	idly_patn_ctrl(
	input								idly_patn_reqs	,
	input								idly_patn_enab	,
	output	[4:0]						idly_patn_good	,

	input	[7:0]						lvds_fram_mbdi 	,
	input	[7:0]						lvds_dat0_mbdi 	,
	input	[7:0]						lvds_dat1_mbdi 	,
	input	[7:0]						lvds_dat2_mbdi 	,
	input	[7:0]						lvds_dat3_mbdi 	,

	input								lvds_fclk		,
	input								link_clki		,
	input								link_rstn		);
//----------------------------------------------------------------------------------------------------------
	reg		[ 3: 0]					fram_patn_buff	;
	reg		[ 3: 0]					dat0_patn_buff	;
	reg		[ 3: 0]					dat1_patn_buff	;
	reg		[ 3: 0]					dat2_patn_buff	;
	reg		[ 3: 0]					dat3_patn_buff	;

	wire							fram_patn_good	=	lvds_fram_mbdi == 8'H9A	;//9A--10011010
	wire							dat0_patn_good	=	lvds_dat0_mbdi == 8'H9A	;//9A--10011010
	wire							dat1_patn_good	=	lvds_dat1_mbdi == 8'H9A	;//9A--10011010
	wire							dat2_patn_good	=	lvds_dat2_mbdi == 8'H9A	;//9A--10011010
	wire							dat3_patn_good	=	lvds_dat3_mbdi == 8'H9A	;//9A--10011010

	always@(posedge lvds_fclk or negedge link_rstn)
	if(~link_rstn) begin
		fram_patn_buff	<=	0	;
		dat0_patn_buff	<=	0	;
		dat1_patn_buff	<=	0	;
		dat2_patn_buff	<=	0	;
		dat3_patn_buff	<=	0	;
	end else if(idly_patn_reqs)	begin
		fram_patn_buff	<=	0	;
		dat0_patn_buff	<=	0	;
		dat1_patn_buff	<=	0	;
		dat2_patn_buff	<=	0	;
		dat3_patn_buff	<=	0	;
	end else if(idly_patn_enab)	begin
		fram_patn_buff	<={ fram_patn_buff[2:0]	,	fram_patn_good	}	;
		dat0_patn_buff	<={ dat0_patn_buff[2:0]	,	dat0_patn_good	}	;
		dat1_patn_buff	<={ dat1_patn_buff[2:0]	,	dat1_patn_good	}	;
		dat2_patn_buff	<={ dat2_patn_buff[2:0]	,	dat2_patn_good	}	;
		dat3_patn_buff	<={ dat3_patn_buff[2:0]	,	dat3_patn_good	}	;
	end 
//----------------------------------------------------------------------
	reg								patn_good_filt	;		
	reg		[ 7: 0]					patn_good_time	;		
						
	wire							patn_comb_filt	= &{|fram_patn_buff	,
														|dat0_patn_buff	,
														|dat1_patn_buff	,
														|dat2_patn_buff	,
														|dat3_patn_buff	};		

	wire							patn_good_tmax	= &	patn_good_time	;

	always@(posedge lvds_fclk or negedge link_rstn)
	if(~link_rstn) 					patn_good_time	<=	0	;
	else if(~patn_comb_filt)		patn_good_time	<=	0	;
	else if(~patn_good_tmax)		patn_good_time	<=	patn_good_time +1	;


	always@(posedge lvds_fclk or negedge link_rstn)
	if(~link_rstn) 					patn_good_filt	<=	0	;
	else							patn_good_filt	<=	patn_good_tmax	;

//----------------------------------------------------------------------
	reg		[ 1:0]					patn_filt_shft	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 					patn_filt_shft	<=	0	;
	else							patn_filt_shft	<={	patn_good_filt ,patn_filt_shft[1]	};

	assign	idly_patn_good	= {5{	patn_filt_shft[0]	}};


	



endmodule

