
module	link_rstn_slpf(
	output	reg							rstn_slpf		,
	input								rstn_sign		,
			
	input								base_clki		);
/**********************************************************************************************************************/
	reg									slpf_rstn	=	0			;
	reg			[5: 0]					slpf_cnts	=   0			;

	wire								slpf_smax	= &	slpf_cnts	;			
	wire								slpf_lt08	=	slpf_cnts[5:3] == 3'H0	;
	wire		[5:0]					slpf_decs	=	slpf_cnts_lt08	?	6'H0 	:	slpf_cnts - 8	;
	wire		[5:0]					slpf_incs	=	slpf_cnts + 1	;
	wire								slpf_high	=		slpf_cnts	>	6'D50	;

	assign	rstn_slpf	=	slpf_rstn	;

	always@(posedge base_clki)
	if(~rstn_sign)						slpf_cnts	<=	slpf_decs	;
	else if(~slpf_smax)					slpf_cnts	<=	slpf_incs	;

	always@(posedge base_clki)			slpf_rstn	<=	slpf_high	;

/**********************************************************************************************************************/

endmodule
 