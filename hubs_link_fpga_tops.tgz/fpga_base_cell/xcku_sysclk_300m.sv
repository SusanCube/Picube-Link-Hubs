module	xcku_sysclk_300m(
	output								link_fclk	,
	output								link_sclk	,
	output								init_bclk	,
	
	output								link_rstn	,
	output								chip_rstn	,
	output								dlys_rstn	,

	input								auxi_rstn	,
	input								cold_rstn	,
	input								chip_clki	);
/**********************************************************************************************************************/
	wire								mmcm_lock	;

	wire	mixs_rstn		=   &{		cold_rstn ,	mmcm_lock ,	auxi_rstn	};
	assign	dlys_rstn 		=	&{		cold_rstn , mmcm_lock 				};
//------------------------------------------------------------------------------
	reg		[ 7: 0]						chip_rstn_time 	= 	0 	;
	wire	[ 7: 0]						chip_rstn_tnxt	=	1 +	chip_rstn_time	;

	assign	chip_rstn		=   		chip_rstn_time	==	8'H7F	;
	
	always@(posedge chip_clki)			
	if(~chip_rstn)						chip_rstn_time	<=	chip_rstn_tnxt	;
//------------------------------------------------------------------------------
	reg		[ 7: 0]						link_rstn_time 	= 	0	;
	wire	[ 7: 0]						link_rstn_tnxt	=	1 +	link_rstn_time	;

	assign	link_rstn		=   		link_rstn_time	==	8'H7F	;

	always@(posedge link_sclk  or negedge mixs_rstn )
	if(~mixs_rstn)						link_rstn_time	<=	0	;
	else if(~link_rstn)					link_rstn_time	<=	link_rstn_tnxt	;
/**********************************************************************************************************************/
	wire								mmcmo_300	;
	wire								mmcmo_040	;
//----------------------------------------------------------------------
   	(* KEEP = "TRUE" *)
	BUFG 							BUFG_300M(
		.O  						 	(link_fclk		),
    	.I  						 	(mmcmo_300		));		
//----------------------------------------------------------------------
   	(* KEEP = "TRUE" *)
	BUFG 							BUFG_040M(
		.O  						 	(init_bclk		),
    	.I  						 	(mmcmo_040		));		
/**********************************************************************************************************************/
	reg		[3: 0]						mmcm_clrs_shft	= 4'HF	;
	reg		[7: 0]						mmcm_cken_shft	= 8'H0	;
	
	wire								mmcm_clrs	=	mmcm_clrs_shft[0]	;
	wire								mmcm_cken	=	mmcm_cken_shft[0]	;
	
	always@(posedge mmcmo_300)
	if(~mmcm_lock)						mmcm_clrs_shft	<=	4'HF	;
	else 								mmcm_clrs_shft	<= {1'B0	,	mmcm_clrs_shft[3:1]	};
	
	always@(posedge mmcmo_300)
	if(~mmcm_lock)						mmcm_cken_shft	<=	8'H0	;
	else 								mmcm_cken_shft	<= {1'B1	,	mmcm_cken_shft[7:1]	};
//----------------------------------------------------------------------
	(* KEEP = "TRUE" *)
  	BUFGCE_DIV #(
		.BUFGCE_DIVIDE					(4.0 			),// 1-8
		.IS_CE_INVERTED					(1'b0			),// Optional inversion for CE
		.IS_CLR_INVERTED				(1'b0			),// Optional inversion for CLR
		.IS_I_INVERTED					(1'b0			))// Optional inversion for I
   	BUFG_075M (	
		.CLR							(mmcm_clrs		), 	// 1-bit input: Asynchronous clear
		.CE								(mmcm_cken		), 	// 1-bit input: Buffer enable
		.O								(link_sclk		), 	// 1-bit output: Buffer
		.I								(mmcmo_300		));	// 1-bit input: Buffer
/**********************************************************************************************************************/
   	wire        						clkfb_cko	;
  	wire        						clkfb_cki	;
	
   (* KEEP = "TRUE" *)
	BUFG 							clkfb_buf(
		.O								(clkfb_cki	),
    	.I								(clkfb_cko	));
//----------------------------------------------------------------------	
	MMCME3_ADV  #(	
		.BANDWIDTH            			("HIGH"		),
    	.CLKOUT4_CASCADE      			("FALSE"	),
    	.COMPENSATION         			("AUTO"		),
    	.STARTUP_WAIT         			("FALSE"	),
    	.DIVCLK_DIVIDE        			(1			),
    	.CLKFBOUT_MULT_F      			(12.000		),
    	.CLKFBOUT_PHASE       			(0.000		),
    	.CLKFBOUT_USE_FINE_PS 			("FALSE"	),
	
		.CLKOUT0_DIVIDE_F     			(4.000		),
    	.CLKOUT0_PHASE        			(0.000		),
    	.CLKOUT0_DUTY_CYCLE   			(0.500		),
    	.CLKOUT0_USE_FINE_PS  			("FALSE"	),
	
		.CLKOUT1_DIVIDE       			(30.000		),
    	.CLKOUT1_PHASE        			(0.000		),
    	.CLKOUT1_DUTY_CYCLE   			(0.500		),
    	.CLKOUT1_USE_FINE_PS  			("FALSE"	),
	
		.CLKOUT2_DIVIDE       			(16			),
    	.CLKOUT2_PHASE        			(0.000		),
    	.CLKOUT2_DUTY_CYCLE   			(0.500		),
    	.CLKOUT2_USE_FINE_PS  			("FALSE"	),

    	.CLKIN1_PERIOD        			(10.000		))
    
	CHIP_MMCM(
		.CLKFBIN             			(clkfb_cki		),
		.CLKFBOUT            			(clkfb_cko		),
		.CLKFBOUTB           			(				),			//clkfboutb_unused			),
		
		.CLKIN1              			(chip_clki		),
		.CLKIN2              			(1'b0			),
		.CLKINSEL            			(1'b1			),


		.CLKOUT0             			(mmcmo_300		),
		.CLKOUT0B            			(),							//clkout0b_unused			),
		.CLKOUT1             			(mmcmo_040		),			//clkout1_unused			),
		.CLKOUT1B            			(),							//clkout1b_unused			),
		.CLKOUT2             			(),							//clkout2_unused			),
		.CLKOUT2B            			(),							//clkout2b_unused			),
		.CLKOUT3             			(),							//clkout3_unused			),
		.CLKOUT3B            			(),							//clkout3b_unused			),
		.CLKOUT4             			(),							//clkout4_unused			),
		.CLKOUT5             			(),							//clkout5_unused			),
		.CLKOUT6             			(),							//clkout6_unused			),
		
		// Ports for dynamic reconfiguration
		.DADDR               			(7'h0),
		.DCLK                			(1'b0),
		.DEN                 			(1'b0),
		.DI                  			(16'h0),
		.DO                  			(),							//do_unused),
		.DRDY                			(),							//drdy_unused),
		.DWE                 			(1'b0),
		.CDDCDONE            			(),
		.CDDCREQ             			(1'b0),
		// Ports for dynamic phase shift
		.PSCLK               			(1'b0),
		.PSEN                			(1'b0),
		.PSINCDEC            			(1'b0),

		.PSDONE              			(),							//psdone_unused),
		.CLKINSTOPPED        			(),							//clkinstopped_unused),
		.CLKFBSTOPPED        			(),							//clkfbstopped_unused),
		.PWRDWN              			(1'b0			),
		.LOCKED              			( mmcm_lock		),
		.RST                 			(~chip_rstn		));
/**********************************************************************************************************************/
endmodule
//		.CLR							(1'b0		), 	// 1-bit input: Asynchronous clear
//		.CE								(mmcm_lock		), 	// 1-bit input: Buffer enable
