module	xdat_patn_quiz(
	input								link_cmnd_reqs	,
	output								link_quiz_good	,

	input								link_fram_vlid	,
	input	[31: 0]						link_fram_data	,
	input								link_clki		,
	input								link_rstn		);
//----------------------------------------------------------------------------------------------------------------------
	reg									link_fram_samp	;
	reg									link_reqs_samp	;
	
	wire								link_fram_rise	;
	wire								link_fram_fall	;
	wire								link_reqs_issu	;

	assign	link_fram_rise	=		{	link_fram_vlid	,	link_fram_samp	}	==	2'H2	;
	assign	link_fram_fall	=		{	link_fram_vlid	,	link_fram_samp	}	==	2'H1	;
	assign	link_reqs_issu	=		{	link_cmnd_reqs	,	link_reqs_samp	}	==	2'H2	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_fram_samp	<=	0	;
	else 								link_fram_samp	<=	link_fram_vlid	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_reqs_samp	<=	0	;
	else								link_reqs_samp	<=	link_reqs_samp	;
//----------------------------------------------------------------------------------------------------------------------
	wire								link_cmnd_issu	;
	wire								link_rows_issu	;

	assign	link_cmnd_issu	=	&{		link_fram_rise	,	link_fram_data == "OVCT" || link_fram_data == "IVCT"	}	;
	assign	link_rows_issu	=	&{		link_fram_rise	,	link_fram_data == "DATA" };
//----------------------------------------------------------------------------------------------------------------------
	reg									link_quiz_time	;
	reg		[11: 0]						link_data_rows	;
	reg		[15: 0]						link_data_cols	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_quiz_time	<=	0	;
	else if(link_fram_fall)				link_quiz_time	<=	0	;
	else if(link_rows_issu)				link_quiz_time	<=	1	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_data_rows	<=	0	;
	else if(link_cmnd_issu)				link_data_rows	<=	0	;
	else if(link_rows_issu)				link_data_rows	<=	1 + link_data_rows	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						link_data_cols	<=	0	;
	else if(link_cmnd_issu)				link_data_cols	<=	0	;
	else if(link_fram_fall)				link_data_cols	<=	0	;
	else if(link_fram_vlid)				link_data_cols	<=	1 + link_data_cols	;
//----------------------------------------------------------------------------------------------------------------------
	wire    link_cmnd_quiz	    =  (  link_cmnd_issu |   link_quiz_time ) &(!link_fram_fall); 

	assign	link_quiz_good		=	link_cmnd_quiz	?	link_fram_data	==	{	4'H1,	link_data_rows	,	link_data_cols	}	:	1'B1		;

endmodule
