
module  port_link_numb_accu	(	
	input		[ 7: 0]				port_link_csen	,
	output		[ 3: 0]				port_link_numb	);

	wire		[ 1: 0]				port_link_1vs2	;
	wire		[ 1: 0]				port_link_3vs4	;
	wire		[ 1: 0]				port_link_5vs6	;
	wire		[ 1: 0]				port_link_7vs8	;

	wire		[ 2: 0]				port_link_1vs4	;
	wire		[ 2: 0]				port_link_5vs8	;

	assign		port_link_1vs2	=	port_link_csen[0] +	port_link_csen[1]	;
	assign		port_link_3vs4	=	port_link_csen[2] +	port_link_csen[3]	;
	assign		port_link_5vs6	=	port_link_csen[4] +	port_link_csen[5]	;
	assign		port_link_7vs8	=	port_link_csen[6] +	port_link_csen[7]	;
	
	assign		port_link_1vs4	=	port_link_1vs2 +	port_link_3vs4	;
	assign		port_link_5vs8	=	port_link_5vs6 +	port_link_7vs8	;

	assign		port_link_numb	=	port_link_1vs4	+	port_link_5vs8	;
	
	



endmodule