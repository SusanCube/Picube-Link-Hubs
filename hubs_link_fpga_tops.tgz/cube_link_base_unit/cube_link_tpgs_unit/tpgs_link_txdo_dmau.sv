
module	tpgs_link_txdo_dmau (	

	input	[7:0]					link_txdo_fram_mbdi	,
	input	[7:0]					link_txdo_dat0_mbdi	,
	input	[7:0]					link_txdo_dat1_mbdi	,
	input	[7:0]					link_txdo_dat2_mbdi	,
	input	[7:0]					link_txdo_dat3_mbdi	,

	output	reg	[7:0]				link_txdo_fram_mbdo	,
	output	reg	[7:0]				link_txdo_dat0_mbdo	,
	output	reg	[7:0]				link_txdo_dat1_mbdo	,
	output	reg	[7:0]				link_txdo_dat2_mbdo	,
	output	reg	[7:0]				link_txdo_dat3_mbdo	,
	
	input							link_clki		,
	input							link_rstn		);
/**********************************************************************************************************/
	 
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)	begin
		link_txdo_fram_mbdo	<=	0	;
		link_txdo_dat0_mbdo	<=	0	;
		link_txdo_dat1_mbdo	<=	0	;
		link_txdo_dat2_mbdo	<=	0	;
		link_txdo_dat3_mbdo	<=	0	;
	end else  begin
		link_txdo_fram_mbdo	<=	link_txdo_fram_mbdi	;
		link_txdo_dat0_mbdo	<=	link_txdo_dat0_mbdi	;
		link_txdo_dat1_mbdo	<=	link_txdo_dat1_mbdi	;
		link_txdo_dat2_mbdo	<=	link_txdo_dat2_mbdi	;
		link_txdo_dat3_mbdo	<=	link_txdo_dat3_mbdi	;
	end

		
 

endmodule
