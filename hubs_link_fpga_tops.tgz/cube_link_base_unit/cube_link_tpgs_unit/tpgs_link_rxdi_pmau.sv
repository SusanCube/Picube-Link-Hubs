
module	tpgs_link_rxdi_pmau (
	input								lvds_fclk_inpp	,
	input								lvds_fclk_inpn	,
	input								lvds_fram_inpp	,
	input								lvds_fram_inpn	,
	input								lvds_dat0_inpp	,
	input								lvds_dat0_inpn	,
	input								lvds_dat1_inpp	,
	input								lvds_dat1_inpn	,
	input								lvds_dat2_inpp	,
	input								lvds_dat2_inpn	,
	input								lvds_dat3_inpp	,
	input								lvds_dat3_inpn	,
	
	output		[ 7: 0]					lvds_fram_mbdo	,//reg
	output		[ 7: 0]					lvds_dat0_mbdo	,//reg
	output		[ 7: 0]					lvds_dat1_mbdo	,//reg
	output		[ 7: 0]					lvds_dat2_mbdo	,//reg
	output		[ 7: 0]					lvds_dat3_mbdo	,//reg
		
	input								link_clki		,
	input								lvds_rstn		);
/**********************************************************************************************************/
	IBUFDS						LVDS_FCLK_PAD	(
		.I                  		(lvds_fclk_inpp	),
		.IB                 		(lvds_fclk_inpn	),
		.O                  		(lvds_fclk_w	));

	BUFG						LVDS_FCLK_BUFG	(
		.I							(lvds_fclk_w	),
		.O							(lvds_fclk		));	

	wire							lvds_fckp		;
	wire							lvds_fckn		;

	assign	lvds_fckp	=	lvds_fclk		;
	assign	lvds_fckn	= ~	lvds_fclk		;
/**********************************************************************************************************/
	wire							lvds_fram_q0	;
	wire							lvds_dat0_q0	;
	wire							lvds_dat1_q0	;
	wire							lvds_dat2_q0	;
	wire							lvds_dat3_q0	;

	wire							lvds_fram_q1	;
	wire							lvds_dat0_q1	;
	wire							lvds_dat1_q1	;
	wire							lvds_dat2_q1	;
	wire							lvds_dat3_q1	;

	wire	[ 1: 0]					lvds_fram_iddr	= {	lvds_fram_q0 , lvds_fram_q1	};
	wire	[ 1: 0]					lvds_dat0_iddr	= {	lvds_dat0_q0 , lvds_dat0_q1	};
	wire	[ 1: 0]					lvds_dat1_iddr	= {	lvds_dat1_q0 , lvds_dat1_q1	};
	wire	[ 1: 0]					lvds_dat2_iddr	= {	lvds_dat2_q0 , lvds_dat2_q1	};
	wire	[ 1: 0]					lvds_dat3_iddr	= {	lvds_dat3_q0 , lvds_dat3_q1	};
//----------------------------------------------------------------------------------------------------------	
	IBUFDS						LVDS_FRAM_PAD	(
		.I                  		(lvds_fram_inpp	),
		.IB                 		(lvds_fram_inpn	),
		.O                  		(lvds_fram_rxdi	));

 	IDDRE1 #(
    	.DDR_CLK_EDGE				("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED				(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED				(1'b0			)) // Optional inversion for C
    IDDRE1_FRAM_IN	(
		.C							(lvds_fckp		), // 1-bit input: High-speed clock
		.CB							(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R							(1'B0			), // 1-bit input: Active-High Async Reset
  		.D							(lvds_fram_rxdi	), // 1-bit input: Serial Data Input
		.Q1							(lvds_fram_q0	), // 1-bit output: Registered parallel output 1
		.Q2							(lvds_fram_q1	));// 1-bit output: Registered parallel output 2
//----------------------------------------------------------------------------------------------------------	
	IBUFDS						LVDS_DAT0_PAD	(
		.I                  		(lvds_dat0_inpp	),
		.IB                 		(lvds_dat0_inpn	),
		.O                  		(lvds_dat0_rxdi	));

 	IDDRE1 #(
    	.DDR_CLK_EDGE				("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED				(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED				(1'b0			)) // Optional inversion for C
    IDDRE1_DAT0_IN	(
		.C							(lvds_fckp		), // 1-bit input: High-speed clock
		.CB							(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R							(1'B0			), // 1-bit input: Active-High Async Reset
  		.D							(lvds_dat0_rxdi	), // 1-bit input: Serial Data Input
		.Q1							(lvds_dat0_q0	), // 1-bit output: Registered parallel output 1
		.Q2							(lvds_dat0_q1	));// 1-bit output: Registered parallel output 2
//----------------------------------------------------------------------------------------------------------	
	IBUFDS						LVDS_DAT1_PAD	(
		.I                  		(lvds_dat1_inpp	),
		.IB                 		(lvds_dat1_inpn	),
		.O                  		(lvds_dat1_rxdi	));


	IDDRE1 #(
    	.DDR_CLK_EDGE				("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED				(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED				(1'b0			)) // Optional inversion for C
    IDDRE1_DAT1_IN	(
		.C							(lvds_fckp		), // 1-bit input: High-speed clock
		.CB							(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R							(1'B0			), // 1-bit input: Active-High Async Reset
  		.D							(lvds_dat1_rxdi	), // 1-bit input: Serial Data Input
		.Q1							(lvds_dat1_q0	), // 1-bit output: Registered parallel output 1
		.Q2							(lvds_dat1_q1	));// 1-bit output: Registered parallel output 2
//----------------------------------------------------------------------------------------------------------	
	IBUFDS						LVDS_DAT2_PAD	(
		.I                  		(lvds_dat2_inpp	),
		.IB                 		(lvds_dat2_inpn	),
		.O                  		(lvds_dat2_rxdi	));


	IDDRE1 #(
    	.DDR_CLK_EDGE				("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED				(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED				(1'b0			)) // Optional inversion for C
    IDDRE1_DAT2_IN	(
		.C							(lvds_fckp		), // 1-bit input: High-speed clock
		.CB							(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R							(1'B0			), // 1-bit input: Active-High Async Reset
  		.D							(lvds_dat2_rxdi	), // 1-bit input: Serial Data Input
		.Q1							(lvds_dat2_q0	), // 1-bit output: Registered parallel output 1
		.Q2							(lvds_dat2_q1	));// 1-bit output: Registered parallel output 2
//----------------------------------------------------------------------------------------------------------	
	IBUFDS						LVDS_DAT3_PAD	(
		.I                  		(lvds_dat3_inpp	),
		.IB                 		(lvds_dat3_inpn	),
		.O                  		(lvds_dat3_rxdi	));


	IDDRE1 #(
    	.DDR_CLK_EDGE				("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED				(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED				(1'b0			)) // Optional inversion for C
    IDDRE1_DAT3_IN	(
		.C							(lvds_fckp		), // 1-bit input: High-speed clock
		.CB							(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R							(1'B0			), // 1-bit input: Active-High Async Reset
  		.D							(lvds_dat3_rxdi	), // 1-bit input: Serial Data Input
		.Q1							(lvds_dat3_q0	), // 1-bit output: Registered parallel output 1
		.Q2							(lvds_dat3_q1	));// 1-bit output: Registered parallel output 2
/**********************************************************************************************************/
	reg		[ 1: 0]					lvds_fram_m2bo	;

	reg		[ 7: 0]					lvds_fram_mbdi	;
	reg		[ 7: 0]					lvds_dat0_mbdi	;
	reg		[ 7: 0]					lvds_dat1_mbdi	;
	reg		[ 7: 0]					lvds_dat2_mbdi	;
	reg		[ 7: 0]					lvds_dat3_mbdi	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(!lvds_rstn) begin
		lvds_fram_m2bo	<=	0	;
	end else begin	
		lvds_fram_m2bo	<=	lvds_fram_iddr	;
	end
//----------------------------------------------------------------------------------------------------------
	reg		[ 3: 0]					lvds_octs_shft= 4'H8;
	reg								lvds_rxdi_csen	;
	reg								lvds_rxdi_vlid	;

	wire							lvds_octs_wrcs	;	
	wire							lvds_fram_rise	;
	wire							lvds_fram_fall	;

	assign	lvds_octs_wrcs	=		lvds_octs_shft[3]	;

	assign	lvds_fram_rise	=  { 	lvds_fram_iddr , lvds_fram_m2bo }	==	4'HC	;
	assign	lvds_fram_fall	=  { 	lvds_fram_iddr , lvds_fram_m2bo }	==	4'H3	;
	
	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(~lvds_rstn)					lvds_rxdi_csen	<=	0	;
	else if(lvds_fram_rise)			lvds_rxdi_csen	<=	1	;
	else if(lvds_fram_fall)			lvds_rxdi_csen	<=	0	;

	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(!lvds_rstn)					lvds_rxdi_vlid	<=	0	;
	else 							lvds_rxdi_vlid	<=	lvds_rxdi_csen	;

	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(!lvds_rstn) 					lvds_octs_shft	<=	4'H8	;
	else if( lvds_fram_rise)		lvds_octs_shft	<=	4'H1	;
	else if( lvds_rxdi_csen)		lvds_octs_shft	<={ lvds_octs_shft[2:0] , lvds_octs_shft[3]};
	else 							lvds_octs_shft	<=	4'H0	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(!lvds_rstn) begin
		lvds_fram_mbdi	<=	0	;
		lvds_dat0_mbdi	<=	0	;
		lvds_dat1_mbdi	<=	0	;
		lvds_dat2_mbdi	<=	0	;
		lvds_dat3_mbdi	<=	0	;
	end else begin
		lvds_fram_mbdi	<= {lvds_fram_mbdi[5:0]	,	lvds_fram_iddr } ;//lvds_fram_m2bo	};
		lvds_dat0_mbdi	<= {lvds_dat0_mbdi[5:0]	,	lvds_dat0_iddr } ;//lvds_dat0_m2bo	};
		lvds_dat1_mbdi	<= {lvds_dat1_mbdi[5:0]	,	lvds_dat1_iddr } ;//lvds_dat1_m2bo	};
		lvds_dat2_mbdi	<= {lvds_dat2_mbdi[5:0]	,	lvds_dat2_iddr } ;//lvds_dat2_m2bo	};
		lvds_dat3_mbdi	<= {lvds_dat3_mbdi[5:0]	,	lvds_dat3_iddr } ;//lvds_dat3_m2bo	};
	end
//----------------------------------------------------------------------------------------------------------
	reg		[2: 0]					lvds_push_addr	;
	
	wire							lvds_push_csen	;
	wire							lvds_push_init	;
	wire							lvds_push_done	;
	wire	[39: 0]					lvds_push_meta	;
	wire	[39: 0]					lvds_push_data	;

	assign	lvds_push_csen	= |{  	lvds_octs_wrcs 	,	lvds_push_done	};
	assign	lvds_push_init	= &{   	lvds_rxdi_csen	, ~	lvds_rxdi_vlid	};
	assign	lvds_push_done	= &{  ~	lvds_rxdi_csen	,	lvds_rxdi_vlid	};

	assign	lvds_push_meta	=   {	lvds_fram_mbdi	,
									lvds_dat3_mbdi	,
									lvds_dat2_mbdi	,
									lvds_dat1_mbdi	,
									lvds_dat0_mbdi 	};

	assign	lvds_push_data	=	lvds_octs_wrcs	?	lvds_push_meta	:	40'H0	;

	always@(posedge lvds_fckp or negedge lvds_rstn)
	if(!lvds_rstn) 					lvds_push_addr	<=	0	;
	else if(lvds_push_init)			lvds_push_addr	<=	0	;
	else if(lvds_push_csen)			lvds_push_addr	<=	lvds_push_addr + 1	;
//----------------------------------------------------------------------------------------------------------
	reg		[2: 0]					link_pops_addr	;
	reg		[2: 0]					link_pops_enab	;
	reg								link_pops_csen	;
	reg								link_pops_sens	;
	
	wire	[39:0]					link_pops_data	;
	wire							link_pops_init	;
	wire							link_pops_done	;
	wire							link_pops_vlid	;				

	assign	link_pops_init	=		link_pops_enab[1:0]	==	2'H2		;
	assign	link_pops_vlid	= & {	link_pops_csen 	,link_pops_sens }	;
	assign	link_pops_done	=	{ 	link_pops_vlid 	,lvds_fram_mbdo	}	==	9'H100	;
	
	always@(posedge link_clki or negedge lvds_rstn)
	if(!lvds_rstn) 					link_pops_enab	<=	0	;
	else 							link_pops_enab	<={ lvds_rxdi_csen	,	link_pops_enab[2:1]	};

	always@(posedge link_clki or negedge lvds_rstn)
	if(!lvds_rstn) 					link_pops_csen	<=	0	;
	else if(link_pops_init)			link_pops_csen	<=  1 	;
	else if(link_pops_done)			link_pops_csen	<=  0 	;		
	
	always@(posedge link_clki or negedge lvds_rstn)
	if(!lvds_rstn) 					link_pops_sens	<=	0	;
	else 							link_pops_sens	<=  link_pops_csen 	;		
	
	always@(posedge link_clki or negedge lvds_rstn)
	if(!lvds_rstn) 					link_pops_addr	<=	0	;
	else if(link_pops_init)			link_pops_addr	<=	0	;
	else if(link_pops_done)			link_pops_addr	<=	0	;
	else if(link_pops_csen)			link_pops_addr	<=	link_pops_addr + 1	;
//----------------------------------------------------------------------
	assign	lvds_fram_mbdo	=		link_pops_vlid	?	link_pops_data[39:32] : 0	;
	assign	lvds_dat3_mbdo	=		link_pops_vlid	?	link_pops_data[31:24] : 0	;
	assign	lvds_dat2_mbdo	=		link_pops_vlid	?	link_pops_data[23:16] : 0	;
	assign	lvds_dat1_mbdo	=		link_pops_vlid	?	link_pops_data[15: 8] : 0	;
	assign	lvds_dat0_mbdo	=		link_pops_vlid	?	link_pops_data[ 7: 0] : 0	;
//----------------------------------------------------------------------
	dual_port_tags				u_rxdi_port_push_fifo(
		.wport_csen					(	lvds_push_csen	),
		.wport_addr					(	lvds_push_addr	),
		.wport_data					(	lvds_push_data	),
		.wport_clki					(	lvds_fckp		),

		.rport_addr					(	link_pops_addr	),
		.rport_data					(	link_pops_data	),
		.rport_clki					(	link_clki		));

endmodule 