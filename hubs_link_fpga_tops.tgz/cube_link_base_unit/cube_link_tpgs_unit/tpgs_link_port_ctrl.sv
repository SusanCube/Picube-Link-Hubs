/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"

module	tpgs_link_port_ctrl(
//TXDO CONTROL
	input		[ 7: 0]				tpgs_core_txdo_fram	,
	input		[ 7: 0]				tpgs_core_txdo_dat0	,
	input		[ 7: 0]				tpgs_core_txdo_dat1	,
	input		[ 7: 0]				tpgs_core_txdo_dat2	,
	input		[ 7: 0]				tpgs_core_txdo_dat3	,

	output		[ 7: 0]				tpgs_port_txdo_fram	,
	output		[ 7: 0]				tpgs_port_txdo_dat0	,
	output		[ 7: 0]				tpgs_port_txdo_dat1	,
	output		[ 7: 0]				tpgs_port_txdo_dat2	,
	output		[ 7: 0]				tpgs_port_txdo_dat3	,
//RXDI CONTROL
	input							tpgs_link_port_init	,
	input		[ 7: 0]				tpgs_port_rxdi_fram	,
	input		[ 7: 0]				tpgs_port_rxdi_dat0	,
	input		[ 7: 0]				tpgs_port_rxdi_dat1	,
	input		[ 7: 0]				tpgs_port_rxdi_dat2	,
	input		[ 7: 0]				tpgs_port_rxdi_dat3	,
	
	output							tpgs_rxdi_trim_mark	,
	output							tpgs_rxdi_icfg_mark	,
	output							tpgs_rxdi_ocfg_mark	,
	output							tpgs_rxdi_nnex_mark	,
	output							tpgs_rxdi_ivct_mark	,
	output							tpgs_rxdi_ovct_mark	,
	output							tpgs_rxdi_imtx_mark	,
	output							tpgs_rxdi_omtx_mark	,
	output							tpgs_rxdi_rivt_mark	,
	output							tpgs_rxdi_rovt_mark	,
	output							tpgs_rxdi_rimt_mark	,
	output							tpgs_rxdi_romt_mark	,
	output							tpgs_rxdi_risv_mark	,
	output							tpgs_rxdi_rosv_mark	,
	output							tpgs_rxdi_rism_mark	,
	output							tpgs_rxdi_rosm_mark	,
	output							tpgs_rxdi_aset_mark	,
	output							tpgs_rxdi_dnld_mark	,
	output							tpgs_rxdi_boot_mark	,
	output							tpgs_rxdi_auxi_mark	,

	output							tpgs_rxdi_cmnd_lead	,
	output							tpgs_rxdi_cmnd_wrcs	,
	output							tpgs_rxdi_cmnd_coda	,

	output							tpgs_rxdi_data_lead	,
	output							tpgs_rxdi_data_wrcs	,
	output		[31: 0]				tpgs_rxdi_data_word	,

	input							tpgs_sclk			,
	input							tpgs_rstn			);	
/**********************************************************************************************************/
//TPGS recover cmnd acmd data INTERFACE
	tpgs_link_rxdi_dmau 			u_tpgs_link_rxdi_dmau(
		.link_rxdi_port_init			(tpgs_link_port_init	),//input		
	
		.link_rxdi_fram_mbdi			(tpgs_port_rxdi_fram	),//input	[7:0]	
		.link_rxdi_dat0_mbdi			(tpgs_port_rxdi_dat0	),//input	[7:0]	
		.link_rxdi_dat1_mbdi			(tpgs_port_rxdi_dat1	),//input	[7:0]	
		.link_rxdi_dat2_mbdi			(tpgs_port_rxdi_dat2	),//input	[7:0]	
		.link_rxdi_dat3_mbdi			(tpgs_port_rxdi_dat3	),//input	[7:0]	
			
		.link_rxdi_trim_mark			(tpgs_rxdi_trim_mark	),//output	
		.link_rxdi_icfg_mark			(tpgs_rxdi_icfg_mark	),//output	
		.link_rxdi_ocfg_mark			(tpgs_rxdi_ocfg_mark	),//output	
		.link_rxdi_nnex_mark			(tpgs_rxdi_nnex_mark	),//output	
		.link_rxdi_ivct_mark			(tpgs_rxdi_ivct_mark	),//output	
		.link_rxdi_ovct_mark			(tpgs_rxdi_ovct_mark	),//output	
		.link_rxdi_imtx_mark			(tpgs_rxdi_imtx_mark	),//output	
		.link_rxdi_omtx_mark			(tpgs_rxdi_omtx_mark	),//output	
		.link_rxdi_rivt_mark			(tpgs_rxdi_rivt_mark	),//output	
		.link_rxdi_rovt_mark			(tpgs_rxdi_rovt_mark	),//output	
		.link_rxdi_rimt_mark			(tpgs_rxdi_rimt_mark	),//output	
		.link_rxdi_romt_mark			(tpgs_rxdi_romt_mark	),//output	
		.link_rxdi_risv_mark			(tpgs_rxdi_risv_mark	),//output	
		.link_rxdi_rosv_mark			(tpgs_rxdi_rosv_mark	),//output	
		.link_rxdi_rism_mark			(tpgs_rxdi_rism_mark	),//output	
		.link_rxdi_rosm_mark			(tpgs_rxdi_rosm_mark	),//output	
		.link_rxdi_aset_mark			(tpgs_rxdi_aset_mark	),//output	
		.link_rxdi_dnld_mark			(tpgs_rxdi_dnld_mark	),//output	
		.link_rxdi_boot_mark			(tpgs_rxdi_boot_mark	),//output	
		.link_rxdi_auxi_mark			(tpgs_rxdi_auxi_mark	),//output	
		
		.link_rxdi_cmnd_lead			(tpgs_rxdi_cmnd_lead	),//output	reg			
		.link_rxdi_cmnd_wrcs			(tpgs_rxdi_cmnd_wrcs	),//output	reg			
		.link_rxdi_cmnd_coda			(tpgs_rxdi_cmnd_coda	),//output	reg			
			
		.link_rxdi_data_lead			(tpgs_rxdi_data_lead	),//output	reg			
		.link_rxdi_data_wrcs			(tpgs_rxdi_data_wrcs	),//output	reg			
		.link_rxdi_data_word			(tpgs_rxdi_data_word	),//output	reg	[31: 0]	
	
		.link_clki						(tpgs_sclk				),//input	
		.link_rstn						(tpgs_rstn				));//input			
/**********************************************************************************************************/
//TPGS transimitter ack response data INTERFACE
	link_slav_txdo_port			u_tpgs_txdo_port (	
		.link_txdo_fram_mbdi		(tpgs_core_txdo_fram	),//input	[7:0]	
		.link_txdo_dat0_mbdi		(tpgs_core_txdo_dat0	),//input	[7:0]	
		.link_txdo_dat1_mbdi		(tpgs_core_txdo_dat1	),//input	[7:0]	
		.link_txdo_dat2_mbdi		(tpgs_core_txdo_dat2	),//input	[7:0]	
		.link_txdo_dat3_mbdi		(tpgs_core_txdo_dat3	),//input	[7:0]	

		.link_txdo_fram_mbdo		(tpgs_port_txdo_fram	),//output	reg	[7:0]
		.link_txdo_dat0_mbdo		(tpgs_port_txdo_dat0	),//output	reg	[7:0]
		.link_txdo_dat1_mbdo		(tpgs_port_txdo_dat1	),//output	reg	[7:0]
		.link_txdo_dat2_mbdo		(tpgs_port_txdo_dat2	),//output	reg	[7:0]
		.link_txdo_dat3_mbdo		(tpgs_port_txdo_dat3	),//output	reg	[7:0]
	
		.link_clki					(tpgs_sclk				),//input	
		.link_rstn					(tpgs_rstn				));//input	

endmodule
 	
