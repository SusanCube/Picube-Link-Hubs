module	cube_edge_wdma_muxs (
	input	[ 0: 7]	[255: 0]		cube_wdma_mtrx_data	,
	input	[ 0: 7]	[ 24: 0]		cube_wdma_mtrx_addr	,
	input	[ 0: 7]					cube_wdma_mtrx_drdy	,				
	
	output	reg	[255: 0]			cube_wdma_mono_data	,
	output	reg	[ 24: 0]			cube_wdma_mono_addr	,
	output	reg						cube_wdma_mono_drdy	,				
	
	input							cube_clki			,
	input							cube_rstn			);
/**********************************************************************************************************/
	reg		[ 0: 1][255: 0]			cube_idat_lvl0_data	;
	reg		[ 0: 1][ 24: 0]			cube_idat_lvl0_addr	;
	reg		[ 0: 1]					cube_idat_lvl0_drdy	;				
/**********************************************************************************************************/
	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_data[0]	<=	0	;
	else if(cube_wdma_mtrx_drdy[0])	cube_idat_lvl0_data[0]	<=	cube_wdma_mtrx_data[0]	;
	else if(cube_wdma_mtrx_drdy[1])	cube_idat_lvl0_data[0]	<=	cube_wdma_mtrx_data[1]	;
	else if(cube_wdma_mtrx_drdy[2])	cube_idat_lvl0_data[0]	<=	cube_wdma_mtrx_data[2]	;
	else 							cube_idat_lvl0_data[0]	<=	cube_wdma_mtrx_data[3]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_data[1]	<=	0	;
	else if(cube_wdma_mtrx_drdy[4])	cube_idat_lvl0_data[1]	<=	cube_wdma_mtrx_data[4]	;
	else if(cube_wdma_mtrx_drdy[5])	cube_idat_lvl0_data[1]	<=	cube_wdma_mtrx_data[5]	;
	else if(cube_wdma_mtrx_drdy[6])	cube_idat_lvl0_data[1]	<=	cube_wdma_mtrx_data[6]	;
	else 							cube_idat_lvl0_data[1]	<=	cube_wdma_mtrx_data[7]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_addr[0]	<=	0	;
	else if(cube_wdma_mtrx_drdy[0])	cube_idat_lvl0_addr[0]	<=	cube_wdma_mtrx_addr[0]	;
	else if(cube_wdma_mtrx_drdy[1])	cube_idat_lvl0_addr[0]	<=	cube_wdma_mtrx_addr[1]	;
	else if(cube_wdma_mtrx_drdy[2])	cube_idat_lvl0_addr[0]	<=	cube_wdma_mtrx_addr[2]	;
	else 							cube_idat_lvl0_addr[0]	<=	cube_wdma_mtrx_addr[3]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_addr[1]	<=	0	;
	else if(cube_wdma_mtrx_drdy[4])	cube_idat_lvl0_addr[1]	<=	cube_wdma_mtrx_addr[4]	;
	else if(cube_wdma_mtrx_drdy[5])	cube_idat_lvl0_addr[1]	<=	cube_wdma_mtrx_addr[5]	;
	else if(cube_wdma_mtrx_drdy[6])	cube_idat_lvl0_addr[1]	<=	cube_wdma_mtrx_addr[6]	;
	else 							cube_idat_lvl0_addr[1]	<=	cube_wdma_mtrx_addr[7]	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_drdy[0]	<=	0	;
	else 							cube_idat_lvl0_drdy[0]	<= |cube_wdma_mtrx_drdy[0:3];

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_idat_lvl0_drdy[1]	<=	0	;
	else 							cube_idat_lvl0_drdy[1]	<= |cube_wdma_mtrx_drdy[4:7];
/**********************************************************************************************************/
	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_wdma_mono_data	<=	0	;
	else if(cube_idat_lvl0_drdy[0])	cube_wdma_mono_data	<=	cube_idat_lvl0_data[0]	;
	else if(cube_idat_lvl0_drdy[1])	cube_wdma_mono_data	<=	cube_idat_lvl0_data[1]	;
	else							cube_wdma_mono_data	<=	0	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_wdma_mono_addr	<=	0	;
	else if(cube_idat_lvl0_drdy[0])	cube_wdma_mono_addr	<=	cube_idat_lvl0_addr[0]	;
	else if(cube_idat_lvl0_drdy[1])	cube_wdma_mono_addr	<=	cube_idat_lvl0_addr[1]	;
	else							cube_wdma_mono_addr	<=	0	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn)					cube_wdma_mono_drdy	<=	0	;
	else 							cube_wdma_mono_drdy	<= |cube_idat_lvl0_drdy[0:1];
/**********************************************************************************************************/


endmodule