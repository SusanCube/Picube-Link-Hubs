/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	cube_idat_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_edge_wdma_idat(
	output		[137:0]				uila_tpes_wdma_ddrs	,					

	input							this_tpgs_pile_lead	,
	input		[ 4: 0]				this_tpgs_edge_base	,
	input		[ 3: 0]				ecos_omni_pile_numb	,
	

	input		[24 : 0]			llmb_mast_ddrs_base	,
	input		[19 : 0]			llmb_meta_imag_cols	,
	input		[19 : 0]			llmb_devs_imag_cols	,

	input							llmb_edge_imag_even	,//0:ODD 1: EVEN
	input		[24 : 0]			llmb_edge_imag_size	,
	input		[19 : 0]			llmb_edge_imag_cols	,

	input							cube_edge_wdma_enab	,//write enable
	input							cube_edge_wdma_mode	,//0:VECT 1: MTRX
	output							cube_edge_wdma_done	,
	
	input							cube_edge_idat_lead	,
	input							cube_edge_idat_wrcs	,
	input		[ 31: 0]			cube_edge_idat_data	,

	input							link_clki			,
	input							link_rstn			,

	input							cube_edge_wdma_init	,	
	input							cube_edge_wdma_reqs	,	
	input		[ 3: 0]				cube_edge_wdma_size	,

	output							cube_edge_wdma_ov16	,
	output							cube_edge_wdma_ov08	,
	output							cube_edge_wdma_ov04	,
	output							cube_edge_wdma_ov02	,
	

	output		[255: 0]			ubus_edge_wdma_data	,
	output		[ 24: 0]			ubus_edge_wdma_addr	,
	output	reg						ubus_edge_wdma_drdy	,				
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg			[  3: 0]			cube_idat_wdma_samp	;

	wire							cube_idat_wdma_disa	;
	wire							cube_idat_wdma_prep	;
	wire							cube_idat_wdma_init	;

	assign	cube_idat_wdma_disa	= 	cube_idat_wdma_samp[2:0] ==	3'B000	;	
	assign	cube_idat_wdma_prep	= 	cube_idat_wdma_samp[2:0] ==	3'B100	;
	assign	cube_idat_wdma_init	= 	cube_idat_wdma_samp[2:0] ==	3'B110	;

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					cube_idat_wdma_samp	<=	0	;
	else							cube_idat_wdma_samp	<={	cube_edge_wdma_enab	, cube_idat_wdma_samp[3:1]	};	
/**********************************************************************************************************/
	reg			[  4: 0]			this_tpgs_edge_indx	;
	
	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					this_tpgs_edge_indx	<=	0	;
	else if(cube_idat_wdma_disa)	this_tpgs_edge_indx	<=	this_tpgs_edge_base	+	llmb_edge_imag_even	;
/**********************************************************************************************************/
	reg			[  2: 0]			cube_idat_word_cnts	;
	reg			[ 15: 0]			cube_idat_page_cnts	;
	reg			[255: 0]			cube_idat_page_data	;
	reg								cube_idat_page_wrcs	;	
//	reg								cube_idat_rows_next	;	
	
	wire							idat_rows_page_wrcs	;
	wire							idat_rows_page_last	;
	
	assign	idat_rows_page_wrcs	= &{cube_edge_idat_wrcs	,	cube_idat_word_cnts	};
	assign	idat_rows_page_last	= &{idat_rows_page_wrcs	,	cube_idat_page_cnts+1 == llmb_edge_imag_cols[19:4]	};
	
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_word_cnts	<=	0	;
	else if(cube_idat_wdma_disa)	cube_idat_word_cnts	<=	0	;
	else if(cube_edge_idat_lead)	cube_idat_word_cnts	<=	0	;
	else 							cube_idat_word_cnts	<=	cube_idat_word_cnts	+	cube_edge_idat_wrcs	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_cnts	<=	0	;
	else if(cube_idat_wdma_disa)	cube_idat_page_cnts	<=	0	;
	else if(idat_rows_page_last)	cube_idat_page_cnts	<=	0	;
	else 							cube_idat_page_cnts	<=	cube_idat_page_cnts	+	idat_rows_page_wrcs	;	

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_data	<=	0	;
	else if(cube_edge_idat_lead)	cube_idat_page_data	<=	0	;
	else if(cube_edge_idat_wrcs)	cube_idat_page_data	<={	cube_edge_idat_data			,	cube_idat_page_data[255:32]};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_wrcs	<=	0	;
	else							cube_idat_page_wrcs	<=	idat_rows_page_wrcs	;
/**********************************************************************************************************/
	reg			[24: 0]				mtrx_idat_wdma_base	;
	reg			[24: 0]				mtrx_idat_wdma_ofst	;
		
	wire		[19: 0]				mtrx_tpgs_edge_bias	;
	wire		[19: 0]				mtrx_next_rows_skip	;
	
	assign	mtrx_tpgs_edge_bias	=	this_tpgs_edge_indx	*	llmb_edge_imag_cols	;
	assign	mtrx_next_rows_skip	=	this_tpgs_pile_lead	?	llmb_meta_imag_cols * ecos_omni_pile_numb :	llmb_devs_imag_cols	;

	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					mtrx_idat_wdma_base	<=	0	;
	else if(cube_idat_wdma_disa)	mtrx_idat_wdma_base	<=	0	;
	else if(cube_idat_wdma_prep)	mtrx_idat_wdma_base	<=	llmb_mast_ddrs_base	+ mtrx_tpgs_edge_bias[19:4]	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					mtrx_idat_wdma_ofst	<=	0	;
	else if(cube_idat_wdma_disa)	mtrx_idat_wdma_ofst	<=	0	;
	else if(cube_idat_wdma_prep)	mtrx_idat_wdma_ofst	<=	mtrx_next_rows_skip[19:4]	;
	else if(idat_rows_page_last) 	mtrx_idat_wdma_ofst	<=	mtrx_idat_wdma_ofst + mtrx_next_rows_skip[19:4]	;
//--------------
	reg			[24: 0]				vect_idat_wdma_base	;
	
	wire		[24: 0]				vect_tpgs_edge_bias	;
	
	assign	vect_tpgs_edge_bias	=	this_tpgs_edge_indx	*	llmb_edge_imag_size	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					vect_idat_wdma_base	<=	0	;
	else if(cube_idat_wdma_disa)	vect_idat_wdma_base	<=	0	;
	else if(cube_idat_wdma_prep)	vect_idat_wdma_base	<=	llmb_mast_ddrs_base	+ vect_tpgs_edge_bias		;
/**********************************************************************************************************/
	reg			[ 24: 0]			cube_idat_wdma_addr	;
	reg			[ 24: 0]			cube_idat_wdma_wadd	;

	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					cube_idat_wdma_addr	<=	0	;
	else if(cube_idat_wdma_disa)	cube_idat_wdma_addr	<=	0	;
	else if(cube_idat_wdma_prep)	cube_idat_wdma_addr	<=	0	;
	else if(cube_idat_wdma_init)	cube_idat_wdma_addr	<=	cube_edge_wdma_mode	?	mtrx_idat_wdma_base	:	vect_idat_wdma_base	;
	else if(idat_rows_page_last)	cube_idat_wdma_addr	<=	cube_edge_wdma_mode	?	mtrx_idat_wdma_base +	mtrx_idat_wdma_ofst	:
																					cube_idat_wdma_addr	+	1					;
	else if(idat_rows_page_wrcs)	cube_idat_wdma_addr	<=	cube_idat_wdma_addr	+	1					;


	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					cube_idat_wdma_wadd	<=	0	;
	else							cube_idat_wdma_wadd	<=	cube_idat_wdma_addr	;
	
/**********************************************************************************************************/
	reg			[ 24: 0]			cube_wdma_push_cnts	;

	wire	[  8:  0]				cube_idat_push_dptr	;

	assign	cube_idat_push_dptr	=	cube_wdma_push_cnts[8:0]	;
	assign	cube_edge_wdma_done	= &{cube_edge_wdma_enab	,	cube_wdma_push_cnts	== llmb_edge_imag_size };
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					cube_wdma_push_cnts	<=	0	;	
	else if(cube_idat_wdma_disa)	cube_wdma_push_cnts	<=	0	;	
	else 							cube_wdma_push_cnts	<=	cube_wdma_push_cnts + cube_idat_page_wrcs	;	
/**********************************************************************************************************/
	reg		[ 24: 0]				ubus_wdma_pops_cnts	;
	reg		[  3: 0]				ubus_wdma_page_cnts	;

	wire	[  8: 0]				ubus_idat_pops_dptr	;
	wire	[  8: 0]				ubus_idat_wdma_lsba	;
	wire	[  8: 0]				ubus_idat_wdma_nxta	;	
	wire							cube_idat_wdma_last	;
	
	assign	ubus_idat_wdma_lsba	=	ubus_wdma_pops_cnts[8:0]	;
	assign	ubus_idat_wdma_nxta	=	ubus_idat_wdma_lsba +  1	;
	
	assign	ubus_idat_pops_dptr	=	ubus_edge_wdma_drdy	?	ubus_idat_wdma_nxta	:	ubus_idat_wdma_lsba	;
	assign	cube_idat_wdma_last	= &{ubus_edge_wdma_drdy	,	ubus_wdma_page_cnts	==	cube_edge_wdma_size};

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_edge_wdma_drdy	<=	0	;
	else if(cube_edge_wdma_init)	ubus_edge_wdma_drdy	<=	0	;	
	else if(cube_edge_wdma_reqs)	ubus_edge_wdma_drdy	<=	1	;	
	else if(cube_idat_wdma_last)	ubus_edge_wdma_drdy	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_wdma_page_cnts	<=	0	;	
	else if(cube_edge_wdma_init)	ubus_wdma_page_cnts	<=	0	;	
	else if(cube_edge_wdma_reqs)	ubus_wdma_page_cnts	<=	0	;	
	else if(cube_idat_wdma_last)	ubus_wdma_page_cnts	<=	0	;	
	else 							ubus_wdma_page_cnts	<=	ubus_wdma_page_cnts	+ ubus_edge_wdma_drdy ;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_wdma_pops_cnts	<=	0	;	
	else if(cube_edge_wdma_init)	ubus_wdma_pops_cnts	<=	0	;	
	else 							ubus_wdma_pops_cnts	<=	ubus_wdma_pops_cnts + ubus_edge_wdma_drdy	;	
/**********************************************************************************************************/
	wire		[24: 0]				cube_wdma_push_sync;
	wire		[24: 0]				cube_wdma_resv_numb	;

	assign	cube_wdma_resv_numb	=	cube_wdma_push_sync	-	ubus_wdma_pops_cnts	;
	assign	cube_edge_wdma_ov16	= |	cube_wdma_resv_numb[24:4]	;
	assign	cube_edge_wdma_ov08	= |	cube_wdma_resv_numb[24:3]	;
	assign	cube_edge_wdma_ov04	= |	cube_wdma_resv_numb[24:2]	;
	assign	cube_edge_wdma_ov02	= |	cube_wdma_resv_numb[24:1]	;
	

	gens_sync_gray	#( .MSB(24) )
								u_idat_dptr_sync_gens(
		.data_asyn					(cube_wdma_push_cnts	),//input	[24: 0]	
		.scki						(link_clki				),
		
		.data_sync					(cube_wdma_push_sync	),//output	[24: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_idat_wdma_beat_data (
		.wport_csen					(cube_idat_page_wrcs	),//input  				 		
		.wport_data					(cube_idat_page_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(cube_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(link_clki				),//input						

		.rport_addr					(ubus_idat_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_edge_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
	u_idat_wdma_beat_addr (
		.wport_csen					(cube_idat_page_wrcs	),//input  				 		
		.wport_addr					(cube_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(cube_idat_wdma_wadd	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						
		
		.rport_addr					(ubus_idat_pops_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_edge_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						


	assign	uila_tpes_wdma_ddrs	={	this_tpgs_pile_lead	// 		total 11bits
								,	cube_edge_wdma_mode	//
								,	cube_edge_idat_lead	//			total  13bits
								,	cube_edge_idat_wrcs	//	
								,	idat_rows_page_wrcs	//	
								,	idat_rows_page_last	//	
								,	this_tpgs_edge_base	//[4:0]			total  132bits		
								,	ecos_omni_pile_numb	//[3:0]
								,	cube_idat_push_dptr	//[8:0]			total  123bits		

								,	cube_idat_word_cnts	//[2:0]			total  114bits		
								,	cube_idat_page_cnts	//[15:0]						
								,	mtrx_next_rows_skip	//[19:0]
								,	mtrx_idat_wdma_base	//[24:0]
								,	mtrx_idat_wdma_ofst	//[24:0]
								,	cube_idat_wdma_wadd	//[24:0]
	};




endmodule 
 
/*
	ila_138	uila_tpgm_rdma_ddrs(
				.clk	(ubus_clki				)	,
				.probe0	({  
							this_tpgs_pile_lead	// 		total 11bits
						,	cube_edge_wdma_mode	//
						,	this_tpgs_edge_base	//[4:0]	
						,	ecos_omni_pile_numb	//[3:0]
						,	cube_edge_idat_lead	//			total  13bits
						,	cube_edge_idat_wrcs	//	
						,	idat_rows_page_wrcs	//	
						,	idat_rows_page_last	//	
						,	cube_idat_push_dptr	//[8:0]					total  113bits		

						,	cube_idat_word_cnts	//[2:0]					total  104bits		
						,	cube_idat_page_cnts	//[15:0]						
						,	mtrx_next_rows_skip	//[19:0]
						,	mtrx_idat_wdma_base	//[24:0]
						,	mtrx_idat_wdma_ofst	//[24:0]
						,	cube_idat_wdma_wadd	//[24:0]
						})
	);

*/ 