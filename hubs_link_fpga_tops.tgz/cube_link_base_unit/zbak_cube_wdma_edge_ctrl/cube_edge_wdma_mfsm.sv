//----------------------------------------------------------------------------------------------------------
module cube_edge_wdma_mfsm(
	input							edge_wdma_mfsm_enab	,
	input							edge_wdma_pack_done	,

	input		[ 0: 7]				cube_edge_fifo_ov16	,
	input		[ 0: 7]				cube_edge_fifo_ov08	,
	input		[ 0: 7]				cube_edge_fifo_ov04	,
	input		[ 0: 7]				cube_edge_fifo_ov02	,
	
	output							cube_edge_wdma_init	,
	output		[ 0: 7]				cube_edge_wdma_reqs	,
	output	reg	[ 3: 0]				cube_edge_wdma_size	,
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************/
	wire							cube_idat_ov16_case	;
	wire							cube_idat_ov08_case	;
	wire							cube_idat_ov04_case	;
	wire							cube_idat_ov02_case	;
	wire							cube_idat_ovfl_case	;
	
	wire  		[ 3: 0]				cube_idat_ov16_port	;
	wire  		[ 3: 0]				cube_idat_ov08_port	;
	wire  		[ 3: 0]				cube_idat_ov04_port	;
	wire  		[ 3: 0]				cube_idat_ov02_port	;
	
	wire  		[ 3: 0]				cube_idat_seek_port	;
	wire  		[ 3: 0]				cube_idat_seek_leng	;
		
	assign	cube_idat_ov16_case	= |	cube_edge_fifo_ov16	;
	assign	cube_idat_ov08_case	= |	cube_edge_fifo_ov08	;
	assign	cube_idat_ov04_case	= |	cube_edge_fifo_ov04	;
	assign	cube_idat_ov02_case	= |	cube_edge_fifo_ov02	;

	assign	cube_idat_ovfl_case	= |{cube_idat_ov16_case	,	
									cube_idat_ov08_case	,
									cube_idat_ov04_case	, 	
									cube_idat_ov02_case};

	assign	cube_idat_ov16_port	=	cube_edge_fifo_ov16[0]	?	4'H0	:	
									cube_edge_fifo_ov16[1]	?	4'H1	:	
									cube_edge_fifo_ov16[2]	?	4'H2	:
									cube_edge_fifo_ov16[3]	?	4'H3	:
									cube_edge_fifo_ov16[4]	?	4'H4	:
									cube_edge_fifo_ov16[5]	?	4'H5	:
									cube_edge_fifo_ov16[6]	?	4'H6	:
									cube_edge_fifo_ov16[7]	?	4'H7	:	4'HF	;

	assign	cube_idat_ov08_port	=	cube_edge_fifo_ov08[0]	?	4'H0	:	
									cube_edge_fifo_ov08[1]	?	4'H1	:	
									cube_edge_fifo_ov08[2]	?	4'H2	:
									cube_edge_fifo_ov08[3]	?	4'H3	:
									cube_edge_fifo_ov08[4]	?	4'H4	:
									cube_edge_fifo_ov08[5]	?	4'H5	:
									cube_edge_fifo_ov08[6]	?	4'H6	:
									cube_edge_fifo_ov08[7]	?	4'H7	:	4'HF	;
									
	assign	cube_idat_ov04_port	=	cube_edge_fifo_ov04[0]	?	4'H0	:	
									cube_edge_fifo_ov04[1]	?	4'H1	:	
									cube_edge_fifo_ov04[2]	?	4'H2	:
									cube_edge_fifo_ov04[3]	?	4'H3	:
									cube_edge_fifo_ov04[4]	?	4'H4	:
									cube_edge_fifo_ov04[5]	?	4'H5	:
									cube_edge_fifo_ov04[6]	?	4'H6	:
									cube_edge_fifo_ov04[7]	?	4'H7	:	4'HF	;

	assign	cube_idat_ov02_port	=	cube_edge_fifo_ov02[0]	?	4'H0	:	
									cube_edge_fifo_ov02[1]	?	4'H1	:	
									cube_edge_fifo_ov02[2]	?	4'H2	:
									cube_edge_fifo_ov02[3]	?	4'H3	:
									cube_edge_fifo_ov02[4]	?	4'H4	:
									cube_edge_fifo_ov02[5]	?	4'H5	:
									cube_edge_fifo_ov02[6]	?	4'H6	:
									cube_edge_fifo_ov02[7]	?	4'H7	:	4'HF	;

	assign	cube_idat_seek_leng	=	cube_idat_ov16_case		?	4'HF	:
									cube_idat_ov08_case		?	4'H7	:
									cube_idat_ov04_case		?	4'H3	:
									cube_idat_ov02_case		?	4'H1	:	4'H0	;

	assign	cube_idat_seek_port	=	cube_idat_ov16_case		?	cube_idat_ov16_port	:
									cube_idat_ov08_case		?	cube_idat_ov08_port	:
									cube_idat_ov04_case		?	cube_idat_ov04_port	:	
									cube_idat_ov02_case		?	cube_idat_ov02_port	:	4'HF	;
/**********************************************************************/
	reg		[ 2: 0]					cube_idat_load_mfsm	;
	reg		[ 3: 0]					cube_idat_load_port	;

	parameter	CUBE_IDAT_LOAD_IDLE	=	3'H0	;
	parameter	CUBE_IDAT_LOAD_INIT	=	3'H1	;
	parameter	CUBE_IDAT_LOAD_SEEK	=	3'H2	;
	parameter	CUBE_IDAT_LOAD_REQS	=	3'H3	;
	parameter	CUBE_IDAT_LOAD_DATA	=	3'H4	;
	
	assign 	cube_edge_wdma_init	 =	cube_idat_load_mfsm	==	CUBE_IDAT_LOAD_INIT	;
	wire	cube_idat_load_seek	 =	cube_idat_load_mfsm	==	CUBE_IDAT_LOAD_SEEK	;
	wire   	cube_idat_load_reqx	 =	cube_idat_load_mfsm	==	CUBE_IDAT_LOAD_REQS	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					cube_idat_load_mfsm	<=	CUBE_IDAT_LOAD_IDLE	;
	else if(~edge_wdma_mfsm_enab)	cube_idat_load_mfsm	<=	CUBE_IDAT_LOAD_IDLE	;
	else begin
		case(cube_idat_load_mfsm)	
			CUBE_IDAT_LOAD_IDLE	:	cube_idat_load_mfsm	<=							CUBE_IDAT_LOAD_INIT	;
			CUBE_IDAT_LOAD_INIT	:	cube_idat_load_mfsm	<=							CUBE_IDAT_LOAD_SEEK	;
			CUBE_IDAT_LOAD_SEEK	:	cube_idat_load_mfsm	<=	cube_idat_ovfl_case	?	CUBE_IDAT_LOAD_REQS	:	CUBE_IDAT_LOAD_SEEK	;
			CUBE_IDAT_LOAD_REQS	:	cube_idat_load_mfsm	<=							CUBE_IDAT_LOAD_DATA	;
			CUBE_IDAT_LOAD_DATA	:	cube_idat_load_mfsm	<=	edge_wdma_pack_done	?	CUBE_IDAT_LOAD_SEEK	:	CUBE_IDAT_LOAD_DATA;
			default	:				cube_idat_load_mfsm	<=							CUBE_IDAT_LOAD_IDLE	;
		endcase
	end
/**********************************************************************/
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					cube_edge_wdma_size	<=	0	;
	else if(cube_idat_load_seek)	cube_edge_wdma_size	<=	cube_idat_ovfl_case	?	cube_idat_seek_leng	:	5'H0	;
	else							cube_edge_wdma_size	<=	cube_edge_wdma_size	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					cube_idat_load_port	<=	4'HF	;
	else if(cube_idat_load_seek)	cube_idat_load_port	<=	cube_idat_ovfl_case	?	cube_idat_seek_port	:	4'HF	;
	else							cube_idat_load_port	<=	cube_idat_load_port	;	
/**********************************************************************/
	assign 	cube_edge_wdma_reqs[0]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H0	};
	assign 	cube_edge_wdma_reqs[1]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H1	};
	assign 	cube_edge_wdma_reqs[2]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H2	};
	assign 	cube_edge_wdma_reqs[3]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H3	};
	assign 	cube_edge_wdma_reqs[4]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H4	};
	assign 	cube_edge_wdma_reqs[5]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H5	};
	assign 	cube_edge_wdma_reqs[6]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H6	};
	assign 	cube_edge_wdma_reqs[7]=&{cube_idat_load_reqx , cube_idat_load_port == 4'H7	};
	


endmodule										

 