
module	cube_edge_wdma_ddrs(
	input							ubus_wdma_fifo_enab	,
	input		[24: 0]				cube_wdma_fifo_wcnt	,
	
	output	reg	[24: 0]				ubus_rdma_ddrs_rcnt	,
	output							ubus_rdma_ddrs_rreq	,
	input							ubus_rdma_ddrs_rrdy	,
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************/
	reg			[1: 0]				ubus_rdma_ddrs_mfsm	;
	reg			[3: 0]				ubus_rdma_ddrs_cnts	;
	reg			[3: 0]				ubus_rdma_ddrs_size	;
	
	
	parameter	UBUS_RDMA_DDRS_IDLE	=	2'H0	;
	parameter	UBUS_RDMA_DDRS_SEEK	=	2'H1	;
	parameter	UBUS_RDMA_DDRS_RREQ	=	2'H2	;
	
	wire		ubus_rdma_ddrs_gt04	=	cube_wdma_fifo_wcnt	>=	ubus_rdma_ddrs_rcnt + 4	;
	wire		ubus_rdma_ddrs_gt08	=	cube_wdma_fifo_wcnt	>=	ubus_rdma_ddrs_rcnt + 8	;
	wire		ubus_rdma_ddrs_gt16	=	cube_wdma_fifo_wcnt	>=	ubus_rdma_ddrs_rcnt +16	;

	wire		ubus_rdma_ddrs_done	;
	wire		ubus_rdma_ddrs_ovfl	= |{ubus_rdma_ddrs_gt04		,	
										ubus_rdma_ddrs_gt08		,	
										ubus_rdma_ddrs_gt16	   };
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_ddrs_mfsm	<=	UBUS_RDMA_DDRS_IDLE	;
	else if(~ubus_wdma_fifo_enab)	ubus_rdma_ddrs_mfsm	<=	UBUS_RDMA_DDRS_IDLE	;
	else begin
		case(ubus_rdma_ddrs_mfsm)
			UBUS_RDMA_DDRS_IDLE	:	ubus_rdma_ddrs_mfsm	<=													UBUS_RDMA_DDRS_SEEK	;
			UBUS_RDMA_DDRS_SEEK	:	ubus_rdma_ddrs_mfsm	<=	ubus_rdma_ddrs_ovfl	?	UBUS_RDMA_DDRS_RREQ	:	UBUS_RDMA_DDRS_SEEK	;	
			UBUS_RDMA_DDRS_RREQ	:	ubus_rdma_ddrs_mfsm	<=	ubus_rdma_ddrs_done	?	UBUS_RDMA_DDRS_SEEK	:	UBUS_RDMA_DDRS_RREQ	;
		endcase
	end

	wire		ubus_rdma_ddrs_seek	=	ubus_rdma_ddrs_mfsm	==	UBUS_RDMA_DDRS_SEEK	;
	assign		ubus_rdma_ddrs_rreq	=	ubus_rdma_ddrs_mfsm	==	UBUS_RDMA_DDRS_RREQ	;
/**********************************************************************/
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_ddrs_rcnt	<=	0	;
	else if(~ubus_wdma_fifo_enab)	ubus_rdma_ddrs_rcnt	<=	0	;		
	else if( ubus_rdma_ddrs_rreq)	ubus_rdma_ddrs_rcnt	<=	ubus_rdma_ddrs_rcnt	+ 	ubus_rdma_ddrs_rrdy	;	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_ddrs_size	<=	0	;
	else if(~ubus_wdma_fifo_enab)	ubus_rdma_ddrs_size	<=	0	;		
	else if( ubus_rdma_ddrs_seek)	ubus_rdma_ddrs_size	<=	ubus_rdma_ddrs_gt04	? 	4'H3	:
															ubus_rdma_ddrs_gt08	? 	4'H7	:
															ubus_rdma_ddrs_gt16	? 	4'HF	:	4'H0	;		

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_ddrs_cnts	<=	0	;
	else if( ubus_rdma_ddrs_rreq)	ubus_rdma_ddrs_cnts	<=	ubus_rdma_ddrs_cnts + 	ubus_rdma_ddrs_rrdy	;		
	else							ubus_rdma_ddrs_cnts	<=	0	;


	assign	ubus_rdma_ddrs_done	= &{ubus_rdma_ddrs_rrdy	,	ubus_rdma_ddrs_rreq	,
									ubus_rdma_ddrs_cnts	==	ubus_rdma_ddrs_size	};
	  
endmodule
 