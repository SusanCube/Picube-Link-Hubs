/*----author edward------*/
module	mast_isde_wdma_arbit(
	input							mast_devs_isde_enab	,
	input		[ 3: 1]				mast_devs_isde_port	,
	output							mast_devs_isde_done	,

	input							link_clki			,
	input							link_rstn			,

	output							mast_dev1_wdma_enab	,
	input							mast_dev1_wdma_done	,
	input							mast_dev1_wdma_reqs	,
	output							ubus_dev1_wdma_vlid	,
	input		[24: 0]				mast_dev1_wdma_addr	,
	input		[255:0]				mast_dev1_wdma_data	,
	
	output							mast_dev2_wdma_enab	,
	input							mast_dev2_wdma_done	,
	input							mast_dev2_wdma_reqs	,
	output							ubus_dev2_wdma_vlid	,
	input		[24: 0]				mast_dev2_wdma_addr	,
	input		[255:0]				mast_dev2_wdma_data	,
	
	output							mast_dev3_wdma_enab	,
	input							mast_dev3_wdma_done	,
	input							mast_dev3_wdma_reqs	,
	output							ubus_dev3_wdma_vlid	,
	input		[24: 0]				mast_dev3_wdma_addr	,
	input		[255:0]				mast_dev3_wdma_data	,

	output							ubus_isde_wdma_csen	,
	output		[ 24: 0]			ubus_isde_wdma_addr	,
	output		[255: 0]			ubus_isde_wdma_data	,
	input							ubus_isde_wdma_trdy	,
	input							ubus_isde_wdma_wrdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg								mast_dev1_isde_enab	;
	reg								mast_dev2_isde_enab	;
	reg								mast_dev3_isde_enab	;

	wire		[2:0]				devs_isde_enab_case	;

	assign	devs_isde_enab_case	= {	mast_dev3_isde_enab	,	mast_dev2_isde_enab	,	mast_dev1_isde_enab	};

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					begin
		mast_dev1_isde_enab	<=	0	;
		mast_dev2_isde_enab	<=	0	;
		mast_dev3_isde_enab	<=	0	;
	end else begin	
		mast_dev1_isde_enab	<=	mast_devs_isde_enab	&	mast_devs_isde_port[1]	;
		mast_dev2_isde_enab	<=	mast_devs_isde_enab	&	mast_devs_isde_port[2]	;
		mast_dev3_isde_enab	<=	mast_devs_isde_enab	&	mast_devs_isde_port[3]	;
	end
//----------------------------------------------------------------------	
	reg			[ 1: 0]				mast_dev1_isde_samp	;
	reg			[ 1: 0]				mast_dev2_isde_samp	;
	reg			[ 1: 0]				mast_dev3_isde_samp	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					begin
		mast_dev1_isde_samp	<=	0	;
		mast_dev2_isde_samp	<=	0	;
		mast_dev3_isde_samp	<=	0	;
	end else begin	
		mast_dev1_isde_samp	<={	mast_dev1_isde_enab	,	mast_dev1_isde_samp[1]	};
		mast_dev2_isde_samp	<={	mast_dev2_isde_enab	,	mast_dev2_isde_samp[1]	};
		mast_dev3_isde_samp	<={	mast_dev3_isde_enab	,	mast_dev3_isde_samp[1]	};
	end
	
	assign		mast_dev1_wdma_enab	=	mast_dev1_isde_samp[0]	;
	assign		mast_dev2_wdma_enab	=	mast_dev2_isde_samp[0]	;
	assign		mast_dev3_wdma_enab	=	mast_dev3_isde_samp[0]	;

	wire		ubus_isde_wdma_enab	= |{mast_dev1_wdma_enab	,	mast_dev2_wdma_enab	,	mast_dev3_wdma_enab	};	
//----------------------------------------------------------------------
	reg								ubus_isde_wdma_done	;

	wire	[ 2: 0]					devs_isde_enab_sync	;
	assign		devs_isde_enab_sync	=  {mast_dev3_wdma_enab	,	mast_dev2_wdma_enab	,	mast_dev1_wdma_enab	};	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_isde_wdma_done	<=	0	;
	else begin
		case(devs_isde_enab_sync)
			3'B000	:				ubus_isde_wdma_done	<=	0					;
			3'B001	:				ubus_isde_wdma_done	<=	mast_dev1_wdma_done	;
			3'B010	:				ubus_isde_wdma_done	<=	mast_dev2_wdma_done	;
			3'B011	:				ubus_isde_wdma_done	<=&{mast_dev2_wdma_done	,	mast_dev1_wdma_done	};
			3'B100	:				ubus_isde_wdma_done	<=	mast_dev3_wdma_done	;
			3'B101	:				ubus_isde_wdma_done	<=&{mast_dev3_wdma_done	,	mast_dev1_wdma_done	};
			3'B110	:				ubus_isde_wdma_done	<=&{mast_dev3_wdma_done	,	mast_dev2_wdma_done	};
			3'B111	:				ubus_isde_wdma_done	<=&{mast_dev3_wdma_done	,	mast_dev2_wdma_done	,	mast_dev1_wdma_done	};
		endcase
	end	

	reg			[ 1: 0]				mast_isde_done_samp	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					mast_isde_done_samp	<=	0	;
	else if(~mast_devs_isde_enab)	mast_isde_done_samp	<=	0	;
	else							mast_isde_done_samp	<= {ubus_isde_wdma_done	,	mast_isde_done_samp[1]	};	

	assign	mast_devs_isde_done	=	mast_isde_done_samp[0]	;
/**********************************************************************************************************/
	reg			[ 1: 0]				ubus_wdma_pack_mfsm	;

	parameter	UBUS_WDMA_PACK_IDLE	=	2'H0	;
	parameter	UBUS_WDMA_PACK_DEV1	=	2'H1	;
	parameter	UBUS_WDMA_PACK_DEV2	=	2'H2	;
	parameter	UBUS_WDMA_PACK_DEV3	=	2'H3	;
			
	wire							ubus_wdma_hits_idle	;
	assign	ubus_wdma_hits_idle	=	ubus_wdma_pack_mfsm	==	UBUS_WDMA_PACK_IDLE	;	
//----------------------------------------------------------------------
	reg			[ 2: 0]				ubus_wdma_page_cnts	;
	parameter	UBUS_WDMA_PACK_PAGE	=	3'H7	;

	wire							dev1_isde_wdma_reqs	;
	wire							dev2_isde_wdma_reqs	;
	wire							dev3_isde_wdma_reqs	;

	wire							ubus_isde_wdma_csen	;
	
	wire							ubus_wdma_page_vlid	;
	wire							ubus_wdma_page_last	;
	wire							ubus_wdma_page_hrdy	;

	assign	dev1_isde_wdma_reqs	=	mast_dev1_wdma_reqs	;
	assign	dev2_isde_wdma_reqs	=&{~mast_dev1_wdma_reqs	,	mast_dev2_wdma_reqs	};
	assign	dev3_isde_wdma_reqs	=&{~mast_dev1_wdma_reqs	, ~	mast_dev2_wdma_reqs	,	mast_dev3_wdma_reqs };
	
	assign	ubus_wdma_page_hrdy	=&{	ubus_isde_wdma_trdy	,	ubus_isde_wdma_wrdy	}; 
	assign	ubus_wdma_page_vlid	= &{ubus_isde_wdma_csen	,	ubus_wdma_page_hrdy };
	assign	ubus_wdma_page_last	= &{ubus_wdma_page_vlid	,	ubus_wdma_page_cnts ==	UBUS_WDMA_PACK_PAGE	};

//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_pack_mfsm	<=	UBUS_WDMA_PACK_IDLE	;
	else if(~ubus_isde_wdma_enab)	ubus_wdma_pack_mfsm	<=	UBUS_WDMA_PACK_IDLE	;
	else begin
		case(ubus_wdma_pack_mfsm)	
			UBUS_WDMA_PACK_IDLE		:	ubus_wdma_pack_mfsm	<=	dev1_isde_wdma_reqs	?	UBUS_WDMA_PACK_DEV1	:
																dev2_isde_wdma_reqs	?	UBUS_WDMA_PACK_DEV2	:
																dev3_isde_wdma_reqs	?	UBUS_WDMA_PACK_DEV3	:	UBUS_WDMA_PACK_IDLE	;

			UBUS_WDMA_PACK_DEV1		:	ubus_wdma_pack_mfsm	<=	ubus_wdma_page_last	?	UBUS_WDMA_PACK_IDLE	:	UBUS_WDMA_PACK_DEV1	;
			UBUS_WDMA_PACK_DEV2		:	ubus_wdma_pack_mfsm	<=	ubus_wdma_page_last	?	UBUS_WDMA_PACK_IDLE	:	UBUS_WDMA_PACK_DEV2	;	
			UBUS_WDMA_PACK_DEV3		:	ubus_wdma_pack_mfsm	<=	ubus_wdma_page_last	?	UBUS_WDMA_PACK_IDLE	:	UBUS_WDMA_PACK_DEV3	;
		endcase
	end
/**********************************************************************************************************/
	wire								ubus_dev1_wdma_selx	;
	wire								ubus_dev2_wdma_selx	;
	wire								ubus_dev3_wdma_selx	;
	
	assign	ubus_dev1_wdma_vlid	= &{ubus_dev1_wdma_selx	,	ubus_wdma_page_vlid	};
	assign	ubus_dev2_wdma_vlid	= &{ubus_dev2_wdma_selx	,	ubus_wdma_page_vlid	};
	assign	ubus_dev3_wdma_vlid	= &{ubus_dev3_wdma_selx	,	ubus_wdma_page_vlid	};

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_page_cnts	<=	0	;
	else if(ubus_wdma_hits_idle)	ubus_wdma_page_cnts	<=	0	;
	else if(ubus_wdma_page_last)	ubus_wdma_page_cnts	<=	0	;	
	else							ubus_wdma_page_cnts	<=	ubus_wdma_page_cnts +	ubus_wdma_page_vlid	;	

	assign	ubus_dev1_wdma_selx	=	ubus_wdma_pack_mfsm	==	UBUS_WDMA_PACK_DEV1	;
	assign	ubus_dev2_wdma_selx	=	ubus_wdma_pack_mfsm	==	UBUS_WDMA_PACK_DEV2	;
	assign	ubus_dev3_wdma_selx	=	ubus_wdma_pack_mfsm	==	UBUS_WDMA_PACK_DEV3	;

	assign	ubus_isde_wdma_csen	= |{ubus_dev1_wdma_selx	&	ubus_wdma_page_hrdy	,
									ubus_dev2_wdma_selx	&	ubus_wdma_page_hrdy	,
									ubus_dev3_wdma_selx	&	ubus_wdma_page_hrdy	};

	assign	ubus_isde_wdma_addr	=	ubus_dev1_wdma_selx	?	mast_dev1_wdma_addr	:	
									ubus_dev2_wdma_selx	?	mast_dev2_wdma_addr	:	
									ubus_dev3_wdma_selx	?	mast_dev3_wdma_addr	:	25'H0	;

	assign	ubus_isde_wdma_data	=	ubus_dev1_wdma_selx	?	mast_dev1_wdma_data	:	
									ubus_dev2_wdma_selx	?	mast_dev2_wdma_data	:	
									ubus_dev3_wdma_selx	?	mast_dev3_wdma_data	:	256'H0	;
/**********************************************************************************************************/
/*
	ila_376	uila_tpgm_rdma_ddrs(
				.clk	(ubus_clki				)	,
				.probe0	({  
							mast_devs_isde_enab	
						,	mast_devs_isde_done	
						,	mast_devs_isde_port	
						,	mast_dev1_wdma_enab	
						,	mast_dev1_wdma_done	
						,	mast_dev1_wdma_reqs	
						,	ubus_dev1_wdma_vlid	
						,	mast_dev1_wdma_addr	
						,	mast_dev2_wdma_enab	
						,	mast_dev2_wdma_done	
						,	mast_dev2_wdma_reqs	
						,	ubus_dev2_wdma_vlid	
						,	mast_dev2_wdma_addr	
						,	mast_dev3_wdma_enab	
						,	mast_dev3_wdma_done	
						,	mast_dev3_wdma_reqs	
						,	ubus_dev3_wdma_vlid	
						,	mast_dev3_wdma_addr	
						,	ubus_isde_wdma_csen	
						,	ubus_isde_wdma_addr	
						,	ubus_isde_wdma_trdy	
						,	ubus_isde_wdma_wrdy								
						,	ubus_isde_wdma_data	
			})
	);
*/

endmodule 

//	input		[255:0]				mast_dev1_wdma_data	,
//	input		[255:0]				mast_dev2_wdma_data	,
//	input		[255:0]				mast_dev3_wdma_data	,
	

 /*
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_dev1_wdma_selx	<=	0	;
	else if(ubus_wdma_hits_idle)	ubus_dev1_wdma_selx	<=	dev1_isde_wdma_reqs	;
	else if(ubus_wdma_page_last)	ubus_dev1_wdma_selx	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_dev2_wdma_selx	<=	0	;
	else if(ubus_wdma_hits_idle)	ubus_dev2_wdma_selx	<=	dev2_isde_wdma_reqs	;
	else if(ubus_wdma_page_last)	ubus_dev2_wdma_selx	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_dev3_wdma_selx	<=	0	;
	else if(ubus_wdma_hits_idle)	ubus_dev3_wdma_selx	<=	dev3_isde_wdma_reqs	;
	else if(ubus_wdma_page_last)	ubus_dev3_wdma_selx	<=	0	;
*/
//	reg								mast_dev1_isde_done	;
//	reg								mast_dev2_isde_done	;
//	reg								mast_dev3_isde_done	;
//	reg								mast_isde_fake_done	;	
//
//	always@(posedge ubus_clki or negedge ubus_rstn)
//	if(~ubus_rstn)					mast_dev1_isde_done	<=	0	;
//	else if(~mast_dev1_wdma_enab)	mast_dev1_isde_done	<=	0	;
//	else							mast_dev1_isde_done	<=	mast_dev1_wdma_done	;
//
//	always@(posedge ubus_clki or negedge ubus_rstn)
//	if(~ubus_rstn)					mast_dev2_isde_done	<=	0	;
//	else if(~mast_dev2_wdma_enab)	mast_dev2_isde_done	<=	0	;
//	else							mast_dev2_isde_done	<=	mast_dev2_wdma_done	;
//
//	always@(posedge ubus_clki or negedge ubus_rstn)
//	if(~ubus_rstn)					mast_dev3_isde_done	<=	0	;
//	else if(~mast_dev3_wdma_enab)	mast_dev3_isde_done	<=	0	;
//	else							mast_dev3_isde_done	<=	mast_dev3_wdma_done	;
//
//	always@(posedge ubus_clki or negedge ubus_rstn)
//	if(~ubus_rstn)					mast_isde_fake_done	<=	0	;
//	else							mast_isde_fake_done	<=|{mast_dev1_isde_done	,
//															mast_dev2_isde_done	,
//
//															mast_dev3_isde_done	};
/*
	assign	ubus_isde_wdma_done	=&{~mast_dev1_wdma_enab |(	mast_dev1_wdma_enab &	mast_dev1_wdma_done  ),
								   ~mast_dev2_wdma_enab |(	mast_dev2_wdma_enab &	mast_dev2_wdma_done  ),
								   ~mast_dev3_wdma_enab |(	mast_dev3_wdma_enab &	mast_dev3_wdma_done  )};

*/
