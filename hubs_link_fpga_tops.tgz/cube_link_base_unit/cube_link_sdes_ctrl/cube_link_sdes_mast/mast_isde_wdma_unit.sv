/*----author edward------*/
//	input		[24 : 0]			mosx_devs_ddrs_base	,
//	input		[24 : 0]			mosx_devs_ddrs_size	,
//	input							mgt1_osde_rdma_trdy	,
//	output							mgt1_osde_rdma_drdy	,
//	output		[255: 0]			mgt1_osde_rdma_data	,
//	input							mgt2_osde_rdma_trdy	,
//	output							mgt2_osde_rdma_drdy	,
//	output		[255: 0]			mgt2_osde_rdma_data	,
//	input							mgt3_osde_rdma_trdy	,
//	output							mgt3_osde_rdma_drdy	,
//	output		[255: 0]			mgt3_osde_rdma_data	,

//	output							ubus_osde_rdma_csen	,
//	output		[ 24: 0]			ubus_osde_rdma_addr	,
//	input							ubus_osde_rdma_trdy	,
//	input		[255: 0]			ubus_osde_rdma_data	,
//	input							ubus_osde_rdma_drdy	,


module	mast_isde_wdma_unit(
	input		[ 3:  1]			mast_devs_sdes_port	,		
	input							mast_devs_isde_enab	,
	input							mast_devs_isde_mode	,
	output							mast_devs_isde_done	,
	input							mast_devs_osde_enab	,
	output							mast_devs_osde_done	,

	input		[19: 0]				mast_meta_imag_cols	,

	input		[24: 0]				misx_dev1_ddrs_size	,
	input		[24: 0]				mism_dev1_ddrs_base	,
	input		[19: 0]				mism_dev1_ddrs_cols	,
	input		[24: 0]				misv_dev1_ddrs_base	,

	input		[24: 0]				misx_dev2_ddrs_size	,
	input		[24: 0]				mism_dev2_ddrs_base	,
	input		[19: 0]				mism_dev2_ddrs_cols	,
	input		[24: 0]				misv_dev2_ddrs_base	,

	input		[24: 0]				misx_dev3_ddrs_size	,
	input		[24: 0]				mism_dev3_ddrs_base	,
	input		[19: 0]				mism_dev3_ddrs_cols	,
	input		[24: 0]				misv_dev3_ddrs_base	,

	input							link_clki			,
	input							link_rstn			,
//----------------------------------------------------------------------
	input							mgt1_isde_wdma_drdy	,
	input		[255: 0]			mgt1_isde_wdma_data	,
	input							mgt1_clki			,
	input							mgt1_rstn			,

	input							mgt2_isde_wdma_drdy	,
	input		[255: 0]			mgt2_isde_wdma_data	,
	input							mgt2_clki			,
	input							mgt2_rstn			,

	input							mgt3_isde_wdma_drdy	,
	input		[255: 0]			mgt3_isde_wdma_data	,
	input							mgt3_clki			,
	input							mgt3_rstn			,

	output							ubus_isde_wdma_csen	,
	output		[ 24: 0]			ubus_isde_wdma_addr	,
	output		[255: 0]			ubus_isde_wdma_data	,
	input							ubus_isde_wdma_trdy	,
	input							ubus_isde_wdma_wrdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
//----------------------------------------------------------------------
//	add@20250608   for remove mgth osde
	assign	mast_devs_osde_done	=	mast_devs_osde_enab	;
//----------------------------------------------------------------------
	mast_isde_mgth_ctrl			u_mast_isde_mgth_ctrl(
		.mast_devs_isde_port		(mast_devs_sdes_port	),//input		[ 3: 1]	

		.mast_devs_isde_enab		(mast_devs_isde_enab	),//input				
		.mast_devs_isde_mode		(mast_devs_isde_mode	),//input				
		.mast_devs_isde_done		(mast_devs_isde_done	),//output				
		
		.mast_meta_imag_cols		(mast_meta_imag_cols	),//input		[19: 0]	
		
		.misx_dev1_ddrs_size		(misx_dev1_ddrs_size	),//input		[24: 0]	
		.mism_dev1_ddrs_base		(mism_dev1_ddrs_base	),//input		[24: 0]	
		.mism_dev1_ddrs_cols		(mism_dev1_ddrs_cols	),//input		[19: 0]	
		.misv_dev1_ddrs_base		(misv_dev1_ddrs_base	),//input		[24: 0]	
		
		.misx_dev2_ddrs_size		(misx_dev2_ddrs_size	),//input		[24: 0]	
		.mism_dev2_ddrs_base		(mism_dev2_ddrs_base	),//input		[24: 0]	
		.mism_dev2_ddrs_cols		(mism_dev2_ddrs_cols	),//input		[19: 0]	
		.misv_dev2_ddrs_base		(misv_dev2_ddrs_base	),//input		[24: 0]	
		
		.misx_dev3_ddrs_size		(misx_dev3_ddrs_size	),//input		[24: 0]	
		.mism_dev3_ddrs_base		(mism_dev3_ddrs_base	),//input		[24: 0]	
		.mism_dev3_ddrs_cols		(mism_dev3_ddrs_cols	),//input		[19: 0]	
		.misv_dev3_ddrs_base		(misv_dev3_ddrs_base	),//input		[24: 0]	
		.link_clki					(link_clki				),//input				
		.link_rstn					(link_rstn				),//input				
		
		.mgt1_isde_wdma_drdy		(mgt1_isde_wdma_drdy	),//input				
		.mgt1_isde_wdma_data		(mgt1_isde_wdma_data	),//input		[255: 0]
		.mgt1_clki					(mgt1_clki				),//input				
		.mgt1_rstn					(mgt1_rstn				),//input				
		
		.mgt2_isde_wdma_drdy		(mgt2_isde_wdma_drdy	),//input				
		.mgt2_isde_wdma_data		(mgt2_isde_wdma_data	),//input		[255: 0]
		.mgt2_clki					(mgt2_clki				),//input				
		.mgt2_rstn					(mgt2_rstn				),//input				
		
		.mgt3_isde_wdma_drdy		(mgt3_isde_wdma_drdy	),//input				
		.mgt3_isde_wdma_data		(mgt3_isde_wdma_data	),//input		[255: 0]
		.mgt3_clki					(mgt3_clki				),//input				
		.mgt3_rstn					(mgt3_rstn				),//input				
		
		.ubus_isde_wdma_csen		(ubus_isde_wdma_csen	),//output				
		.ubus_isde_wdma_addr		(ubus_isde_wdma_addr	),//output		[ 24: 0]
		.ubus_isde_wdma_data		(ubus_isde_wdma_data	),//output		[255: 0]
		.ubus_isde_wdma_trdy		(ubus_isde_wdma_trdy	),//input				
		.ubus_isde_wdma_wrdy		(ubus_isde_wdma_wrdy	),//input				
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));	//input				
//----------------------------------------------------------------------------------------------------------
//	mast_osde_mgth_ctrl			u_mast_osde_mgth_ctrl(
//		.mast_devs_osde_port		(mast_devs_sdes_port	),//input		[ 3:  1]
//		.mast_devs_osde_enab		(mast_devs_osde_enab	),//input				
//		.mast_devs_osde_done		(mast_devs_osde_done	),//output				
//		.mosx_devs_ddrs_base		(mosx_devs_ddrs_base	),//input		[24 : 0]
//		.mosx_devs_ddrs_size		(mosx_devs_ddrs_size	),//input		[24 : 0]
//		.link_clki					(link_clki				),//input				
//		.link_rstn					(link_rstn				),//input				
//
//		.mgt1_osde_rdma_trdy		(mgt1_osde_rdma_trdy	),//input				
//		.mgt1_osde_rdma_drdy		(mgt1_osde_rdma_drdy	),//output				
//		.mgt1_osde_rdma_data		(mgt1_osde_rdma_data	),//output		[255: 0]
//		.mgt1_clki					(mgt1_clki				),//input				
//		.mgt1_rstn					(mgt1_rstn				),//input				
//		
//		.mgt2_osde_rdma_trdy		(mgt2_osde_rdma_trdy	),//input				
//		.mgt2_osde_rdma_drdy		(mgt2_osde_rdma_drdy	),//output				
//		.mgt2_osde_rdma_data		(mgt2_osde_rdma_data	),//output		[255: 0]
//		.mgt2_clki					(mgt2_clki				),//input				
//		.mgt2_rstn					(mgt2_rstn				),//input				
//		
//		.mgt3_osde_rdma_trdy		(mgt3_osde_rdma_trdy	),//input				
//		.mgt3_osde_rdma_drdy		(mgt3_osde_rdma_drdy	),//output				
//		.mgt3_osde_rdma_data		(mgt3_osde_rdma_data	),//output		[255: 0]
//		.mgt3_clki					(mgt3_clki				),//input				
//		.mgt3_rstn					(mgt3_rstn				),//input				
//		
//		.ubus_osde_rdma_csen		(ubus_osde_rdma_csen	),//output	reg			
//		.ubus_osde_rdma_addr		(ubus_osde_rdma_addr	),//output	reg	[ 24: 0]
//		.ubus_osde_rdma_trdy		(ubus_osde_rdma_trdy	),//input				
//		.ubus_osde_rdma_data		(ubus_osde_rdma_data	),//input		[255: 0]
//		.ubus_osde_rdma_drdy		(ubus_osde_rdma_drdy	),//input				
//		.ubus_clki					(ubus_clki				),//input				
//		.ubus_rstn					(ubus_rstn				));		//input				


endmodule 

