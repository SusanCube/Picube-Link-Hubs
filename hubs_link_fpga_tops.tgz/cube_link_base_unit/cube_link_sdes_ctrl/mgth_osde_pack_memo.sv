/*----author edward------*/

module	mgth_osde_pack_memo(
	input							ubus_rdma_reqs	,
	input							ubus_rdma_wrcs	,
	input	[255:0 ]				ubus_rdma_data	,
	input							ubus_clki		,
	input							ubus_rstn		,

	input							mgth_osde_reqs	,
	input							mgth_osde_rdcs	,
	output	[255:0 ]				mgth_osde_data	,
	input							mgth_clki		,
	input							mgth_rstn		);

	reg		[2:0]					ubus_rdma_addr	;
	reg		[2:0]					mgth_osde_addr	;
	
	reg		[0:7][255:0]			ubus_rdma_memo	;


	wire	[0:7]					ubus_rdma_csid	;
	wire	[0:7]					ubus_rdma_wrid	;
	wire	[0:7]					mgth_osde_csid	;
	wire	[0:7]					mgth_osde_rdid	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_addr	<=	0	;
	else if(ubus_rdma_reqs)			ubus_rdma_addr	<=	0	;
	else if(ubus_rdma_wrcs)			ubus_rdma_addr	<=	1 +	ubus_rdma_addr	;

	always@(posedge mgth_clki or negedge mgth_rstn)
	if(!mgth_rstn)					mgth_osde_addr	<=	0	;
	else if(mgth_osde_reqs)			mgth_osde_addr	<=	0	;
	else if(mgth_osde_rdcs)			mgth_osde_addr	<=	1 +	mgth_osde_addr	;


	for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_osde_memo_cdec
		assign	ubus_rdma_csid[i]	=	ubus_rdma_addr	==	i	;
		assign	ubus_rdma_wrid[i]	= &{ubus_rdma_wrcs , ubus_rdma_csid[i]	};

		assign	mgth_osde_csid[i]	=	mgth_osde_addr	==	i	;
		assign	mgth_osde_rdid[i]	= &{mgth_osde_rdcs , mgth_osde_csid[i]	};

		always@(posedge ubus_clki or negedge ubus_rstn)
		if(!ubus_rstn)				ubus_rdma_memo[i]	<=	0	;
		else if(ubus_rdma_wrid[i])	ubus_rdma_memo[i]	<=	ubus_rdma_data	;	
	end

	assign	mgth_osde_data	=	mgth_osde_rdid[0]	?	ubus_rdma_memo[0]	:
								mgth_osde_rdid[1]	?	ubus_rdma_memo[1]	:
								mgth_osde_rdid[2]	?	ubus_rdma_memo[2]	:
								mgth_osde_rdid[3]	?	ubus_rdma_memo[3]	:
								mgth_osde_rdid[4]	?	ubus_rdma_memo[4]	:
								mgth_osde_rdid[5]	?	ubus_rdma_memo[5]	:
								mgth_osde_rdid[6]	?	ubus_rdma_memo[6]	:
								mgth_osde_rdid[7]	?	ubus_rdma_memo[7]	:	256'H0	;
							

endmodule
 