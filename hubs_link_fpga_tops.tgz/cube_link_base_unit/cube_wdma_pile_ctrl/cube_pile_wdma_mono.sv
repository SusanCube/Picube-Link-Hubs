/*----author edward------*/

module	cube_pile_wdma_mono(
	input		[ 3: 0]				ecos_pile_omni_numb	,
	input		[ 3: 0]				ecos_pile_this_indx	,
	
	input		[24 : 0]			pile_xdat_ddrs_base	,	
	input		[19 : 0]			pile_xdat_rows_numb	,
	input		[19 : 0]			pile_xdat_cols_numb	,

	input							cube_pile_wdma_enab	,//write enable
	input							cube_pile_wdma_mode	,//0:VECT 1: MTRX
	output							cube_pile_wdma_done	,
	
	input							cube_pile_idat_lead	,
	input							cube_pile_idat_wrcs	,
	input		[ 31: 0]			cube_pile_idat_word	,

	input							link_clki			,
	input							link_rstn			,

	input							cube_pile_wdma_init	,	
	input							cube_pile_wdma_updt	,	
	
	input							cube_pile_wdma_reqs	,	
	input		[ 3: 0]				cube_pile_wdma_size	,

	output							cube_pile_wdma_ov16	,
	output							cube_pile_wdma_ov08	,
	output							cube_pile_wdma_ov04	,
	output							cube_pile_wdma_ov02	,
	
	output		[255: 0]			ubus_pile_wdma_data	,
	output		[ 24: 0]			ubus_pile_wdma_addr	,
	output	reg						ubus_pile_wdma_drdy	,	

	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg			[  2: 0]			ubus_wdma_ddrs_samp	;	
	reg								ubus_wdma_ddrs_done	;

	reg			[  1: 0]			cube_wdma_done_samp	;	
	
	wire							ubus_wdma_ddrs_enab	;
	wire							ubus_wdma_ddrs_disa	;
	wire							ubus_wdma_ddrs_last	;
	
	assign	ubus_wdma_ddrs_enab	= 	ubus_wdma_ddrs_samp[1:0] ==	2'B11	;
	assign	ubus_wdma_ddrs_disa	= 	ubus_wdma_ddrs_samp[1:0] ==	2'B00	;

	assign	cube_pile_wdma_done	=	cube_wdma_done_samp[ 0 ] ;	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_ddrs_samp	<=	0	;
	else							ubus_wdma_ddrs_samp	<={	cube_pile_wdma_enab	, ubus_wdma_ddrs_samp[2:1]	};	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_ddrs_done	<=	0	;
	else if(ubus_wdma_ddrs_disa)	ubus_wdma_ddrs_done	<=	0	;	
	else if(cube_pile_wdma_init)	ubus_wdma_ddrs_done	<=	0	;	
	else if(ubus_wdma_ddrs_last)	ubus_wdma_ddrs_done	<=	1	;	

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					cube_wdma_done_samp	<=	0	;
	else							cube_wdma_done_samp	<={	ubus_wdma_ddrs_done	, cube_wdma_done_samp[ 1]	};	
//----------------------------------------------------------------------------------------------------------
	reg			[  3: 0]			link_wdma_ddrs_samp	;
	
	reg			[ 24: 0]			mtrx_rows_page_leng	;
	reg			[ 24: 0]			mtrx_rows_page_ofst	;
	
	reg			[ 24: 0]			vect_meta_page_ofst	;

	reg			[  2: 0]			cube_idat_word_cnts	;
	reg			[ 15: 0]			cube_idat_page_cnts	;
	reg			[ 19: 0]			cube_idat_rows_cnts	;

	reg			[255: 0]			cube_idat_page_data	;
	reg								cube_idat_page_wrcs	;	
	reg								cube_idat_rows_wrcs	;	

	wire							link_wdma_ddrs_disa	;

	wire							link_wdma_ddrs_rise	;
	wire							link_wdma_ddrs_init	;
	wire							idat_page_last_word	;
	wire							idat_rows_last_page	;
	wire		[ 24: 0]			meta_imag_page_size	;
//	wire							idat_meta_last_rows	;


	wire		[15: 0]				pile_xdat_cols_page	;

	assign	pile_xdat_cols_page	=	pile_xdat_cols_numb[19:4]	;
	
	assign	link_wdma_ddrs_disa	= 	link_wdma_ddrs_samp[2:0] ==	3'B000	;	
	assign	link_wdma_ddrs_rise	= 	link_wdma_ddrs_samp[2:0] ==	3'B100	;
	assign	link_wdma_ddrs_init	= 	link_wdma_ddrs_samp[2:0] ==	3'B110	;

	assign	idat_page_last_word	= &{cube_pile_idat_wrcs	,	cube_idat_word_cnts	};
	assign	idat_rows_last_page	= &{idat_page_last_word	,	cube_idat_page_cnts+1==	pile_xdat_cols_page	};
	assign	meta_imag_page_size	=	pile_xdat_cols_page	*	pile_xdat_rows_numb	;
		
	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)					link_wdma_ddrs_samp	<=	0	;
	else							link_wdma_ddrs_samp	<={	cube_pile_wdma_enab	, link_wdma_ddrs_samp[3:1]	};	


	
	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn) 					mtrx_rows_page_leng	<=	0	;
	else if(link_wdma_ddrs_disa)	mtrx_rows_page_leng	<=	pile_xdat_cols_page	*	ecos_pile_omni_numb	;

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn) 					mtrx_rows_page_ofst	<=	0	;
	else if(link_wdma_ddrs_disa)	mtrx_rows_page_ofst	<=	pile_xdat_cols_page	*	ecos_pile_this_indx	;

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn) 					vect_meta_page_ofst	<=	0	;
	else if(link_wdma_ddrs_rise)	vect_meta_page_ofst	<=	meta_imag_page_size	*	ecos_pile_this_indx	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_word_cnts	<=	0	;
	else if(link_wdma_ddrs_disa)	cube_idat_word_cnts	<=	0	;
	else if(cube_pile_idat_lead)	cube_idat_word_cnts	<=	0	;
	else 							cube_idat_word_cnts	<=	cube_idat_word_cnts	+	cube_pile_idat_wrcs	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_cnts	<=	0	;
	else if(link_wdma_ddrs_disa)	cube_idat_page_cnts	<=	0	;
	else if(idat_rows_last_page)	cube_idat_page_cnts	<=	0	;
	else 							cube_idat_page_cnts	<=	cube_idat_page_cnts	+	idat_page_last_word	;	

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_data	<=	0	;
	else if(link_wdma_ddrs_disa)	cube_idat_page_data	<=	0	;
	else if(cube_pile_idat_lead)	cube_idat_page_data	<=	0	;
	else if(cube_pile_idat_wrcs)	cube_idat_page_data	<={	cube_pile_idat_word			,	cube_idat_page_data[255:32]	};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_page_wrcs	<=	0	;
	else							cube_idat_page_wrcs	<=	idat_page_last_word	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_idat_rows_wrcs	<=	0	;
	else							cube_idat_rows_wrcs	<=	idat_rows_last_page	;
/**********************************************************************************************************/
	reg			[ 24: 0]			mtrx_idat_wdma_base	;
	reg			[ 24: 0]			mtrx_idat_wdma_ofst	;
	reg			[ 24: 0]			vect_idat_wdma_addr	;
	reg			[ 24: 0]			idat_fifo_push_cnts	;

	wire		[  8: 0]			cube_idat_push_dptr	;
	assign	cube_idat_push_dptr	=	idat_fifo_push_cnts[8:0]	;

	wire		[ 24: 0]			mtrx_idat_wdma_addr	;
	wire		[ 24: 0]			cube_pile_wdma_addr	;

	assign	mtrx_idat_wdma_addr	=	mtrx_idat_wdma_base + 	mtrx_idat_wdma_ofst	;
	assign	cube_pile_wdma_addr	=	cube_pile_wdma_mode	?	mtrx_idat_wdma_addr	: vect_idat_wdma_addr	;

	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					mtrx_idat_wdma_base	<=	0	;
	else if(link_wdma_ddrs_init)	mtrx_idat_wdma_base	<=	pile_xdat_ddrs_base	+ mtrx_rows_page_ofst	;
	else if(cube_idat_rows_wrcs) 	mtrx_idat_wdma_base	<=	mtrx_idat_wdma_base + mtrx_rows_page_leng	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					mtrx_idat_wdma_ofst	<=	0	;
	else if(link_wdma_ddrs_init)	mtrx_idat_wdma_ofst	<=	0	;
	else if(cube_idat_rows_wrcs) 	mtrx_idat_wdma_ofst	<=	0	;
	else 						 	mtrx_idat_wdma_ofst	<=	mtrx_idat_wdma_ofst + cube_idat_page_wrcs	;

	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					vect_idat_wdma_addr	<=	0	;
	else if(link_wdma_ddrs_init)	vect_idat_wdma_addr	<=	pile_xdat_ddrs_base + vect_meta_page_ofst	;
	else 						 	vect_idat_wdma_addr	<=	vect_idat_wdma_addr + cube_idat_page_wrcs	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)					idat_fifo_push_cnts	<=	0	;	
	else if(link_wdma_ddrs_disa)	idat_fifo_push_cnts	<=	0	;	
	else if(link_wdma_ddrs_rise)	idat_fifo_push_cnts	<=	0	;	
	else 							idat_fifo_push_cnts	<=	idat_fifo_push_cnts +	cube_idat_page_wrcs	;	
/**********************************************************************************************************/
	reg		[ 24: 0]				ubus_idat_pops_cnts	;
	reg		[  3: 0]				ubus_idat_wdma_cnts	;

	wire	[  8: 0]				ubus_idat_wdma_lsba	;
	wire	[  8: 0]				ubus_idat_wdma_nxta	;
	
	wire	[  8: 0]				ubus_pops_wdma_dptr	;
	wire							cube_pile_wdma_last	;

	assign	ubus_idat_wdma_lsba	=	ubus_idat_pops_cnts[8:0]	;
	assign	ubus_idat_wdma_nxta	=	ubus_idat_wdma_lsba +  1	;
	
	assign	ubus_pops_wdma_dptr	=	ubus_pile_wdma_drdy	?	ubus_idat_wdma_nxta	:	ubus_idat_wdma_lsba	;
	assign	cube_pile_wdma_last	= &{ubus_pile_wdma_drdy	,	ubus_idat_wdma_cnts	==	cube_pile_wdma_size};

	assign	ubus_wdma_ddrs_last	= &{ubus_wdma_ddrs_enab	,	ubus_idat_pops_cnts	==	meta_imag_page_size};

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_pile_wdma_drdy	<=	0	;
	else if(cube_pile_wdma_init)	ubus_pile_wdma_drdy	<=	0	;	
	else if(cube_pile_wdma_reqs)	ubus_pile_wdma_drdy	<=	1	;	
	else if(cube_pile_wdma_last)	ubus_pile_wdma_drdy	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_idat_wdma_cnts	<=	0	;	
	else if(cube_pile_wdma_init)	ubus_idat_wdma_cnts	<=	0	;	
	else if(cube_pile_wdma_reqs)	ubus_idat_wdma_cnts	<=	0	;	
	else if(cube_pile_wdma_last)	ubus_idat_wdma_cnts	<=	0	;	
	else 							ubus_idat_wdma_cnts	<=	ubus_idat_wdma_cnts	+ ubus_pile_wdma_drdy ;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_idat_pops_cnts	<=	0	;	
	else if(ubus_wdma_ddrs_disa)	ubus_idat_pops_cnts	<=	0	;	
	else if(cube_pile_wdma_init)	ubus_idat_pops_cnts	<=	0	;	
	else 							ubus_idat_pops_cnts	<=	ubus_idat_pops_cnts + ubus_pile_wdma_drdy	;	
/**********************************************************************************************************/
	wire		[ 24: 0]			tpgs_ubus_push_sync	;

	reg			[ 24: 0]			updt_tpgs_push_cnts	;
	reg			[ 24: 0]			updt_ubus_pops_cnts	;
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					updt_tpgs_push_cnts	<=	0	;	
	else if(cube_pile_wdma_updt)	updt_tpgs_push_cnts	<=	tpgs_ubus_push_sync	;	
	else							updt_tpgs_push_cnts	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					updt_ubus_pops_cnts	<=	0	;	
	else if(cube_pile_wdma_updt)	updt_ubus_pops_cnts	<=	ubus_idat_pops_cnts	;	
	else							updt_ubus_pops_cnts	<=	0	;	
	
	
	wire		[ 24: 0]			tpgs_push_vlid_numb	;

	assign	tpgs_push_vlid_numb	=	updt_tpgs_push_cnts	-	updt_ubus_pops_cnts	;

	assign	cube_pile_wdma_ov16	= |	tpgs_push_vlid_numb[24:4]	;
	assign	cube_pile_wdma_ov08	= |	tpgs_push_vlid_numb[24:3]	;
	assign	cube_pile_wdma_ov04	= |	tpgs_push_vlid_numb[24:2]	;
	assign	cube_pile_wdma_ov02	= |	tpgs_push_vlid_numb[24:1]	;
/**********************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )
								u_tpgs_dptr_sync_gens(
		.data_asyn					(idat_fifo_push_cnts	),//input	[24: 0]	
		.scki						(link_clki				),
		
		.data_sync					(tpgs_ubus_push_sync	),//output	[24: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_idat_wdma_beat_data (
		.wport_csen					(cube_idat_page_wrcs	),//input  				 		
		.wport_data					(cube_idat_page_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(cube_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(link_clki				),//input						

		.rport_addr					(ubus_pops_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_pile_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
	u_idat_wdma_beat_addr (
		.wport_csen					(cube_idat_page_wrcs	),//input  				 		
		.wport_addr					(cube_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(cube_pile_wdma_addr	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						
		
		.rport_addr					(ubus_pops_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_pile_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

endmodule 
  
