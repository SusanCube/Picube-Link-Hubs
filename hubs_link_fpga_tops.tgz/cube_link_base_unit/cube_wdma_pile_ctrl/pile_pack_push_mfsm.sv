//----------------------------------------------------------------------------------------------------------
module pile_pack_push_mfsm(
	input							pile_pack_wdma_enab	,
	input							mono_pile_push_drdy	,
	input							mono_pile_pops_last	,

	input		[ 0: 3]				mono_pile_pack_ov16	,
	input		[ 0: 3]				mono_pile_pack_ov08	,
	input		[ 0: 3]				mono_pile_pack_ov04	,
	input		[ 0: 3]				mono_pile_pack_ov02	,
		
	output							mono_pile_push_init	,
	output							mono_pile_push_updt	,
	output		[ 0: 3]				mono_pile_push_reqs	,
	output		[ 3: 0]				mono_pile_push_size	,
	output							mono_pile_pops_reqs	,
	output		[ 3: 0]				mono_pile_pops_size	,
	
			
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************/
	wire							pile_pack_ov16_case	;
	wire							pile_pack_ov08_case	;
	wire							pile_pack_ov04_case	;
	wire							pile_pack_ovfl_case	;
	
	wire  		[ 3: 0]				pile_pack_ov16_port	;
	wire  		[ 3: 0]				pile_pack_ov08_port	;
	wire  		[ 3: 0]				pile_pack_ov04_port	;
	wire  		[ 3: 0]				pile_pack_ov02_port	;
	

	wire  		[ 3: 0]				pile_pack_seek_port	;
	wire  		[ 3: 0]				pile_pack_seek_leng	;
		
	assign	pile_pack_ov16_case	= |	mono_pile_pack_ov16	;
	assign	pile_pack_ov08_case	= |	mono_pile_pack_ov08	;
	assign	pile_pack_ov04_case	= |	mono_pile_pack_ov04	;
	assign	pile_pack_ov02_case	= |	mono_pile_pack_ov02	;
	

	assign	pile_pack_ovfl_case	= |{pile_pack_ov16_case	,	
									pile_pack_ov08_case	, 	
									pile_pack_ov04_case	,
									pile_pack_ov02_case	};

	assign	pile_pack_ov16_port	=	mono_pile_pack_ov16[3]	?	4'H3	:
									mono_pile_pack_ov16[2]	?	4'H2	:
									mono_pile_pack_ov16[1]	?	4'H1	:	4'H0	;

	assign	pile_pack_ov08_port	=	mono_pile_pack_ov08[3]	?	4'H3	:
									mono_pile_pack_ov08[2]	?	4'H2	:
									mono_pile_pack_ov08[1]	?	4'H1	:	4'H0	;
									
	assign	pile_pack_ov04_port	=	mono_pile_pack_ov04[3]	?	4'H3	:
									mono_pile_pack_ov04[2]	?	4'H2	:
									mono_pile_pack_ov04[1]	?	4'H1	:	4'H0	;

	assign	pile_pack_ov02_port	=	mono_pile_pack_ov02[3]	?	4'H3	:
									mono_pile_pack_ov02[2]	?	4'H2	:
									mono_pile_pack_ov02[1]	?	4'H1	:	4'H0	;

	assign	pile_pack_seek_leng	=	pile_pack_ov16_case		?	4'HF	:
									pile_pack_ov08_case		?	4'H7	:
									pile_pack_ov04_case		?	4'H3	:	
									pile_pack_ov02_case		?	4'H1	:	4'H0	;

	assign	pile_pack_seek_port	=	pile_pack_ov16_case		?	pile_pack_ov16_port	:
									pile_pack_ov08_case		?	pile_pack_ov08_port	:
									pile_pack_ov04_case		?	pile_pack_ov04_port	:	
									pile_pack_ov02_case		?	pile_pack_ov02_port	:	4'HF	;
/**********************************************************************/
	reg			[ 3: 0]				mono_pile_push_mfsm	;
	reg			[ 3: 0]				mono_pile_push_port	;
	reg			[ 3: 0]				mono_pile_wdma_size	;


	parameter	MONO_PILE_PUSH_IDLE	=	4'H0	;
	parameter	MONO_PILE_PUSH_INIT	=	4'H1	;
	parameter	MONO_PILE_PUSH_UPDT	=	4'H2	;
	parameter	MONO_PILE_PUSH_SEEK	=	4'H4	;
	parameter	MONO_PILE_PUSH_REQS	=	4'H5	;
	parameter	MONO_PILE_PUSH_PACK	=	4'H6	;
	parameter	MONO_PILE_POPS_REQS	=	4'H7	;
	parameter	MONO_PILE_POPS_PACK	=	4'H8	;
	
	
	wire	mono_pile_push_idle	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_IDLE	;
	assign 	mono_pile_push_init	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_INIT	;
	assign 	mono_pile_push_updt	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_UPDT	;
	
	wire	mono_pile_push_seek	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_SEEK	;
	wire   	mono_pile_push_reqx	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_REQS	;
	wire   	mono_pile_push_pack	 =	mono_pile_push_mfsm	==	MONO_PILE_PUSH_PACK	;
	assign	mono_pile_pops_reqs	 =	mono_pile_push_mfsm	==	MONO_PILE_POPS_REQS	;

	wire							mono_pile_push_last	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					mono_pile_push_mfsm	<=	MONO_PILE_PUSH_IDLE	;
	else if(~pile_pack_wdma_enab)	mono_pile_push_mfsm	<=	MONO_PILE_PUSH_IDLE	;
	else begin
		case(mono_pile_push_mfsm)	
			MONO_PILE_PUSH_IDLE	:	mono_pile_push_mfsm	<=							MONO_PILE_PUSH_INIT	;
			MONO_PILE_PUSH_INIT	:	mono_pile_push_mfsm	<=							MONO_PILE_PUSH_UPDT	;
			
			MONO_PILE_PUSH_UPDT	:	mono_pile_push_mfsm	<=							MONO_PILE_PUSH_SEEK	;
			MONO_PILE_PUSH_SEEK	:	mono_pile_push_mfsm	<=	pile_pack_ovfl_case	?	MONO_PILE_PUSH_REQS	:	MONO_PILE_PUSH_UPDT	;

			MONO_PILE_PUSH_REQS	:	mono_pile_push_mfsm	<=							MONO_PILE_PUSH_PACK	;
			MONO_PILE_PUSH_PACK	:	mono_pile_push_mfsm	<=	mono_pile_push_last	?	MONO_PILE_POPS_REQS	:	MONO_PILE_PUSH_PACK;

			MONO_PILE_POPS_REQS	:	mono_pile_push_mfsm	<=							MONO_PILE_POPS_PACK	;
			MONO_PILE_POPS_PACK	:	mono_pile_push_mfsm	<=	mono_pile_pops_last	?	MONO_PILE_PUSH_UPDT	:	MONO_PILE_POPS_PACK;
			default	:				mono_pile_push_mfsm	<=							MONO_PILE_PUSH_IDLE	;
		endcase
	end
/**********************************************************************/
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					mono_pile_wdma_size	<=	0	;
	else if(mono_pile_push_seek)	mono_pile_wdma_size	<=	pile_pack_ovfl_case	?	pile_pack_seek_leng	:	5'H0	;
	else							mono_pile_wdma_size	<=	mono_pile_wdma_size	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					mono_pile_push_port	<=	4'HF	;
	else if(mono_pile_push_idle)	mono_pile_push_port	<=	4'HF	;
	else if(mono_pile_push_seek)	mono_pile_push_port	<=	pile_pack_ovfl_case	?	pile_pack_seek_port	:	4'HF	;
	else							mono_pile_push_port	<=	mono_pile_push_port	;	
/**********************************************************************/
	assign 	mono_pile_push_reqs[0]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H0	};
	assign 	mono_pile_push_reqs[1]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H1	};
	assign 	mono_pile_push_reqs[2]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H2	};
	assign 	mono_pile_push_reqs[3]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H3	};
/***********************************************************************************************************/
	reg		[ 3: 0]					pile_pack_load_cnts	;

	wire	mono_pile_push_pass	= &{mono_pile_push_pack	,	mono_pile_push_drdy	};	

	assign	mono_pile_push_last	= &{mono_pile_push_pass	,	pile_pack_load_cnts	==	mono_pile_wdma_size};


	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)					pile_pack_load_cnts	<=	0	;
	else if(~pile_pack_wdma_enab)	pile_pack_load_cnts	<=	0	;
	else if( mono_pile_push_last)	pile_pack_load_cnts	<=	0	;
	else if( mono_pile_push_reqx)	pile_pack_load_cnts	<=	0	;
	else if( mono_pile_push_pass)	pile_pack_load_cnts	<=	pile_pack_load_cnts+1;
/***********************************************************************************************************/

	assign	mono_pile_push_size	=	mono_pile_wdma_size	;
	assign	mono_pile_pops_size	=	mono_pile_wdma_size	;


endmodule										

//	reg		[ 3: 0]					pile_pack_load_numb	;
//	always@(posedge ubus_clki or negedge ubus_rstn)	
//	if(!ubus_rstn)					pile_pack_load_numb	<=	0	;
//	else if(mono_pile_push_reqx)	pile_pack_load_numb	<=	mono_pile_wdma_size	;
//	else if(mono_pile_push_last)	pile_pack_load_numb	<=	0	;


//	assign 	mono_pile_push_reqs[4]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H4	};
//	assign 	mono_pile_push_reqs[5]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H5	};
//	assign 	mono_pile_push_reqs[6]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H6	};
//	assign 	mono_pile_push_reqs[7]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H7	};
//	assign 	mono_pile_push_reqs[8]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H8	};
//	assign 	mono_pile_push_reqs[9]=&{mono_pile_push_reqx , mono_pile_push_port == 4'H9	}; 