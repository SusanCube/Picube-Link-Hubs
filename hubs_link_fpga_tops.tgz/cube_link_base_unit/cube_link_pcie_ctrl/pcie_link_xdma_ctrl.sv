/*----author edward------*/
module	pcie_link_xdma_ctrl(
	input		[24 : 0]			pcie_xdma_ddrs_base	,
	input		[19 : 0]			pcie_xdma_rows_numb	,
	input		[31 : 0]			pcie_xdma_cols_numb	,

	input							pcie_link_rdma_enab	,//write enable
	output							pcie_link_rdma_done	,//pcie bar clock domain

	input							pcie_link_wdma_enab	,//write enable
	output							pcie_link_wdma_done	,//pcie bar clock domain

	input							pcie_axis_rdma_trdy	,
	output							pcie_axis_rdma_drdy	,
	output							pcie_axis_rdma_last	,
	output		[255:0]				pcie_axis_rdma_data	,

	output							pcie_axis_wdma_trdy	,
	input							pcie_axis_wdma_drdy	,
	input		[255:0]				pcie_axis_wdma_data	,

	input							pcie_aclk			,
	input							pcie_bclk			,
	input							pcie_rstn			,


	output							ubus_pcie_wdma_csen	,
	output		[ 24: 0]			ubus_pcie_wdma_addr	,
	output		[255: 0]			ubus_pcie_wdma_data	,
	input							ubus_pcie_wdma_trdy	,
	input							ubus_pcie_wdma_wrdy	,
	output							ubus_pcie_rdma_csen	,
	output		[ 24: 0]			ubus_pcie_rdma_addr	,
	input							ubus_pcie_rdma_trdy	,
	input		[255: 0]			ubus_pcie_rdma_data	,
	input							ubus_pcie_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
	
	
	pcie_link_wdma_data			u_pcie_link_wdma_idat(
		.pcie_xdma_rows_numb		(pcie_xdma_rows_numb	),//input		[19 : 0]
		.pcie_xdma_cols_numb		(pcie_xdma_cols_numb	),//input		[15 : 0]
		.pcie_link_wdma_base		(pcie_xdma_ddrs_base	),//input		[24 : 0]
		.pcie_link_wdma_enab		(pcie_link_wdma_enab	),//input				//write enable
		.pcie_link_wdma_done		(pcie_link_wdma_done	),//output				//pcie bar clock domain
		
		.pcie_axis_wdma_trdy		(pcie_axis_wdma_trdy	),//output				
		.pcie_axis_wdma_drdy		(pcie_axis_wdma_drdy	),//input				
		.pcie_axis_wdma_data		(pcie_axis_wdma_data	),//input		[255:0]	
		.pcie_aclk					(pcie_aclk				),//input				
		.pcie_bclk					(pcie_bclk				),//input				
		.pcie_rstn					(pcie_rstn				),//input				

		.ubus_pcie_wdma_csen		(ubus_pcie_wdma_csen	),//output	reg		
		.ubus_pcie_wdma_addr		(ubus_pcie_wdma_addr	),//output	[ 24: 0]
		.ubus_pcie_wdma_data		(ubus_pcie_wdma_data	),//output	[255: 0]
		.ubus_pcie_wdma_trdy		(ubus_pcie_wdma_trdy	),//input			
		.ubus_pcie_wdma_wrdy		(ubus_pcie_wdma_wrdy	),//input			
		
		.ubus_clki					(ubus_clki				),//input			
		.ubus_rstn					(ubus_rstn				));//input			

	pcie_link_rdma_data			u_pcie_link_rdma_odat(
		.pcie_xdma_rows_numb		(pcie_xdma_rows_numb	),//input		[19 : 0]
		.pcie_xdma_cols_numb		(pcie_xdma_cols_numb	),//input		[15 : 0]
		.pcie_link_rdma_base		(pcie_xdma_ddrs_base	),//input		[24 : 0]
		.pcie_link_rdma_enab		(pcie_link_rdma_enab	),//input				
		.pcie_link_rdma_done		(pcie_link_rdma_done	),//output				

		.pcie_axis_rdma_trdy		(pcie_axis_rdma_trdy	),//input				
		.pcie_axis_rdma_drdy		(pcie_axis_rdma_drdy	),//output				
		.pcie_axis_rdma_data		(pcie_axis_rdma_data	),//output		[255:0]	
		.pcie_axis_rdma_last		(pcie_axis_rdma_last	),//output		[255:0]	
		
		.pcie_aclk					(pcie_aclk				),//input				
		.pcie_bclk					(pcie_bclk				),//input				
		.pcie_rstn					(pcie_rstn				),//input				
	
		.ubus_pcie_rdma_csen		(ubus_pcie_rdma_csen	),//output	reg			
		.ubus_pcie_rdma_addr		(ubus_pcie_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_pcie_rdma_trdy		(ubus_pcie_rdma_trdy	),//input				
		.ubus_pcie_rdma_data		(ubus_pcie_rdma_data	),//input		[255: 0]
		.ubus_pcie_rdma_drdy		(ubus_pcie_rdma_drdy	),//input				

		.ubus_clki					(ubus_clki				),//input			
		.ubus_rstn					(ubus_rstn				));//input			

endmodule 

