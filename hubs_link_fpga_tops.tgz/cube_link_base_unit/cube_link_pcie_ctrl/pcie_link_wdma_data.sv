/*----author edward------*/
module	pcie_link_wdma_data(

//----------------------------------------------------------------------	
	input		[19 : 0]			pcie_xdma_rows_numb	,
	input		[31 : 0]			pcie_xdma_cols_numb	,

	input		[24 : 0]			pcie_link_wdma_base	,
	input							pcie_link_wdma_enab	,//write enable
	output							pcie_link_wdma_done	,//pcie bar clock domain
	input							pcie_bclk			,

	output		reg					pcie_axis_wdma_trdy	,
	input							pcie_axis_wdma_drdy	,
	input		[255:0]				pcie_axis_wdma_data	,
	input							pcie_aclk			,
	input							pcie_rstn			,
	
	output							ubus_pcie_wdma_csen	,
	output		[ 24: 0]			ubus_pcie_wdma_addr	,
	output		[255: 0]			ubus_pcie_wdma_data	,
	input							ubus_pcie_wdma_trdy	,
	input							ubus_pcie_wdma_wrdy	,
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg			[ 24:0]				pcie_wlnk_page_size	;
	reg			[ 24:0]				pcie_wlnk_page_addr	;

	wire		[ 24:0]				pcie_wlnk_page_numb	;
	wire		[ 24:0]				pcie_wlnk_page_leng	;
	wire							pcie_wlnk_page_tiny	;
	
	assign	pcie_wlnk_page_leng	=	pcie_xdma_cols_numb[28: 4];
	assign	pcie_wlnk_page_tiny	= |	pcie_xdma_cols_numb[ 3: 0];
	assign	pcie_wlnk_page_numb	=	pcie_wlnk_page_leng + pcie_wlnk_page_tiny	;
	
	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)					pcie_wlnk_page_size	<=	0	;
	else if(~pcie_link_wdma_enab)	pcie_wlnk_page_size	<=	pcie_wlnk_page_numb	;	

	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)					pcie_wlnk_page_addr	<=	0	;
	else if(~pcie_link_wdma_enab)	pcie_wlnk_page_addr	<=	pcie_link_wdma_base	;	
/**********************************************************************************************************/
//sync enable mode signal
	reg		[  2: 0]				pcie_wdma_enab_samp	;
	reg		[  2: 0]				ubus_wdma_enab_samp	;

	wire							pcie_axis_wdma_disa	=	pcie_wdma_enab_samp[1:0] == 2'B00	;
	wire							pcie_axis_wdma_init	=	pcie_wdma_enab_samp[1:0] == 2'B10	;

	wire							ubus_ddrs_wdma_disa	=	ubus_wdma_enab_samp[1:0] == 2'B00	;
	wire							ubus_ddrs_wdma_init	=	ubus_wdma_enab_samp[1:0] == 2'B10	;
	wire							ubus_ddrs_wdma_enab	=	ubus_wdma_enab_samp[1:0] == 2'B11	;

	always@(posedge pcie_aclk or negedge  pcie_rstn)
	if(~pcie_rstn)					pcie_wdma_enab_samp	<=	0	;
	else							pcie_wdma_enab_samp	<={	pcie_link_wdma_enab	, pcie_wdma_enab_samp[2:1]	};	

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_enab_samp	<=	0	;
	else							ubus_wdma_enab_samp	<={	pcie_link_wdma_enab	, ubus_wdma_enab_samp[2:1]	};	
/**********************************************************************************************************/
	reg								pcie_axis_wdma_csen	;
	reg		[ 24: 0]				pcie_axis_wdma_addr	;
	reg		[ 24: 0]				pcie_axis_push_cnts	;

	wire	[  8: 0]				pcie_axis_push_dptr	;
	wire							pcie_axis_wdma_last	;
	wire							pcie_axis_wdma_vlid	;

	wire	[ 24: 0]				pcie_push_cnts_inc1	;
	wire	[ 24: 0]				pcie_axis_push_ovfl	;
	wire	[ 24: 0]				ubus_ddrs_pops_sync	;

	assign	pcie_push_cnts_inc1	=	pcie_axis_push_cnts + 1		;
	assign	pcie_axis_push_dptr	=	pcie_axis_push_cnts[8 : 0]	;
	assign	pcie_axis_push_ovfl	=	ubus_ddrs_pops_sync + 9'H80	;
	
	assign	pcie_axis_wdma_trdy	= &{pcie_axis_wdma_csen	,	pcie_axis_push_ovfl >	pcie_push_cnts_inc1	};
	assign	pcie_axis_wdma_vlid	= &{pcie_axis_wdma_trdy	,	pcie_axis_wdma_drdy	};
	assign	pcie_axis_wdma_last	= &{pcie_axis_wdma_vlid	,	pcie_wlnk_page_size	== 	pcie_push_cnts_inc1 };
	
	always@(posedge pcie_aclk or negedge pcie_rstn )
	if(!pcie_rstn)					pcie_axis_wdma_csen	<=	0	;	
	else if(pcie_axis_wdma_init)	pcie_axis_wdma_csen	<=	1	;	
	else if(pcie_axis_wdma_last)	pcie_axis_wdma_csen	<=	0	;	

	always@(posedge pcie_aclk or negedge pcie_rstn )
	if(!pcie_rstn)					pcie_axis_wdma_addr	<=	0	;
	else if(pcie_axis_wdma_disa)	pcie_axis_wdma_addr	<=	0	;
	else if(pcie_axis_wdma_init)	pcie_axis_wdma_addr	<=	pcie_wlnk_page_addr	;
	else if(pcie_axis_wdma_csen)	pcie_axis_wdma_addr	<=	pcie_axis_wdma_addr	+ pcie_axis_wdma_vlid	;

	always@(posedge pcie_aclk or negedge pcie_rstn )
	if(!pcie_rstn)					pcie_axis_push_cnts	<=	0	;	
	else if(pcie_axis_wdma_disa)	pcie_axis_push_cnts	<=	0	;	
	else if(pcie_axis_wdma_csen)	pcie_axis_push_cnts	<=	pcie_axis_push_cnts + pcie_axis_wdma_vlid	;	
/**********************************************************************************************************/
	reg								ubus_ddrs_pops_csen	;
	reg								ubus_ddrs_pops_done	;
	reg		[ 24: 0]				ubus_ddrs_pops_cnts	;
	
	wire	[ 24: 0]				ubus_pops_cnts_inc1	;
	wire	[ 24: 0]				pcie_ubus_push_sync	;

	wire							ubus_ddrs_pops_vlid	;
	wire							ubus_ddrs_pops_last	;
	
	wire	[  8: 0]				ubus_pcie_wdma_lsba	;
	wire	[  8: 0]				ubus_pcie_wdma_nxta	;
	wire	[  8: 0]				ubus_pcie_wdma_dptr	;

	assign	ubus_pcie_wdma_lsba	=	ubus_ddrs_pops_cnts[8:0]	;
	assign	ubus_pcie_wdma_nxta	=	ubus_pcie_wdma_lsba +  1	;
	assign	ubus_pcie_wdma_dptr	=	ubus_pcie_wdma_csen	?	ubus_pcie_wdma_nxta	:	ubus_pcie_wdma_lsba	;

	assign	ubus_pops_cnts_inc1	=	ubus_ddrs_pops_cnts	+ 1	;
	
	assign	ubus_ddrs_pops_vlid	= &{ubus_ddrs_pops_csen	,	
									pcie_ubus_push_sync	>=	ubus_pops_cnts_inc1	};

	assign	ubus_ddrs_pops_last	= &{ubus_ddrs_pops_csen	,	ubus_pcie_wdma_csen	,	
									ubus_pops_cnts_inc1 ==	pcie_wlnk_page_size	};

	assign	ubus_pcie_wdma_csen	= &{ubus_ddrs_pops_csen	,	ubus_ddrs_pops_vlid	,	
									ubus_pcie_wdma_trdy	,	ubus_pcie_wdma_wrdy	};
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_ddrs_pops_csen	<=	0	;
	else if(ubus_ddrs_wdma_disa)	ubus_ddrs_pops_csen	<=	0	;
	else if(ubus_ddrs_wdma_init)	ubus_ddrs_pops_csen	<=	1	;
	else if(ubus_ddrs_pops_last)	ubus_ddrs_pops_csen	<=	0	;
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_ddrs_pops_done	<=	0	;	
	else if(ubus_ddrs_wdma_disa)	ubus_ddrs_pops_done	<=	0	;	
	else if(ubus_ddrs_pops_last)	ubus_ddrs_pops_done	<=	1	;	
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_ddrs_pops_cnts	<=	0	;	
	else if(ubus_ddrs_wdma_disa)	ubus_ddrs_pops_cnts	<=	0	;	
	else if(ubus_ddrs_wdma_init)	ubus_ddrs_pops_cnts	<=	0	;	
	else 							ubus_ddrs_pops_cnts	<=	ubus_ddrs_pops_cnts + ubus_pcie_wdma_csen	;	
/**********************************************************************************************************/
	reg			[ 1: 0]				pcie_wdma_done_samp	;
	assign	pcie_link_wdma_done	=	pcie_wdma_done_samp[0]	;

	always@(posedge pcie_bclk or negedge  pcie_rstn)
	if(~pcie_rstn)					pcie_wdma_done_samp	<=	0	;
	else							pcie_wdma_done_samp	<={	ubus_ddrs_pops_done	, pcie_wdma_done_samp[ 1 ]	};	
/**********************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )
								u_pcie_dptr_sync_gens(
		.data_asyn					(pcie_axis_push_cnts	),//input	[24: 0]	
		.scki						(pcie_aclk				),

		.data_sync					(pcie_ubus_push_sync	),//output	[24: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			

	gens_sync_gray	#( .MSB(24) )
								u_ubus_dptr_sync_gens(
		.data_asyn					(ubus_ddrs_pops_cnts	),//input	[24: 0]	
		.scki						(ubus_clki				),
		
		.data_sync					(ubus_ddrs_pops_sync	),//output	[24: 0]	
		.clki						(pcie_aclk				),//input			
		.rstn						(pcie_rstn				));//input			


	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
								u_idat_wdma_beat_data (
		.wport_csen					(pcie_axis_wdma_vlid	),//input  				 		
		.wport_data					(pcie_axis_wdma_data	),//input		[DATA_BITS-1:0]
		.wport_addr					(pcie_axis_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(pcie_aclk				),//input						

		.rport_addr					(ubus_pcie_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_pcie_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
								u_idat_wdma_beat_addr (
		.wport_csen					(pcie_axis_wdma_vlid	),//input  				 		
		.wport_data					(pcie_axis_wdma_addr	),//input		[DATA_BITS-1:0]
		.wport_addr					(pcie_axis_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_clki					(pcie_aclk				),//input						
		
		.rport_addr					(ubus_pcie_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_pcie_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						
 

endmodule 

