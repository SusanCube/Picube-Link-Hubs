/*----author edward------*/
module	noddr_pcie_link_rdma_data(
	input								pcie_link_rdma_enab	,
	output								pcie_link_rdma_done	,
	input		[24 : 0]				pcie_link_rdma_base	,
	input		[31 : 0]				pcie_link_rdma_cols	,
	input								pcie_bclk			,

	input								pcie_axis_rdma_trdy	,
	output								pcie_axis_rdma_drdy	,
	output								pcie_axis_rdma_last	,
	output		[255:0]					pcie_axis_rdma_data	,
	input								pcie_aclk			,
	input								pcie_rstn			,

	output								ubus_pcie_rdma_csen	,
	output	reg	[ 24: 0]				ubus_pcie_rdma_addr	,
	input								ubus_pcie_rdma_trdy	,
	input		[255: 0]				ubus_pcie_rdma_data	,
	input								ubus_pcie_rdma_drdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire		[25: 0]					pcie_rdma_axis_cfig	= {	pcie_link_rdma_enab	,	pcie_link_rdma_cols[28: 4]	};

	wire		[25: 0]					pcie_rdma_cfig_gray	;
	wire								pcie_rdma_ddrs_enab	=	pcie_rdma_cfig_gray[25:25]	;	
	wire		[24: 0]					pcie_rdma_ddrs_page	=	pcie_rdma_cfig_gray[24: 0]	;	
	wire		[21: 0]					pcie_rdma_ddrs_pack	=	pcie_rdma_cfig_gray[24: 3]	;	
	wire		[ 2: 0]					pcie_rdma_ddrs_rmnt	=	pcie_rdma_cfig_gray[ 2: 0]	;	

	wire								pcie_rdma_task_vlid	= |	pcie_rdma_cfig_gray[24: 0]	;	

	gens_sync_gray #(.MSB(25))		u_pcie_rdma_cfig_gray(
		.data_asyn						(pcie_rdma_axis_cfig	),//input	[MSB: 0]
		.scki							(pcie_bclk				),//input			

		.data_sync						(pcie_rdma_cfig_gray	),//
		.clki							(pcie_aclk				),//
		.rstn							(pcie_rstn				));//
//------------------------------------------------------------------------------
	wire		[25: 0]					pcie_rdma_ubus_cfig	= {	pcie_link_rdma_enab	,	pcie_link_rdma_base[24: 0]	};

	wire		[25: 0]					ubus_rdma_cfig_gray	;
	wire								ubus_rdma_ddrs_enab	=	ubus_rdma_cfig_gray[25:25]	;
	wire		[24: 0]					ubus_rdma_ddrs_addr	=	ubus_rdma_cfig_gray[24: 0]	;
//--------------------------------------
	gens_sync_gray	#(.MSB(25))		u_ubus_rdma_cfig_gray(
		.data_asyn						(pcie_rdma_ubus_cfig	),//input	[23: 0]	
		.scki							(pcie_bclk				),
		
		.data_sync						(ubus_rdma_cfig_gray	),//output	[23: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input		
//------------------------------------------------------------------------------
	wire								pcie_hits_rdma_done	;

	gens_sign_slow_fast	#(.EXTN(2))	u_gens_tune_rxdi_done(
		.slow_sign						(pcie_hits_rdma_done	),//output	
		.slow_clki						(pcie_aclk				),//input	
		.slow_rstn						(pcie_rstn				),

		.fast_sign  					(pcie_link_rdma_done	),//input	
		.fast_clki						(pcie_bclk		),//input	
		.fast_rstn						(pcie_rstn		));//input	

/**********************************************************************************************************************/
	reg			[3: 0]					pcie_rdma_ddrs_mfsm	;

	parameter	PCIE_RDMA_DDRS_IDLE	=	4'H0	;
	parameter	PCIE_RDMA_DDRS_REQS	=	4'H1	;
	parameter	PCIE_RDMA_UBUS_REQS	=	4'H2	;
	parameter	PCIE_RDMA_UBUS_PACK	=	4'H3	;
	parameter	PCIE_RDMA_DDRS_SEEK	=	4'H4	;
	parameter	PCIE_RDMA_PACK_REQS	=	4'H5	;
	parameter	PCIE_RDMA_PACK_DATA	=	4'H6	;
	parameter	PCIE_RDMA_RMNT_REQS	=	4'H7	;
	parameter	PCIE_RDMA_RMNT_DATA	=	4'H8	;
	parameter	PCIE_RDMA_DDRS_LOOP	=	4'H9	;
	parameter	PCIE_RDMA_DDRS_DONE	=	4'HA	;
//------------------------------------------------------------------------------
	wire								pcie_rdma_ubus_vlid	;
	wire								pcie_rdma_task_done	;

	reg									pcie_rdma_pack_resv	;
	wire								pcie_rdma_pack_last	;
	wire								pcie_rdma_rmnt_last	;

	
	always@(posedge pcie_aclk or negedge  pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_ddrs_mfsm	<=	PCIE_RDMA_DDRS_IDLE	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_ddrs_mfsm	<=	PCIE_RDMA_DDRS_IDLE	;
	else begin
		case(pcie_rdma_ddrs_mfsm)	
				PCIE_RDMA_DDRS_IDLE	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_task_vlid	?	PCIE_RDMA_DDRS_REQS	:	PCIE_RDMA_DDRS_DONE	;
				PCIE_RDMA_DDRS_REQS	:	pcie_rdma_ddrs_mfsm	<=													PCIE_RDMA_UBUS_REQS	;
				PCIE_RDMA_UBUS_REQS	:	pcie_rdma_ddrs_mfsm	<=													PCIE_RDMA_UBUS_PACK	;
				PCIE_RDMA_UBUS_PACK	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_ubus_vlid	?	PCIE_RDMA_DDRS_SEEK	:	PCIE_RDMA_UBUS_PACK	;	
				PCIE_RDMA_DDRS_SEEK	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_pack_resv	?	PCIE_RDMA_PACK_REQS	:	PCIE_RDMA_RMNT_REQS	;
				PCIE_RDMA_PACK_REQS	:	pcie_rdma_ddrs_mfsm	<=													PCIE_RDMA_PACK_DATA	;
				PCIE_RDMA_PACK_DATA	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_pack_last	?	PCIE_RDMA_DDRS_LOOP	:	PCIE_RDMA_PACK_DATA	;
				PCIE_RDMA_RMNT_REQS	:	pcie_rdma_ddrs_mfsm	<=													PCIE_RDMA_RMNT_DATA	;
				PCIE_RDMA_RMNT_DATA	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_rmnt_last	?	PCIE_RDMA_DDRS_DONE	:	PCIE_RDMA_RMNT_DATA	;
				PCIE_RDMA_DDRS_LOOP	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_task_done	?	PCIE_RDMA_DDRS_DONE	:	PCIE_RDMA_UBUS_REQS	;
				PCIE_RDMA_DDRS_DONE	:	pcie_rdma_ddrs_mfsm	<=	pcie_rdma_ddrs_enab	?	PCIE_RDMA_DDRS_DONE	:	PCIE_RDMA_DDRS_IDLE	;	

				default				:	pcie_rdma_ddrs_mfsm	<=													PCIE_RDMA_DDRS_IDLE	;
		endcase
	end
//------------------------------------------------------------------------------
	wire								pcie_hits_ddrs_reqs	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_DDRS_REQS	;
	wire								pcie_hits_ddrs_seek	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_DDRS_SEEK	;
	wire								pcie_hits_ddrs_done	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_DDRS_DONE	;
	
	
	wire								pcie_hits_ubus_reqs	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_UBUS_REQS	;
	wire								pcie_hits_pack_reqs	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_PACK_REQS	;
	wire								pcie_hits_pack_data	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_PACK_DATA	;
	wire								pcie_hits_rmnt_reqs	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_RMNT_REQS	;
	wire								pcie_hits_rmnt_data	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_RMNT_DATA	;
	assign								pcie_hits_rdma_done	=	pcie_rdma_ddrs_mfsm	==	PCIE_RDMA_DDRS_DONE	;
/**********************************************************************************************************************/
	wire								ubus_rdma_pack_reqs	;
	wire								ubus_pack_data_done	;
//------------------------------------------------------------------------------
	gens_edge_fast_slow	#(.EXTN(5))	u_ubus_rdma_pack_reqs(	
		.slow_edge						(ubus_rdma_pack_reqs	),//output	
		.slow_clki						(ubus_clki				),//input	
		.slow_rstn						(ubus_rstn				),//input	

		.fast_sign  					(pcie_hits_ubus_reqs	),//input
		.fast_clki						(pcie_aclk				),//input
		.fast_rstn						(pcie_rstn				));//input
//------------------------------------------------------------------------------
	gens_edge_slow_fast				u_ubus_pack_data_done(
		.fast_edge						(pcie_rdma_ubus_vlid	),//output	
		.fast_clki						(pcie_aclk				),//input	
		.fast_rstn						(pcie_rstn				),//input	

		.slow_sign  					(ubus_pack_data_done	),//input	
		.slow_clki						(ubus_clki				),//input	
		.slow_rstn						(ubus_rstn				));//input	
	//------------------------------------------------------------------------------
	reg									ubus_pack_cmnd_csen	;
	reg									ubus_pack_data_csen	;

	reg		[ 2: 0]						ubus_pack_cmnd_cnts	;
	reg		[ 2: 0]						ubus_pack_data_cnts	;

	wire		ubus_pack_cmnd_done = &{ubus_pack_cmnd_cnts	,	ubus_pack_cmnd_csen	};
	assign		ubus_pack_data_done = &{ubus_pack_data_cnts	,	ubus_pcie_rdma_drdy	};
	assign		ubus_pcie_rdma_csen	=	ubus_pack_cmnd_csen	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_pack_cmnd_csen	<=	0	;
	else if(ubus_rdma_pack_reqs)		ubus_pack_cmnd_csen	<=	1	;	
	else if(ubus_pack_cmnd_done)		ubus_pack_cmnd_csen	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_pack_data_csen	<=	0	;
	else if(ubus_rdma_pack_reqs)		ubus_pack_data_csen	<=	1	;	
	else if(ubus_pack_data_done)		ubus_pack_data_csen	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_pack_cmnd_cnts	<=	0	;
	else if(ubus_rdma_pack_reqs)		ubus_pack_cmnd_cnts	<=	0	;	
	else if(ubus_pack_cmnd_csen)		ubus_pack_cmnd_cnts	<=	ubus_pack_cmnd_done	?	0	:	ubus_pack_cmnd_cnts + 1;	
	else 								ubus_pack_cmnd_cnts	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_pack_data_cnts	<=	0	;
	else if(ubus_rdma_pack_reqs)		ubus_pack_data_cnts	<=	0	;	
	else if(ubus_pcie_rdma_drdy)		ubus_pack_data_cnts	<=	ubus_pack_data_done	?	0	:	ubus_pack_data_cnts + 1;
	else								ubus_pack_data_cnts	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_pcie_rdma_addr	<=	0	;
	else if(~ubus_rdma_ddrs_enab)		ubus_pcie_rdma_addr	<=	ubus_rdma_ddrs_addr	;	
	else if( ubus_pack_cmnd_csen)		ubus_pcie_rdma_addr	<=	ubus_pcie_rdma_addr + 1;
//------------------------------------------------------------------------------
	wire	[ 0: 7]						ubus_rdma_data_wrcs	;

	(* ram_style="block" *) 			
	reg		[ 0: 7][255: 0]				ubus_rdma_data_memo	;
	(* ram_style="block" *) 			
	reg		[ 0: 7][255: 0]				pcie_rdma_data_memo	;
	

	for(genvar i = 0 ; i < 8 ; i++ )	begin: ubus_rdma_memo_wrcs
		assign	ubus_rdma_data_wrcs[i]= &{ubus_pcie_rdma_drdy	,	ubus_pack_data_cnts	==	i}	;

		always@(posedge ubus_clki or negedge ubus_rstn)
		if(~ubus_rstn)					ubus_rdma_data_memo[i]	<=	0	;
		else if(ubus_rdma_data_wrcs[i])	ubus_rdma_data_memo[i]	<=	ubus_pcie_rdma_data	;

		always@(posedge pcie_aclk or negedge pcie_rstn)
		if(~pcie_rstn)					pcie_rdma_data_memo[i]	<=	0	;
		else if( pcie_hits_ddrs_seek )	pcie_rdma_data_memo[i]	<=	ubus_rdma_data_memo[i]	;
	end
/**********************************************************************************************************************/
	reg			[24: 0]					pcie_rdma_data_pole	;						
	reg			[24: 0]					pcie_rdma_data_cnts	;						
	reg			[21: 0]					pcie_rdma_pack_cnts	;
	reg			[ 2: 0]					pcie_rdma_page_cnts	;

	wire		[ 2: 0]					pcie_rdma_page_inc1	;

	assign		pcie_axis_rdma_drdy	= &{pcie_axis_rdma_trdy	,	pcie_hits_pack_data | 	pcie_hits_rmnt_data	};
	assign		pcie_axis_rdma_last	= &{pcie_axis_rdma_drdy	,	pcie_rdma_data_pole ==	pcie_rdma_data_cnts };
	assign		pcie_axis_rdma_data	= 	pcie_rdma_data_memo[pcie_rdma_page_cnts]	;

	assign		pcie_rdma_page_inc1	=	pcie_rdma_page_cnts + 1	;
	assign		pcie_rdma_pack_last	= &{pcie_axis_rdma_drdy	,	pcie_hits_pack_data	,	pcie_rdma_page_cnts	==	3'H7 				};
	assign		pcie_rdma_rmnt_last	= &{pcie_axis_rdma_drdy	,	pcie_hits_rmnt_data	,	pcie_rdma_page_inc1	==	pcie_rdma_ddrs_rmnt	};

	assign		pcie_rdma_task_done	=	pcie_rdma_data_cnts	==	pcie_rdma_ddrs_page	;

	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_pack_cnts	<=	0	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_pack_cnts	<=	0	;	
	else if( pcie_hits_pack_reqs)		pcie_rdma_pack_cnts	<=	pcie_rdma_pack_cnts + 1	;	

	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_page_cnts	<=	0	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_page_cnts	<=	0	;	
	else if( pcie_hits_pack_reqs)		pcie_rdma_page_cnts	<=	0	;	
	else if( pcie_hits_rmnt_reqs)		pcie_rdma_page_cnts	<=	0	;	
	else if( pcie_axis_rdma_drdy)		pcie_rdma_page_cnts	<=	pcie_rdma_page_cnts + 1	;	

	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_data_pole	<=	0	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_data_pole	<=	pcie_rdma_ddrs_page	- 1	;	
	
	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_data_cnts	<=	0	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_data_cnts	<=	0	;	
	else if( pcie_axis_rdma_drdy)		pcie_rdma_data_cnts	<=	pcie_rdma_data_cnts + 1	;	

	always@(posedge pcie_aclk or negedge pcie_rstn)
	if(~pcie_rstn)						pcie_rdma_pack_resv	<=	0	;
	else if(~pcie_rdma_ddrs_enab)		pcie_rdma_pack_resv	<=	0	;	
	else 								pcie_rdma_pack_resv	<=	pcie_rdma_ddrs_page >=	pcie_rdma_data_cnts + 8		;	
/**********************************************************************************************************************/
endmodule 
 
