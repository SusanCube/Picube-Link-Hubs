

module	tpes_link_rxdi_tune	(
	output	reg						tpem_tune_bslp	,
	input							tpem_tune_mode	,
	input	[39 :0]					tpem_txdo_pack	,
	input							tpem_sclk		,
	input							tpem_rstn		,

	output							tpes_tune_good	,
	output	reg [39:0]				tpes_tune_acks	,
    input							tpes_sclk		,
	input                           tpes_rstn       );	
/**********************************************************************/	
	reg		[ 1: 0]					tpem_txdo_tune_samp	;
	wire	tpem_txdo_tune_enab	=	tpem_txdo_tune_samp[0]	;

	always@(posedge	tpem_sclk or negedge  tpem_rstn)
	if(~tpem_rstn)					tpem_txdo_tune_samp	<=	0	;
	else							tpem_txdo_tune_samp	<=	{tpem_tune_mode	,	tpem_txdo_tune_samp[1]}	;
/**********************************************************************/	
	reg		[ 2: 0]					tpem_tune_mfsm	;
	reg		[ 3: 0]					tpem_seek_time	;
	reg		[ 3: 0]					tpem_patn_cnts	;
	reg		[13: 0]					tpem_pdtv_time	;
	reg								tpem_tune_good	;
	
	reg		[39: 0]					tpem_samp_patn	;	

	parameter		TPEM_TUNE_PATN_IDLE	=	3'H0	;
	parameter		TPEM_TUNE_PHSE_DETC	=	3'H1	;
	parameter		TPEM_TUNE_PATN_SEEK	=	3'H2	;
	parameter		TPEM_TUNE_PATN_BSLP	=	3'H3	;
	parameter		TPEM_TUNE_PATN_GOOD	=	3'H4	;

	wire							tpem_patn_fram_miss	;	
	wire							tpem_patn_seek_tmax	;	
	wire							tpem_patn_seek_miss	;	
	wire							tpem_phse_detc_tmax	;				

	wire							tpem_tune_hits_idle;
	wire							tpem_tune_hits_pdtv;
	wire							tpem_tune_hits_seek	;
	wire							tpem_tune_hits_bslp	;
	wire							tpem_tune_hits_good	;


`ifdef	FAST_SIMU
	assign	tpem_phse_detc_tmax	= &	tpem_pdtv_time[10:0]	;
`else
	assign	tpem_phse_detc_tmax	= &	tpem_pdtv_time[13:0]	;
`endif
	
	assign	tpem_patn_fram_miss	=	tpem_txdo_pack !=	40'H9A9A9A9A9A	;
	assign	tpem_patn_seek_tmax	=	tpem_seek_time 	==	4'HF	;
	assign	tpem_patn_seek_miss	=	tpem_patn_cnts 	<=	4'H8	;
	
	assign	tpem_tune_hits_idle=	tpem_tune_mfsm	==	TPEM_TUNE_PATN_IDLE	;
	assign	tpem_tune_hits_pdtv=	tpem_tune_mfsm	==	TPEM_TUNE_PHSE_DETC	;
	assign	tpem_tune_hits_seek	=	tpem_tune_mfsm	==	TPEM_TUNE_PATN_SEEK	;
	assign	tpem_tune_hits_bslp	=	tpem_tune_mfsm	==	TPEM_TUNE_PATN_BSLP	;
	assign	tpem_tune_hits_good	=	tpem_tune_mfsm	==	TPEM_TUNE_PATN_GOOD	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_tune_mfsm	<=	TPEM_TUNE_PATN_IDLE	;
	else if( tpem_txdo_tune_enab) begin
		case(tpem_tune_mfsm)
			TPEM_TUNE_PATN_IDLE	:	tpem_tune_mfsm	<=							TPEM_TUNE_PHSE_DETC	;
			TPEM_TUNE_PHSE_DETC	:	tpem_tune_mfsm	<=	tpem_phse_detc_tmax	?	TPEM_TUNE_PATN_SEEK	:	TPEM_TUNE_PHSE_DETC	;
			TPEM_TUNE_PATN_SEEK	:	tpem_tune_mfsm	<=	tpem_patn_seek_tmax	?	TPEM_TUNE_PATN_BSLP	:	TPEM_TUNE_PATN_SEEK	;
			TPEM_TUNE_PATN_BSLP	:	tpem_tune_mfsm	<=	tpem_patn_seek_miss	?	TPEM_TUNE_PATN_SEEK	:	TPEM_TUNE_PATN_GOOD	;
			TPEM_TUNE_PATN_GOOD	:	tpem_tune_mfsm	<=							TPEM_TUNE_PATN_GOOD	;
			default				:	tpem_tune_mfsm	<=							TPEM_TUNE_PATN_IDLE	;		
		endcase
	end	else						tpem_tune_mfsm	<=	TPEM_TUNE_PATN_IDLE	;
	
	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_samp_patn	<=	0	;
	else if( tpem_tune_hits_bslp)	tpem_samp_patn	<=	tpem_txdo_pack	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_seek_time	<=	0	;
	else if(~tpem_tune_hits_seek)	tpem_seek_time	<=	0	;
	else 							tpem_seek_time	<=	tpem_seek_time + 1	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_patn_cnts	<=	0	;
	else if( tpem_tune_hits_seek)	tpem_patn_cnts	<=	tpem_patn_fram_miss	?	4'H0	: tpem_patn_cnts + 1	;
	else							tpem_patn_cnts	<=	0	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_pdtv_time	<=	0	;
	else if( tpem_tune_hits_pdtv)	tpem_pdtv_time	<=	tpem_pdtv_time + 1	;
	else							tpem_pdtv_time	<=	0	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_tune_bslp	<=	0	;
	else if( tpem_tune_hits_bslp)	tpem_tune_bslp	<=	tpem_patn_seek_miss	;
	else							tpem_tune_bslp	<=	0	;

	always@(posedge	tpem_sclk or negedge tpem_rstn )
	if(~tpem_rstn)					tpem_tune_good	<=	0	;
	else							tpem_tune_good	<=	tpem_tune_hits_good	;	
/**********************************************************************/	
	reg		[ 3: 0]					tune_good_samp	;
	reg								txdo_patn_enab	;

	wire	tpes_tune_acks_send	= {	tune_good_samp[2] ,tune_good_samp[0]} ==	2'B10	;	
	
	always@(posedge	tpes_sclk or negedge  tpes_rstn)
	if(~tpes_rstn)					tune_good_samp	<=	0	;
	else							tune_good_samp	<=	{tpem_tune_good	,	tune_good_samp[3:1]}	;
/**********************************************************************/	
	always@(posedge	tpes_sclk)// or negedge  tpes_rstn)
	if(~tpes_rstn)					tpes_tune_acks	<=	40'H0	;
	else if( tpes_tune_acks_send) 	tpes_tune_acks	<=	40'HFF41434B53	;
	else							tpes_tune_acks	<=	40'H0	;
/**********************************************************************/	
	assign	tpes_tune_good	=	tune_good_samp[0]	;

endmodule





