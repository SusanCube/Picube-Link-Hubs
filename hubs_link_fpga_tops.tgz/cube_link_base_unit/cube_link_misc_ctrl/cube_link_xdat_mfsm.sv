
module	cube_link_xdat_mfsm(
	output							cube_link_xdat_idle	,
	output	reg						cube_link_ivct_done	,
	output	reg						cube_link_ovct_done	,
	output	reg						cube_link_imtx_done	,
	output	reg						cube_link_omtx_done	,

	output							cube_ivct_cmnd_lead	,
	output							cube_imtx_cmnd_lead	,
	output							cube_ovct_cmnd_lead	,
	output							cube_omtx_cmnd_lead	,
	output							cube_idat_cmnd_post	,
	output							cube_odat_cmnd_post	,

	output	reg						link_odat_rdma_enab	,
	output	reg						link_odat_rdma_mode	,
	input							link_odat_rdma_done	,
	output	reg						link_idat_wdma_enab	,
	output	reg						link_idat_wdma_mode	,
	input							link_idat_wdma_done	,

	input							cube_link_xdat_scut	,
	input							cube_link_ivct_reqs	,
	input							cube_link_ovct_reqs	,
	input							cube_link_imtx_reqs	,
	input							cube_link_omtx_reqs	,
	
	input							cube_link_cmnd_coda	,
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
		
	input							link_clki			,
	input							link_rstn			);
//********************************************************************************************************//
	reg		[ 3: 0]					cube_link_xdat_mfsm	;

	parameter	CUBE_LINK_XDAT_IDLE	=	4'H0	;
	parameter	CUBE_IVCT_CMND_LEAD	=	4'H1	;
	parameter	CUBE_IMTX_CMND_LEAD	=	4'H2	;
	parameter	CUBE_OVCT_CMND_LEAD	=	4'H3	;
	parameter	CUBE_OMTX_CMND_LEAD	=	4'H4	;

	parameter	CUBE_IDAT_CMND_POST	=	4'H5	;
	parameter	CUBE_IDAT_WDMA_DATA	=	4'H6	;
	parameter	CUBE_IDAT_WDMA_DONE	=	4'H7	;
	
	parameter	CUBE_ODAT_CMND_POST	=	4'H8	;
	parameter	CUBE_ODAT_ACKS_POST	=	4'H9	;
	parameter	CUBE_ODAT_RDMA_DATA	=	4'HA	;
	parameter	CUBE_ODAT_RDMA_DONE	=	4'HB	;
	parameter	CUBE_ODAT_SCUT_DONE	=	4'HC	;
	
	parameter	CUBE_LINK_XDAT_DONE	=	4'HD	;

	assign		cube_link_xdat_idle	=	cube_link_xdat_mfsm	==	CUBE_LINK_XDAT_IDLE	;
	assign		cube_ivct_cmnd_lead	=	cube_link_xdat_mfsm	==	CUBE_IVCT_CMND_LEAD	;
	assign		cube_ovct_cmnd_lead	=	cube_link_xdat_mfsm	==	CUBE_OVCT_CMND_LEAD	;
	assign		cube_imtx_cmnd_lead	=	cube_link_xdat_mfsm	==	CUBE_IMTX_CMND_LEAD	;
	assign		cube_omtx_cmnd_lead	=	cube_link_xdat_mfsm	==	CUBE_OMTX_CMND_LEAD	;
	assign		cube_idat_cmnd_post	=	cube_link_xdat_mfsm	==	CUBE_IDAT_CMND_POST	;
	
	wire		cube_odat_acks_coda	=	cube_link_xdat_mfsm	==	CUBE_ODAT_ACKS_POST	;

	assign		cube_odat_cmnd_post	=	cube_link_xdat_mfsm	==	CUBE_ODAT_CMND_POST	;
	assign		cube_odat_data_post	=	cube_link_xdat_mfsm	==	CUBE_ODAT_RDMA_DATA	;
	assign		cube_link_xdat_done	=	cube_link_xdat_mfsm	==	CUBE_LINK_XDAT_DONE	;
//********************************************************************************************************//
	wire							cube_scut_cmnd_coda	;
	wire							cube_link_xdat_reqs	;
	wire							cube_link_idat_reqs	;
	wire							cube_link_odat_reqs	;

	reg								cube_link_wdma_done	;


	assign	cube_scut_cmnd_coda	= &{cube_link_xdat_scut	,	cube_link_cmnd_coda};
	assign	cube_link_idat_reqs	= |{cube_link_ivct_reqs	,	cube_link_imtx_reqs	};
	assign	cube_link_odat_reqs	= |{cube_link_ovct_reqs	,	cube_link_omtx_reqs	};

	assign	cube_link_xdat_reqs	= |{cube_link_idat_reqs	,	cube_link_odat_reqs	};

	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)
		cube_link_xdat_mfsm	<=	CUBE_LINK_XDAT_IDLE	;
	else begin
		case(cube_link_xdat_mfsm)
			CUBE_LINK_XDAT_IDLE:	cube_link_xdat_mfsm	<=	cube_link_ivct_reqs	?	CUBE_IVCT_CMND_LEAD	:	
															cube_link_imtx_reqs	?	CUBE_IMTX_CMND_LEAD	:	
															cube_link_ovct_reqs	?	CUBE_OVCT_CMND_LEAD	:	
															cube_link_omtx_reqs	?	CUBE_OMTX_CMND_LEAD	:	CUBE_LINK_XDAT_IDLE	;
			
			CUBE_IVCT_CMND_LEAD	:	cube_link_xdat_mfsm	<=							CUBE_IDAT_CMND_POST	;	
			CUBE_IMTX_CMND_LEAD	:	cube_link_xdat_mfsm	<=							CUBE_IDAT_CMND_POST	;	
			CUBE_OVCT_CMND_LEAD	:	cube_link_xdat_mfsm	<=							CUBE_ODAT_CMND_POST	;	
			CUBE_OMTX_CMND_LEAD	:	cube_link_xdat_mfsm	<=							CUBE_ODAT_CMND_POST	;	

			CUBE_IDAT_CMND_POST	:	cube_link_xdat_mfsm	<=	cube_link_cmnd_coda	?	CUBE_IDAT_WDMA_DATA	:	CUBE_IDAT_CMND_POST	;
			CUBE_IDAT_WDMA_DATA	:	cube_link_xdat_mfsm	<=	cube_link_resp_coda	? (	cube_link_xdat_scut	?	CUBE_LINK_XDAT_DONE	:	CUBE_IDAT_WDMA_DONE	)	:	CUBE_IDAT_WDMA_DATA	;
			CUBE_IDAT_WDMA_DONE	:	cube_link_xdat_mfsm	<=	cube_link_wdma_done	?	CUBE_LINK_XDAT_DONE	:	CUBE_IDAT_WDMA_DONE	;


			CUBE_ODAT_CMND_POST	:	cube_link_xdat_mfsm	<=	cube_link_cmnd_coda	?	CUBE_ODAT_ACKS_POST	:	CUBE_ODAT_CMND_POST	;
			CUBE_ODAT_ACKS_POST	:	cube_link_xdat_mfsm	<=  cube_link_acks_coda	? (	cube_link_xdat_scut	?	CUBE_ODAT_RDMA_DONE	:	CUBE_ODAT_RDMA_DATA	)	:	CUBE_ODAT_ACKS_POST	;
			CUBE_ODAT_RDMA_DATA	:	cube_link_xdat_mfsm	<=	link_odat_rdma_done	? 	CUBE_ODAT_RDMA_DONE	:	CUBE_ODAT_RDMA_DATA	;
			CUBE_ODAT_RDMA_DONE	:	cube_link_xdat_mfsm	<=	cube_link_resp_coda	? 	CUBE_LINK_XDAT_DONE	:	CUBE_ODAT_RDMA_DONE	;

			CUBE_LINK_XDAT_DONE	:	cube_link_xdat_mfsm	<=	cube_link_xdat_reqs	?	CUBE_LINK_XDAT_DONE	:	CUBE_LINK_XDAT_IDLE	;
			default				:	cube_link_xdat_mfsm	<=	CUBE_LINK_XDAT_IDLE	;
		endcase		
	end



/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)	begin
		cube_link_ivct_done	<=	0	;
		cube_link_ovct_done	<=	0	;
		cube_link_imtx_done	<=	0	;
		cube_link_omtx_done	<=	0	;
	end else 	 	begin
		cube_link_ivct_done	<=	&{cube_link_ivct_reqs	,	cube_link_xdat_done};	;
		cube_link_ovct_done	<=	&{cube_link_ovct_reqs	,	cube_link_xdat_done};	;
		cube_link_imtx_done	<=	&{cube_link_imtx_reqs	,	cube_link_xdat_done};	;
		cube_link_omtx_done	<=	&{cube_link_omtx_reqs	,	cube_link_xdat_done};	;
	end
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					cube_link_wdma_done	<=	1'H0	;
	else if(cube_link_xdat_idle)	cube_link_wdma_done	<=	1'H0	;
	else if(cube_link_xdat_scut)	cube_link_wdma_done	<=	1'H0	;
	else if(link_idat_wdma_done)	cube_link_wdma_done	<=	1'B1	 ;
	
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_idat_wdma_enab	<=	1'H0	;
	else if(cube_link_xdat_idle)	link_idat_wdma_enab	<=	1'H0	;
	else if(cube_link_xdat_scut)	link_idat_wdma_enab	<=	1'H0	;
	else if(cube_link_cmnd_coda)	link_idat_wdma_enab	<=	cube_link_idat_reqs ;
	else if(link_idat_wdma_done)	link_idat_wdma_enab	<=	1'B0	;
	
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_idat_wdma_mode	<=	1'H0	;
	else if(cube_link_xdat_idle)	link_idat_wdma_mode	<=	1'H0	;
	else if(cube_link_xdat_scut)	link_idat_wdma_mode	<=	1'H0	;	
	else if(cube_link_cmnd_coda)	link_idat_wdma_mode	<=	cube_link_imtx_reqs ;
	else if(cube_link_resp_coda)	link_idat_wdma_mode	<=	1'H0	;
	
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_odat_rdma_enab	<=	1'H0	;
	else if(cube_link_xdat_idle)	link_odat_rdma_enab	<=	1'H0	;
	else if(cube_link_xdat_scut)	link_odat_rdma_enab	<=	1'H0	;
	else if(cube_odat_acks_coda)	link_odat_rdma_enab	<=	cube_link_acks_coda ;
	else if(link_odat_rdma_done)	link_odat_rdma_enab	<=	1'B0	;
	
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)					link_odat_rdma_mode	<=	1'H0	;
	else if(cube_link_xdat_idle)	link_odat_rdma_mode	<=	1'H0	;
	else if(cube_link_xdat_scut)	link_odat_rdma_mode	<=	1'H0	;
	else if(cube_link_acks_coda)	link_odat_rdma_mode	<=	cube_link_omtx_reqs ;
	else if(cube_link_resp_coda)	link_odat_rdma_mode	<=	1'H0	;
/**********************************************************************************************************/
	
endmodule
 