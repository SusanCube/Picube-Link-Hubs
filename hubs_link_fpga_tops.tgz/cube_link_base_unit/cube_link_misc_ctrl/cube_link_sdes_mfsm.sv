
module	cube_link_sdes_mfsm(
	output							cube_link_sdes_idle	,
	input							cube_link_risv_reqs	,
	input							cube_link_rosv_reqs	,
	input							cube_link_rism_reqs	,
	input							cube_link_rosm_reqs	,

	output	reg						cube_link_risv_done	,
	output	reg						cube_link_rosv_done	,
	output	reg						cube_link_rism_done	,
	output	reg						cube_link_rosm_done	,
		
	input							cube_link_cmnd_coda	,
	input							cube_link_acmd_coda	,
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
	
	output							cube_link_risv_lead	,
	output							cube_link_rosv_lead	,
	output							cube_link_rism_lead	,
	output							cube_link_rosm_lead	,
	output							cube_link_acmd_lead	,
	
	output							cube_link_cmnd_post	,
	output							cube_link_acmd_post	,
		
	input							link_clki			,
	input							link_rstn			);
/**********************************************************************************************************/
	reg		[ 3: 0]					cube_link_sdes_mfsm	;

	parameter	CUBE_LINK_SDES_IDLE	=	4'H0	;
	parameter	CUBE_LINK_RISV_LEAD	=	4'H1	;
	parameter	CUBE_LINK_ROSV_LEAD	=	4'H2	;
	parameter	CUBE_LINK_RISM_LEAD	=	4'H3	;
	parameter	CUBE_LINK_ROSM_LEAD	=	4'H4	;
	parameter	CUBE_LINK_CMND_POST	=	4'H5	;
	parameter	CUBE_LINK_ACKS_POST	=	4'H6	;
	parameter	CUBE_LINK_ACMD_LEAD	=	4'H7	;
	parameter	CUBE_LINK_ACMD_POST	=	4'H8	;
	parameter	CUBE_LINK_SDES_POST	=	4'H9	;
	parameter	CUBE_LINK_SDES_DONE	=	4'HA	;
/**********************************************************************************************************/
	wire							cube_link_sdes_reqs	;
	assign	cube_link_sdes_reqs	= |{cube_link_risv_reqs	,	cube_link_rosv_reqs	|	
									cube_link_rism_reqs	,	cube_link_rosm_reqs	};

	assign	cube_link_sdes_idle	=	cube_link_sdes_mfsm	==	CUBE_LINK_SDES_IDLE	;
	assign	cube_link_risv_lead	=	cube_link_sdes_mfsm	==	CUBE_LINK_RISV_LEAD	;
	assign	cube_link_rosv_lead	=	cube_link_sdes_mfsm	==	CUBE_LINK_ROSV_LEAD	;
	assign	cube_link_rism_lead	=	cube_link_sdes_mfsm	==	CUBE_LINK_RISM_LEAD	;
	assign	cube_link_rosm_lead	=	cube_link_sdes_mfsm	==	CUBE_LINK_ROSM_LEAD	;
	assign	cube_link_cmnd_post	=	cube_link_sdes_mfsm	==	CUBE_LINK_CMND_POST	;
	wire	cube_link_acks_post	=	cube_link_sdes_mfsm	==	CUBE_LINK_ACKS_POST	;
	assign	cube_link_acmd_lead	=	cube_link_sdes_mfsm	==	CUBE_LINK_ACMD_LEAD	;
	assign	cube_link_acmd_post	=	cube_link_sdes_mfsm	==	CUBE_LINK_ACMD_POST	;
	wire	cube_link_sdes_post	=	cube_link_sdes_mfsm	==	CUBE_LINK_SDES_POST	;
	assign	cube_link_sdes_done	=	cube_link_sdes_mfsm	==	CUBE_LINK_SDES_DONE	;
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(!link_rstn)
		cube_link_sdes_mfsm	<=	CUBE_LINK_SDES_IDLE	;
	else begin
		case(cube_link_sdes_mfsm)
			CUBE_LINK_SDES_IDLE:	cube_link_sdes_mfsm	<=	cube_link_risv_reqs	?	CUBE_LINK_RISV_LEAD	:	
															cube_link_rosv_reqs	?	CUBE_LINK_ROSV_LEAD	:	
															cube_link_rism_reqs	?	CUBE_LINK_RISM_LEAD	:	
															cube_link_rosm_reqs	?	CUBE_LINK_ROSM_LEAD	:	
																					CUBE_LINK_SDES_IDLE	;
			
			CUBE_LINK_RISV_LEAD	:	cube_link_sdes_mfsm	<=							CUBE_LINK_CMND_POST	;	
			CUBE_LINK_ROSV_LEAD	:	cube_link_sdes_mfsm	<=							CUBE_LINK_CMND_POST	;	
			CUBE_LINK_RISM_LEAD	:	cube_link_sdes_mfsm	<=							CUBE_LINK_CMND_POST	;	
			CUBE_LINK_ROSM_LEAD	:	cube_link_sdes_mfsm	<=							CUBE_LINK_CMND_POST	;	
			
			CUBE_LINK_CMND_POST	:	cube_link_sdes_mfsm	<=	cube_link_cmnd_coda	?	CUBE_LINK_ACKS_POST	:	CUBE_LINK_CMND_POST	;
			
			CUBE_LINK_ACKS_POST	:	cube_link_sdes_mfsm	<=	cube_link_acks_coda	?	CUBE_LINK_ACMD_LEAD	:	CUBE_LINK_ACKS_POST	;
			
			CUBE_LINK_ACMD_LEAD	:	cube_link_sdes_mfsm	<=							CUBE_LINK_ACMD_POST	;
			CUBE_LINK_ACMD_POST	:	cube_link_sdes_mfsm	<=	cube_link_acmd_coda	?	CUBE_LINK_SDES_POST	:	CUBE_LINK_ACMD_POST	;

			CUBE_LINK_SDES_POST	:	cube_link_sdes_mfsm	<=	cube_link_resp_coda	?	CUBE_LINK_SDES_DONE	:	CUBE_LINK_SDES_POST	;
			CUBE_LINK_SDES_DONE	:	cube_link_sdes_mfsm	<=	cube_link_sdes_reqs	?	CUBE_LINK_SDES_DONE	:	CUBE_LINK_SDES_IDLE	;
			default	:				cube_link_sdes_mfsm	<=							CUBE_LINK_SDES_IDLE	;
		endcase		
	end
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)	begin
		cube_link_risv_done	<=	0	;
		cube_link_rosv_done	<=	0	;
		cube_link_rism_done	<=	0	;
		cube_link_rosm_done	<=	0	;
	end else 	 	begin
		cube_link_risv_done	<=	&{cube_link_risv_reqs	,	cube_link_sdes_done	};
		cube_link_rosv_done	<=	&{cube_link_rosv_reqs	,	cube_link_sdes_done	};
		cube_link_rism_done	<=	&{cube_link_rism_reqs	,	cube_link_sdes_done	};
		cube_link_rosm_done	<=	&{cube_link_rosm_reqs	,	cube_link_sdes_done	};
	end

endmodule
 
 
