module	cube_link_cfig_mfsm(
	output							cube_link_cfig_idle	,

	output	reg						cube_link_trim_done	,//add @ 20241028
	output	reg						cube_link_icfg_done	,
	output	reg						cube_link_ocfg_done	,
	output	reg						cube_link_nnex_done	,
	output	reg						cube_link_aset_done	,
	output	reg						cube_link_dnld_done	,
	output	reg						cube_link_boot_done	,
	output	reg						cube_link_rivt_done	,
	output	reg						cube_link_rovt_done	,
	output	reg						cube_link_rimt_done	,
	output	reg						cube_link_romt_done	,

	output							cube_link_trim_lead	,
	output							cube_link_icfg_lead	,
	output							cube_link_ocfg_lead	,
	output							cube_link_nnex_lead	,
	output							cube_link_aset_lead	,
	output							cube_link_dnld_lead	,
	output							cube_link_boot_lead	,
	output							cube_link_rivt_lead	,
	output							cube_link_rovt_lead	,
	output							cube_link_rimt_lead	,
	output							cube_link_romt_lead	,

	output							cube_link_cmnd_post	,
	
	input							cube_link_cmnd_coda	,
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
		
	input							cube_link_trim_reqs	,//add @ 20241028
	input							cube_link_icfg_reqs	,
	input							cube_link_ocfg_reqs	,
	input							cube_link_nnex_reqs	,
	input							cube_link_aset_reqs	,
	input							cube_link_dnld_reqs	,
	input							cube_link_boot_reqs	,
	input							cube_link_rivt_reqs	,
	input							cube_link_rovt_reqs	,
	input							cube_link_rimt_reqs	,
	input							cube_link_romt_reqs	,
	
	input							link_clki			,
	input							link_rstn			);
//********************************************************************************************************//
	reg		[ 3: 0]					cube_link_cfig_mfsm	;
	reg								cube_link_remt_cmnd	;

	parameter	CUBE_LINK_CFIG_IDLE	=	4'H0	;
	parameter	CUBE_ICFG_CMND_LEAD	=	4'H1	;
	parameter	CUBE_OCFG_CMND_LEAD	=	4'H2	;
	parameter	CUBE_NNEX_CMND_LEAD	=	4'H3	;

	parameter	CUBE_TRIM_CMND_LEAD	=	4'H4	;

	parameter	CUBE_RIVT_CMND_LEAD	=	4'H5	;
	parameter	CUBE_RIMT_CMND_LEAD	=	4'H6	;
	parameter	CUBE_ROVT_CMND_LEAD	=	4'H7	;
	parameter	CUBE_ROMT_CMND_LEAD	=	4'H8	;
		
	parameter	CUBE_ASET_CMND_LEAD	=	4'H9	;
	parameter	CUBE_DNLD_CMND_LEAD	=	4'HA	;
	parameter	CUBE_BOOT_CMND_LEAD	=	4'HB	;

	parameter	CUBE_CFIG_CMND_TXDO	=	4'HC	;
	
	parameter	CUBE_CFIG_ACKS_RXDI	=	4'HD	;
	parameter	CUBE_CFIG_RESP_RXDI	=	4'HE	;
	
	parameter	CUBE_LINK_CFIG_DONE	=	4'HF	;
//********************************************************************************************************//
	assign		cube_link_cfig_idle	=	cube_link_cfig_mfsm	==	CUBE_LINK_CFIG_IDLE	;
	assign		cube_link_cmnd_post	=	cube_link_cfig_mfsm	==	CUBE_CFIG_CMND_TXDO	;
	assign		cube_link_cfig_done	=	cube_link_cfig_mfsm	==	CUBE_LINK_CFIG_DONE	;

	assign		cube_link_trim_lead	=	cube_link_cfig_mfsm	==	CUBE_TRIM_CMND_LEAD	;
	assign		cube_link_icfg_lead	=	cube_link_cfig_mfsm	==	CUBE_ICFG_CMND_LEAD	;
	assign		cube_link_ocfg_lead	=	cube_link_cfig_mfsm	==	CUBE_OCFG_CMND_LEAD	;
	assign		cube_link_nnex_lead	=	cube_link_cfig_mfsm	==	CUBE_NNEX_CMND_LEAD	;
	assign		cube_link_aset_lead	=	cube_link_cfig_mfsm	==	CUBE_ASET_CMND_LEAD	;	
	assign		cube_link_dnld_lead	=	cube_link_cfig_mfsm	==	CUBE_DNLD_CMND_LEAD	;	
	assign		cube_link_boot_lead	=	cube_link_cfig_mfsm	==	CUBE_BOOT_CMND_LEAD	;	
	assign		cube_link_rivt_lead	=	cube_link_cfig_mfsm	==	CUBE_RIVT_CMND_LEAD	;	
	assign		cube_link_rovt_lead	=	cube_link_cfig_mfsm	==	CUBE_ROVT_CMND_LEAD	;	
	assign		cube_link_rimt_lead	=	cube_link_cfig_mfsm	==	CUBE_RIMT_CMND_LEAD	;	
	assign		cube_link_romt_lead	=	cube_link_cfig_mfsm	==	CUBE_ROMT_CMND_LEAD	;	

/**********************************************************************************************************/
	wire		cube_link_cfig_reqs	=|{	cube_link_trim_reqs	,
										cube_link_icfg_reqs	,	cube_link_ocfg_reqs	,
										cube_link_nnex_reqs	,	cube_link_aset_reqs	,
										cube_link_dnld_reqs	,	cube_link_boot_reqs	,
										cube_link_rivt_reqs	,	cube_link_rovt_reqs	,
										cube_link_rimt_reqs	,	cube_link_romt_reqs};
	
	wire		cube_link_remt_reqs	=|{	cube_link_rivt_reqs	,	cube_link_rovt_reqs	,
										cube_link_rimt_reqs	,	cube_link_romt_reqs};										
//----------------------------------------------------------------------		
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					cube_link_cfig_mfsm	<=	CUBE_LINK_CFIG_IDLE	;
	else begin
		case(cube_link_cfig_mfsm)
			CUBE_LINK_CFIG_IDLE://0
				cube_link_cfig_mfsm	<=	cube_link_trim_reqs	?	CUBE_TRIM_CMND_LEAD	:	
										cube_link_icfg_reqs	?	CUBE_ICFG_CMND_LEAD	:	
										cube_link_ocfg_reqs	?	CUBE_OCFG_CMND_LEAD	:	
										cube_link_nnex_reqs	?	CUBE_NNEX_CMND_LEAD	:	
										cube_link_aset_reqs	?	CUBE_ASET_CMND_LEAD	:	
										cube_link_dnld_reqs	?	CUBE_DNLD_CMND_LEAD	:	
										cube_link_boot_reqs	?	CUBE_BOOT_CMND_LEAD	:
										cube_link_rivt_reqs	?	CUBE_RIVT_CMND_LEAD	:	
										cube_link_rovt_reqs	?	CUBE_ROVT_CMND_LEAD	:	
										cube_link_rimt_reqs	?	CUBE_RIMT_CMND_LEAD	:	
										cube_link_romt_reqs	?	CUBE_ROMT_CMND_LEAD	:	CUBE_LINK_CFIG_IDLE	;

			CUBE_TRIM_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_ICFG_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_OCFG_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_NNEX_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_ASET_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_DNLD_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_BOOT_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;	
			CUBE_RIVT_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;
			CUBE_RIMT_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;
			CUBE_ROVT_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;
			CUBE_ROMT_CMND_LEAD	:	cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;

			CUBE_CFIG_CMND_TXDO	:
				if(cube_link_cmnd_coda)
					cube_link_cfig_mfsm	<=	cube_link_trim_reqs	?	CUBE_LINK_CFIG_DONE	:	CUBE_CFIG_ACKS_RXDI	;
				else
					cube_link_cfig_mfsm	<=	CUBE_CFIG_CMND_TXDO	;

//				cube_link_cfig_mfsm	<=	cube_link_acks_coda	?	CUBE_LINK_CFIG_DONE	:	CUBE_CFIG_ACKS_RXDI	;
			CUBE_CFIG_ACKS_RXDI	:
				if(cube_link_acks_coda)	
					cube_link_cfig_mfsm	<=	cube_link_remt_cmnd	?	CUBE_CFIG_RESP_RXDI	:	CUBE_LINK_CFIG_DONE	;
				else
					cube_link_cfig_mfsm	<=	CUBE_CFIG_ACKS_RXDI	;

			CUBE_CFIG_RESP_RXDI	:
				cube_link_cfig_mfsm	<=	cube_link_resp_coda	?	CUBE_LINK_CFIG_DONE	:	CUBE_CFIG_RESP_RXDI	;

			CUBE_LINK_CFIG_DONE	:
				cube_link_cfig_mfsm	<=	cube_link_cfig_reqs	?	CUBE_LINK_CFIG_DONE	:	CUBE_LINK_CFIG_IDLE	;
//			default	:
//				cube_link_cfig_mfsm	<=							CUBE_LINK_CFIG_IDLE	;
		endcase		
	end
/**********************************************************************************************************/
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)					cube_link_remt_cmnd	<=	0	;
	else if(cube_link_cfig_idle)	cube_link_remt_cmnd	<=	cube_link_remt_reqs	;
	else if(cube_link_cfig_done)	cube_link_remt_cmnd	<=	0	;

	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)	begin
		cube_link_trim_done	<=	0	;
		cube_link_icfg_done	<=	0	;
		cube_link_ocfg_done	<=	0	;
		cube_link_nnex_done	<=	0	;
		cube_link_aset_done	<=	0	;
		cube_link_dnld_done	<=	0	;
		cube_link_boot_done	<=	0	;
		cube_link_rivt_done	<=	0	;
		cube_link_rovt_done	<=	0	;
		cube_link_rimt_done	<=	0	;
		cube_link_romt_done	<=	0	;
	end else	begin
		cube_link_trim_done	<=	&{cube_link_cfig_done	,	cube_link_trim_reqs	}	;
		cube_link_icfg_done	<=	&{cube_link_cfig_done	,	cube_link_icfg_reqs	}	;
		cube_link_ocfg_done	<=	&{cube_link_cfig_done	,	cube_link_ocfg_reqs	}	;
		cube_link_nnex_done	<=	&{cube_link_cfig_done	,	cube_link_nnex_reqs	}	;
		cube_link_aset_done	<=	&{cube_link_cfig_done	,	cube_link_aset_reqs	}	;
		cube_link_dnld_done	<=	&{cube_link_cfig_done	,	cube_link_dnld_reqs	}	;
		cube_link_boot_done	<=	&{cube_link_cfig_done	,	cube_link_boot_reqs	}	;
		cube_link_rivt_done	<=	&{cube_link_cfig_done	,	cube_link_rivt_reqs	}	;
		cube_link_rovt_done	<=	&{cube_link_cfig_done	,	cube_link_rovt_reqs	}	;
		cube_link_rimt_done	<=	&{cube_link_cfig_done	,	cube_link_rimt_reqs	}	;
		cube_link_romt_done	<=	&{cube_link_cfig_done	,	cube_link_romt_reqs	}	;
	end

endmodule
 