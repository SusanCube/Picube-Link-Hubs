/*----------------------------------------------------------------------

----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_acks_misc #
	( parameter LINK_MODE	=	"TPGM" )	(
	input							cube_link_acks_reqs	,//only used for CMND+ACKS+ODAT+RESP
	output							cube_link_acks_idle	,
	output							cube_link_acks_done	,
//-MISC SIGNAL
	output	reg		[ 7: 0]			cube_acks_fram_mbdo	,
	output	reg		[ 7: 0]			cube_acks_dat3_mbdo	,
	output	reg		[ 7: 0]			cube_acks_dat2_mbdo	,
	output	reg		[ 7: 0]			cube_acks_dat0_mbdo	,
	output	reg		[ 7: 0]			cube_acks_dat1_mbdo	,
//-	cmnd buffer
	output	reg		[ 3: 0]			cube_link_acks_indx	,
	input			[31: 0]			cube_link_acks_data	,
	
	input							cube_sclk			,
	input							cube_rstn			);	
//MISC Parameter -------------------------------------------------------------------------------------------
	wire							cube_link_acks_lead	;
	wire							cube_link_acks_post	;
	wire							cube_link_acks_coda	;

	if(LINK_MODE == "TPGM")
		assign	cube_link_acks_coda	=&{	cube_link_acks_post	,	cube_link_acks_indx	==	`TPGM_LINK_ACKS_LENG};
	else
		assign	cube_link_acks_coda	=&{	cube_link_acks_post	,	cube_link_acks_indx	==	`TPEM_LINK_ACKS_LENG};
		
//MISC Control -------------------------------------------------------------------------------------------
	always@(posedge cube_sclk or negedge cube_rstn)
	if(!cube_rstn)					cube_link_acks_indx	<=	0	;
	else if(cube_link_acks_idle)	cube_link_acks_indx	<=	0	;
	else if(cube_link_acks_post)	cube_link_acks_indx	<=	cube_link_acks_indx + 1	;
	else							cube_link_acks_indx	<=	cube_link_acks_indx		;	
//----------------------------------
	wire	[31: 0]					cube_mixs_word_data	;
	wire	[ 7: 0]					word_dat3_lane_mbit	;
	wire	[ 7: 0]					word_dat2_lane_mbit	;
	wire	[ 7: 0]					word_dat1_lane_mbit	;
	wire	[ 7: 0]					word_dat0_lane_mbit	;
	
	wire	[31: 0]					cube_acks_lead_code	=	`CUBE_LINK_ACKS_LEAD	;
	assign	cube_mixs_word_data	=	cube_link_acks_lead	?	cube_acks_lead_code	:
									cube_link_acks_post	?	cube_link_acks_data	:	32'H0	;

	assign	word_dat3_lane_mbit	=	cube_mixs_word_data[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_mixs_word_data[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_mixs_word_data[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_mixs_word_data[ 7: 0]	;
//----------------------------------
  	always@(posedge cube_sclk or negedge cube_rstn)
  	if(!cube_rstn) begin
  		cube_acks_dat3_mbdo	<=	0	;
  		cube_acks_dat2_mbdo	<=	0	;
  		cube_acks_dat1_mbdo	<=	0	;
  		cube_acks_dat0_mbdo	<=	0	;
	end else begin
  		cube_acks_dat3_mbdo	<=	word_dat3_lane_mbit	;
		cube_acks_dat2_mbdo	<=	word_dat2_lane_mbit	;
  		cube_acks_dat1_mbdo	<=	word_dat1_lane_mbit	;
		cube_acks_dat0_mbdo	<=	word_dat0_lane_mbit	;
	end

	always@(posedge cube_sclk or negedge cube_rstn)
	if(~cube_rstn) 					cube_acks_fram_mbdo	<=	8'H00	;
	else if(cube_link_acks_lead)	cube_acks_fram_mbdo	<=	8'HFF	;
	else if(cube_link_acks_post)	cube_acks_fram_mbdo	<=	8'HFF	;
	else 							cube_acks_fram_mbdo	<=	8'H00	;	
	
//	else if(cube_link_acks_idle)	cube_acks_fram_mbdo	<=	8'H00	;
//	else if(cube_link_acks_lead)	cube_acks_fram_mbdo	<=	8'HFF	;
//	else if(cube_link_acks_done)	cube_acks_fram_mbdo	<=	8'H00	;
//	else 							cube_acks_fram_mbdo	<=	cube_acks_fram_mbdo	;
//----------------------------------------------------------------------	
	cube_link_acks_mfsm				u_cube_acks_mfsm(
		.cube_link_acks_idle		(cube_link_acks_idle	),//output
		.cube_link_acks_done		(cube_link_acks_done	),//output
		.cube_link_acks_lead		(cube_link_acks_lead	),//output
		.cube_link_acks_post		(cube_link_acks_post	),//output
		
		.cube_link_acks_reqs		(cube_link_acks_reqs	),//input
		.cube_link_acks_coda		(cube_link_acks_coda	),//input
		
		.cube_sclk					(cube_sclk				),//input
		.cube_rstn					(cube_rstn				));//input

endmodule

	