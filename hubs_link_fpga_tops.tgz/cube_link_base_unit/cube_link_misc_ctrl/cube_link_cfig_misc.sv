/*----------------------------------------------------------------------

----------------------------------------------------------------------*/
`include	"agile_card_vars.vh"
module	cube_link_cfig_misc #
	( parameter LINK_MODE	=	"TPGM" )	(
	output	reg	[ 7: 0]				cube_clnk_fram_mbdo	,
	output	reg	[ 7: 0]				cube_clnk_dat0_mbdo	,
	output	reg	[ 7: 0]				cube_clnk_dat1_mbdo	,
	output	reg	[ 7: 0]				cube_clnk_dat2_mbdo	,
	output	reg	[ 7: 0]				cube_clnk_dat3_mbdo	,

	output							cube_link_cfig_idle	,

	output							cube_link_trim_done	,
	output							cube_link_icfg_done	,
	output							cube_link_ocfg_done	,
	output							cube_link_nnex_done	,
	output							cube_link_aset_done	,
	output							cube_link_dnld_done	,
	output							cube_link_boot_done	,
	output							cube_link_rivt_done	,
	output							cube_link_rovt_done	,
	output							cube_link_rimt_done	,
	output							cube_link_romt_done	,
	
	input							cube_link_trim_reqs	,
	input							cube_link_icfg_reqs	,
	input							cube_link_ocfg_reqs	,
	input							cube_link_nnex_reqs	,
	input							cube_link_aset_reqs	,
	input							cube_link_dnld_reqs	,
	input							cube_link_boot_reqs	,
	input							cube_link_rivt_reqs	,
	input							cube_link_rovt_reqs	,
	input							cube_link_rimt_reqs	,
	input							cube_link_romt_reqs	,
		
	output	reg		[ 3: 0]			cube_link_cmnd_indx	,
	input			[31: 0]			cube_link_cmnd_data	,
	input							cube_link_acks_coda	,
	input							cube_link_resp_coda	,
	
	input							link_clki			,
	input							link_rstn			);	
//MISC Parameter -------------------------------------------------------------------------------------------
	reg								cube_link_cmnd_done	;

	wire							cube_link_trim_lead	;
	wire							cube_link_icfg_lead	;
	wire							cube_link_ocfg_lead	;
	wire							cube_link_nnex_lead	;
	wire							cube_link_aset_lead	;
	wire							cube_link_dnld_lead	;
	wire							cube_link_boot_lead	;
	wire							cube_link_rivt_lead	;
	wire							cube_link_rovt_lead	;
	wire							cube_link_rimt_lead	;
	wire							cube_link_romt_lead	;
	
	wire							cube_link_cmnd_lead	;
	wire							cube_link_cmnd_post	; 
	wire							cube_link_cmnd_coda	; 

	wire	[3: 0]					cube_link_cmnd_leng	;	


	if(LINK_MODE == "TPGM")
		assign	cube_link_cmnd_leng	= `TPGM_LINK_CMND_LENG	;
	else
		assign	cube_link_cmnd_leng	= `TPEM_LINK_CMND_LENG	;
	
	
	assign	cube_link_cmnd_coda	=&{	cube_link_cmnd_post	,	cube_link_cmnd_indx	== cube_link_cmnd_leng	};
	
	assign	cube_link_cmnd_lead	= |{cube_link_trim_lead	,
									cube_link_icfg_lead	,	cube_link_ocfg_lead	,
									cube_link_nnex_lead	,	cube_link_aset_lead	,	
									cube_link_dnld_lead	,	cube_link_boot_lead	,
									cube_link_rivt_lead	,	cube_link_rovt_lead	,
									cube_link_rimt_lead	,	cube_link_romt_lead};
//MISC Control -------------------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					cube_link_cmnd_indx	<=	0	;
	else if(cube_link_cfig_idle)	cube_link_cmnd_indx	<=	0	;
	else if(cube_link_cmnd_post)	cube_link_cmnd_indx	<=	cube_link_cmnd_indx + 1	;
	else							cube_link_cmnd_indx	<=	cube_link_cmnd_indx		;	
//----------------------------------
	wire		[31: 0]				cube_link_trim_code	=	`CUBE_LINK_TRIM_LEAD	;
	wire		[31: 0]				cube_link_icfg_code	=	`CUBE_LINK_ICFG_LEAD	;
	wire		[31: 0]				cube_link_ocfg_code	=	`CUBE_LINK_OCFG_LEAD	;
	wire		[31: 0]				cube_link_nnex_code	=	`CUBE_LINK_NNEX_LEAD	;
	wire		[31: 0]				cube_link_aset_code	=	`CUBE_LINK_ASET_LEAD	;
	wire		[31: 0]				cube_link_dnld_code	=	`CUBE_LINK_DNLD_LEAD	;
	wire		[31: 0]				cube_link_boot_code	=	`CUBE_LINK_BOOT_LEAD	;
	wire		[31: 0]				cube_link_rivt_code	=	`CUBE_LINK_RIVT_LEAD	;
	wire		[31: 0]				cube_link_rovt_code	=	`CUBE_LINK_ROVT_LEAD	;
	wire		[31: 0]				cube_link_rimt_code	=	`CUBE_LINK_RIMT_LEAD	;
	wire		[31: 0]				cube_link_romt_code	=	`CUBE_LINK_ROMT_LEAD	;
	
	wire		[ 7: 0]				word_dat3_lane_mbit	;
	wire		[ 7: 0]				word_dat2_lane_mbit	;
	wire		[ 7: 0]				word_dat1_lane_mbit	;
	wire		[ 7: 0]				word_dat0_lane_mbit	;
	wire		[31: 0]				cube_link_mixs_data	;

	assign	cube_link_mixs_data	=	cube_link_trim_lead	?	cube_link_trim_code		:
									cube_link_icfg_lead	?	cube_link_icfg_code		:
									cube_link_ocfg_lead	?	cube_link_ocfg_code		:	
									cube_link_nnex_lead	?	cube_link_nnex_code		:	
									cube_link_aset_lead	?	cube_link_aset_code		:	
									cube_link_dnld_lead	?	cube_link_dnld_code		:	
									cube_link_boot_lead	?	cube_link_boot_code		:
									cube_link_rivt_lead	?	cube_link_rivt_code		:	
									cube_link_rovt_lead	?	cube_link_rovt_code		:	
									cube_link_rimt_lead	?	cube_link_rimt_code		:	
									cube_link_romt_lead	?	cube_link_romt_code		:
									cube_link_cmnd_post	?	cube_link_cmnd_data		:	32'H0	;
	
	assign	word_dat3_lane_mbit	=	cube_link_mixs_data[31:24]	;
	assign	word_dat2_lane_mbit	=	cube_link_mixs_data[23:16]	;
	assign	word_dat1_lane_mbit	=	cube_link_mixs_data[15: 8]	;
	assign	word_dat0_lane_mbit	=	cube_link_mixs_data[ 7: 0]	;
//----------------------------------
  	always@(posedge link_clki or negedge link_rstn)
  	if(!link_rstn) 	begin	  		cube_clnk_dat3_mbdo	<=	0	;
  									cube_clnk_dat2_mbdo	<=	0	;
 									cube_clnk_dat1_mbdo	<=	0	;
  									cube_clnk_dat0_mbdo	<=	0	;
	end 	else 	begin
  									cube_clnk_dat3_mbdo	<=	word_dat3_lane_mbit	;
									cube_clnk_dat2_mbdo	<=	word_dat2_lane_mbit	;
									cube_clnk_dat1_mbdo	<=	word_dat1_lane_mbit	;
									cube_clnk_dat0_mbdo	<=	word_dat0_lane_mbit	;
	end

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_cfig_idle)	cube_clnk_fram_mbdo	<=	8'H00	;
	else if(cube_link_cmnd_lead)	cube_clnk_fram_mbdo	<=	8'HFF	;
	else if(cube_link_cmnd_done)	cube_clnk_fram_mbdo	<=	8'H00	;
	else 							cube_clnk_fram_mbdo	<=	cube_clnk_fram_mbdo	;
//----------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					cube_link_cmnd_done	<=	0	;
	else							cube_link_cmnd_done	<=	cube_link_cmnd_coda	;
//----------------------------------------------------------------------	
	cube_link_cfig_mfsm			u_cube_link_cfig_mfsm(
		.cube_link_cfig_idle		(cube_link_cfig_idle	),//output

		.cube_link_trim_done		(cube_link_trim_done	),//output
		.cube_link_icfg_done		(cube_link_icfg_done	),//output
		.cube_link_ocfg_done		(cube_link_ocfg_done	),//output
		.cube_link_nnex_done		(cube_link_nnex_done	),//output
		.cube_link_aset_done		(cube_link_aset_done	),//output
		.cube_link_dnld_done		(cube_link_dnld_done	),//output
		.cube_link_boot_done		(cube_link_boot_done	),//output
		.cube_link_rivt_done		(cube_link_rivt_done	),
		.cube_link_rovt_done		(cube_link_rovt_done	),
		.cube_link_rimt_done		(cube_link_rimt_done	),
		.cube_link_romt_done		(cube_link_romt_done	),

		.cube_link_trim_reqs		(cube_link_trim_reqs	),//input
		.cube_link_icfg_reqs		(cube_link_icfg_reqs	),//input
		.cube_link_ocfg_reqs		(cube_link_ocfg_reqs	),//input
		.cube_link_nnex_reqs		(cube_link_nnex_reqs	),//input
		.cube_link_aset_reqs		(cube_link_aset_reqs	),//input
		.cube_link_dnld_reqs		(cube_link_dnld_reqs	),//input
		.cube_link_boot_reqs		(cube_link_boot_reqs	),//input
		.cube_link_rivt_reqs		(cube_link_rivt_reqs	),
		.cube_link_rovt_reqs		(cube_link_rovt_reqs	),
		.cube_link_rimt_reqs		(cube_link_rimt_reqs	),
		.cube_link_romt_reqs		(cube_link_romt_reqs	),
		
		.cube_link_trim_lead		(cube_link_trim_lead	),//output
		.cube_link_icfg_lead		(cube_link_icfg_lead	),//output
		.cube_link_ocfg_lead		(cube_link_ocfg_lead	),//output
		.cube_link_nnex_lead		(cube_link_nnex_lead	),//output
		.cube_link_aset_lead		(cube_link_aset_lead	),//output
		.cube_link_dnld_lead		(cube_link_dnld_lead	),//output
		.cube_link_boot_lead		(cube_link_boot_lead	),//output
		.cube_link_rivt_lead		(cube_link_rivt_lead	),
		.cube_link_rovt_lead		(cube_link_rovt_lead	),
		.cube_link_rimt_lead		(cube_link_rimt_lead	),
		.cube_link_romt_lead		(cube_link_romt_lead	),

		.cube_link_cmnd_post		(cube_link_cmnd_post	),//output
		.cube_link_cmnd_coda		(cube_link_cmnd_coda	),//input
		.cube_link_acks_coda		(cube_link_acks_coda	),//input
		.cube_link_resp_coda		(cube_link_resp_coda	),//input
		

		.link_clki					(link_clki				),//input
		.link_rstn					(link_rstn				));//input

endmodule
				
	