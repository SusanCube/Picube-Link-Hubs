
module	cube_link_acks_mfsm(
	output							cube_link_acks_idle	,
	output	reg						cube_link_acks_done	,
	output							cube_link_acks_lead	,
	output							cube_link_acks_post	,
	
	input							cube_link_acks_reqs	,
	input							cube_link_acks_coda	,
	
	input							cube_sclk			,
	input							cube_rstn			);
//********************************************************************************************************//
	reg		[ 1: 0]					cube_acks_mfsm	;
	
	parameter	CUBE_ACKS_IDLE	=	2'H0	;
	parameter	CUBE_ACKS_LEAD	=	2'H1	;
	parameter	CUBE_ACKS_POST	=	2'H2	;
	parameter	CUBE_ACKS_DONE	=	2'H3	;
//********************************************************************************************************//
	assign		cube_link_acks_idle	= cube_acks_mfsm ==	CUBE_ACKS_IDLE	;
	assign		cube_link_acks_lead	= cube_acks_mfsm ==	CUBE_ACKS_LEAD	;
	assign		cube_link_acks_post	= cube_acks_mfsm ==	CUBE_ACKS_POST	;
	wire		cube_link_acks_deal	= cube_acks_mfsm ==	CUBE_ACKS_DONE	;
//********************************************************************************************************//
	always@(posedge cube_sclk or negedge cube_rstn)	
	if(!cube_rstn)
		cube_acks_mfsm	<=	CUBE_ACKS_IDLE	;
	else begin
		case(cube_acks_mfsm)
			CUBE_ACKS_IDLE	://0
				cube_acks_mfsm	<=	cube_link_acks_reqs	?	CUBE_ACKS_LEAD	:	CUBE_ACKS_IDLE	;
			CUBE_ACKS_LEAD	://1
				cube_acks_mfsm	<=							CUBE_ACKS_POST						;	
			CUBE_ACKS_POST	://2
				cube_acks_mfsm	<=	cube_link_acks_coda	?	CUBE_ACKS_DONE	:	CUBE_ACKS_POST	;
			CUBE_ACKS_DONE	://3
				cube_acks_mfsm	<=	cube_link_acks_reqs	?	CUBE_ACKS_DONE	:	CUBE_ACKS_IDLE	;	
		endcase		
	end
//********************************************************************************************************//
	always@(posedge cube_sclk or negedge cube_rstn)	
	if(~cube_rstn)					cube_link_acks_done	<=	0	;	
	else							cube_link_acks_done	<=	cube_link_acks_deal	;	


endmodule

