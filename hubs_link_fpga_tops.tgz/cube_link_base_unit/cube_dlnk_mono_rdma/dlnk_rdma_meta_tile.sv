//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	dlnk_rdma_meta_tile(
	input								dlnk_rdma_tile_enab	,
	output								dlnk_rdma_tile_done	,
	
	output	reg							dlnk_rdma_ddrs_reqs	,
	output	reg	[24: 0]					dlnk_rdma_ddrs_addr	,
	input								dlnk_rdma_ddrs_crdy	,
	input								dlnk_rdma_ddrs_drdy	,
		
	output								dlnk_rdma_txdo_reqs	,
	input								dlnk_rdma_txdo_lead	,
	input								dlnk_rdma_txdo_coda	,
		
	input		[24: 0]					dlnk_rdma_ddrs_base	,
	input		[14: 0]					dlnk_rdma_bulk_numb	,
	input		[12: 0]					dlnk_rdma_pack_numb	,
		
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	reg			[ 3: 0]					dlnk_rdma_tile_mfsm	;

	parameter	TILE_RDMA_DDRS_IDLE	=	4'H0	;
	parameter	TILE_RDMA_TXDO_LEAD	=	4'H1	;
	parameter	TILE_RDMA_DDRS_RREQ	=	4'H2	;
	parameter	TILE_RDMA_DDRS_CMND	=	4'H3	;
	parameter	TILE_RDMA_DDRS_DATA	=	4'H4	;
	parameter	TILE_RDMA_DDRS_LOOP	=	4'H5	;
	parameter	TILE_RDMA_TXDO_CODA	=	4'H6	;
	parameter	TILE_RDMA_PACK_LOOP	=	4'H7	;
	parameter	TILE_RDMA_BULK_LOOP	=	4'H8	;
	parameter	TILE_RDMA_DDRS_DONE	=	4'H9	;

	wire								dlnk_rdma_bulk_last	;
	wire								dlnk_rdma_rows_last	;
	wire								dlnk_rdma_pack_last	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_tile_mfsm	<=	TILE_RDMA_DDRS_IDLE	;
	else if(~dlnk_rdma_tile_enab)		dlnk_rdma_tile_mfsm	<=	TILE_RDMA_DDRS_IDLE	;
	else begin	
		case(dlnk_rdma_tile_mfsm)	
			TILE_RDMA_DDRS_IDLE	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_tile_enab	?	TILE_RDMA_TXDO_LEAD	:	TILE_RDMA_DDRS_IDLE	;	

			TILE_RDMA_TXDO_LEAD	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_txdo_lead	?	TILE_RDMA_DDRS_RREQ	:	TILE_RDMA_TXDO_LEAD	;
			
			TILE_RDMA_DDRS_RREQ	:		dlnk_rdma_tile_mfsm	<=													TILE_RDMA_DDRS_CMND	;
			TILE_RDMA_DDRS_CMND	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_ddrs_crdy	?	TILE_RDMA_DDRS_DATA	:	TILE_RDMA_DDRS_CMND	;
			TILE_RDMA_DDRS_DATA	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_ddrs_drdy	?	TILE_RDMA_DDRS_LOOP	:	TILE_RDMA_DDRS_DATA	;
			TILE_RDMA_DDRS_LOOP	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_rows_last	?	TILE_RDMA_TXDO_CODA	:	TILE_RDMA_DDRS_RREQ	;
			
			TILE_RDMA_TXDO_CODA	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_txdo_coda	?	TILE_RDMA_PACK_LOOP	:	TILE_RDMA_TXDO_CODA	;

			TILE_RDMA_PACK_LOOP	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_pack_last	?	TILE_RDMA_BULK_LOOP	:	TILE_RDMA_TXDO_LEAD	;
			TILE_RDMA_BULK_LOOP	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_bulk_last	?	TILE_RDMA_DDRS_DONE	:	TILE_RDMA_TXDO_LEAD	;

			TILE_RDMA_DDRS_DONE	:		dlnk_rdma_tile_mfsm	<=	dlnk_rdma_tile_enab	?	TILE_RDMA_DDRS_DONE	:	TILE_RDMA_DDRS_IDLE	;
		endcase
	end	
//------------------------------------------------------------------------------
	wire								tile_rdma_ddrs_idle =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_IDLE	;
	wire								tile_rdma_ddrs_done =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_DONE	;

	wire								tile_rdma_txdo_lead =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_TXDO_LEAD	;
	wire								tile_rdma_txdo_coda =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_TXDO_CODA	;

	wire								tile_rdma_ddrs_rreq =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_RREQ	;
	wire								tile_rdma_ddrs_cmnd =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_CMND	;
	wire								tile_rdma_ddrs_data =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_DATA	;
	wire								tile_rdma_ddrs_loop =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_DDRS_LOOP	;

	wire								tile_rdma_pack_loop =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_PACK_LOOP	;
	wire								tile_rdma_bulk_loop =	dlnk_rdma_tile_mfsm	==	TILE_RDMA_BULK_LOOP	;
	
	wire								tile_rdma_ddrs_crdy	= &{tile_rdma_ddrs_cmnd	,  	dlnk_rdma_ddrs_crdy	};
	wire								tile_rdma_ddrs_drdy	= &{tile_rdma_ddrs_data	,  	dlnk_rdma_ddrs_drdy	};

	assign		dlnk_rdma_tile_done	=	tile_rdma_ddrs_done	;
	assign		dlnk_rdma_txdo_reqs	=	tile_rdma_txdo_coda	;			
/**********************************************************************************************************************/
	reg			[14: 0]					tile_rdma_bulk_cnts	;
	reg			[12: 0]					tile_rdma_pack_cnts	;
	reg			[ 5: 0]					tile_rdma_rows_cnts	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_reqs	<=	0	;
	else if( tile_rdma_ddrs_idle)		dlnk_rdma_ddrs_reqs	<=	0	;
	else if( tile_rdma_ddrs_rreq)		dlnk_rdma_ddrs_reqs	<=	1	;
	else if( tile_rdma_ddrs_drdy)		dlnk_rdma_ddrs_reqs	<=	0	;
//------------------------------------------------------------------------------
	wire		[14: 0]					tile_rdma_bulk_inc1	=	tile_rdma_bulk_cnts + 1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tile_rdma_bulk_cnts	<=	0	;
	else if(tile_rdma_ddrs_idle)		tile_rdma_bulk_cnts	<=	0	;
	else if(tile_rdma_bulk_loop)		tile_rdma_bulk_cnts	<=	1 +	tile_rdma_bulk_cnts	;
//------------------------------------------------------------------------------
	wire		[12: 0]					tile_rdma_pack_inc1	=	tile_rdma_pack_cnts + 1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tile_rdma_pack_cnts	<=	0	;
	else if(tile_rdma_ddrs_idle)		tile_rdma_pack_cnts	<=	0	;
	else if(tile_rdma_pack_loop)		tile_rdma_pack_cnts	<=	dlnk_rdma_pack_last	?	0	:	1 +	tile_rdma_pack_cnts	;
//------------------------------------------------------------------------------
	wire								tile_rows_loop_init	;
	
	assign		tile_rows_loop_init	= |{tile_rdma_txdo_lead	,	tile_rdma_txdo_coda	};
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tile_rdma_rows_cnts	<=	0	;
	else if(tile_rdma_ddrs_idle)		tile_rdma_rows_cnts	<=	0	;
	else if(tile_rows_loop_init)		tile_rdma_rows_cnts	<=	0	;
	else if(tile_rdma_ddrs_crdy)		tile_rdma_rows_cnts	<=	tile_rdma_rows_cnts	+ 1 ;
/**********************************************************************************************************************/
	wire	[19: 0]						meta_bulk_rows_indx	= 	tile_rdma_rows_cnts + (	tile_rdma_bulk_cnts * 32 )	;
	wire	[21: 0]						meta_bulk_rows_pack	= 	meta_bulk_rows_indx	*	dlnk_rdma_pack_numb	+	tile_rdma_pack_cnts	;

	reg		[19: 0]						meta_rdma_rows_indx	;
	reg		[21: 0]						meta_rdma_pack_indx	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						meta_rdma_rows_indx	<=	0	;
	else								meta_rdma_rows_indx	<=	meta_bulk_rows_indx ;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						meta_rdma_pack_indx	<=	0	;
	else								meta_rdma_pack_indx	<=	meta_bulk_rows_pack	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_addr	<=	0	;
	else if( tile_rdma_ddrs_idle)		dlnk_rdma_ddrs_addr	<=	0	;
	else 								dlnk_rdma_ddrs_addr	<=	8 *	meta_rdma_pack_indx +	dlnk_rdma_ddrs_base		;
/**********************************************************************************************************************/
	assign		dlnk_rdma_bulk_last	= &{tile_rdma_bulk_loop	,	tile_rdma_bulk_inc1	==	dlnk_rdma_bulk_numb	};
	assign		dlnk_rdma_pack_last	= &{tile_rdma_pack_loop	,	tile_rdma_pack_inc1	==	dlnk_rdma_pack_numb	};
	assign		dlnk_rdma_rows_last	= &{tile_rdma_ddrs_loop	,	tile_rdma_rows_cnts	==	6'H20				};
	




endmodule

