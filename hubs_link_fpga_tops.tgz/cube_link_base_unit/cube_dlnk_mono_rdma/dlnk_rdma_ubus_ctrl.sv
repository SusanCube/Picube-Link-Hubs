module	dlnk_rdma_ubus_ctrl(
	input								dlnk_rdma_meta_mode	,//0:vect 	1:mtrx
	input		[ 9: 0]					dlnk_rdma_meta_page	,//0:vect 	1:mtrx
	

	input								dlnk_rdma_ddrs_reqs	,
	input		[24: 0]					dlnk_rdma_ddrs_addr	,
	output								dlnk_rdma_ddrs_crdy	,
	output								dlnk_rdma_ddrs_drdy	,
	
	input								dlnk_txdo_data_reqs	,
	input		[12: 0]					dlnk_txdo_data_indx	,
	output		[31: 0]					dlnk_txdo_data_word	,	
	input								link_sclk			,
	input								link_rstn			,

	output	reg							ubus_rdma_ddrs_csen	,
	output	reg	[ 24: 0]				ubus_rdma_ddrs_addr	,
	input								ubus_rdma_ddrs_trdy	,
	input		[255: 0]				ubus_rdma_ddrs_data	,
	input								ubus_rdma_ddrs_drdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire		[ 9: 0]					ubus_rdma_meta_page	;

	gens_sync_gray 		#(	.MSB (9) )	
									u_gens_ubus_page_gray(
		.data_asyn						(dlnk_rdma_meta_page	),//input	[MSB: 0]
		.scki							(link_sclk				),//input			
		.data_sync						(ubus_rdma_meta_page	),//output	reg [MSB: 0]
		.clki							(ubus_clki				),//input				
		.rstn							(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	wire		[25: 0]					dlnk_reqs_gray_code	;
	wire		[25: 0]					ubus_reqs_gray_code	;
	
	wire								ubus_rdma_ddrs_reqs	;
	wire		[24: 0]					ubus_rdma_ddrs_base	;
	
	assign		dlnk_reqs_gray_code	= {	dlnk_rdma_ddrs_reqs	,	dlnk_rdma_ddrs_addr	};
	assign		ubus_rdma_ddrs_reqs	=	ubus_reqs_gray_code[25]		;
	assign		ubus_rdma_ddrs_base	=	ubus_reqs_gray_code[24: 0]	;

	gens_sync_gray 		#(	.MSB (25) )	
									u_gens_ubus_reqs_gray(
		.data_asyn						(dlnk_reqs_gray_code	),//input	[MSB: 0]
		.scki							(link_sclk				),//input			
		.data_sync						(ubus_reqs_gray_code	),//output	reg [MSB: 0]
		.clki							(ubus_clki				),//input				
		.rstn							(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	wire								ubus_rdma_pack_crdy	;
	wire								ubus_rdma_pack_drdy	;

	gens_edge_fast_slow	#(	.EXTN (5)	)
									u_dlnk_rdma_ddrs_crdy(	
		.slow_edge						(dlnk_rdma_ddrs_crdy	),//output	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				),//input	
		.fast_sign  					(ubus_rdma_pack_crdy	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input

	gens_edge_fast_slow	#(	.EXTN (5)	)
									u_dlnk_rdma_ddrs_drdy(	
		.slow_edge						(dlnk_rdma_ddrs_drdy	),//output	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				),//input	
		.fast_sign  					(ubus_rdma_pack_drdy	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input
//------------------------------------------------------------------------------
	wire								ubus_rdma_rows_issu	;

	gens_asyn_edge 					u_gens_ubus_rdma_rows(
		.data_edge						(ubus_rdma_rows_issu	),//output
		.data_inpp						(dlnk_txdo_data_reqs	),//input
		.edge_mode						(1'B0					),//input
		.clki							(ubus_clki				),//input	
		.rstn							(ubus_rstn				));//input	
//------------------------------------------------------------------------------
	wire								ubus_rdma_meta_mode	;
	wire		[ 9: 0]					ubus_rdma_meta_size	;	

	assign		ubus_rdma_meta_size	=	ubus_rdma_meta_mode	? 10'H7	: ubus_rdma_meta_page -1	;

	gens_sign_slow_fast				u_gens_ubus_rdma_mode(
		.slow_sign						(dlnk_rdma_meta_mode	),//input	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				),//input	
		.fast_sign  					(ubus_rdma_meta_mode	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				));//input	
//------------------------------------------------------------------------------
	wire								ubus_rdma_reqs_issu	;
	reg 								ubus_rdma_reqs_sync	;

	assign		ubus_rdma_reqs_issu	= &{ubus_rdma_ddrs_reqs	, ~	ubus_rdma_reqs_sync	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_reqs_sync	<=	0	;
	else								ubus_rdma_reqs_sync	<=	ubus_rdma_ddrs_reqs	;
/**********************************************************************************************************************/
	reg									ubus_rdma_data_csen	;

	reg			[ 9: 0]					ubus_rdma_cmnd_cnts	;
	reg			[ 9: 0]					ubus_rdma_data_cnts	;
//------------------------------------------------------------------------------
	wire								ubus_rdma_cmnd_vlid	;
	wire								ubus_rdma_data_vlid	;


	assign		ubus_rdma_cmnd_vlid	= &{ubus_rdma_ddrs_csen	,	ubus_rdma_ddrs_trdy};
	assign		ubus_rdma_data_vlid	= &{ubus_rdma_data_csen	,	ubus_rdma_ddrs_drdy};

	assign		ubus_rdma_pack_crdy	= &{ubus_rdma_cmnd_vlid	,	ubus_rdma_cmnd_cnts == ubus_rdma_meta_size	};
	assign		ubus_rdma_pack_drdy	= &{ubus_rdma_data_vlid	,	ubus_rdma_data_cnts == ubus_rdma_meta_size	};

//------------------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_ddrs_csen	<=	0	;
	else if(ubus_rdma_reqs_issu)		ubus_rdma_ddrs_csen	<=	1	;
	else if(ubus_rdma_pack_crdy)		ubus_rdma_ddrs_csen	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_ddrs_addr	<=	0	;
	else if(ubus_rdma_reqs_issu)		ubus_rdma_ddrs_addr	<=	ubus_rdma_ddrs_base	;
	else if(ubus_rdma_cmnd_vlid)		ubus_rdma_ddrs_addr	<=	ubus_rdma_ddrs_addr + 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_csen	<=	0	;
	else if(ubus_rdma_reqs_issu)		ubus_rdma_data_csen	<=	1	;
	else if(ubus_rdma_pack_drdy)		ubus_rdma_data_csen	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_rdma_reqs_issu)		ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_rdma_cmnd_vlid)		ubus_rdma_cmnd_cnts	<=	ubus_rdma_cmnd_cnts + 1	;
		
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_reqs_issu)		ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_data_vlid)		ubus_rdma_data_cnts	<=	ubus_rdma_data_cnts + 1	;
//------------------------------------------------------------------------------
	reg			[ 8: 0]					ubus_rdma_data_indx	;
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_rdma_data_indx	<=	0	;
	else if(ubus_rdma_rows_issu)		ubus_rdma_data_indx	<=	0	;
	else if(ubus_rdma_data_vlid)		ubus_rdma_data_indx	<=	ubus_rdma_data_indx + 1	;
/**********************************************************************************************************************/
	dual_port_8to1_bram				u_ubus_rdma_memo(
  	.wport_csen							(ubus_rdma_data_vlid	), // input wire [0:0] wea
  	.wport_addr							(ubus_rdma_data_indx	), // input wire [10:0] addra
  	.wport_data							(ubus_rdma_ddrs_data	), // input wire [255:0] dina
	.wport_clki							(ubus_clki				), // input wire clka
  	
  	.rport_addr							(dlnk_txdo_data_indx	), // input wire [13:0] addrb
  	.rport_data							(dlnk_txdo_data_word	),// output wire [31:0] doutb
  	.rport_clki							(link_sclk				)); // input wire clkb



endmodule
