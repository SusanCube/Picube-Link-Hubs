//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	dlnk_rdma_meta_vect(
	input								dlnk_rdma_vect_enab	,
	output								dlnk_rdma_vect_done	,

	output	reg							dlnk_rdma_ddrs_reqs	,//to ubus,sync by link_sclk in ubus module
	output	reg	[24: 0]					dlnk_rdma_ddrs_addr	,//to ubus,sync by link_sclk in ubus module
	input								dlnk_rdma_ddrs_crdy	,//from ubus,sync by link_sclk in ubus module
	input								dlnk_rdma_ddrs_drdy	,//from ubus,sync by link_sclk in ubus module
	
	output								dlnk_rdma_txdo_reqs	,
	input								dlnk_rdma_txdo_lead	,
	input								dlnk_rdma_txdo_coda	,

	input		[24: 0]					dlnk_rdma_ddrs_base	,
	input		[19: 0]					dlnk_rdma_rows_numb	,
	input		[ 9: 0]					dlnk_rdma_page_numb	,

	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	reg			[ 3: 0]					dlnk_rdma_vect_mfsm	;

	parameter	VECT_RDMA_DDRS_IDLE	=	4'H0	;
	parameter	VECT_RDMA_TXDO_LEAD	=	4'H1	;
	parameter	VECT_RDMA_DDRS_RREQ	=	4'H2	;
	parameter	VECT_RDMA_DDRS_CMND	=	4'H3	;
	parameter	VECT_RDMA_DDRS_DATA	=	4'H4	;
	parameter	VECT_RDMA_TXDO_CODA	=	4'H5	;
	parameter	VECT_RDMA_ROWS_LOOP	=	4'H6	;
	parameter	VECT_RDMA_DDRS_DONE	=	4'H7	;

	wire								vect_rdma_rows_last	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_vect_mfsm	<=	VECT_RDMA_DDRS_IDLE	;
	else if(~dlnk_rdma_vect_enab)		dlnk_rdma_vect_mfsm	<=	VECT_RDMA_DDRS_IDLE	;
	else begin	
		case(dlnk_rdma_vect_mfsm)	
			VECT_RDMA_DDRS_IDLE	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_vect_enab	?	VECT_RDMA_TXDO_LEAD	:	VECT_RDMA_DDRS_IDLE	;

			VECT_RDMA_TXDO_LEAD	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_txdo_lead	?	VECT_RDMA_DDRS_RREQ	:	VECT_RDMA_TXDO_LEAD	;
			
			VECT_RDMA_DDRS_RREQ	:		dlnk_rdma_vect_mfsm	<=													VECT_RDMA_DDRS_CMND	;
			
			VECT_RDMA_DDRS_CMND	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_ddrs_crdy	?	VECT_RDMA_DDRS_DATA	:	VECT_RDMA_DDRS_CMND	;
			
			VECT_RDMA_DDRS_DATA	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_ddrs_drdy	?	VECT_RDMA_TXDO_CODA	:	VECT_RDMA_DDRS_DATA	;
			
			VECT_RDMA_TXDO_CODA	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_txdo_coda	?	VECT_RDMA_ROWS_LOOP	:	VECT_RDMA_TXDO_CODA	;
			
			VECT_RDMA_ROWS_LOOP	:		dlnk_rdma_vect_mfsm	<=	vect_rdma_rows_last	?	VECT_RDMA_DDRS_DONE	:	VECT_RDMA_TXDO_LEAD	;
			
			VECT_RDMA_DDRS_DONE	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_vect_enab	?	VECT_RDMA_DDRS_DONE	:	VECT_RDMA_DDRS_IDLE	;
		
			default				:		dlnk_rdma_vect_mfsm	<=													VECT_RDMA_DDRS_IDLE	;
		endcase
	end	
//------------------------------------------------------------------------------
	wire								vect_rdma_ddrs_idle	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_IDLE	;
	wire								vect_rdma_ddrs_done	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_DONE	;

	wire								vect_rdma_txdo_lead =	dlnk_rdma_vect_mfsm	==	VECT_RDMA_TXDO_LEAD	;
	wire								vect_rdma_txdo_coda =	dlnk_rdma_vect_mfsm	==	VECT_RDMA_TXDO_CODA	;

	wire								vect_rdma_ddrs_rreq	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_RREQ	;
	wire								vect_rdma_ddrs_cmnd	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_CMND	;
	wire								vect_rdma_ddrs_data	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_DATA	;

	wire								vect_rdma_rows_loop	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_ROWS_LOOP	;
	wire								vect_rdma_ddrs_beok	= &{vect_rdma_ddrs_data	,  	dlnk_rdma_ddrs_drdy	};	
	
	assign		dlnk_rdma_vect_done	=	vect_rdma_ddrs_done	;
	assign		dlnk_rdma_txdo_reqs	=	vect_rdma_txdo_coda	;	
/**********************************************************************************************************************/
	reg			[19: 0]					vect_rdma_rows_cnts	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_reqs	<=	0	;
	else if( vect_rdma_ddrs_idle)		dlnk_rdma_ddrs_reqs	<=	0	;
	else if( vect_rdma_ddrs_rreq)		dlnk_rdma_ddrs_reqs	<=	1	;
	else if( vect_rdma_ddrs_beok)		dlnk_rdma_ddrs_reqs	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						vect_rdma_rows_cnts	<=	0	;
	else if( vect_rdma_ddrs_idle)		vect_rdma_rows_cnts	<=	0	;
	else if( vect_rdma_ddrs_beok)		vect_rdma_rows_cnts	<=	1 +	vect_rdma_rows_cnts	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_addr	<=	0	;
	else if( vect_rdma_ddrs_idle)		dlnk_rdma_ddrs_addr	<=	dlnk_rdma_ddrs_base		;
	else if( vect_rdma_rows_loop)		dlnk_rdma_ddrs_addr	<=	dlnk_rdma_ddrs_addr	+	dlnk_rdma_page_numb	;
/**********************************************************************************************************************/
	assign		vect_rdma_rows_last	= &{vect_rdma_rows_loop	,	vect_rdma_rows_cnts	==	dlnk_rdma_rows_numb	}	;
	
endmodule
//	wire								vect_rdma_pack_last	;
//			VECT_RDMA_DDRS_DATA	:		dlnk_rdma_vect_mfsm	<=	dlnk_rdma_ddrs_drdy	?	VECT_RDMA_DDRS_LOOP	:	VECT_RDMA_DDRS_DATA	;
//			VECT_RDMA_DDRS_LOOP	:		dlnk_rdma_vect_mfsm	<=	vect_rdma_pack_last	?	VECT_RDMA_TXDO_CODA	:	VECT_RDMA_DDRS_RREQ	;

//	else if( vect_rdma_pack_last)		vect_rdma_rows_cnts	<=	1 +	vect_rdma_rows_cnts	;
//	wire								vect_rdma_ddrs_loop	=	dlnk_rdma_vect_mfsm	==	VECT_RDMA_DDRS_LOOP	;
//	assign		vect_rdma_pack_last	= &{vect_rdma_ddrs_loop	,	vect_rdma_pack_cnts	==	vect_rdma_pack_numb	}	;
//------------------------------------------------------------------------------
//	reg			[18: 0]					vect_rdma_pack_cnts	;
//	always@(posedge link_sclk or negedge link_rstn)
//	if(~link_rstn)						vect_rdma_pack_cnts	<=	0	;
//	else if( vect_rdma_ddrs_idle)		vect_rdma_pack_cnts	<=	0	;
//	else if( vect_rdma_txdo_lead)		vect_rdma_pack_cnts	<=	0	;
//	else if( vect_rdma_ddrs_beok)		vect_rdma_pack_cnts	<=	1 +	vect_rdma_pack_cnts	;
//	reg			[18: 0]					vect_rdma_pack_numb	;
//
//	always@(posedge link_sclk or negedge link_rstn)
//	if(~link_rstn)						vect_rdma_pack_numb	<=	0	;
//	else if(~dlnk_rdma_vect_enab)		vect_rdma_pack_numb	<=	dlnk_rdma_cols_numb[19:5]	;
//------------------------------------------------------------------------------
