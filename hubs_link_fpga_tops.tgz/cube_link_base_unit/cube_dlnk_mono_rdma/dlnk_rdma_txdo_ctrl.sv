/*
	ONE	PIXS	: 16 BITS	
	2	PIXS	: 32 BITS	->	ONE WORD 	
	8 	WORD 	:256 BITS	->	ONE PAGE
	N  	PAGE	:XXX BITS	->	ONE	ROW			
*/
`include	"agile_card_vars.vh"

module	dlnk_rdma_txdo_ctrl(
	output	reg	[ 7: 0]					dlnk_txdo_fram_mbdo	,
	output	reg	[ 7: 0]					dlnk_txdo_dat3_mbdo	,
	output	reg	[ 7: 0]					dlnk_txdo_dat2_mbdo	,
	output	reg	[ 7: 0]					dlnk_txdo_dat1_mbdo	,
	output	reg	[ 7: 0]					dlnk_txdo_dat0_mbdo	,
//------------------------------------------------------------------------------
	output								dlnk_txdo_data_done	,	
	input								dlnk_txdo_data_enab	,	
	input		[ 19: 0]				dlnk_txdo_rows_numb	,
	input		[ 18: 0]				dlnk_txdo_word_numb	,
//------------------------------------------------------------------------------
	output		[12: 0]					dlnk_txdo_data_indx	,
	input		[31: 0]					dlnk_txdo_data_word	,
	input								dlnk_txdo_data_reqs	,
	output								dlnk_txdo_data_lead	,
	output								dlnk_txdo_data_coda	,
//------------------------------------------------------------------------------		
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	reg			[ 2: 0]					dlnk_txdo_rows_mfsm	;

	parameter	DLNK_TXDO_META_IDLE	=	3'H0	;
	parameter	DLNK_TXDO_ROWS_LEAD	=	3'H1	;
	parameter	DLNK_TXDO_ROWS_PREF	=	3'H2	;
	parameter	DLNK_TXDO_ROWS_DATA	=	3'H3	;
	parameter	DLNK_TXDO_ROWS_CODA	=	3'H4	;
	parameter	DLNK_TXDO_META_DONE	=	3'H5	;

	wire								dlnk_txdo_word_last	;
	wire								dlnk_txdo_rows_last	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						dlnk_txdo_rows_mfsm	<=	DLNK_TXDO_META_IDLE	;
	else begin	
		case(dlnk_txdo_rows_mfsm) 	
			DLNK_TXDO_META_IDLE	:		dlnk_txdo_rows_mfsm	<=	dlnk_txdo_data_enab	?	DLNK_TXDO_ROWS_LEAD	:	DLNK_TXDO_META_IDLE	;

			DLNK_TXDO_ROWS_LEAD	:		dlnk_txdo_rows_mfsm	<=	dlnk_txdo_data_reqs	?	DLNK_TXDO_ROWS_PREF	:	DLNK_TXDO_ROWS_LEAD	;
			DLNK_TXDO_ROWS_PREF	:		dlnk_txdo_rows_mfsm	<=													DLNK_TXDO_ROWS_DATA	;
			DLNK_TXDO_ROWS_DATA	:		dlnk_txdo_rows_mfsm	<=	dlnk_txdo_word_last	?	DLNK_TXDO_ROWS_CODA	:	DLNK_TXDO_ROWS_DATA	;
			DLNK_TXDO_ROWS_CODA	:		dlnk_txdo_rows_mfsm	<=	dlnk_txdo_rows_last	? 	DLNK_TXDO_META_DONE	:	DLNK_TXDO_ROWS_LEAD	;

			DLNK_TXDO_META_DONE	:		dlnk_txdo_rows_mfsm	<=	dlnk_txdo_data_enab	? 	DLNK_TXDO_META_DONE	:	DLNK_TXDO_META_IDLE	;
			default				:		dlnk_txdo_rows_mfsm	<=													DLNK_TXDO_META_IDLE	;
		endcase
	end	
//------------------------------------------------------------------------------
	wire								dlnk_txdo_data_idle =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_META_IDLE	;	
	assign								dlnk_txdo_data_lead =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_ROWS_LEAD	;	
	wire								dlnk_txdo_rows_pref =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_ROWS_PREF	;	
	wire								dlnk_txdo_rows_data =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_ROWS_DATA	;	
	assign								dlnk_txdo_data_coda =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_ROWS_CODA	;	
	assign								dlnk_txdo_data_done =	dlnk_txdo_rows_mfsm	==	DLNK_TXDO_META_DONE	;	
/**********************************************************************************************************************/
	reg			[19: 0]					dlnk_txdo_rows_cnts	;
	reg			[18: 0]					dlnk_txdo_word_cnts	;
	reg									dlnk_txdo_rows_csen	;
//-------------------------------------------------------------------------------
	wire								dlnk_txdo_rows_head	;
	
	assign		dlnk_txdo_rows_head	= &{dlnk_txdo_data_lead ,	dlnk_txdo_data_reqs	};

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_txdo_rows_cnts	<=	0	;
	else if(dlnk_txdo_data_idle)		dlnk_txdo_rows_cnts	<=	0	;
	else if(dlnk_txdo_rows_head)		dlnk_txdo_rows_cnts	<=	1 +	dlnk_txdo_rows_cnts	;
//-------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_txdo_rows_csen	<=	0	;
	else if(dlnk_txdo_rows_head)		dlnk_txdo_rows_csen	<=	1	;
	else if(dlnk_txdo_word_last)		dlnk_txdo_rows_csen	<=	0	;
//-------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_txdo_word_cnts	<=	0	;
	else if(dlnk_txdo_data_lead)		dlnk_txdo_word_cnts	<=	0	;
	else if(dlnk_txdo_word_last)		dlnk_txdo_word_cnts	<=	0	;
	else if(dlnk_txdo_rows_csen)		dlnk_txdo_word_cnts	<=	1 +	dlnk_txdo_word_cnts	;

//-------------------------------------------------------------------------------
	assign		dlnk_txdo_word_last	= &{dlnk_txdo_rows_data	,	dlnk_txdo_word_cnts	==	dlnk_txdo_word_numb	};
	assign		dlnk_txdo_rows_last	= &{dlnk_txdo_data_coda	,	dlnk_txdo_rows_cnts	==	dlnk_txdo_rows_numb	};
	assign		dlnk_txdo_data_indx	=	dlnk_txdo_word_cnts[12: 0]	;
/**********************************************************************************************************************/
	wire	[ 31:0]						dlnk_rows_lead_code	=	`CUBE_LINK_DATA_LEAD	;


	always@(posedge link_sclk or negedge  link_rstn)
	if(!link_rstn)					dlnk_txdo_fram_mbdo	<=	8'H00	;
	else if(dlnk_txdo_data_idle)	dlnk_txdo_fram_mbdo	<=	8'H00	;
	else if(dlnk_txdo_word_last)	dlnk_txdo_fram_mbdo	<= 	8'H00	;
	else if(dlnk_txdo_rows_head)	dlnk_txdo_fram_mbdo	<=	8'HFF	;
	
	always@(posedge link_sclk or negedge  link_rstn)
	if(!link_rstn) begin
		dlnk_txdo_dat3_mbdo	<=			0	;
		dlnk_txdo_dat2_mbdo	<=			0	;
		dlnk_txdo_dat1_mbdo	<=			0	;
		dlnk_txdo_dat0_mbdo	<=			0	;
	end else if(dlnk_txdo_rows_head)begin
		dlnk_txdo_dat3_mbdo	<=			dlnk_rows_lead_code[31:24]	;
		dlnk_txdo_dat2_mbdo	<=			dlnk_rows_lead_code[23:16]	;
		dlnk_txdo_dat1_mbdo	<=			dlnk_rows_lead_code[15: 8]	;
		dlnk_txdo_dat0_mbdo	<=			dlnk_rows_lead_code[ 7: 0]	;
	end else if(dlnk_txdo_rows_csen) begin
		dlnk_txdo_dat3_mbdo	<=			dlnk_txdo_word_last	?	8'H0	:	dlnk_txdo_data_word[31:24]	;
		dlnk_txdo_dat2_mbdo	<=			dlnk_txdo_word_last	?	8'H0	:	dlnk_txdo_data_word[23:16]	;
		dlnk_txdo_dat1_mbdo	<=			dlnk_txdo_word_last	?	8'H0	:	dlnk_txdo_data_word[15: 8]	;
		dlnk_txdo_dat0_mbdo	<=			dlnk_txdo_word_last	?	8'H0	:	dlnk_txdo_data_word[ 7: 0]	;
	end else begin
		dlnk_txdo_dat3_mbdo	<=	0	;
		dlnk_txdo_dat2_mbdo	<=	0	;
		dlnk_txdo_dat1_mbdo	<=	0	;
		dlnk_txdo_dat0_mbdo	<=	0	;
	end
 
endmodule 

	
