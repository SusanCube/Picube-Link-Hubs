module	dlnk_mono_rdma_ctrl(
	
	output		[ 7: 0]					dlnk_odat_fram_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat3_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat2_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat1_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat0_mbdo	,
	
	input								dlnk_odat_ddrs_mode	,	
	input								dlnk_odat_ddrs_enab	,
	output								dlnk_odat_ddrs_done	,	
			
	input		[24: 0]					llmb_mast_ddrs_base	,
	input		[19: 0]					llmb_meta_imag_rows	,
	input		[19: 0]					llmb_meta_imag_cols	,
	input		[19: 0]					llmb_edge_imag_rows	,
	input		[19: 0]					llmb_edge_imag_cols	,
		
	input								link_clki			,
	input								link_rstn			,
	
	output								ubus_dlnk_rdma_csen	,
	output		[ 24: 0]				ubus_dlnk_rdma_addr	, // unit = 256bit = 16dot = 1page
	input		[255: 0]				ubus_dlnk_rdma_data	,
	input								ubus_dlnk_rdma_trdy	,
	input								ubus_dlnk_rdma_drdy	,
	
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								dlnk_txdo_ddrs_done	;
	wire								dlnk_rdma_ddrs_done	;
	assign		dlnk_odat_ddrs_done	= &{dlnk_txdo_ddrs_done	,	dlnk_rdma_ddrs_done	};
/**********************************************************************************************************************/
	wire								dlnk_txdo_rows_reqs	;
	wire								dlnk_txdo_rows_lead	;
	wire								dlnk_txdo_rows_coda	;
	wire		[12: 0]					dlnk_txdo_data_indx	;
	wire		[31: 0]					dlnk_txdo_data_word	;

	wire		[24: 0]					dlnk_rdma_ddrs_addr	;
	
	dlnk_rdma_txdo_ctrl				u_dlnk_rdma_txdo_ctrl(
		.dlnk_txdo_fram_mbdo			(dlnk_odat_fram_mbdo	),//output	reg	[ 7: 0]	
		.dlnk_txdo_dat3_mbdo			(dlnk_odat_dat3_mbdo	),//output	reg	[ 7: 0]	
		.dlnk_txdo_dat2_mbdo			(dlnk_odat_dat2_mbdo	),//output	reg	[ 7: 0]	
		.dlnk_txdo_dat1_mbdo			(dlnk_odat_dat1_mbdo	),//output	reg	[ 7: 0]	
		.dlnk_txdo_dat0_mbdo			(dlnk_odat_dat0_mbdo	),//output	reg	[ 7: 0]	

		.dlnk_txdo_data_enab			(dlnk_odat_ddrs_enab	),//input				
		.dlnk_txdo_data_done			(dlnk_txdo_ddrs_done	),//output				
		
		.dlnk_txdo_rows_numb			(llmb_edge_imag_rows		),//input		[ 19: 0]
		.dlnk_txdo_word_numb			(llmb_edge_imag_cols[19:1]	),//input		[ 18: 0]
		
		.dlnk_txdo_data_indx			(dlnk_txdo_data_indx	),//output	reg	[13: 0]	
		.dlnk_txdo_data_word			(dlnk_txdo_data_word	),//input		[255:0 ]
		.dlnk_txdo_data_reqs			(dlnk_txdo_data_reqs	),//input				
		.dlnk_txdo_data_lead			(dlnk_txdo_data_lead	),//output				
		.dlnk_txdo_data_coda			(dlnk_txdo_data_coda	),//output				
		.link_sclk						(link_clki				),//input				
		.link_rstn						(link_rstn				));//input				
//------------------------------------------------------------------------------
	dlnk_rdma_meta_ctrl				u_dlnk_rdma_meta_ctrl(
		.dlnk_rdma_meta_enab			(dlnk_odat_ddrs_enab	),//input
		.dlnk_rdma_meta_mode			(dlnk_odat_ddrs_mode	),//input				
		.dlnk_rdma_meta_done			(dlnk_rdma_ddrs_done	),//input
						
		.dlnk_rdma_ddrs_reqs			(dlnk_rdma_ddrs_reqs	),//output				
		.dlnk_rdma_ddrs_addr			(dlnk_rdma_ddrs_addr	),//output		[24: 0]	
		.dlnk_rdma_ddrs_crdy			(dlnk_rdma_ddrs_crdy	),//input				
		.dlnk_rdma_ddrs_drdy			(dlnk_rdma_ddrs_drdy	),//input				
		
		.dlnk_txdo_data_reqs			(dlnk_txdo_data_reqs	),//output				
		.dlnk_txdo_data_lead			(dlnk_txdo_data_lead	),//input				
		.dlnk_txdo_data_coda			(dlnk_txdo_data_coda	),//input				
	
		.llmb_meta_ddrs_base			(llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_meta_imag_rows			(llmb_meta_imag_rows	),//input		[19: 0]	
		.llmb_meta_imag_cols			(llmb_meta_imag_cols	),//input		[19: 0]	
		.link_sclk						(link_clki				),//input				
		.link_rstn						(link_rstn				));//input				
//------------------------------------------------------------------------------
	dlnk_rdma_ubus_ctrl				u_dlnk_rdma_ubus_ctrl(
		.dlnk_rdma_meta_mode			(dlnk_odat_ddrs_mode		),//input				
		.dlnk_rdma_meta_page			(llmb_meta_imag_cols[13:4]	),//input				
		
		.dlnk_rdma_ddrs_reqs			(dlnk_rdma_ddrs_reqs	),//input				
		.dlnk_rdma_ddrs_addr			(dlnk_rdma_ddrs_addr	),//input		[24: 0]	
		.dlnk_rdma_ddrs_crdy			(dlnk_rdma_ddrs_crdy	),//output				
		.dlnk_rdma_ddrs_drdy			(dlnk_rdma_ddrs_drdy	),//output				

		.dlnk_txdo_data_reqs			(dlnk_txdo_data_reqs	),//input				
		.dlnk_txdo_data_indx			(dlnk_txdo_data_indx	),//input		[ 13: 0]
		.dlnk_txdo_data_word			(dlnk_txdo_data_word	),//output		[ 31: 0]
		.link_sclk						(link_clki				),//input				
		.link_rstn						(link_rstn				),//input				

		.ubus_rdma_ddrs_csen			(ubus_dlnk_rdma_csen	),//output	reg			
		.ubus_rdma_ddrs_addr			(ubus_dlnk_rdma_addr	),//output	reg	[ 24: 0]
		.ubus_rdma_ddrs_data			(ubus_dlnk_rdma_data	),//input		[255: 0]
		.ubus_rdma_ddrs_trdy			(ubus_dlnk_rdma_trdy	),//input				
		.ubus_rdma_ddrs_drdy			(ubus_dlnk_rdma_drdy	),//input				
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input				
/**********************************************************************************************************************/
endmodule
