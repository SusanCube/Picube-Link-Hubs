module	behv_ubus_intf_ddrs(

	input		[15:0]					ubus_memo_rows_size	,	

	input								ubus_dlnk_rdma_enab	,
	output								ubus_dlnk_rdma_csen	,
	output		[ 24: 0]				ubus_dlnk_rdma_addr	, // unit = 256bit = 16dot = 1page
	input		[255: 0]				ubus_dlnk_rdma_data	,
	output	reg							ubus_dlnk_rdma_trdy	,
	output								ubus_dlnk_rdma_drdy	,

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								ubus_rdma_doen_reqs	;
	assign		ubus_rdma_doen_reqs	= &{ubus_dlnk_rdma_csen	,	ubus_dlnk_rdma_trdy	};
	
	reg			[8: 0]					ubus_rdma_doen_shft	;	
	assign								ubus_dlnk_rdma_drdy	=	ubus_rdma_doen_shft[0]	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_rdma_doen_shft	<=	0	;
	else								ubus_rdma_doen_shft	<= {ubus_rdma_doen_reqs	,	ubus_rdma_doen_shft[8:1]	};
/**********************************************************************************************************************/
	reg			[15:0]					ubus_meta_rows_indx	;
	reg			[15:0]					ubus_meta_cols_indx	;

	wire		ubus_meta_cols_bmax	= 	ubus_meta_cols_indx == 	ubus_memo_rows_size - 16 ;

	always@(posedge ubus_clki or posedge ubus_dlnk_rdma_enab)	
	if(~ubus_dlnk_rdma_enab)			ubus_meta_cols_indx	<=	0	;
	else if(ubus_dlnk_rdma_drdy)		ubus_meta_cols_indx	<=	ubus_meta_cols_bmax	?	0	:	ubus_meta_cols_indx + 16	;
	
	always@(posedge ubus_clki or posedge ubus_dlnk_rdma_enab)	
	if(~ubus_dlnk_rdma_enab)			ubus_meta_rows_indx	<=	0	;
	else if(ubus_dlnk_rdma_drdy)		ubus_meta_rows_indx	<=	ubus_meta_cols_bmax	?	ubus_meta_rows_indx + 1	:	ubus_meta_rows_indx	;
//----------------------------------------------------------------------------------------------------------------------
	wire		[31: 0]					ubus_dlnk_word_7	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10007	;	
	wire		[31: 0]					ubus_dlnk_word_6	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10006	;	
	wire		[31: 0]					ubus_dlnk_word_5	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10005	;	
	wire		[31: 0]					ubus_dlnk_word_4	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10004	;	
	wire		[31: 0]					ubus_dlnk_word_3	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10003	;	
	wire		[31: 0]					ubus_dlnk_word_2	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10002	;	
	wire		[31: 0]					ubus_dlnk_word_1	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10001	;	
	wire		[31: 0]					ubus_dlnk_word_0	=	{	ubus_meta_rows_indx[15:0]	,	ubus_meta_cols_indx[15:0] }	+ 32'H10000	;	

	assign		ubus_dlnk_rdma_data	=	ubus_dlnk_rdma_enab	? {	ubus_dlnk_word_7	,
																ubus_dlnk_word_6	,
																ubus_dlnk_word_5	,
																ubus_dlnk_word_4	,
																ubus_dlnk_word_3	,
																ubus_dlnk_word_2	,
																ubus_dlnk_word_1	,
																ubus_dlnk_word_0	}	:	0	;	
/**********************************************************************************************************************/
	reg			[2: 0]					ubus_trdy_rand_seed	;
	
	always@(posedge ubus_clki)			ubus_trdy_rand_seed	<=	$urandom_range(0, 15);
	
	always@(posedge ubus_clki)			ubus_dlnk_rdma_trdy	<=	ubus_trdy_rand_seed != 3'H1 ;
	



endmodule
