//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	dlnk_rdma_meta_rect(
	input								dlnk_rdma_rect_enab	,
	output								dlnk_rdma_rect_done	,
	
	output	reg							dlnk_rdma_ddrs_reqs	,
	output	reg	[24: 0]					dlnk_rdma_ddrs_addr	,
	input								dlnk_rdma_ddrs_crdy	,
	input								dlnk_rdma_ddrs_drdy	,
		
	output								dlnk_rdma_txdo_reqs	,
	input								dlnk_rdma_txdo_lead	,
	input								dlnk_rdma_txdo_coda	,
		
	input		[24: 0]					dlnk_rdma_ddrs_base	,
	input		[ 4: 0]					dlnk_rdma_rows_numb	,
	input		[12: 0]					dlnk_rdma_pack_numb	,
		
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	reg			[ 3: 0]					dlnk_rdma_rect_mfsm	;

	parameter	RECT_RDMA_DDRS_IDLE	=	4'H0	;
	parameter	RECT_RDMA_TXDO_LEAD	=	4'H1	;
	parameter	RECT_RDMA_DDRS_RREQ	=	4'H2	;
	parameter	RECT_RDMA_DDRS_CMND	=	4'H3	;
	parameter	RECT_RDMA_DDRS_DATA	=	4'H4	;
	parameter	RECT_RDMA_DDRS_LOOP	=	4'H5	;
	parameter	RECT_RDMA_TXDO_CODA	=	4'H6	;
	parameter	RECT_RDMA_PACK_LOOP	=	4'H7	;
	parameter	RECT_RDMA_DDRS_DONE	=	4'H8	;

	wire								rect_rdma_tail_last	;
	wire								rect_rdma_pack_last	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_rect_mfsm	<=	RECT_RDMA_DDRS_IDLE	;
	else if(~dlnk_rdma_rect_enab)		dlnk_rdma_rect_mfsm	<=	RECT_RDMA_DDRS_IDLE	;
	else begin	
		case(dlnk_rdma_rect_mfsm)	
			RECT_RDMA_DDRS_IDLE	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_rect_enab	?	RECT_RDMA_TXDO_LEAD	:	RECT_RDMA_DDRS_IDLE	;	

			
			RECT_RDMA_TXDO_LEAD	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_txdo_lead	?	RECT_RDMA_DDRS_RREQ	:	RECT_RDMA_TXDO_LEAD	;
			RECT_RDMA_DDRS_RREQ	:		dlnk_rdma_rect_mfsm	<=													RECT_RDMA_DDRS_CMND	;
			RECT_RDMA_DDRS_CMND	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_ddrs_crdy	?	RECT_RDMA_DDRS_DATA	:	RECT_RDMA_DDRS_CMND	;
			RECT_RDMA_DDRS_DATA	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_ddrs_drdy	?	RECT_RDMA_DDRS_LOOP	:	RECT_RDMA_DDRS_DATA	;
			RECT_RDMA_DDRS_LOOP	:		dlnk_rdma_rect_mfsm	<=	rect_rdma_tail_last	?	RECT_RDMA_TXDO_CODA	:	RECT_RDMA_DDRS_RREQ	;
			RECT_RDMA_TXDO_CODA	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_txdo_coda	?	RECT_RDMA_PACK_LOOP	:	RECT_RDMA_TXDO_CODA	;

			
			RECT_RDMA_PACK_LOOP	:		dlnk_rdma_rect_mfsm	<=	rect_rdma_pack_last	?	RECT_RDMA_DDRS_DONE	:	RECT_RDMA_TXDO_LEAD	;

			RECT_RDMA_DDRS_DONE	:		dlnk_rdma_rect_mfsm	<=	dlnk_rdma_rect_enab	?	RECT_RDMA_DDRS_DONE	:	RECT_RDMA_DDRS_IDLE	;

			default				:		dlnk_rdma_rect_mfsm	<=													RECT_RDMA_DDRS_IDLE	;
		endcase
	end	
//------------------------------------------------------------------------------
	wire								rect_rdma_ddrs_idle =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_IDLE	;
	wire								rect_rdma_ddrs_done =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_DONE	;

	wire								rect_rdma_txdo_lead =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_TXDO_LEAD	;
	wire								rect_rdma_txdo_coda =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_TXDO_CODA	;

	wire								rect_rdma_ddrs_rreq =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_RREQ	;
	wire								rect_rdma_ddrs_cmnd =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_CMND	;
	wire								rect_rdma_ddrs_data =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_DATA	;
	wire								rect_rdma_ddrs_loop =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_DDRS_LOOP	;

	wire								rect_rdma_pack_loop =	dlnk_rdma_rect_mfsm	==	RECT_RDMA_PACK_LOOP	;

	wire								rect_rdma_ddrs_crdy	= &{rect_rdma_ddrs_cmnd	,  	dlnk_rdma_ddrs_crdy	};	
	wire								rect_rdma_ddrs_drdy	= &{rect_rdma_ddrs_data	,  	dlnk_rdma_ddrs_drdy	};	

	assign		dlnk_rdma_txdo_reqs	=	rect_rdma_txdo_coda	;		
	assign		dlnk_rdma_rect_done	=	rect_rdma_ddrs_done	;	
/**********************************************************************************************************************/
	reg			[ 5: 0]					rect_rdma_rows_cnts	;
	reg			[12: 0]					rect_rdma_pack_cnts	;
//------------------------------------------------------------------------------
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_reqs	<=	0	;
	else if( rect_rdma_ddrs_idle)		dlnk_rdma_ddrs_reqs	<=	0	;
	else if( rect_rdma_ddrs_rreq)		dlnk_rdma_ddrs_reqs	<=	1	;
	else if( rect_rdma_ddrs_drdy)		dlnk_rdma_ddrs_reqs	<=	0	;
//------------------------------------------------------------------------------
	wire								rect_rdma_rows_init	= &{rect_rdma_ddrs_loop	,	rect_rdma_tail_last	};
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						rect_rdma_rows_cnts	<=	0	;
	else if(rect_rdma_ddrs_idle)		rect_rdma_rows_cnts	<=	0	;
	else if(rect_rdma_rows_init)		rect_rdma_rows_cnts	<=	0	;
	else if(rect_rdma_ddrs_crdy)		rect_rdma_rows_cnts	<=	1 +	rect_rdma_rows_cnts	;
//------------------------------------------------------------------------------
	wire								rect_rdma_pack_next	= &{rect_rdma_pack_loop	, ~	rect_rdma_pack_last	};	
	wire		[12: 0]					rect_rdma_pack_inc1	=	rect_rdma_pack_cnts + 1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						rect_rdma_pack_cnts	<=	0	;
	else if(rect_rdma_ddrs_idle)		rect_rdma_pack_cnts	<=	0	;
	else if(rect_rdma_pack_next)		rect_rdma_pack_cnts	<=	rect_rdma_pack_inc1	;
/**********************************************************************************************************************/
	wire		[24: 0]					rect_rows_pack_indx	=	rect_rdma_rows_cnts *	dlnk_rdma_pack_numb	+	rect_rdma_pack_cnts	;
	
	reg			[24: 0]					meta_rect_rows_pack	;
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						meta_rect_rows_pack	<=	0	;
	else								meta_rect_rows_pack	<=	rect_rows_pack_indx ;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						dlnk_rdma_ddrs_addr	<=	0	;
	else if( rect_rdma_ddrs_idle)		dlnk_rdma_ddrs_addr	<=	0	;
	else 								dlnk_rdma_ddrs_addr	<=	8 *	meta_rect_rows_pack +	dlnk_rdma_ddrs_base	;	
/**********************************************************************************************************************/
	assign		rect_rdma_pack_last	= &{rect_rdma_pack_loop	,	rect_rdma_pack_inc1	==	dlnk_rdma_pack_numb	};
	assign		rect_rdma_tail_last	= &{rect_rdma_ddrs_loop	,	rect_rdma_rows_cnts	==	dlnk_rdma_rows_numb	};

endmodule

