`include	"agile_card_vars.vh"

module	scut_root_edge_ctrl (
	input							cube_link_scut_enab	,
	
	input							root_rxdi_data_lead	,
	input							root_rxdi_data_wrcs	,
	input		[ 31: 0]			root_rxdi_data_word	,
	
	output	reg	[  7: 0]			root_scut_edge_fram	,
	output		[  7: 0]			root_scut_edge_dat3	,
	output		[  7: 0]			root_scut_edge_dat2	,
	output		[  7: 0]			root_scut_edge_dat1	,
	output		[  7: 0]			root_scut_edge_dat0	,
	
	input							cube_clki			,
	input							cube_rstn			);
/**********************************************************************************************************/
	reg		[31: 0]					root_scut_edge_word	;
	wire							lump_txdo_fram_high	;

	assign	lump_txdo_fram_high	= |{root_rxdi_data_lead	,
									root_rxdi_data_wrcs	};

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn) 					root_scut_edge_fram	<=	0	;
	else if(~cube_link_scut_enab)	root_scut_edge_fram	<=	0	;
	else if( lump_txdo_fram_high)	root_scut_edge_fram	<=	8'HFF	;
	else							root_scut_edge_fram	<=	0	;	

	always@(posedge cube_clki or negedge cube_rstn)
	if(!cube_rstn) 					root_scut_edge_word	<=	0	;
	else if(~cube_link_scut_enab)	root_scut_edge_word	<=	0	;
	else if( root_rxdi_data_lead)	root_scut_edge_word	<= `CUBE_LINK_DATA_LEAD	;
	else if( root_rxdi_data_wrcs)	root_scut_edge_word	<=	root_rxdi_data_word	;
	else							root_scut_edge_word	<=	0	;

	assign	root_scut_edge_dat3	=	root_scut_edge_word[31:24]	;
	assign	root_scut_edge_dat2	=	root_scut_edge_word[23:16]	;
	assign	root_scut_edge_dat1	=	root_scut_edge_word[15: 8]	;
	assign	root_scut_edge_dat0	=	root_scut_edge_word[ 7: 0]	;
/**********************************************************************************************************/								
									
endmodule