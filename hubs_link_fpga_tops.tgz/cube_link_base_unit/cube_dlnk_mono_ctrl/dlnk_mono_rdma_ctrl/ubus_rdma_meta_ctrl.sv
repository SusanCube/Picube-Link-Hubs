//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"
module	ubus_rdma_meta_ctrl(
	input							dlnk_odat_ddrs_enab	,
	input							dlnk_odat_ddrs_mode	,//0:vect 	1:mtrx
	
	output							ubus_rdma_ddrs_enab	,

	output							ubus_rdma_pack_reqs	,
	output		[24: 0]				ubus_rdma_pack_addr	,			
	output		[ 5: 0]				ubus_rdma_pack_size	,
	input							ubus_rdma_pack_drdy	,
	input							ubus_rdma_pack_crdy	,
	
	input							dlnk_odat_load_csen	,
	input							dlnk_odat_coda_csen	,

	input		[24: 0]				llmb_mast_ddrs_base	, 
	input		[19: 0]				llmb_meta_imag_rows	, 
	input		[19: 0]				llmb_meta_imag_cols	, 
	input							llmb_meta_tile_size	,//0:128 dots 1:32 dots
		
	input							link_clki			,
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg			[ 1: 0]				ubus_rdma_mode_samp	;
	reg			[ 3: 0]				ubus_rdma_enab_samp	;


	wire							ubus_rdma_ddrs_disa	;
	wire							ubus_rdma_ddrs_reqs	;
	wire							ubus_rdma_ddrs_mtrx	;

	assign	ubus_rdma_ddrs_mtrx	=	ubus_rdma_mode_samp[ 0 ] ;
	assign	ubus_rdma_ddrs_disa	=	ubus_rdma_enab_samp[2:0] == 3'B000	;
	assign	ubus_rdma_ddrs_init	=	ubus_rdma_enab_samp[2:0] == 3'B100	;
	assign	ubus_rdma_ddrs_reqs	=	ubus_rdma_enab_samp[2:0] == 3'B110	;
	assign	ubus_rdma_ddrs_enab	=	ubus_rdma_enab_samp[2:0] == 3'B111	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_enab_samp	<=	0	;
	else 							ubus_rdma_enab_samp	<= {dlnk_odat_ddrs_enab	,	ubus_rdma_enab_samp[3:1]};	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_mode_samp	<=	0	;
	else 							ubus_rdma_mode_samp	<= {dlnk_odat_ddrs_mode	,	ubus_rdma_mode_samp[ 1 ]};	
/**********************************************************************************************************/
	wire		[14: 0]					meta_imag_tile_rows	;
	wire		[ 4: 0]					meta_imag_rect_rows	;
	wire		[14: 0]					meta_cols_128d_pack	;
	wire		[14: 0]					meta_cols_032d_pack	;
	wire		[14: 0]					meta_tile_pack_numb	;
	wire		[15: 0]					meta_imag_cols_page	;


	assign		meta_cols_128d_pack	= { 2'H0 ,	meta_cols_032d_pack[14:2]	};

	assign		meta_tile_pack_numb	=	llmb_meta_tile_size	?	meta_cols_032d_pack	:	
																meta_cols_128d_pack	;




	wire		ubus_rdma_tile_case	=|	meta_imag_tile_rows	;
	wire		ubus_rdma_rect_case	=|	meta_imag_rect_rows	;
	
	wire		ubus_rdma_tile_reqs	= &{ubus_rdma_ddrs_reqs	,	ubus_rdma_ddrs_mtrx	, ubus_rdma_tile_case	};
	wire		ubus_rdma_rect_reqs	= &{ubus_rdma_ddrs_reqs	,	ubus_rdma_ddrs_mtrx	, ubus_rdma_rect_case	};
	wire		ubus_rdma_vect_reqs	= &{ubus_rdma_ddrs_reqs	,  ~ubus_rdma_ddrs_mtrx	};

	wire		ubus_rdma_tile_done	;
	wire		ubus_rdma_rect_done	;
	wire		ubus_rdma_vect_done	;

	wire		ubus_rdma_rect_join	= &{ubus_rdma_tile_done	,	ubus_rdma_rect_case};
	
	gens_sync_gray	#(.MSB(14))	
								u_tile_rows_sync_gens(
		.data_asyn					(llmb_meta_imag_rows[19: 5]	),
		.scki						(link_clki					),

		.data_sync					(meta_imag_tile_rows		),
		.clki						(ubus_clki					),
		.rstn						(ubus_rstn					));

	gens_sync_gray	#(.MSB( 4))	
								u_rect_rows_sync_gens(
		.data_asyn					(llmb_meta_imag_rows[ 4: 0]	),
		.scki						(link_clki					),

		.data_sync					(meta_imag_rect_rows		),
		.clki						(ubus_clki					),
		.rstn						(ubus_rstn					));

	gens_sync_gray	#(.MSB(15))	
								u_meta_cols_sync_page(
		.data_asyn					(llmb_meta_imag_cols[19: 4]	),
		.scki						(link_clki					),

		.data_sync					(meta_imag_cols_page		),
		.clki						(ubus_clki					),
		.rstn						(ubus_rstn					));


	gens_sync_gray	#(.MSB(14))	
								u_pack_032d_sync_gens(
		.data_asyn					(llmb_meta_imag_cols[19: 5]	),
		.scki						(link_clki					),

		.data_sync					(meta_cols_032d_pack		),
		.clki						(ubus_clki					),
		.rstn						(ubus_rstn					));
/**********************************************************************************************************/
	wire		[24: 0]				meta_rect_ddrs_ofst	;
	reg			[24: 0]				meta_rect_ddrs_base	;

	assign	meta_rect_ddrs_ofst	=	meta_imag_tile_rows	*	llmb_meta_imag_cols[19:4]	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					meta_rect_ddrs_base	<=	0	;
	else							meta_rect_ddrs_base	<=	llmb_mast_ddrs_base	+	meta_rect_ddrs_ofst	;
/**********************************************************************************************************/
	reg		[ 3: 0]					ubus_rdma_meta_mfsm	;

	reg								ubus_rdma_tile_enab	;
	reg								ubus_rdma_rect_enab	;
	reg								ubus_rdma_vect_enab	;

	parameter	UBUS_RDMA_META_IDLE	=	4'H0	;
	parameter	UBUS_RDMA_TILE_REQS	=	4'H1	;
	parameter	UBUS_RDMA_TILE_DONE	=	4'H2	;
	parameter	UBUS_RDMA_RECT_REQS	=	4'H3	;
	parameter	UBUS_RDMA_RECT_DONE	=	4'H4	;
	parameter	UBUS_RDMA_VECT_REQS	=	4'H5	;
	parameter	UBUS_RDMA_VECT_DONE	=	4'H6	;
	parameter	UBUS_RDMA_META_DONE	=	4'H7	;

	wire		ubus_rdma_tile_rise	=	ubus_rdma_meta_mfsm	==	UBUS_RDMA_TILE_REQS	;
	wire		ubus_rdma_rect_rise	=	ubus_rdma_meta_mfsm	==	UBUS_RDMA_RECT_REQS	;
	wire		ubus_rdma_vect_rise	=	ubus_rdma_meta_mfsm	==	UBUS_RDMA_VECT_REQS	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_meta_mfsm	<=	UBUS_RDMA_META_IDLE	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_meta_mfsm	<=	UBUS_RDMA_META_IDLE	;
	else begin
		case(ubus_rdma_meta_mfsm)
			UBUS_RDMA_META_IDLE	:	ubus_rdma_meta_mfsm	<=	ubus_rdma_tile_reqs	?	UBUS_RDMA_TILE_REQS	:
															ubus_rdma_rect_reqs	?	UBUS_RDMA_RECT_REQS	:
															ubus_rdma_vect_reqs	?	UBUS_RDMA_VECT_REQS	:	UBUS_RDMA_META_IDLE	;
															
			UBUS_RDMA_TILE_REQS	:	ubus_rdma_meta_mfsm	<=							UBUS_RDMA_TILE_DONE	;
			UBUS_RDMA_TILE_DONE	:	ubus_rdma_meta_mfsm	<= 	ubus_rdma_rect_join	?	UBUS_RDMA_RECT_REQS	:	
															ubus_rdma_tile_done	?	UBUS_RDMA_META_DONE :	UBUS_RDMA_TILE_DONE	;
															
			UBUS_RDMA_RECT_REQS	:	ubus_rdma_meta_mfsm	<=							UBUS_RDMA_RECT_DONE	;
			UBUS_RDMA_RECT_DONE	:	ubus_rdma_meta_mfsm	<= 	ubus_rdma_rect_done	?	UBUS_RDMA_META_DONE	:	UBUS_RDMA_RECT_DONE	;

			UBUS_RDMA_VECT_REQS	:	ubus_rdma_meta_mfsm	<=							UBUS_RDMA_VECT_DONE	;
			UBUS_RDMA_VECT_DONE	:	ubus_rdma_meta_mfsm	<= 	ubus_rdma_vect_done	?	UBUS_RDMA_META_DONE	:	UBUS_RDMA_VECT_DONE	;

			UBUS_RDMA_META_DONE	:	ubus_rdma_meta_mfsm	<= 	ubus_rdma_ddrs_disa	?	UBUS_RDMA_META_IDLE	:	UBUS_RDMA_META_DONE	;

			default				:	ubus_rdma_meta_mfsm	<= 	UBUS_RDMA_META_IDLE	;
		endcase
	end
//----------------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_tile_enab	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_tile_enab	<=	0	;
	else if(ubus_rdma_tile_rise)	ubus_rdma_tile_enab	<=	1	;
	else if(ubus_rdma_tile_done)	ubus_rdma_tile_enab	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_rect_enab	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_rect_enab	<=	0	;
	else if(ubus_rdma_rect_rise)	ubus_rdma_rect_enab	<=	1	;
	else if(ubus_rdma_rect_done)	ubus_rdma_rect_enab	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_vect_enab	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_vect_enab	<=	0	;
	else if(ubus_rdma_vect_rise)	ubus_rdma_vect_enab	<=	1	;
	else if(ubus_rdma_vect_done)	ubus_rdma_vect_enab	<=	0	;
/**********************************************************************************************************/
	wire							ubus_tile_pack_reqs	;
	wire							ubus_rect_pack_reqs	;
	wire							ubus_vect_pack_reqs	;
	
	wire		[24: 0]				ubus_tile_pack_addr	;
	wire		[24: 0]				ubus_rect_pack_addr	;
	wire		[24: 0]				ubus_vect_pack_addr	;

	assign	ubus_rdma_pack_reqs	=	ubus_rdma_tile_enab	?	ubus_tile_pack_reqs	:
									ubus_rdma_rect_enab	?	ubus_rect_pack_reqs	:
									ubus_rdma_vect_enab	?	ubus_vect_pack_reqs	:	1'H0	;

	assign	ubus_rdma_pack_size	=	ubus_rdma_vect_enab	?	6'H2	:	
									llmb_meta_tile_size	?	6'H2	:	6'H8	;

	assign	ubus_rdma_pack_addr	=	ubus_rdma_tile_enab	?	ubus_tile_pack_addr	:
									ubus_rdma_rect_enab	?	ubus_rect_pack_addr	:
									ubus_rdma_vect_enab	?	ubus_vect_pack_addr	:	25'H0	;
/**********************************************************************************************************/
	ubus_rdma_tile_mfsm			u_ubus_rdma_tile_mfsm(
		.ubus_rdma_tile_enab		(ubus_rdma_tile_enab	),//input				
		.ubus_rdma_tile_done		(ubus_rdma_tile_done	),//output				

		.ubus_rdma_pack_reqs		(ubus_tile_pack_reqs	),//output				
		.ubus_rdma_pack_addr		(ubus_tile_pack_addr	),//output	[24: 0]		
		.ubus_rdma_pack_crdy		(ubus_rdma_pack_crdy	),//input				
		.ubus_rdma_pack_drdy		(ubus_rdma_pack_drdy	),//input				

		.dlnk_odat_load_csen		(dlnk_odat_load_csen	),//input				
		.dlnk_odat_coda_csen		(dlnk_odat_coda_csen	),//input				

		.llmb_mast_ddrs_base		(llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_meta_imag_cols		(meta_imag_cols_page	),//llmb_meta_imag_cols[19:4]	),//input		[19: 0]	
		.llmb_tile_rows_numb		(meta_imag_tile_rows	),//input		[14: 0]	
		.llmb_tile_pack_numb		(meta_tile_pack_numb	),//meta_cols_128d_pack	),//input		[12: 0]	

		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				

	ubus_rdma_rect_mfsm			u_ubus_rdma_rect_mfsm(
		.ubus_rdma_rect_enab		(ubus_rdma_rect_enab	),//input				
		.ubus_rdma_rect_done		(ubus_rdma_rect_done	),//output				

		.ubus_rdma_pack_reqs		(ubus_rect_pack_reqs	),//output				
		.ubus_rdma_pack_addr		(ubus_rect_pack_addr	),//output	reg	[24: 0]	
		.ubus_rdma_pack_crdy		(ubus_rdma_pack_crdy	),//input				
		.ubus_rdma_pack_drdy		(ubus_rdma_pack_drdy	),//input				

		.dlnk_odat_load_csen		(dlnk_odat_load_csen	),//input				
		.dlnk_odat_coda_csen		(dlnk_odat_coda_csen	),//input				

		.llmb_mast_ddrs_base		(meta_rect_ddrs_base	),//llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_meta_imag_cols		(meta_imag_cols_page	),//llmb_meta_imag_cols[19:4]	),//input		[15: 0]	
		.llmb_rect_rows_numb		(meta_imag_rect_rows	),//input		[ 4: 0]	///////////////////////////////////
		.llmb_rect_pack_numb		(meta_tile_pack_numb	),//meta_cols_128d_pack	),//input		[12: 0]	
		
		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				

	ubus_rdma_vect_mfsm			u_ubus_rdma_vect_mfsm(
		.ubus_rdma_vect_enab		(ubus_rdma_vect_enab	),//input				
		.ubus_rdma_vect_done		(ubus_rdma_vect_done	),//output				

		.ubus_rdma_pack_reqs		(ubus_vect_pack_reqs	),//output				
		.ubus_rdma_pack_addr		(ubus_vect_pack_addr	),//output	reg	[24: 0]	
		.ubus_rdma_pack_crdy		(ubus_rdma_pack_crdy	),//input				
		.ubus_rdma_pack_drdy		(ubus_rdma_pack_drdy	),//input				

		.dlnk_odat_load_csen		(dlnk_odat_load_csen	),//input				
		.dlnk_odat_coda_csen		(dlnk_odat_coda_csen	),//input				

		.llmb_mast_ddrs_base		(llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_vect_rows_numb		(llmb_meta_imag_rows	),//input		[19: 0]	
		.llmb_vect_pack_numb		(meta_cols_032d_pack	),//input		[12: 0]	//pack base on 64 dots

		.ubus_clki					(ubus_clki				),//input				
		.ubus_rstn					(ubus_rstn				));//input				
	 
endmodule

