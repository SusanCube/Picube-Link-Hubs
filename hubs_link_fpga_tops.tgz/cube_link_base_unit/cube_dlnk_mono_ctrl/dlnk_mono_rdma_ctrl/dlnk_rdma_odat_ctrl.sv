/*
	ONE	PIXS	: 16 BITS	
	2	PIXS	: 32 BITS	->	ONE WORD 	
	8 	WORD 	:256 BITS	->	ONE PAGE
	N  	PAGE	:XXX BITS	->	ONE	ROW			
*/
`include	"agile_card_vars.vh"

module	dlnk_rdma_odat_ctrl(
	output	reg	[ 7: 0]				dlnk_odat_fram_mbdo	,
	output	reg	[ 7: 0]				dlnk_odat_dat3_mbdo	,
	output	reg	[ 7: 0]				dlnk_odat_dat2_mbdo	,
	output	reg	[ 7: 0]				dlnk_odat_dat1_mbdo	,
	output	reg	[ 7: 0]				dlnk_odat_dat0_mbdo	,
//------------------------------------------------------
	input							dlnk_odat_ddrs_enab	,	
	output							dlnk_odat_ddrs_done	,	
//------------------------------------------------------
	input		[ 19: 0]			llmb_edge_imag_rows	,
	input		[ 15: 0]			llmb_edge_imag_cols	,

	output							dlnk_odat_page_reqs	,
	input		[255:0 ]			dlnk_odat_page_data	,
	input							dlnk_odat_page_drdy	,
	
	input							link_clki			,
	input							link_rstn			,
	
	output							ubus_dlnk_txdo_load	,		
	output							ubus_dlnk_txdo_coda	,

	input							ubus_clki			,
	input							ubus_rstn			);
//--------------ASYNC SIGNALS HAND-SHAKE
	reg			[ 2: 0]				dlnk_rdma_odat_mfsm	;
	reg			[ 1: 0]				dlnk_odat_load_samp	;
	reg			[ 1: 0]				dlnk_odat_coda_samp	;

	wire							dlnk_hits_fram_idle	;
	wire							dlnk_hits_rows_load	;
	wire							dlnk_hits_rows_lead	;
	wire							dlnk_hits_rows_body	;
	wire							dlnk_hits_rows_coda	;
	
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					dlnk_odat_load_samp	<=	0	;
	else							dlnk_odat_load_samp	<= {dlnk_hits_rows_load	,	dlnk_odat_load_samp[1]	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					dlnk_odat_coda_samp	<=	0	;
	else							dlnk_odat_coda_samp	<= {dlnk_hits_rows_coda	,	dlnk_odat_coda_samp[1]	};
//-------------------------------------------------------------------------------
	parameter	DLNK_TXDO_FRAM_IDLE	=	3'H0	;
	parameter	DLNK_TXDO_ROWS_LOAD	=	3'H1	;
	parameter	DLNK_TXDO_ROWS_LEAD	=	3'H2	;
	parameter	DLNK_TXDO_ROWS_BODY	=	3'H3	;
	parameter	DLNK_TXDO_ROWS_CODA	=	3'H4	;
	parameter	DLNK_TXDO_FRAM_DONE	=	3'H5	;
	


	assign	dlnk_hits_fram_idle	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_FRAM_IDLE	;	
	assign	dlnk_hits_rows_load	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_ROWS_LOAD	;	
	assign	dlnk_hits_rows_lead	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_ROWS_LEAD	;	
	assign	dlnk_hits_rows_body	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_ROWS_BODY	;
	assign	dlnk_hits_rows_coda	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_ROWS_CODA	;

	assign	dlnk_odat_ddrs_done	=	dlnk_rdma_odat_mfsm	==	DLNK_TXDO_FRAM_DONE	;

	assign	ubus_dlnk_txdo_load	=	dlnk_odat_load_samp[ 0 ];
	assign	ubus_dlnk_txdo_coda	=	dlnk_odat_coda_samp[ 0 ];
	


	wire	dlnk_hits_txdo_lead	= &{dlnk_hits_rows_lead	,	dlnk_odat_page_drdy};
//-------------------------------------------------------------------------------
	wire							dlnk_txdo_mute_tmax	;
	
	wire							dlnk_txdo_cols_done	;
	wire							dlnk_txdo_rows_done	;	
	
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					dlnk_rdma_odat_mfsm	<=	DLNK_TXDO_FRAM_IDLE	;
	else if(~dlnk_odat_ddrs_enab)	dlnk_rdma_odat_mfsm	<=	DLNK_TXDO_FRAM_IDLE	;
	else begin
		case(dlnk_rdma_odat_mfsm) 
			DLNK_TXDO_FRAM_IDLE	:	dlnk_rdma_odat_mfsm	<=													DLNK_TXDO_ROWS_LOAD	;

			DLNK_TXDO_ROWS_LOAD	:	dlnk_rdma_odat_mfsm	<=	dlnk_odat_page_drdy	? 	DLNK_TXDO_ROWS_LEAD	:	DLNK_TXDO_ROWS_LOAD	;

			DLNK_TXDO_ROWS_LEAD	:	dlnk_rdma_odat_mfsm	<=													DLNK_TXDO_ROWS_BODY	;
			
			DLNK_TXDO_ROWS_BODY	:	dlnk_rdma_odat_mfsm	<=	dlnk_txdo_rows_done	?	DLNK_TXDO_FRAM_DONE	:
															dlnk_txdo_cols_done	?	DLNK_TXDO_ROWS_CODA	:	DLNK_TXDO_ROWS_BODY	;

			DLNK_TXDO_ROWS_CODA	:	dlnk_rdma_odat_mfsm	<=	dlnk_txdo_mute_tmax	? 	DLNK_TXDO_ROWS_LOAD	:	DLNK_TXDO_ROWS_CODA	;

			DLNK_TXDO_FRAM_DONE	:	dlnk_rdma_odat_mfsm	<=	dlnk_odat_ddrs_enab	? 	DLNK_TXDO_FRAM_DONE	:	DLNK_TXDO_FRAM_IDLE	;
			default				:	dlnk_rdma_odat_mfsm	<=													DLNK_TXDO_FRAM_IDLE	;
		endcase
	end	
/**********************************************************************************************************/
	reg		[ 3: 0]					dlnk_coda_time_cnts	;
	
	reg		[ 2: 0]					dlnk_page_word_cnts	;
	reg		[15: 0]					dlnk_cols_page_cnts	;
	reg		[19: 0]					dlnk_fram_rows_cnts	;

	wire	[15: 0]					fram_cols_page_numb	;

	wire	[15: 0]					dlnk_cols_page_inc1	;
	wire	[19: 0]					dlnk_fram_rows_inc1	;
	
	wire							dlnk_page_word_last	;
	wire							dlnk_fram_rows_last	;

	assign	fram_cols_page_numb	=	llmb_edge_imag_cols	;
	
	assign	dlnk_cols_page_inc1	=	dlnk_cols_page_cnts	+ 1	;
	assign	dlnk_fram_rows_inc1	=	dlnk_fram_rows_cnts	+ 1	;
	
	assign	dlnk_txdo_mute_tmax	= & dlnk_coda_time_cnts	;

	assign	dlnk_page_word_last	= &{dlnk_hits_rows_body	,	dlnk_page_word_cnts	};
	assign	dlnk_txdo_cols_done	= &{dlnk_page_word_last	,	dlnk_cols_page_inc1 == 	fram_cols_page_numb	};
	assign	dlnk_txdo_rows_done	= &{dlnk_txdo_cols_done	,	dlnk_fram_rows_inc1 == 	llmb_edge_imag_rows	};

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_page_word_cnts	<=	0	;
	else if(~dlnk_hits_rows_body)	dlnk_page_word_cnts	<=	0	;
	else 							dlnk_page_word_cnts	<=	dlnk_page_word_cnts + 1	;

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_cols_page_cnts	<=	0	;
	else if(~dlnk_hits_rows_body)	dlnk_cols_page_cnts	<=	0	;
	else 							dlnk_cols_page_cnts	<=	dlnk_cols_page_cnts + dlnk_page_word_last	;

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_fram_rows_cnts	<=	0	;
	else if( dlnk_hits_fram_idle)	dlnk_fram_rows_cnts	<=	0	;
	else if( dlnk_txdo_cols_done)	dlnk_fram_rows_cnts	<=	dlnk_fram_rows_cnts + 1	;

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_coda_time_cnts	<=	0	;
	else if( dlnk_hits_fram_idle)	dlnk_coda_time_cnts	<=	0	;
	else if(~dlnk_hits_rows_coda)	dlnk_coda_time_cnts	<=	0	;
	else 							dlnk_coda_time_cnts	<=	dlnk_coda_time_cnts + 1	;
/**********************************************************************************************************/
	reg		[255:0]					dlnk_odat_page_buff	;
	wire							dlnk_odat_pack_rdcs	;
	
//	wire	[ 31:0]					dlnk_odat_pack_word	=	dlnk_odat_page_buff[255:224];
	wire	[ 31:0]					dlnk_odat_pack_word	=	dlnk_odat_page_buff[31:0];

	wire	[ 31:0]					dlnk_odat_rows_lead	=	`CUBE_LINK_DATA_LEAD	;

	wire	dlnk_odat_page_reqx	= &{dlnk_hits_rows_body , dlnk_page_word_last ,~ dlnk_txdo_cols_done 	};
	assign	dlnk_odat_page_reqs	= dlnk_odat_page_reqx 	| dlnk_hits_rows_lead	;

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_odat_page_buff	<=	0	;
	else if( dlnk_hits_fram_idle)	dlnk_odat_page_buff	<=	0	;
	else if( dlnk_odat_page_reqs)	dlnk_odat_page_buff	<=	dlnk_odat_page_data	;
//	else if( dlnk_hits_rows_body)	dlnk_odat_page_buff	<={	dlnk_odat_page_buff[223:0], 32'H0	}	;
	else if( dlnk_hits_rows_body)	dlnk_odat_page_buff	<={	32'H0	,dlnk_odat_page_buff[255:32]	}	;
	else							dlnk_odat_page_buff	<=	dlnk_odat_page_buff	;
/**********************************************************************************************************/

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn)					dlnk_odat_fram_mbdo	<=	0		;
	else if(dlnk_hits_rows_lead)	dlnk_odat_fram_mbdo	<=	8'HFF	;
	else if(dlnk_hits_rows_body)	dlnk_odat_fram_mbdo	<= 	8'HFF	;
	else							dlnk_odat_fram_mbdo	<= 	8'H00	;

	always@(posedge link_clki or negedge  link_rstn)
	if(!link_rstn) begin
		dlnk_odat_dat3_mbdo	<=	0	;
		dlnk_odat_dat2_mbdo	<=	0	;
		dlnk_odat_dat1_mbdo	<=	0	;
		dlnk_odat_dat0_mbdo	<=	0	;
	end else if(dlnk_hits_rows_lead)begin
		dlnk_odat_dat3_mbdo	<=	dlnk_odat_rows_lead[31:24]	;
		dlnk_odat_dat2_mbdo	<=	dlnk_odat_rows_lead[23:16]	;
		dlnk_odat_dat1_mbdo	<=	dlnk_odat_rows_lead[15: 8]	;
		dlnk_odat_dat0_mbdo	<=	dlnk_odat_rows_lead[ 7: 0]	;
	end else if(dlnk_hits_rows_body) begin
		dlnk_odat_dat3_mbdo	<=	dlnk_odat_pack_word[31:24]	;
		dlnk_odat_dat2_mbdo	<=	dlnk_odat_pack_word[23:16]	;
		dlnk_odat_dat1_mbdo	<=	dlnk_odat_pack_word[15: 8]	;
		dlnk_odat_dat0_mbdo	<=	dlnk_odat_pack_word[ 7: 0]	;
	end else begin
		dlnk_odat_dat3_mbdo	<=	0	;
		dlnk_odat_dat2_mbdo	<=	0	;
		dlnk_odat_dat1_mbdo	<=	0	;
		dlnk_odat_dat0_mbdo	<=	0	;
	end
 
endmodule 

	
