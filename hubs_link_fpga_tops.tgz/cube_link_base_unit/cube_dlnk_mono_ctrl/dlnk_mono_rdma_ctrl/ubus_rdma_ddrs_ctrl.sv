module	ubus_rdma_ddrs_ctrl(
	input							dlnk_odat_ddrs_enab	,
	input							dlnk_odat_page_reqs	,
	output		[255:0]				dlnk_odat_page_data	,
	output							dlnk_odat_page_drdy	,

	input							link_clki			,
	input							link_rstn			,

	input							ubus_rdma_ddrs_enab	,
	input							ubus_rdma_pack_reqs	,
	input		[ 5: 0]				ubus_rdma_pack_size	,
	input		[24: 0]				ubus_rdma_pack_addr	,
	output							ubus_rdma_pack_drdy	,
	output							ubus_rdma_pack_crdy	,
	
	output	reg						ddrs_ubus_rdma_csen	,
	output	reg	[ 24: 0]			ddrs_ubus_rdma_addr	,
	input							ddrs_ubus_rdma_trdy	,
	input		[255: 0]			ddrs_ubus_rdma_data	,
	input							ddrs_ubus_rdma_drdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
/***********************************************************************************************************/
	reg								ubus_rdma_reqs_samp	;
	wire							ubus_rdma_reqs_rise	;

	assign	ubus_rdma_reqs_rise	= &{ubus_rdma_pack_reqs	, ~	ubus_rdma_reqs_samp	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_reqs_samp	<=	0	;
	else							ubus_rdma_reqs_samp	<=	ubus_rdma_pack_reqs	;
/***********************************************************************************************************/
	reg								ddrs_ubus_data_csen	;
	
	reg			[ 5: 0]				ubus_rdma_cmnd_cnts	;
	reg			[ 5: 0]				ubus_rdma_data_cnts	;

	reg			[24: 0]				ubus_rdma_push_dptr	;

	wire							ubus_rdma_ddrs_disa	;
	wire							ubus_rdma_cmnd_vlid	;
	wire							ubus_rdma_data_vlid	;
	
	wire							ubus_rdma_pack_done	;
	wire	[15: 0]					ubus_rdma_cmnd_inc1	; 
	wire	[15: 0]					ubus_rdma_data_inc1	; 

	assign	ubus_rdma_ddrs_disa	= ~	ubus_rdma_ddrs_enab	;

	assign	ubus_rdma_cmnd_vlid	= &{ddrs_ubus_rdma_csen	,	ddrs_ubus_rdma_trdy};
	assign	ubus_rdma_data_vlid	= &{ddrs_ubus_data_csen	,	ddrs_ubus_rdma_drdy};

	assign	ubus_rdma_cmnd_inc1	=	ubus_rdma_cmnd_cnts + 1	; 
	assign	ubus_rdma_data_inc1	=	ubus_rdma_data_cnts + 1	; 

	assign	ubus_rdma_pack_crdy	= &{ubus_rdma_cmnd_vlid	,	ubus_rdma_cmnd_inc1 == ubus_rdma_pack_size	};
	assign	ubus_rdma_pack_drdy	= &{ubus_rdma_data_vlid	,	ubus_rdma_data_inc1 == ubus_rdma_pack_size	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ddrs_ubus_rdma_csen	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ddrs_ubus_rdma_csen	<=	0	;
	else if(ubus_rdma_reqs_rise)	ddrs_ubus_rdma_csen	<=	1	;
	else if(ubus_rdma_pack_crdy)	ddrs_ubus_rdma_csen	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ddrs_ubus_data_csen	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ddrs_ubus_data_csen	<=	0	;
	else if(ubus_rdma_reqs_rise)	ddrs_ubus_data_csen	<=	1	;
	else if(ubus_rdma_pack_drdy)	ddrs_ubus_data_csen	<=	0	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_rdma_reqs_rise)	ubus_rdma_cmnd_cnts	<=	0	;
	else if(ubus_rdma_cmnd_vlid)	ubus_rdma_cmnd_cnts	<=	ubus_rdma_pack_crdy	?	0	:	ubus_rdma_cmnd_cnts + 1	;
		
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_reqs_rise)	ubus_rdma_data_cnts	<=	0	;
	else if(ubus_rdma_data_vlid)	ubus_rdma_data_cnts	<=	ubus_rdma_pack_drdy	?	0	:	ubus_rdma_data_cnts + 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_rdma_push_dptr	<=	0	;
	else if(ubus_rdma_ddrs_disa)	ubus_rdma_push_dptr	<=	0	;
	else if(ubus_rdma_data_vlid)	ubus_rdma_push_dptr	<=	ubus_rdma_push_dptr	+ 1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ddrs_ubus_rdma_addr	<=	0	;
	else if(ubus_rdma_reqs_rise)	ddrs_ubus_rdma_addr	<=	ubus_rdma_pack_addr	;
	else if(ubus_rdma_cmnd_vlid)	ddrs_ubus_rdma_addr	<=	ddrs_ubus_rdma_addr + 1	;
/***********************************************************************************************************/
	reg			[24: 0]					dlnk_odat_pops_dptr	;
	wire		[24: 0]					ubus_push_dptr_sync	;
	
	wire							dlnk_rdma_ddrs_disa	;
	assign	dlnk_rdma_ddrs_disa	= ~	dlnk_odat_ddrs_enab	;	

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)					dlnk_odat_pops_dptr	<=	0	;
	else if(dlnk_rdma_ddrs_disa)	dlnk_odat_pops_dptr	<=	0	;
	else if(dlnk_odat_page_reqs)	dlnk_odat_pops_dptr	<=	dlnk_odat_pops_dptr	+ 1	;

	assign	dlnk_odat_page_drdy	= &{ubus_rdma_ddrs_enab	,
									ubus_push_dptr_sync	>=	dlnk_odat_pops_dptr + 4};
/***********************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )
								u_ubus_dptr_sync_gens(
		.data_asyn					(ubus_rdma_push_dptr	),//input	[24: 0]	
		.scki						(ubus_clki				),
		
		.data_sync					(ubus_push_dptr_sync	),//output	[24: 0]	
		.clki						(link_clki				),//input			
		.rstn						(link_rstn				));//input			

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
	u_idat_rdma_beat_data (
		.wport_csen					(ubus_rdma_data_vlid		),//input  				 		
		.wport_data					(ddrs_ubus_rdma_data		),//input		[DATA_BITS-1:0]
		.wport_addr					(ubus_rdma_push_dptr[ 8: 0]	),//input		[ADDR_BITS-1:0]
		.wport_clki					(ubus_clki					),//input						

		.rport_addr					(dlnk_odat_pops_dptr[ 8: 0]	),//input		[ADDR_BITS-1:0]
		.rport_data					(dlnk_odat_page_data		),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(link_clki					));//input						


endmodule
