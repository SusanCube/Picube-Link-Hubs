/*----author edward------*/

module	dlnk_mono_wdma_ctrl(
	input							dlnk_idat_wdma_enab	,//write enable
	output							dlnk_idat_wdma_done	,

	input		[24 : 0]			dlnk_idat_ddrs_base	,	
	input		[19 : 0]			dlnk_idat_rows_numb	,
	input		[15 : 0]			dlnk_idat_cols_numb	,
	
	input							dlnk_mono_idat_lead	,
	input							dlnk_mono_idat_wrcs	,
	input		[ 31: 0]			dlnk_mono_idat_data	,

	input							link_clki			,
	input							link_rstn			,

	output							ubus_dlnk_wdma_csen	,
	output		[ 24: 0]			ubus_dlnk_wdma_addr	,
	output		[255: 0]			ubus_dlnk_wdma_data	,
	input							ubus_dlnk_wdma_trdy	,
	input							ubus_dlnk_wdma_wrdy	,

	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
	reg			[  2: 0]			ubus_wdma_ddrs_samp	;	
	reg			[  1: 0]			ubus_wdma_done_samp	;	
	reg								ubus_wdma_ddrs_done	;

	wire							ubus_mono_wdma_disa	;
	wire							ubus_mono_wdma_init	;
	wire							ubus_mono_wdma_enab	;
	
	assign	ubus_mono_wdma_disa	=	ubus_wdma_ddrs_samp[1:0]==2'B00	;
	assign	ubus_mono_wdma_init	=	ubus_wdma_ddrs_samp[1:0]==2'B10	;
	assign	ubus_mono_wdma_enab	=	ubus_wdma_ddrs_samp[1:0]==2'B11	;
	assign	dlnk_idat_wdma_done	=	ubus_wdma_done_samp[0]	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)					ubus_wdma_ddrs_samp	<=	0	;
	else							ubus_wdma_ddrs_samp	<={	dlnk_idat_wdma_enab	, ubus_wdma_ddrs_samp[2:1]	};	

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)					ubus_wdma_done_samp	<=	0	;
	else							ubus_wdma_done_samp	<={	ubus_wdma_ddrs_done	, ubus_wdma_done_samp[ 1 ]	};	
/**********************************************************************************************************/
	reg			[  2: 0]			dlnk_idat_word_cnts	;
	reg			[ 24: 0]			dlnk_idat_page_cnts	;	
	reg			[ 24: 0]			dlnk_idat_page_addr	;	
	reg			[255: 0]			dlnk_idat_page_data	;
	reg								dlnk_idat_page_wrcs	;

	wire							last_word_each_page	;
	wire		[  8: 0]			dlnk_idat_push_dptr	;

	assign	last_word_each_page	= &{dlnk_mono_idat_wrcs	,	dlnk_idat_word_cnts	};
	assign	dlnk_idat_push_dptr	=	dlnk_idat_page_cnts[ 8: 0]	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					dlnk_idat_word_cnts	<=	0	;
	else if(~dlnk_idat_wdma_enab)	dlnk_idat_word_cnts	<=	0	;
	else if( dlnk_mono_idat_lead)	dlnk_idat_word_cnts	<=	0	;
	else 							dlnk_idat_word_cnts	<=	dlnk_idat_word_cnts	+	dlnk_mono_idat_wrcs	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					dlnk_idat_page_data	<=	0	;
	else if(~dlnk_idat_wdma_enab)	dlnk_idat_page_data	<=	0	;
	else if( dlnk_mono_idat_lead)	dlnk_idat_page_data	<=	0	;
	else if( dlnk_mono_idat_wrcs)	dlnk_idat_page_data	<={	dlnk_mono_idat_data	,	dlnk_idat_page_data[255:32]	};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					dlnk_idat_page_addr	<=	0	;
	else if(~dlnk_idat_wdma_enab)	dlnk_idat_page_addr	<=	dlnk_idat_ddrs_base	;
	else if(dlnk_idat_page_wrcs)	dlnk_idat_page_addr	<=	dlnk_idat_page_addr + 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					dlnk_idat_page_cnts	<=	0	;
	else if(~dlnk_idat_wdma_enab)	dlnk_idat_page_cnts	<=	0	;
	else if(dlnk_idat_page_wrcs)	dlnk_idat_page_cnts	<=	dlnk_idat_page_cnts + 1	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 					dlnk_idat_page_wrcs	<=	0	;
	else							dlnk_idat_page_wrcs	<=	last_word_each_page	;
/**********************************************************************************************************/
	reg		[ 24: 0]				ubus_idat_wdma_size	;
//	reg		[ 24: 0]				ubus_idat_wdma_cnts	;
	reg		[ 20: 0]				ubus_idat_wdma_cnts	;
	
	wire	[ 24: 0]				dlnk_wdma_sync_cnts	;

	wire							ubus_idat_wdma_vlid	;
	wire	[  8: 0]				ubus_idat_wdma_lsba	;
	wire	[  8: 0]				ubus_idat_wdma_nxta	;	
	wire	[  8: 0]				ubus_idat_wdma_dptr	;
	wire							ubus_idat_wdma_last	;

	assign	ubus_idat_wdma_vlid	= &{ubus_mono_wdma_enab	,	
									dlnk_wdma_sync_cnts	>	ubus_idat_wdma_cnts	,
									dlnk_wdma_sync_cnts	!=	ubus_idat_wdma_cnts};
									
	assign	ubus_dlnk_wdma_csen	= &{ubus_idat_wdma_vlid	,	ubus_dlnk_wdma_trdy	,	ubus_dlnk_wdma_wrdy};

	assign	ubus_idat_wdma_lsba	=	ubus_idat_wdma_cnts[ 8: 0]	;
	assign	ubus_idat_wdma_nxta	=	ubus_idat_wdma_lsba +  1	;
	assign	ubus_idat_wdma_dptr	=	ubus_idat_wdma_vlid	?	ubus_idat_wdma_nxta	:	ubus_idat_wdma_lsba	;

	assign	ubus_idat_wdma_last	= &{ubus_mono_wdma_enab	,	ubus_idat_wdma_vlid	,
									ubus_idat_wdma_cnts+1==	ubus_idat_wdma_size	};
	
	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_idat_wdma_cnts	<=	0	;	
	else if(ubus_mono_wdma_disa)	ubus_idat_wdma_cnts	<=	0	;	
	else if(ubus_mono_wdma_init)	ubus_idat_wdma_cnts	<=	0	;	
	else 							ubus_idat_wdma_cnts	<=	ubus_idat_wdma_cnts	+ ubus_idat_wdma_vlid	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_idat_wdma_size	<=	0	;	
	else if(ubus_mono_wdma_disa)	ubus_idat_wdma_size	<=	0	;	
	else if(ubus_mono_wdma_init)	ubus_idat_wdma_size	<=	dlnk_idat_rows_numb * dlnk_idat_cols_numb	;	

	always@(posedge ubus_clki or negedge ubus_rstn )
	if(!ubus_rstn)					ubus_wdma_ddrs_done	<=	0	;	
	else if(ubus_mono_wdma_disa)	ubus_wdma_ddrs_done	<=	0	;	
	else if(ubus_idat_wdma_last)	ubus_wdma_ddrs_done	<=	1	;	
/**********************************************************************************************************/
	gens_sync_gray	#( .MSB(24) )
								u_ubus_dptr_sync_gens(
		.data_asyn					(dlnk_idat_page_cnts	),//input	[24: 0]	
		.scki						(link_clki				),
				
		.data_sync					(dlnk_wdma_sync_cnts	),//output	[24: 0]	
		.clki						(ubus_clki				),//input			
		.rstn						(ubus_rstn				));//input			

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 256 ))	
								u_idat_wdma_beat_data (
		.wport_csen					(dlnk_idat_page_wrcs	),//input  				 		
		.wport_addr					(dlnk_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(dlnk_idat_page_data	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						

		.rport_addr					(ubus_idat_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_dlnk_wdma_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 25 ))	
								u_idat_wdma_beat_addr (
		.wport_csen					(dlnk_idat_page_wrcs	),//input  				 		
		.wport_addr					(dlnk_idat_push_dptr	),//input		[ADDR_BITS-1:0]
		.wport_data					(dlnk_idat_page_addr	),//input		[DATA_BITS-1:0]
		.wport_clki					(link_clki				),//input						
		
		.rport_addr					(ubus_idat_wdma_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data					(ubus_dlnk_wdma_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki					(ubus_clki				));//input						

endmodule 
  