//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	ubus_rdma_vect_mfsm(
	input								ubus_rdma_vect_enab	,
	output								ubus_rdma_vect_done	,

	output								ubus_rdma_pack_reqs	,
	output	reg	[24: 0]					ubus_rdma_pack_addr	,
	input								ubus_rdma_pack_crdy	,
	input								ubus_rdma_pack_drdy	,

	input								dlnk_odat_load_csen	,
	input								dlnk_odat_coda_csen	,

	input		[24: 0]					llmb_mast_ddrs_base	,
	input		[19: 0]					llmb_vect_rows_numb	,
	input		[14: 0]					llmb_vect_pack_numb	,//pack base on 64 dots

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
//--------------UBUS_RDMA_VECT_MFSM
	reg		[ 3: 0]					ubus_rdma_vect_mfsm	;

	parameter	UBUS_ODAT_RDMA_IDLE	=	4'H0	;
	parameter	UBUS_ODAT_RDMA_LOAD	=	4'H1	;
	
	parameter	UBUS_COLS_PACK_REQS	=	4'H2	;
	parameter	UBUS_COLS_PACK_CMND	=	4'H3	;
	parameter	UBUS_COLS_PACK_DATA	=	4'H4	;

	parameter	UBUS_ODAT_ROWS_CODA	=	4'H5	;
	parameter	UBUS_ODAT_RDMA_DONE	=	4'H6	;

	wire							rdma_cols_pack_last	;
	wire							rdma_vect_rows_last	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_rdma_vect_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else if(~ubus_rdma_vect_enab)		ubus_rdma_vect_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else begin	
		case(ubus_rdma_vect_mfsm)	

			UBUS_ODAT_RDMA_IDLE	:		ubus_rdma_vect_mfsm	<=													UBUS_ODAT_RDMA_LOAD	;	

			UBUS_ODAT_RDMA_LOAD	:		ubus_rdma_vect_mfsm	<=	dlnk_odat_load_csen	?	UBUS_COLS_PACK_REQS	:	UBUS_ODAT_RDMA_LOAD	;

			UBUS_COLS_PACK_REQS	:		ubus_rdma_vect_mfsm	<=													UBUS_COLS_PACK_CMND	;

			UBUS_COLS_PACK_CMND	:		ubus_rdma_vect_mfsm	<=	ubus_rdma_pack_crdy	?	UBUS_COLS_PACK_DATA	:	UBUS_COLS_PACK_CMND	;

			UBUS_COLS_PACK_DATA	:		ubus_rdma_vect_mfsm	<=	rdma_cols_pack_last	?	UBUS_ODAT_ROWS_CODA	:
																ubus_rdma_pack_drdy	?	UBUS_COLS_PACK_REQS	:	UBUS_COLS_PACK_DATA	;

			UBUS_ODAT_ROWS_CODA	:		ubus_rdma_vect_mfsm	<=	rdma_vect_rows_last	?	UBUS_ODAT_RDMA_DONE	:			
																dlnk_odat_coda_csen	?	UBUS_ODAT_RDMA_LOAD	:	UBUS_ODAT_ROWS_CODA	;

			UBUS_ODAT_RDMA_DONE	:		ubus_rdma_vect_mfsm	<=	ubus_rdma_vect_enab	?	UBUS_ODAT_RDMA_DONE	:	UBUS_ODAT_RDMA_IDLE	;

			default				:		ubus_rdma_vect_mfsm	<=													UBUS_ODAT_RDMA_IDLE	;
		endcase
	end	
/**********************************************************************************************************/
//--------------UBUS_RDMA_VECT_Misc
	wire		ubus_hits_rdma_idle	=	ubus_rdma_vect_mfsm	==	UBUS_ODAT_RDMA_IDLE	;
	wire		ubus_hits_rdma_load	=	ubus_rdma_vect_mfsm	==	UBUS_ODAT_RDMA_LOAD	;
	wire		ubus_hits_pack_reqs	=	ubus_rdma_vect_mfsm	==	UBUS_COLS_PACK_REQS	;
	wire		ubus_hits_pack_cmnd	=	ubus_rdma_vect_mfsm	==	UBUS_COLS_PACK_CMND	;
	wire		ubus_hits_pack_data	=	ubus_rdma_vect_mfsm	==	UBUS_COLS_PACK_DATA	;
	wire		ubus_hits_rows_coda	=	ubus_rdma_vect_mfsm	==	UBUS_ODAT_ROWS_CODA	;
	
	assign		ubus_rdma_pack_reqs	=	ubus_hits_pack_reqs	;//ubus_hits_pack_cmnd	;
	assign		ubus_rdma_vect_done	=	ubus_rdma_vect_mfsm	==	UBUS_ODAT_RDMA_DONE	;

	reg			[ 4: 0]					vect_meta_rows_indx	;//used for UBUS_ROWS_PACK_LOOP ,Range pack_rows(32)
	reg			[14: 0]					vect_cols_pack_indx	;//used for UBUS_VECT_ROWS_LOOP ,Range meta_cols([19:0]) / pack_cols (128)

//	wire		[ 5: 0]					pack_rows_indx_inc1	;
	wire		[14: 0]					vect_pack_indx_inc1	;
	wire		[ 5: 0]					vect_meta_rows_inc1	;

	wire								rdma_vect_pack_done	;

	assign		vect_meta_rows_inc1	=	vect_meta_rows_indx + 1	;
	assign		vect_pack_indx_inc1	=	vect_cols_pack_indx + 1	;

	assign		rdma_vect_rows_last	=	vect_meta_rows_indx	==	llmb_vect_rows_numb	;
	assign		rdma_cols_pack_last	=&{	ubus_rdma_pack_drdy	,	vect_pack_indx_inc1	==	llmb_vect_pack_numb	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						vect_meta_rows_indx	<=	0	;
	else if(ubus_hits_rdma_idle)		vect_meta_rows_indx	<=	0	;
	else if(ubus_rdma_vect_done)		vect_meta_rows_indx	<=	0	;
	else if(rdma_cols_pack_last)		vect_meta_rows_indx	<=	vect_meta_rows_inc1		;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						vect_cols_pack_indx	<=	0	;
	else if(ubus_hits_rdma_idle)		vect_cols_pack_indx	<=	0	;
	else if(ubus_hits_rdma_load)		vect_cols_pack_indx	<=	0	;
	else if(rdma_cols_pack_last)		vect_cols_pack_indx	<=	0	;
	else if(ubus_rdma_pack_drdy)		vect_cols_pack_indx	<=	vect_pack_indx_inc1	;
/**********************************************************************************************************/
//--------------UBUS_RDMA_VECT_ADDR
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_rdma_pack_addr	<=	0	;
	else if( ubus_hits_rdma_idle)		ubus_rdma_pack_addr	<=	llmb_mast_ddrs_base	;
	else if( ubus_hits_pack_cmnd)		ubus_rdma_pack_addr	<=	ubus_rdma_pack_crdy	?	ubus_rdma_pack_addr + 2	:	ubus_rdma_pack_addr	;

endmodule
