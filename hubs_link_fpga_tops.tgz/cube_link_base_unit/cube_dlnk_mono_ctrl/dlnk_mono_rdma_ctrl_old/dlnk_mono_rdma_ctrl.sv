module	dlnk_mono_rdma_ctrl(
	
	output		[ 7: 0]					dlnk_odat_fram_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat3_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat2_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat1_mbdo	,
	output		[ 7: 0]					dlnk_odat_dat0_mbdo	,
	
	input								dlnk_odat_ddrs_mode	,	
	input								dlnk_odat_ddrs_enab	,
	output								dlnk_odat_ddrs_done	,	
			
	input		[24: 0]					llmb_mast_ddrs_base	,
	input		[19: 0]					llmb_meta_imag_rows	,
	input		[19: 0]					llmb_meta_imag_cols	,
	input		[19: 0]					llmb_edge_imag_rows	,
	input		[19: 0]					llmb_edge_imag_cols	,
		
	input								link_clki			,
	input								link_rstn			,
	
	output								ubus_dlnk_rdma_csen	,
	output		[ 24: 0]				ubus_dlnk_rdma_addr	, // unit = 256bit = 16dot = 1page
	input		[255: 0]				ubus_dlnk_rdma_data	,
	input								ubus_dlnk_rdma_trdy	,
	input								ubus_dlnk_rdma_drdy	,
	
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************/
	wire	[ 5: 0]					ubus_rdma_pack_size	;
	wire	[24: 0]					ubus_rdma_pack_addr	;
	wire	[255:0]					dlnk_rdma_page_data	;
	
	dlnk_rdma_odat_ctrl			u_dlnk_rdma_odat_ctrl(
		.dlnk_odat_fram_mbdo		(dlnk_odat_fram_mbdo	),//output	reg	[ 7: 0]		
		.dlnk_odat_dat3_mbdo		(dlnk_odat_dat3_mbdo	),//output	reg	[ 7: 0]		
		.dlnk_odat_dat2_mbdo		(dlnk_odat_dat2_mbdo	),//output	reg	[ 7: 0]		
		.dlnk_odat_dat1_mbdo		(dlnk_odat_dat1_mbdo	),//output	reg	[ 7: 0]		
		.dlnk_odat_dat0_mbdo		(dlnk_odat_dat0_mbdo	),//output	reg	[ 7: 0]		
		
		.dlnk_odat_ddrs_enab		(dlnk_odat_ddrs_enab	),//input					
		.dlnk_odat_ddrs_done		(dlnk_odat_ddrs_done	),//output	

		.llmb_edge_imag_rows		(llmb_edge_imag_rows	),//input		[ 19: 0]
		.llmb_edge_imag_cols		(llmb_edge_imag_cols[19:4]	),//input		[ 19: 0]
		
		.dlnk_odat_page_reqs		(dlnk_odat_page_reqs	),//output					
		.dlnk_odat_page_data		(dlnk_rdma_page_data	),//input		[255:0 ]	
		.dlnk_odat_page_drdy		(dlnk_odat_page_drdy	),//input					

		.link_clki					(link_clki				),//input					
		.link_rstn					(link_rstn				),//input					

		.ubus_dlnk_txdo_load		(ubus_dlnk_txdo_load	),//output		
		.ubus_dlnk_txdo_coda		(ubus_dlnk_txdo_coda	),//output		

		.ubus_clki					(ubus_clki				),//input					
		.ubus_rstn					(ubus_rstn				));//input					
		
	ubus_rdma_ddrs_ctrl			u_ubus_rdma_ddrs_ctrl(
	
		.dlnk_odat_ddrs_enab		(dlnk_odat_ddrs_enab	),//input				
		.dlnk_odat_page_reqs		(dlnk_odat_page_reqs	),//input			
		.dlnk_odat_page_data		(dlnk_rdma_page_data	),//output		[255:0]	
		.dlnk_odat_page_drdy		(dlnk_odat_page_drdy	),

		.ubus_rdma_ddrs_enab		(ubus_rdma_ddrs_enab	),//input				
		.ubus_rdma_pack_reqs		(ubus_rdma_pack_reqs	),//input				
		.ubus_rdma_pack_size		(ubus_rdma_pack_size	),//input		[15: 0]	
		.ubus_rdma_pack_addr		(ubus_rdma_pack_addr	),//input		[15: 0]	
		.ubus_rdma_pack_drdy		(ubus_rdma_pack_drdy	),//output	reg			
		.ubus_rdma_pack_crdy		(ubus_rdma_pack_crdy	),//output	reg			

		.ddrs_ubus_rdma_csen		(ubus_dlnk_rdma_csen	),//output				
		.ddrs_ubus_rdma_trdy		(ubus_dlnk_rdma_trdy	),//input				
		.ddrs_ubus_rdma_drdy		(ubus_dlnk_rdma_drdy	),//input				
		.ddrs_ubus_rdma_addr		(ubus_dlnk_rdma_addr	),//output	reg	[ 24: 0]
		.ddrs_ubus_rdma_data		(ubus_dlnk_rdma_data	),//input		[255: 0]

		.ubus_clki					(ubus_clki				),//input	
		.ubus_rstn					(ubus_rstn				),//input	
		.link_clki					(link_clki				),//input	
		.link_rstn					(link_rstn				));//input	

	ubus_rdma_meta_ctrl			u_ubus_rdma_meta_ctrl(
		.dlnk_odat_ddrs_enab		(dlnk_odat_ddrs_enab	),//input	
		.dlnk_odat_ddrs_mode		(dlnk_odat_ddrs_mode	),//input	//0:vect 1:mtrx
	
		.ubus_rdma_ddrs_enab		(ubus_rdma_ddrs_enab	),//output	

		.ubus_rdma_pack_reqs		(ubus_rdma_pack_reqs	),//output			
		.ubus_rdma_pack_addr		(ubus_rdma_pack_addr	),//output			
		.ubus_rdma_pack_size		(ubus_rdma_pack_size	),//output		[15: 0]	
		.ubus_rdma_pack_drdy		(ubus_rdma_pack_drdy	),//input				
		.ubus_rdma_pack_crdy		(ubus_rdma_pack_crdy	),//input				

		.dlnk_odat_load_csen		(ubus_dlnk_txdo_load	),	
		.dlnk_odat_coda_csen		(ubus_dlnk_txdo_coda	),	

		.llmb_mast_ddrs_base		(llmb_mast_ddrs_base	),//input		[24: 0]	
		.llmb_meta_imag_rows		(llmb_meta_imag_rows	),//input		[19: 0]	
		.llmb_meta_imag_cols		(llmb_meta_imag_cols	),//input		[19: 0]	
	
		.link_clki					(link_clki				),//input					
		.ubus_clki					(ubus_clki				),//input
		.ubus_rstn					(ubus_rstn				));//input
 
endmodule
