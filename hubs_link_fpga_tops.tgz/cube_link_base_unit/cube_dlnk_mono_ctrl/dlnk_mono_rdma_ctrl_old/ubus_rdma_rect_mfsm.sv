//e.g 32000 cols ,16000 words ,	2000 page	,250 PACK  PACK_NUMB =	COLS_NUMB/2/8/8
//e.g 13824 cols ,6912  words ,	864  page	,108 PACK	
//e.g 8192  cols ,4096  words ,	512  page	,64  PACK	
//e.g 6656  cols ,3328  words ,	416  page	,108 PACK	
//e.g 5120  cols ,2560  words ,	 320 page	, 40 PACK  
//e.g 256   cols ,128   words ,	  16 page	,  2 PACK  

`include	"agile_card_vars.vh"

module	ubus_rdma_rect_mfsm(
	input							ubus_rdma_rect_enab	,
	output							ubus_rdma_rect_done	,

	output							ubus_rdma_pack_reqs	,
	output	reg	[24: 0]				ubus_rdma_pack_addr	,
	input							ubus_rdma_pack_crdy	,
	input							ubus_rdma_pack_drdy	,

	input							dlnk_odat_load_csen	,
	input							dlnk_odat_coda_csen	,
	
	input		[24: 0]				llmb_mast_ddrs_base	,
	input		[15: 0]				llmb_meta_imag_cols	,
	input		[ 4: 0]				llmb_rect_rows_numb	,
	input		[12: 0]				llmb_rect_pack_numb	,
	
	input							ubus_clki			,
	input							ubus_rstn			);
/**********************************************************************************************************/
//--------------UBUS_RDMA_RECT_MFSM
	reg		[ 3: 0]					ubus_rdma_rect_mfsm	;

	parameter	UBUS_ODAT_RDMA_IDLE	=	4'H0	;
	parameter	UBUS_ODAT_LEAD_WAIT	=	4'H1	;
	parameter	UBUS_COLS_PACK_CMND	=	4'H2	;
	parameter	UBUS_COLS_PACK_DATA	=	4'H3	;
	parameter	UBUS_PACK_ROWS_LOOP	=	4'H4	;
	parameter	UBUS_ODAT_MUTE_WAIT	=	4'H5	;
	parameter	UBUS_RECT_PACK_LOOP	=	4'H6	;
	parameter	UBUS_ODAT_RDMA_DONE	=	4'H7	;

	wire							rdma_pack_rows_last	;
	wire							rdma_rect_pack_last	;
	wire							rdma_rect_rows_last	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_rect_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else if(~ubus_rdma_rect_enab)	ubus_rdma_rect_mfsm	<=	UBUS_ODAT_RDMA_IDLE	;
	else begin
		case(ubus_rdma_rect_mfsm)
		
			UBUS_ODAT_RDMA_IDLE	:	ubus_rdma_rect_mfsm	<=													UBUS_ODAT_LEAD_WAIT	;	

			UBUS_ODAT_LEAD_WAIT	:	ubus_rdma_rect_mfsm	<=	dlnk_odat_load_csen	?	UBUS_COLS_PACK_CMND	:	UBUS_ODAT_LEAD_WAIT	;
			
			UBUS_COLS_PACK_CMND	:	ubus_rdma_rect_mfsm	<=	ubus_rdma_pack_crdy	?	UBUS_COLS_PACK_DATA	:	UBUS_COLS_PACK_CMND	;

			UBUS_COLS_PACK_DATA	:	ubus_rdma_rect_mfsm	<=	ubus_rdma_pack_drdy	?	UBUS_PACK_ROWS_LOOP	:	UBUS_COLS_PACK_DATA	;

			UBUS_PACK_ROWS_LOOP	:	ubus_rdma_rect_mfsm	<=	rdma_pack_rows_last	?	UBUS_ODAT_MUTE_WAIT	:	UBUS_COLS_PACK_CMND	;

			UBUS_ODAT_MUTE_WAIT	:	ubus_rdma_rect_mfsm	<=	dlnk_odat_coda_csen	?	UBUS_RECT_PACK_LOOP	:	UBUS_ODAT_MUTE_WAIT	;
			
			UBUS_RECT_PACK_LOOP	:	ubus_rdma_rect_mfsm	<=	rdma_rect_pack_last	?	UBUS_ODAT_RDMA_DONE	:	UBUS_ODAT_LEAD_WAIT	;

			UBUS_ODAT_RDMA_DONE	:	ubus_rdma_rect_mfsm	<=	ubus_rdma_rect_enab	?	UBUS_ODAT_RDMA_DONE	:	UBUS_ODAT_RDMA_IDLE	;

			default				:	ubus_rdma_rect_mfsm	<=													UBUS_ODAT_RDMA_IDLE	;
		endcase
	end	
/**********************************************************************************************************/
//--------------UBUS_RDMA_RECT_Misc
	wire		ubus_hits_rdma_idle	=	ubus_rdma_rect_mfsm	==	UBUS_ODAT_RDMA_IDLE	;
	wire		ubus_hits_odat_lead	=	ubus_rdma_rect_mfsm	==	UBUS_ODAT_LEAD_WAIT	;
	wire		ubus_hits_pack_cmnd	=	ubus_rdma_rect_mfsm	==	UBUS_COLS_PACK_CMND	;
	wire		ubus_hits_pack_data	=	ubus_rdma_rect_mfsm	==	UBUS_COLS_PACK_DATA	;
	wire		ubus_hits_pack_rows	=	ubus_rdma_rect_mfsm	==	UBUS_PACK_ROWS_LOOP	;
	wire		ubus_hits_odat_mute	=	ubus_rdma_rect_mfsm	==	UBUS_ODAT_MUTE_WAIT	;
	wire		ubus_hits_rect_pack	=	ubus_rdma_rect_mfsm	==	UBUS_RECT_PACK_LOOP	;
	wire		ubus_hits_rdma_done	=	ubus_rdma_rect_mfsm	==	UBUS_ODAT_RDMA_DONE	;
	assign		ubus_rdma_rect_done	=	ubus_hits_rdma_done	;	
	assign		ubus_rdma_pack_reqs	=	ubus_hits_pack_cmnd	;

	reg			[ 4: 0]				pack_rows_loop_indx	;//used for UBUS_PACK_ROWS_LOOP ,Range pack_rows(32)
	reg			[12: 0]				rect_pack_loop_indx	;//used for UBUS_RECT_PACK_LOOP ,Range meta_cols([19:0]) / pack_cols (128)

	wire		[ 5: 0]				pack_rows_indx_inc1	;
	wire		[12: 0]				rect_pack_indx_inc1	;

	wire							rdma_pack_rows_next	;
	wire							rdma_pack_rows_done	;
	wire							rdma_rect_pack_done	;

	assign		pack_rows_indx_inc1	=	pack_rows_loop_indx + 1	;
	assign		rect_pack_indx_inc1	=	rect_pack_loop_indx + 1	;

	assign		rdma_pack_rows_last	=	pack_rows_loop_indx	==	llmb_rect_rows_numb	;//pack_rows_indx_inc1	==	llmb_rect_rows_numb	;
	assign		rdma_rect_pack_last	=	rect_pack_indx_inc1	==	llmb_rect_pack_numb	;


	assign		rdma_pack_rows_next	= &{ubus_hits_pack_cmnd	,	ubus_rdma_pack_crdy	};//ubus_hits_pack_rows	;
	assign		rdma_pack_rows_done	=	ubus_hits_pack_rows	;
	assign		rdma_rect_pack_done	=	ubus_hits_rect_pack	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					pack_rows_loop_indx	<=	0	;
	else if(ubus_hits_rdma_idle)	pack_rows_loop_indx	<=	0	;
	else if(ubus_hits_odat_mute)	pack_rows_loop_indx	<=	0	;
	else if(rdma_pack_rows_next)	pack_rows_loop_indx	<=	rdma_pack_rows_last	?	 5'H0	:	pack_rows_indx_inc1	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					rect_pack_loop_indx	<=	0	;
	else if(ubus_hits_rdma_idle)	rect_pack_loop_indx	<=	0	;
	else if(rdma_rect_pack_done)	rect_pack_loop_indx	<=	rdma_rect_pack_last	?	13'H0	:	rect_pack_indx_inc1 ;
/**********************************************************************************************************/
//--------------UBUS_RDMA_RECT_ADDR
	wire	[24: 0]					meta_rect_rows_base	= 	pack_rows_loop_indx 		*	llmb_meta_imag_cols	;
	
	wire	[24: 0]					meta_rows_pack_bias	=	rect_pack_loop_indx *  8	;
	wire	[24: 0]					meta_rows_pack_base	=	meta_rows_pack_bias			+	llmb_mast_ddrs_base	;

	reg		[24: 0]					meta_rect_rows_addr	;
	reg		[24: 0]					meta_rows_pack_addr	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					meta_rect_rows_addr	<=	0	;
	else							meta_rect_rows_addr	<=	meta_rect_rows_base ;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					meta_rows_pack_addr	<=	0	;
	else							meta_rows_pack_addr	<=	meta_rows_pack_base	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)					ubus_rdma_pack_addr	<=	0	;
	else if( ubus_hits_rdma_idle)	ubus_rdma_pack_addr	<=	0	;
	else 							ubus_rdma_pack_addr	<=	meta_rect_rows_addr + meta_rows_pack_addr 	;

endmodule

