
module	tpgm_link_txdo_pmau (
	input								tune_txdo_envt	,		
	input								tune_txdo_load	,	
	input		[8: 0]					tune_txdo_taps	,	
	output 	reg	[8: 0]					tune_txdo_vals	,	

	output								tpgm_fclk_outp	,
	output								tpgm_fclk_outn	,
	output								tpgm_fram_outp	,
	output								tpgm_fram_outn	,
	output								tpgm_dat0_outp	,
	output								tpgm_dat0_outn	,
	output								tpgm_dat1_outp	,
	output								tpgm_dat1_outn	,
	output								tpgm_dat2_outp	,
	output								tpgm_dat2_outn	,
	output								tpgm_dat3_outp	,
	output								tpgm_dat3_outn	,

	input	[ 7: 0]						tpgm_fram_mbdi	,
	input	[ 7: 0]						tpgm_dat0_mbdi	,
	input	[ 7: 0]						tpgm_dat1_mbdi	,
	input	[ 7: 0]						tpgm_dat2_mbdi	,
	input	[ 7: 0]						tpgm_dat3_mbdi	,

	input								dlys_cell_rst	,

	input								link_fclk		,
	input								link_sclk		,
	input								link_strb		,
	input								link_rstn		);
/**********************************************************************************************************/
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_vals	<=	0	;
	else if(tune_txdo_load)				tune_txdo_vals	<=	tune_txdo_taps	;
/**********************************************************************************************************/
	reg		[ 7: 0]						tpgm_fram_shft	;	
	reg		[ 7: 0]						tpgm_dat0_shft	;	
	reg		[ 7: 0]						tpgm_dat1_shft	;	
	reg		[ 7: 0]						tpgm_dat2_shft	;	
	reg		[ 7: 0]						tpgm_dat3_shft	;	

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) begin
		tpgm_fram_shft					<=	0	;
		tpgm_dat0_shft					<=	0	;
		tpgm_dat1_shft					<=	0	;
		tpgm_dat2_shft					<=	0	;
		tpgm_dat3_shft					<=	0	;
	end else if(link_strb)	begin
		tpgm_fram_shft					<=	tpgm_fram_mbdi	;
		tpgm_dat0_shft					<=	tpgm_dat0_mbdi	;
		tpgm_dat1_shft					<=	tpgm_dat1_mbdi	;
		tpgm_dat2_shft					<=	tpgm_dat2_mbdi	;
		tpgm_dat3_shft					<=	tpgm_dat3_mbdi	;
	end else begin
		tpgm_fram_shft					<={	tpgm_fram_shft[5:0]	,2'B00	};
		tpgm_dat0_shft					<={	tpgm_dat0_shft[5:0]	,2'B00	};
		tpgm_dat1_shft					<={	tpgm_dat1_shft[5:0]	,2'B00	};
		tpgm_dat2_shft					<={	tpgm_dat2_shft[5:0]	,2'B00	};
		tpgm_dat3_shft					<={	tpgm_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************/
	wire								tpgm_fram_d0	,	tpgm_fram_d1	;
	wire								tpgm_dat0_d0	,	tpgm_dat0_d1	;
	wire								tpgm_dat1_d0	,	tpgm_dat1_d1	;
	wire								tpgm_dat2_d0	,	tpgm_dat2_d1	;
	wire								tpgm_dat3_d0	,	tpgm_dat3_d1	;

	assign		tpgm_fram_d0	=		tpgm_fram_shft[7]	;//| tune_txdo_shft[7]	;
	assign		tpgm_fram_d1	=		tpgm_fram_shft[6]	;//| tune_txdo_shft[6]	;
	assign		tpgm_dat0_d0	=		tpgm_dat0_shft[7]	;//| tune_txdo_shft[7]	;
	assign		tpgm_dat0_d1	=		tpgm_dat0_shft[6]	;//| tune_txdo_shft[6]	;
	assign		tpgm_dat1_d0	=		tpgm_dat1_shft[7]	;//| tune_txdo_shft[7]	;
	assign		tpgm_dat1_d1	=		tpgm_dat1_shft[6]	;//| tune_txdo_shft[6]	;
	assign		tpgm_dat2_d0	=		tpgm_dat2_shft[7]	;//| tune_txdo_shft[7]	;
	assign		tpgm_dat2_d1	=		tpgm_dat2_shft[6]	;//| tune_txdo_shft[6]	;
	assign		tpgm_dat3_d0	=		tpgm_dat3_shft[7]	;//| tune_txdo_shft[7]	;
	assign		tpgm_dat3_d1	=		tpgm_dat3_shft[6]	;//| tune_txdo_shft[6]	;
/***TUNEIO_DLYS*******************************************************************************************************/
	wire		[ 8: 0]					tune_txdo_vout	;
	wire								tune_txdo_reqs	;

	reg									dlys_rstb_sync	= 1'H1				;
	always@(posedge link_fclk )			dlys_rstb_sync	= dlys_cell_rst		;

	gens_asyn_edge 					gens_load_sync_edge(
		.data_edge						(tune_txdo_reqs	),//output		
		.data_inpp						(tune_txdo_load	),//input		
		.edge_mode						(1'B1			),//input		TRIGGER FALL EDGE
		.clki							(link_fclk		),//input		
		.rstn							(link_rstn		));//input		


  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FCLK (	
		.Q								(tpgm_fclk_txdw		),	// 1-bit output: Data output to IOB
		.D1								(1'b0				),	// 1-bit input: Parallel data input 1
		.D2								(1'b1				),	// 1-bit input: Parallel data input 2
		.C								(link_fclk			),	// 1-bit input: High-speed clock input
		.SR								(1'B0				)); // 1-bit input: Active-High Async Reset

	ODELAYE3 #(
    	.CASCADE						("NONE"				),	// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
    	.DELAY_FORMAT					("TIME"				),	// (COUNT, TIME)
    	.DELAY_TYPE						("VAR_LOAD"			),	// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
    	.DELAY_VALUE					(9'H000				),	// Output delay tap setting
    	.IS_CLK_INVERTED				(1'H0				),	// Optional inversion for CLK
    	.IS_RST_INVERTED				(1'H0				),	// Optional inversion for RST
    	.REFCLK_FREQUENCY				(320.0				),	// IDELAYCTRL clock input frequency in MHz (200.0-800.0).
    	.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
    	.UPDATE_MODE					("ASYNC"			))	// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)
	u_FCLK_ODLY (	
		.DATAOUT						(tpgm_fclk_txdo		),  // 1-bit output: Delayed data from ODATAIN input port
		.ODATAIN						(tpgm_fclk_txdw		),  // 1-bit input: Data input

		.EN_VTC							(tune_txdo_envt		),	// 1-bit input: Keep delay constant over VT
		.LOAD							(tune_txdo_reqs		),//(tune_txdo_load		),	// 1-bit input: Load DELAY_VALUE input
		.CNTVALUEIN						(tune_txdo_taps		),//(tune_txdo_taps		),	// 9-bit input: Counter value input
		
		.CNTVALUEOUT					(tune_txdo_vout		),//tune_txdo_vout		),//(tune_txdo_vals		),	// 9-bit output: Counter value output
		.CASC_IN						(1'B0				),	// 1-bit input: Cascade delay input from slave IDELAY CASCADE_OUT
		.CASC_OUT						(					),	// 1-bit output: Cascade delay output to IDELAY input cascade
		.CASC_RETURN					(1'B0				),	// 1-bit input: Cascade delay returning from slave IDELAY DATAOUT
		.INC							(1'H0				),  // 1-bit input: Increment/Decrement tap delay input
		
		.CE								(1'H0				),  // 1-bit input: Active-High enable increment/decrement input
		.CLK							( link_fclk			),  // 1-bit input: Clock input
		.RST							( dlys_rstb_sync	));//1'H0));	// 1-bit input: Asynchronous Reset to the DELAY_VALUE

	OBUFDS							LVDS_FCLK_OUTP	(
		.I								(tpgm_fclk_txdo		),
		.O								(tpgm_fclk_outp		),
		.OB								(tpgm_fclk_outn		));
/***ODDRE1_FRAM*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FRAM (
		.Q								(tpgm_fram_txdo		),// 1-bit output: Data output to IOB
		.D1								(tpgm_fram_d0		),// 1-bit input: Parallel data input 1
		.D2								(tpgm_fram_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_FRAM_OUTP	(
		.I								(tpgm_fram_txdo		),
		.O								(tpgm_fram_outp		),
		.OB								(tpgm_fram_outn		));
/***ODDRE1_DAT0*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT0 (
		.Q								(tpgm_dat0_txdo		),// 1-bit output: Data output to IOB
		.D1								(tpgm_dat0_d0		),// 1-bit input: Parallel data input 1
		.D2								(tpgm_dat0_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT0_OUTP	(
		.I								(tpgm_dat0_txdo		),
		.O								(tpgm_dat0_outp		),
		.OB								(tpgm_dat0_outn		));
/***ODDRE1_DAT1*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT1 (	
		.Q								(tpgm_dat1_txdo		),// 1-bit output: Data output to IOB
		.D1								(tpgm_dat1_d0		),// 1-bit input: Parallel data input 1
		.D2								(tpgm_dat1_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT1_OUTP	(
		.I								(tpgm_dat1_txdo		),
		.O								(tpgm_dat1_outp		),
		.OB								(tpgm_dat1_outn		));
/***ODDRE1_DAT2*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT2 (	
		.Q								(tpgm_dat2_txdo		),// 1-bit output: Data output to IOB
		.D1								(tpgm_dat2_d0		),// 1-bit input: Parallel data input 1
		.D2								(tpgm_dat2_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT2_OUTP	(
		.I								(tpgm_dat2_txdo		),
		.O								(tpgm_dat2_outp		),
		.OB								(tpgm_dat2_outn		));
/***ODDRE1_DAT3*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT3 (	
		.Q								(tpgm_dat3_txdo		),// 1-bit output: Data output to IOB
		.D1								(tpgm_dat3_d0		),// 1-bit input: Parallel data input 1
		.D2								(tpgm_dat3_d1		),// 1-bit input: Parallel data input 2
		.C								(link_fclk			),// 1-bit input: High-speed clock input
		.SR								(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS							LVDS_DAT3_OUTP	(
		.I								(tpgm_dat3_txdo		),
		.O								(tpgm_dat3_outp		),
		.OB								(tpgm_dat3_outn		));

endmodule

