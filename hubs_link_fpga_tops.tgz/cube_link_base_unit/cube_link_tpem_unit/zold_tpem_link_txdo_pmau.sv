
module	tpem_link_txdo_pmau(
	input								tune_txdo_enab	,		
	input								tune_txdo_envt	,	
	input								tune_txdo_load	,	
	input		[8: 0]					tune_txdo_taps	,	
	output 		[8: 0]					tune_txdo_vals	,	

	output								lvds_fclk_outp	,
	output								lvds_fclk_outn	,
	output								lvds_fram_outp	,
	output								lvds_fram_outn	,
	output								lvds_dat0_outp	,
	output								lvds_dat0_outn	,
	output								lvds_dat1_outp	,
	output								lvds_dat1_outn	,
	output								lvds_dat2_outp	,
	output								lvds_dat2_outn	,
	output								lvds_dat3_outp	,
	output								lvds_dat3_outn	,

	input	[ 7: 0]						lvds_fram_mbdi	,
	input	[ 7: 0]						lvds_dat0_mbdi	,
	input	[ 7: 0]						lvds_dat1_mbdi	,
	input	[ 7: 0]						lvds_dat2_mbdi	,
	input	[ 7: 0]						lvds_dat3_mbdi	,
	input								link_clki		,

	input								link_fclk		,
	input								link_strb		,
	input								link_rstn		);
/**********************************************************************************************************/
	reg		[ 1: 0]						tune_txdo_sync	;
	reg									tune_txdo_mode	;
	reg		[ 7: 0]						tune_txdo_shft	;

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_sync	<=	0	;
	else								tune_txdo_sync	<={	tune_txdo_enab	, tune_txdo_sync[1]	};

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)						tune_txdo_mode	<=	0	;
	else if(link_strb)					tune_txdo_mode	<=	tune_txdo_sync[0]	;

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) 						tune_txdo_shft	<=	0		;
	else if(~tune_txdo_mode)			tune_txdo_shft	<=  0		;
	else if(link_strb)					tune_txdo_shft	<=  8'H9A	;
	else 								tune_txdo_shft	<= {tune_txdo_shft[5:0]	,tune_txdo_shft[7:6]	};
/**********************************************************************************************************/
	reg		[ 7: 0]						lvds_fram_shft	;	
	reg		[ 7: 0]						lvds_dat0_shft	;	
	reg		[ 7: 0]						lvds_dat1_shft	;	
	reg		[ 7: 0]						lvds_dat2_shft	;	
	reg		[ 7: 0]						lvds_dat3_shft	;	

	always@(posedge link_fclk or negedge link_rstn)
	if(!link_rstn) begin
		lvds_fram_shft					<=	0	;
		lvds_dat0_shft					<=	0	;
		lvds_dat1_shft					<=	0	;
		lvds_dat2_shft					<=	0	;
		lvds_dat3_shft					<=	0	;
	end else if(link_strb)	begin
		lvds_fram_shft					<=	lvds_fram_mbdi	;
		lvds_dat0_shft					<=	lvds_dat0_mbdi	;
		lvds_dat1_shft					<=	lvds_dat1_mbdi	;
		lvds_dat2_shft					<=	lvds_dat2_mbdi	;
		lvds_dat3_shft					<=	lvds_dat3_mbdi	;
	end else begin
		lvds_fram_shft					<={	lvds_fram_shft[5:0]	,2'B00	};
		lvds_dat0_shft					<={	lvds_dat0_shft[5:0]	,2'B00	};
		lvds_dat1_shft					<={	lvds_dat1_shft[5:0]	,2'B00	};
		lvds_dat2_shft					<={	lvds_dat2_shft[5:0]	,2'B00	};
		lvds_dat3_shft					<={	lvds_dat3_shft[5:0]	,2'B00	};
	end
/**********************************************************************************************************/
	wire								lvds_fram_d0	;
	wire								lvds_dat0_d0	;
	wire								lvds_dat1_d0	;
	wire								lvds_dat2_d0	;
	wire								lvds_dat3_d0	;

	wire								lvds_fram_d1	;
	wire								lvds_dat0_d1	;
	wire								lvds_dat1_d1	;
	wire								lvds_dat2_d1	;
	wire								lvds_dat3_d1	;

	assign		lvds_fram_d0	=		lvds_fram_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_fram_d1	=		lvds_fram_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat0_d0	=		lvds_dat0_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat0_d1	=		lvds_dat0_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat1_d0	=		lvds_dat1_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat1_d1	=		lvds_dat1_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat2_d0	=		lvds_dat2_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat2_d1	=		lvds_dat2_shft[6]	| tune_txdo_shft[6]	;

	assign		lvds_dat3_d0	=		lvds_dat3_shft[7]	| tune_txdo_shft[7]	;
	assign		lvds_dat3_d1	=		lvds_dat3_shft[6]	| tune_txdo_shft[6]	;
/***ODDRE1_FCLK*******************************************************************************************************/
//		.D1								(fclk_pola_c1		),	// 1-bit input: Parallel data input 1
//		.D2								(fclk_pola_c2		),	// 1-bit input: Parallel data input 2

  	ODDRE1 #(
		.IS_C_INVERTED					(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED					(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED					(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL							(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FCLK (	
		.Q								(lvds_fclk_txdw		),	// 1-bit output: Data output to IOB
		.D1								(1'b0				),	// 1-bit input: Parallel data input 1
		.D2								(1'b1				),	// 1-bit input: Parallel data input 2
		.C								(link_fclk			),	// 1-bit input: High-speed clock input
		.SR								(1'B0				)); // 1-bit input: Active-High Async Reset
/***LVDS_FCLK_OUTP*******************************************************************************************************/
	ODELAYE3 #(
    	.CASCADE						("NONE"				),	// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
    	.DELAY_FORMAT					("TIME"			),	// (COUNT, TIME)
    	.DELAY_TYPE						("VAR_LOAD"			),	// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
    	.DELAY_VALUE					(9'H000				),	// Output delay tap setting
    	.IS_CLK_INVERTED				(1'H0				),	// Optional inversion for CLK
    	.IS_RST_INVERTED				(1'H0				),	// Optional inversion for RST
    	.REFCLK_FREQUENCY				(320.0				),	// IDELAYCTRL clock input frequency in MHz (200.0-800.0).
    	.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
    	.UPDATE_MODE					("ASYNC"			))	// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)
	u_FCLK_ODLY (	
		.DATAOUT						(lvds_fclk_txdo		),  // 1-bit output: Delayed data from ODATAIN input port
		.ODATAIN						(lvds_fclk_txdw		),  // 1-bit input: Data input

		.EN_VTC							(tune_txdo_envt		),	// 1-bit input: Keep delay constant over VT
		.LOAD							(1'B0				),//(tune_txdo_load	),// 1-bit input: Load DELAY_VALUE input
		.CNTVALUEIN						(9'H0				),//(tune_txdo_taps	),//(tune_txdo_taps		),	// 9-bit input: Counter value input
		.CNTVALUEOUT					(tune_txdo_vals		),//(tune_txdo_vals	),// 9-bit output: Counter value output

		.CASC_IN						(1'H0				),	// 1-bit input: Cascade delay input from slave IDELAY CASCADE_OUT
		.CASC_OUT						(					),	// 1-bit output: Cascade delay output to IDELAY input cascade
		.CASC_RETURN					(1'H0				),	// 1-bit input: Cascade delay returning from slave IDELAY DATAOUT

		.CE								(1'H0				),  // 1-bit input: Active-High enable increment/decrement input
		.INC							(1'H0				),  // 1-bit input: Increment/Decrement tap delay input
		.CLK							( link_fclk			),	//(link_fclk			),  // 1-bit input: Clock input
		.RST							(~link_rstn			));	// 1-bit input: Asynchronous Reset to the DELAY_VALUE

	OBUFDS							LVDS_FCLK_OUTP	(
		.I								(lvds_fclk_txdo		),
		.O								(lvds_fclk_outp		),
		.OB								(lvds_fclk_outn		));
/**********************************************************************************************************/
	wire								lvds_fram_txdw	;
	wire								lvds_dat3_txdw	;
	wire								lvds_dat2_txdw	;
	wire								lvds_dat1_txdw	;
	wire								lvds_dat0_txdw	;

	wire								lvds_fram_txdo	;
	wire								lvds_dat3_txdo	;
	wire								lvds_dat2_txdo	;
	wire								lvds_dat1_txdo	;
	wire								lvds_dat0_txdo	;

	wire	[ 0: 4]						txdo_dlys_dsrc	;
	wire	[ 0: 4]						txdo_dlys_dout	;

	assign	txdo_dlys_dsrc[0]	=		lvds_fram_txdw	;
	assign	txdo_dlys_dsrc[1]	=		lvds_dat3_txdw	;
	assign	txdo_dlys_dsrc[2]	=		lvds_dat2_txdw	;
	assign	txdo_dlys_dsrc[3]	=		lvds_dat1_txdw	;
	assign	txdo_dlys_dsrc[4]	=		lvds_dat0_txdw	;
	
	assign	lvds_fram_txdo		=		txdo_dlys_dout[0]	;
	assign	lvds_dat3_txdo		=		txdo_dlys_dout[1]	;
	assign	lvds_dat2_txdo		=		txdo_dlys_dout[2]	;
	assign	lvds_dat1_txdo		=		txdo_dlys_dout[3]	;
	assign	lvds_dat0_txdo		=		txdo_dlys_dout[4]	;
/***LVDS_TXDO_ODLY*******************************************************************************************************/
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_txdo_dlys_ctrl
		ODELAYE3 #(
	    	.CASCADE						("NONE"				),	// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
	    	.DELAY_FORMAT					("TIME"			),	// (COUNT, TIME)
	    	.DELAY_TYPE						("VAR_LOAD"			),	// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
	    	.DELAY_VALUE					(9'H000				),	// Output delay tap setting
	    	.IS_CLK_INVERTED				(1'H0				),	// Optional inversion for CLK
	    	.IS_RST_INVERTED				(1'H0				),	// Optional inversion for RST
	    	.REFCLK_FREQUENCY				(320.0				),	// IDELAYCTRL clock input frequency in MHz (200.0-800.0).
	    	.SIM_DEVICE						("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
	    	.UPDATE_MODE					("ASYNC"			))	// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)
		u_TXDO_ODLY (
			.DATAOUT						(txdo_dlys_dout[i]	),  // 1-bit output: Delayed data from ODATAIN input port
			.ODATAIN						(txdo_dlys_dsrc[i]	),  // 1-bit input: Data input

			.CASC_IN						(1'H0				),	// 1-bit input: Cascade delay input from slave IDELAY CASCADE_OUT
			.CASC_OUT						(					),	// 1-bit output: Cascade delay output to IDELAY input cascade
			.CASC_RETURN					(1'H0				),	// 1-bit input: Cascade delay returning from slave IDELAY DATAOUT

			.EN_VTC							(tune_txdo_envt		),	// 1-bit input: Keep delay constant over VT
			.LOAD							(1'H0				),//(tune_txdo_load		),	// 1-bit input: Load DELAY_VALUE input
			.CNTVALUEIN						(9'H0				),//(tune_txdo_taps		),	// 9-bit input: Counter value input
			.CNTVALUEOUT					(					),//(tune_txdo_vals		),	// 9-bit output: Counter value output

			.CE								(1'H0				),  // 1-bit input: Active-High enable increment/decrement input
			.INC							(1'H0				),  // 1-bit input: Increment/Decrement tap delay input
			.CLK							( link_fclk			),	//(link_fclk			),  // 1-bit input: Clock input
			.RST							(~link_rstn			));	// 1-bit input: Asynchronous Reset to the DELAY_VALUEE
	end
/***LVDS_FRAM_OUTP*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_FRAM (
		.Q							(lvds_fram_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_fram_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_fram_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_FRAM_OUTP	(
		.I							(lvds_fram_txdo		),
		.O							(lvds_fram_outp		),
		.OB							(lvds_fram_outn		));
/***LVDS_DAT0_OUTP*******************************************************************************************************/
  	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT0 (
		.Q							(lvds_dat0_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat0_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat0_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT0_OUTP	(
		.I							(lvds_dat0_txdo		),
		.O							(lvds_dat0_outp		),
		.OB							(lvds_dat0_outn		));
/***LVDS_DAT1_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT1 (
		.Q							(lvds_dat1_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat1_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat1_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT1_OUTP	(
		.I							(lvds_dat1_txdo		),
		.O							(lvds_dat1_outp		),
		.OB							(lvds_dat1_outn		));
/***LVDS_DAT2_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT2 (
		.Q							(lvds_dat2_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat2_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat2_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT2_OUTP	(
		.I							(lvds_dat2_txdo		),
		.O							(lvds_dat2_outp		),
		.OB							(lvds_dat2_outn		));
/***LVDS_DAT3_OUTP*******************************************************************************************************/
 	ODDRE1 #(
		.IS_C_INVERTED				(1'b0				),	// Optional inversion for C
		.IS_D1_INVERTED				(1'b0				),  // Unsupported, do not use
		.IS_D2_INVERTED				(1'b0				),  // Unsupported, do not use
		.SIM_DEVICE					("ULTRASCALE"		), 	// Set the device version for simulation functionality (ULTRASCALE)
		.SRVAL						(1'b0				))	// Initializes the ODDRE1 Flip-Flops to the specified value (1'b0, 1'b1)
	ODDRE1_DAT3 (
		.Q							(lvds_dat3_txdw		),// 1-bit output: Data output to IOB
		.D1							(lvds_dat3_d0		),// 1-bit input: Parallel data input 1
		.D2							(lvds_dat3_d1		),// 1-bit input: Parallel data input 2
		.C							(link_fclk			),// 1-bit input: High-speed clock input
		.SR							(1'B0				));  // 1-bit input: Active-High Async Reset

	OBUFDS						LVDS_DAT3_OUTP	(
		.I							(lvds_dat3_txdo		),
		.O							(lvds_dat3_outp		),
		.OB							(lvds_dat3_outn		));

endmodule
/*

	always@(posedge  link_fclk or negedge link_rstn)
	if(~link_rstn)					tune_txdo_samp	<=	0	;
	else if(lvds_patn_load)			tune_txdo_samp	<={	tune_txdo_enab	,	tune_txdo_samp[2:1]	};

*/
