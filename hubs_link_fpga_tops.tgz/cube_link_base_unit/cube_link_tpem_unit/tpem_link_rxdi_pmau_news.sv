
module	tpem_link_rxdi_pmau(
	input								tune_rxdi_mode	,
	output								tune_rxdi_done	,
	input							    tune_rxdi_enab	,
	input		[ 8: 0]				    tune_rxdi_taps	,
	output		[ 4: 0]				    tune_eyes_stat	,	
	output		[ 4: 0]				    tune_slip_stat	,	
	
	input							    tpem_fclk_inpp	,
	input							    tpem_fclk_inpn	,
	input							    tpem_fram_inpp	,
	input							    tpem_fram_inpn	,
	input							    tpem_dat0_inpp	,
	input							    tpem_dat0_inpn	,
	input							    tpem_dat1_inpp	,
	input							    tpem_dat1_inpn	,
	input							    tpem_dat2_inpp	,
	input							    tpem_dat2_inpn	,
	input							    tpem_dat3_inpp	,
	input							    tpem_dat3_inpn	,

	output								rxdi_fram_lead	,
	output								rxdi_fram_body	,
	output								rxdi_fram_coda	,

	output		[ 7: 0]					rxdi_fram_mbdo	,
	output		[ 7: 0]					rxdi_dat0_mbdo	,
	output		[ 7: 0]					rxdi_dat1_mbdo	,
	output		[ 7: 0]					rxdi_dat2_mbdo	,
	output		[ 7: 0]					rxdi_dat3_mbdo	,

	input								dlys_cell_hrst	,
	input								link_sclk		,
	input								link_rstn		);
/***RXDI_CLKI**********************************************************************************************************/
	wire								tpem_fclk	;
	wire								tpem_sclk	;
	
(* keep="true" *)
	IBUFDS							LVDS_FCLK_PAD	(
		.I              				(tpem_fclk_inpp	),
		.IB             				(tpem_fclk_inpn	),
		.O              				(tpem_fclk_w	));
(* keep="true" *)
	BUFG							LVDS_FCLK_BUFG	(
		.I								(tpem_fclk_w	),
		.O								(tpem_fclk		));	
(* keep="true" *)
    BUFG_DIV #(
        .BUFG_DIVIDE        			(4				),
        .IS_CE_INVERTED     			(1'B0			),
        .IS_CLR_INVERTED    			(1'B0			),
        .IS_I_INVERTED      			(1'B0			)) 
									LVDS_DIV4_BUFG (
        .O   							(tpem_sclk		), 
		.I  		 					(tpem_fclk		),
        .CLR 							(~sys_rst_n		),
        .CE  							(1'b1			));
/***lane_idly_tune*******************************************************************************************************/
	wire		[ 0: 4][ 8: 0]			lane_idly_data	;
	wire		[ 0: 4][ 8: 0]			lane_slip_data	;

	wire		[ 0: 4][ 8: 0]			lane_dlys_vout	;
	wire								lane_dlys_envt	;
	wire								lane_dlys_load	;
	wire		[ 8: 0]					lane_dlys_taps	;
		


	lane_tune_rxdi					u_lane_idly_tune(
		.lane_dlys_envt					(lane_dlys_envt			),//output	reg				
		.lane_dlys_load					(lane_dlys_load			),//output	reg				
		.lane_dlys_taps					(lane_dlys_taps			),//output	reg	[ 8: 0]		
		.lane_dlys_vout					(lane_dlys_vout[0]		),//input		[ 8: 0]		

		.host_tune_done					(tune_rxdi_done		),//output					
		.host_tune_enab					(tune_rxdi_enab		),//input					
		.host_tune_taps					(tune_rxdi_taps		),//input		[ 8: 0]		
		.host_eyes_stat					(tune_eyes_stat		),//input					
		.host_slip_stat					(tune_slip_stat		),//input		[ 8: 0]		
		.host_clki						(link_sclk			),//input					
		.host_rstn						(link_rstn			));//input	
/***lane_tune_mode*******************************************************************************************************/
	wire								tune_mode_enab	;
	gens_sign_fast_slow #(	
		.EXTN ( 2 ))
	
	u_gens_tune_rxdi_sign(	
		.fast_sign 						(tune_rxdi_mode		),//input	
		.fast_clki						(link_sclk			),//input	
		.fast_rstn						(link_rstn			),//input	
	
		.slow_sign						(tune_mode_enab		),//output	
		.slow_clki						(tpem_sclk			),//input	
		.slow_rstn						(link_rstn			));//input	
//------------------------------------------------------------------------------
	wire								tpem_fram_rxdi	;
	wire								tpem_dat0_rxdi	;
	wire								tpem_dat1_rxdi	;
	wire								tpem_dat2_rxdi	;
	wire								tpem_dat3_rxdi	;
	wire		[ 0: 4]					tpem_rxdi_intf	;
	assign	tpem_rxdi_intf	=	{		tpem_fram_rxdi	,
										tpem_dat0_rxdi	,
										tpem_dat1_rxdi	,
										tpem_dat2_rxdi	,
										tpem_dat3_rxdi	};
//--DATYA_BUS_IBUFDS----------------------------------------------------------------------------
	IBUFDS							LVDS_FRAM_PAD	(
		.I                  			(tpem_fram_inpp	),
		.IB                 			(tpem_fram_inpn	),
		.O                  			(tpem_fram_rxdi	));

	IBUFDS							LVDS_DAT0_PAD	(
		.I                  			(tpem_dat0_inpp	),
		.IB                 			(tpem_dat0_inpn	),
		.O                  			(tpem_dat0_rxdi	));

	IBUFDS							LVDS_DAT1_PAD	(
		.I                  			(tpem_dat1_inpp	),
		.IB                 			(tpem_dat1_inpn	),
		.O                  			(tpem_dat1_rxdi	));

	IBUFDS							LVDS_DAT2_PAD	(
		.I                  			(tpem_dat2_inpp	),
		.IB                 			(tpem_dat2_inpn	),
		.O                  			(tpem_dat2_rxdi	));

	IBUFDS							LVDS_DAT3_PAD	(
		.I                  			(tpem_dat3_inpp	),
		.IB                 			(tpem_dat3_inpn	),
		.O                  			(tpem_dat3_rxdi	));

/**********************************************************************************************************/
	wire		[ 0: 4]					tpem_eyes_good	;
	wire		[ 0: 4]					tpem_sddi_lump	;
	wire		[ 0: 4][7 : 0]			tpem_isde_lump	;
	wire		[ 0: 4][7 : 0]			tpem_isde_slip	;
	

	wire		[ 7: 0]					tpem_fram_isde	=	tpem_isde_lump[0]	;
	wire		[ 7: 0]					tpem_dat0_isde	=	tpem_isde_lump[1]	;
	wire		[ 7: 0]					tpem_dat1_isde	=	tpem_isde_lump[2]	;
	wire		[ 7: 0]					tpem_dat2_isde	=	tpem_isde_lump[3]	;
	wire		[ 7: 0]					tpem_dat3_isde	=	tpem_isde_lump[4]	;

	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_bus
	//----------------------------------
		IDELAYE3 #(
	    	.CASCADE					("NONE"			),// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
	    	.DELAY_FORMAT				("TIME"		),// Units of the DELAY_VALUE (COUNT, TIME)
	    	.DELAY_SRC					("IDATAIN"		),// Delay input (DATAIN, IDATAIN)
	    	.DELAY_TYPE					("VAR_LOAD"		),// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
	    	.DELAY_VALUE				( 9'H000		),// Input delay value setting
	    	.IS_CLK_INVERTED			( 1'H0			),// Optional inversion for CLK
	    	.IS_RST_INVERTED			( 1'H0			),// Optional inversion for RST
	    	.REFCLK_FREQUENCY			( 320.0			),// IDELAYCTRL clock input frequency in MHz (200.0-800.0)
	    	.SIM_DEVICE					("ULTRASCALE"	),// Set the device version for simulation functionality (ULTRASCALE)
	    	.UPDATE_MODE				("ASYNC"		))// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)

		u_RXDI_IDLY_CELL (
	    	.DATAOUT					(tpem_sddi_lump[i] 	),	// 1-bit output: Delayed data output
	    	.IDATAIN					(tpem_rxdi_intf[i]	),	// 1-bit input: Data input from the IOBUF

			.EN_VTC						(lane_dlys_envt		),	// 1-bit input: Keep delay constant over VT
	    	.LOAD						(lane_dlys_load		),	// 1-bit input: Load DELAY_VALUE input
	    	.CNTVALUEIN					(lane_dlys_taps		),	// 9-bit input: Counter value input
	    	.CNTVALUEOUT				(lane_dlys_vout[i]	),	// 9-bit output: Counter value output

			.CASC_OUT					(  					),	// 1-bit output: Cascade delay output to ODELAY input cascade
	    	.CASC_IN					(1'B0   			),	// 1-bit input: Cascade delay input from slave ODELAY CASCADE_OUT
	    	.CASC_RETURN				(1'B0   	    	),	// 1-bit input: Cascade delay returning from slave ODELAY DATAOUT
			.DATAIN						(1'B0           	),	// 1-bit input: Data input from the logic
	    	.INC						(1'B0				),	// 1-bit input: Increment / Decrement tap delay input
	    	.CE							(1'B0				),	// 1-bit input: Active-High enable increment/decrement input
	    	.CLK						( link_sclk			),	// 1-bit input: Clock input
	    	.RST						( dlys_cell_hrst	));// 1-bit input: Asynchronous Reset to the DELAY_VALUE
//--------------------------------------
	   	ISERDESE3 #(
	    	.DATA_WIDTH					(8					),// Parallel data width (4,8)
	    	.IS_CLK_B_INVERTED			(1'B0				),// Optional inversion for CLK_B
	    	.IS_CLK_INVERTED			(1'B0				),// Optional inversion for CLK
	    	.IS_RST_INVERTED			(1'B1				),// Optional inversion for RST
	    	.FIFO_ENABLE				("FALSE"			),// Enables the use of the FIFO
	    	.FIFO_SYNC_MODE				("FALSE"			),// Always set to FALSE. TRUE is reserved for later use.
	    	.SIM_DEVICE					("ULTRASCALE"		))// Set the device version for simulation functionality (ULTRASCALE)
	
	   	u_RXDI_IDLY_ISDE (
	    	.FIFO_EMPTY					(					),	// 1-bit output: FIFO empty flag
	    	.INTERNAL_DIVCLK			(					),	// 1-bit output: Internally divided down clock used when FIFO is disabled (do not connect)
	    	.Q							(lane_idly_data[i]	),	// 8-bit registered output
	    	.D							(tpem_sddi_lump[i]	),	// 1-bit input: Serial Data Input
	    	.CLK						(tpem_fclk			),	// 1-bit input: High-speed clock
	    	.CLK_B						(tpem_fclk			),	// 1-bit input: Inversion of High-speed clock CLK
	    	.CLKDIV						(tpem_sclk			),	// 1-bit input: Divided Clock
	    	.FIFO_RD_CLK				(1'B0				),	// 1-bit input: FIFO read clock
	    	.FIFO_RD_EN					(1'B0				),	// 1-bit input: Enables reading the FIFO when asserted
	    	.RST						(1'B0				));	// 1-bit input: Asynchronous Reset
		end
/**********************************************************************************************************************/
	wire	[ 7: 0]						tpem_fram_mbdi	=	lane_slip_data[0];
	wire	[ 7: 0]						tpem_dat3_mbdi	=	lane_slip_data[1];
	wire	[ 7: 0]						tpem_dat1_mbdi	=	lane_slip_data[2];
	wire	[ 7: 0]						tpem_dat1_mbdi	=	lane_slip_data[3];
	wire	[ 7: 0]						tpem_dat0_mbdi	=	lane_slip_data[4];

	reg		[ 7: 0]						tpem_fram_m2di	;

	always@(posedge tpem_sclk or negedge link_rstn)
	if(~link_rstn) 						tpem_fram_m2di	<=	0	;
	else 								tpem_fram_m2di	<=	tpem_fram_mbdi	;
//------------------------------------------------------------------------------
	wire								rxdi_fram_vlid	;
	wire								rxdi_fram_rise	;
	wire								rxdi_fram_fall	;
	wire								rxdi_fram_body	;
	wire	[31: 0]						rxdi_fram_data	;

	assign	rxdi_fram_vlid	=		{	tune_mode_enab	,	tpem_fram_mbdi	}					==	 9'H0FF		;		
	assign	rxdi_fram_body	=  	&	{	rxdi_fram_vlid	, ~	rxdi_fram_rise	};
	assign	rxdi_fram_rise	=  		{	tune_mode_enab	,	tpem_fram_m2di	, 	tpem_fram_mbdi	}	==	17'H000FF	;
	assign	rxdi_fram_fall	=  		{	tune_mode_enab	,	tpem_fram_m2di	, 	tpem_fram_mbdi	}	==	17'H0FF00	;
	assign	rxdi_fram_data	=		{	tpem_dat3_mbdi	,	tpem_dat3_mbdi	,	tpem_dat1_mbdi	,	tpem_dat0_mbdi	};
//------------------------------------------------------------------------------
	reg									tpem_push_csen	;
	reg		[31:0]						tpem_push_data	;
	reg		[31:0]						tpem_push_tags	;
	reg		[15: 0]						tpem_push_addr	;
	
	wire								tpem_push_init	;
	wire								tpem_push_clrs	;
	reg									tpem_pops_done	;
	
	
	assign	tpem_push_init	=			rxdi_fram_rise	;
	
	always@(posedge tpem_sclk or negedge link_rstn)
	if(~link_rstn)	begin
		tpem_push_csen	<=	0	;
		tpem_push_data	<=	0	;
		tpem_push_tags	<=	0	;
	end else 		begin
		tpem_push_csen	<=	rxdi_fram_vlid	;
		tpem_push_data	<=	rxdi_fram_data	;
		tpem_push_tags	<=	rxdi_fram_rise	?	2'H1	:
							rxdi_fram_fall	?	2'H3	:
							rxdi_fram_body	?	2'H2	:	2'H0	;
	end	
		
	
	always@(posedge tpem_sclk or negedge link_rstn)
	if(~link_rstn) 						tpem_push_addr	<=	0	;
	else if(tpem_push_init)				tpem_push_addr	<=	0	;
	else if(tpem_push_csen)				tpem_push_addr	<=	fram_push_addr + 1	;
	else if(tpem_push_clrs)				tpem_push_addr	<=	0	;
/**********************************************************************************************************************/
	wire		[15: 0]					tpem_push_dptr	;

	wire								tpem_pops_reqs	;
	wire		[31: 0]					tpem_pops_data	;
	wire		[ 1: 0]					tpem_pops_tags	;
	
	reg									tpem_pops_csen	;
	reg									tpem_pops_done	;
	reg			[15: 0]					tpem_pops_addr	;
	
	wire								tpem_pops_lead	;
	wire								tpem_pops_body	;
	wire								tpem_pops_coda	;
	wire								tpem_pops_drdy	;
	

	assign	tpem_pops_drdy 	=	&	{	tpem_pops_csen	,	tpem_push_dptr	>	tpem_pops_addr };
	assign	tpem_pops_lead	=		{	tpem_pops_drdy	,	tpem_pops_tags	} 	==	3'B101		;
	assign	tpem_pops_body	=		{	tpem_pops_drdy	,	tpem_pops_tags	} 	==	3'B110		;
	assign	tpem_pops_coda	=		{	tpem_pops_drdy	,	tpem_pops_tags	} 	==	3'B111		;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						tpem_pops_csen	<=	0	;
	else if(tpem_pops_reqs)				tpem_pops_csen	<=	1	;
	else if(tpem_pops_coda)				tpem_pops_csen	<=	0	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						tpem_pops_done	<=	0	;
	else if(tpem_pops_reqs)				tpem_pops_done	<=	0	;
	else if(tpem_pops_coda)				tpem_pops_done	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						tpem_pops_addr	<=	0	;
	else if(tpem_pops_reqs)				tpem_pops_addr	<=	0	;
	else if(tpem_pops_drdy)				tpem_pops_addr	<=	tpem_pops_addr + 1	;
/**********************************************************************************************************************/
	gens_sync_gray #( .MSB (15) )	
									u_rxdi_port_push_dptr(
		.data_asyn						(tpem_push_addr		),
		.scki							(tpem_sclk			),
		.data_sync						(tpem_push_dptr		),
		.clki							(link_sclk			),
		.rstn							(link_rstn			));

	gens_edge_fast_slow	#( .EXTN (5) )	
									u_fram_pops_done_edge(
		.slow_edge						(tpem_push_clrs	),//output	
		.slow_clki						(tpem_sclk		),//input	
		.slow_rstn						(link_rstn		),//input	
		
		.fast_sign  					(tpem_pops_done	),//input	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		));//input	

	gens_edge_slow_fast				u_fram_pops_reqs_edge(
		.fast_edge						(tpem_pops_reqs	),//output	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		),//input	
		.slow_sign  					(tpem_push_csen	),//input	
		.slow_clki						(tpem_sclk		),//input	
		.slow_rstn						(link_rstn		));//input	
	
	trip_port_tags					u_rxdi_port_push_fifo(
		.wport_csen						(tpem_push_csen		),
		.wport_addr						(tpem_push_addr[2:0]),
		.wport_tags						(tpem_push_tags		),
		.wport_data						(tpem_push_data		),
		.wport_rstn						(tpem_push_init		),
		.wport_clki						(tpem_sclk			),

		.rport_addr						(tpem_pops_addr[2:0]),
		.rport_tags						(tpem_pops_tags		),
		.rport_data						(tpem_pops_data		),
		.rport_clki						(link_sclk			));
/**********************************************************************************************************************/
	assign	rxdi_fram_lead	=			tpem_pops_drdy	?	tpem_pops_lead			:	0	;
	assign	rxdi_fram_body	=			tpem_pops_drdy	?	tpem_pops_body 			:	0	;
	assign	rxdi_fram_coda	=			tpem_pops_drdy	?	tpem_pops_coda			:	0	;

	assign	rxdi_fram_mbdo	=		{8{	tpem_pops_lead	|	tpem_pops_body	}}		;
	assign	rxdi_dat3_mbdo	=			tpem_pops_drdy	?	tpem_pops_data[31:24]	:	0	;
	assign	rxdi_dat2_mbdo	=			tpem_pops_drdy	?	tpem_pops_data[23:16]	:	0	;
	assign	rxdi_dat1_mbdo	=			tpem_pops_drdy	?	tpem_pops_data[15: 8]	:	0	;
	assign	rxdi_dat0_mbdo	=			tpem_pops_drdy	?	tpem_pops_data[ 7: 0]	:	0	;

	
endmodule

