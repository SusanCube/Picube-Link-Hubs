/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	tpem_link_misc_ctrl(
	input							tpgs_link_scut_enab	,
	output							tpem_link_port_idle	,
	
	output	[ 7: 0]					tpem_clnk_fram_mbdo	,
	output	[ 7: 0]					tpem_clnk_dat0_mbdo	,
	output	[ 7: 0]					tpem_clnk_dat1_mbdo	,
	output	[ 7: 0]					tpem_clnk_dat2_mbdo	,
	output	[ 7: 0]					tpem_clnk_dat3_mbdo	,
	
	output							tpem_scfg_prog_outp	,
	output							tpem_scfg_data_outp	,
	output							tpem_scfg_cclk_outp	,
	input							tpem_scfg_init_inpp	,
	input							tpem_scfg_done_inpp	,

	output							tpem_link_trim_done	,
	output							tpem_link_icfg_done	,
	output							tpem_link_ocfg_done	,
	output							tpem_link_nnex_done	,
	output							tpem_link_ivct_done	,
	output							tpem_link_ovct_done	,
	output							tpem_link_imtx_done	,
	output							tpem_link_omtx_done	,
	output							tpem_link_aset_done	,
	output							tpem_link_dnld_done	,
	output							tpem_link_boot_done	,
	output							tpes_scfg_aset_done	,
	output							tpes_scfg_dnld_done	,
	output							tpes_scfg_boot_done	,
	
	input							tpem_link_trim_reqs	,
	input							tpem_link_icfg_reqs	,
	input							tpem_link_ocfg_reqs	,
	input							tpem_link_nnex_reqs	,
	input							tpem_link_ivct_reqs	,
	input							tpem_link_ovct_reqs	,
	input							tpem_link_imtx_reqs	,
	input							tpem_link_omtx_reqs	,
	input							tpem_link_aset_reqs	,
	input							tpem_link_dnld_reqs	,
	input							tpem_link_boot_reqs	,
	input							tpes_scfg_aset_reqs	,
	input							tpes_scfg_dnld_reqs	,
	input							tpes_scfg_boot_reqs	,

	output							tpem_idat_wdma_enab	,
	output							tpem_idat_wdma_mode	,
	input							tpem_idat_wdma_done	,
	
	output							tpem_odat_rdma_enab	,
	output							tpem_odat_rdma_mode	,
	input							tpem_odat_rdma_done	,

	output	[ 3: 0]					tpem_link_cmnd_indx	,
	input	[31: 0]					tpem_link_cmnd_data	,

	output	[ 3: 0]					tpem_xdat_cmnd_indx	,
	input	[31: 0]					tpem_xdat_cmnd_data	,

	output	[ 3: 0]					tpem_scfg_cmnd_indx	,
	input	[31: 0]					tpem_scfg_cmnd_data	,

	input							tpem_link_acks_coda	,
	input							tpem_link_resp_coda	,
		
	input							tpem_clki			,
	input							tpem_rstn			);
/**********************************************************************/
	wire							tpem_link_cfig_idle	;
	wire							tpem_link_scfg_idle	;
	wire							tpem_link_xdat_idle	;

	wire	[ 7: 0]					tpem_cfig_fram_mbdo	;
	wire	[ 7: 0]					tpem_cfig_dat0_mbdo	;
	wire	[ 7: 0]					tpem_cfig_dat1_mbdo	;
	wire	[ 7: 0]					tpem_cfig_dat2_mbdo	;
	wire	[ 7: 0]					tpem_cfig_dat3_mbdo	;

	wire	[ 7: 0]					tpem_xdat_fram_mbdo	;
	wire	[ 7: 0]					tpem_xdat_dat0_mbdo	;
	wire	[ 7: 0]					tpem_xdat_dat1_mbdo	;
	wire	[ 7: 0]					tpem_xdat_dat2_mbdo	;
	wire	[ 7: 0]					tpem_xdat_dat3_mbdo	;
	
	assign	tpem_link_port_idle	= &{tpem_link_cfig_idle	,	tpem_link_scfg_idle	,	tpem_link_xdat_idle};
									
	assign	tpem_clnk_fram_mbdo	= 	tpem_cfig_fram_mbdo	|	tpem_xdat_fram_mbdo	;
	assign	tpem_clnk_dat0_mbdo	= 	tpem_cfig_dat0_mbdo	|	tpem_xdat_dat0_mbdo	;
	assign	tpem_clnk_dat1_mbdo	= 	tpem_cfig_dat1_mbdo	|	tpem_xdat_dat1_mbdo	;
	assign	tpem_clnk_dat2_mbdo	= 	tpem_cfig_dat2_mbdo	|	tpem_xdat_dat2_mbdo	;
	assign	tpem_clnk_dat3_mbdo	= 	tpem_cfig_dat3_mbdo	|	tpem_xdat_dat3_mbdo	;
	
/**********************************************************************/
	cube_link_scfg_misc				u_tpem_scfg_cmnd_ctrl(
		.cube_scfg_misc_idle			(tpem_link_scfg_idle	),//output				
		.cube_scfg_aset_done			(tpes_scfg_aset_done	),//output				
		.cube_scfg_dnld_done			(tpes_scfg_dnld_done	),//output				
		.cube_scfg_boot_done			(tpes_scfg_boot_done	),//output		

		.cube_scfg_aset_reqs			(tpes_scfg_aset_reqs	),//input				
		.cube_scfg_dnld_reqs			(tpes_scfg_dnld_reqs	),//input				
		.cube_scfg_boot_reqs			(tpes_scfg_boot_reqs	),//input	

		.cube_scfg_prog_sbdo			(tpem_scfg_prog_outp	),//output	reg			
		.cube_scfg_data_sbdo			(tpem_scfg_data_outp	),//output	reg			
		.cube_scfg_cclk_sbdo			(tpem_scfg_cclk_outp	),//output	reg			
		.cube_scfg_init_sbdi			(tpem_scfg_init_inpp	),//input				
		.cube_scfg_done_sbdi			(tpem_scfg_done_inpp	),//input		

		.cube_scfg_cmnd_indx			(tpem_scfg_cmnd_indx	),//output		[ 3: 0]	
		.cube_scfg_cmnd_data			(tpem_scfg_cmnd_data	),//input		[31: 0]	

		.link_clki						(tpem_clki				),//input		
		.link_rstn						(tpem_rstn				));	//input		
/**********************************************************************/
	cube_link_cfig_misc	#( .LINK_MODE	("TPEM" )	)	
									u_tpem_cfig_cmnd_ctrl(
		.cube_link_cfig_idle			(tpem_link_cfig_idle	),//output	

		.cube_link_trim_done			(tpem_link_trim_done	),//output	
		.cube_link_icfg_done			(tpem_link_icfg_done	),//output	
		.cube_link_ocfg_done			(tpem_link_ocfg_done	),//output	
		.cube_link_nnex_done			(tpem_link_nnex_done	),//output	
		.cube_link_aset_done			(tpem_link_aset_done	),//output	
		.cube_link_dnld_done			(tpem_link_dnld_done	),//output	
		.cube_link_boot_done			(tpem_link_boot_done	),//output	
		.cube_link_rivt_done			(						),//output	
		.cube_link_rovt_done			(						),//output	
		.cube_link_rimt_done			(						),//output	
		.cube_link_romt_done			(						),//output	

		.cube_link_trim_reqs			(tpem_link_trim_reqs	),//input
		.cube_link_icfg_reqs			(tpem_link_icfg_reqs	),//input
		.cube_link_ocfg_reqs			(tpem_link_ocfg_reqs	),//input
		.cube_link_nnex_reqs			(tpem_link_nnex_reqs	),//input
		.cube_link_aset_reqs			(tpem_link_aset_reqs	),//input
		.cube_link_dnld_reqs			(tpem_link_dnld_reqs	),//input
		.cube_link_boot_reqs			(tpem_link_boot_reqs	),//input
		.cube_link_rivt_reqs			(	1'B0				),//input
		.cube_link_rovt_reqs			(	1'B0				),//input
		.cube_link_rimt_reqs			(	1'B0				),//input
		.cube_link_romt_reqs			(	1'B0				),//input

		.cube_clnk_fram_mbdo			(tpem_cfig_fram_mbdo	),//output	reg				
		.cube_clnk_dat0_mbdo			(tpem_cfig_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo			(tpem_cfig_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo			(tpem_cfig_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat3_mbdo			(tpem_cfig_dat3_mbdo	),//output	reg		[ 7: 0]	

		.cube_link_cmnd_indx			(tpem_link_cmnd_indx	),//output			[ 3: 0]
		.cube_link_cmnd_data			(tpem_link_cmnd_data	),//input			[31: 0]

		.cube_link_acks_coda			(tpem_link_acks_coda	),
		.cube_link_resp_coda			(	1'B0				),//input


		.link_clki						(tpem_clki				),//input				
		.link_rstn						(tpem_rstn				));//input				
/**********************************************************************/
	cube_link_xdat_misc	#( .LINK_MODE	("TPEM" )	)
									u_tpem_xdat_cmnd_ctrl(
		.cube_link_xdat_idle			(tpem_link_xdat_idle	),//output					
		.cube_link_ivct_done			(tpem_link_ivct_done	),//output					
		.cube_link_ovct_done			(tpem_link_ovct_done	),//output					
		.cube_link_imtx_done			(tpem_link_imtx_done	),//output					
		.cube_link_omtx_done			(tpem_link_omtx_done	),//output					

		.cube_link_xdat_scut			(tpgs_link_scut_enab	),
		.cube_link_ivct_reqs			(tpem_link_ivct_reqs	),//input					
		.cube_link_ovct_reqs			(tpem_link_ovct_reqs	),//input					
		.cube_link_imtx_reqs			(tpem_link_imtx_reqs	),//input					
		.cube_link_omtx_reqs			(tpem_link_omtx_reqs	),//input					

		.cube_clnk_fram_mbdo			(tpem_xdat_fram_mbdo	),//output	reg				
		.cube_clnk_dat0_mbdo			(tpem_xdat_dat0_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat1_mbdo			(tpem_xdat_dat1_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat2_mbdo			(tpem_xdat_dat2_mbdo	),//output	reg		[ 7: 0]	
		.cube_clnk_dat3_mbdo			(tpem_xdat_dat3_mbdo	),//output	reg		[ 7: 0]	

		.link_odat_rdma_enab			(tpem_odat_rdma_enab	),//output	reg				
		.link_odat_rdma_mode			(tpem_odat_rdma_mode	),//output			
		.link_odat_rdma_done			(tpem_odat_rdma_done	),//input			

		.link_idat_wdma_enab			(tpem_idat_wdma_enab	),//output	reg				
		.link_idat_wdma_mode			(tpem_idat_wdma_mode	),//output					
		.link_idat_wdma_done			(tpem_idat_wdma_done	),//output					

		.cube_link_cmnd_indx			(tpem_xdat_cmnd_indx	),//output	reg		[ 3: 0]	
		.cube_link_cmnd_data			(tpem_xdat_cmnd_data	),//input			[31: 0]

		.cube_link_acks_coda			(tpem_link_acks_coda	),//input					
		.cube_link_resp_coda			(tpem_link_resp_coda	),//input			

		.link_clki						(tpem_clki				),//input				
		.link_rstn						(tpem_rstn				));//input				
/**********************************************************************/
endmodule
/**********************************************************************/
 