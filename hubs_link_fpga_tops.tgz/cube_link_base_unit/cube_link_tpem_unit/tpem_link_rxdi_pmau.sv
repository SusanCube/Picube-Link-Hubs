
module	tpem_link_rxdi_pmau(
	input							    tune_rxdi_enab	,
	input							    tune_rxdi_envt	,
	input							    tune_rxdi_load	,
	input		[ 8: 0]				    tune_rxdi_taps	,
	output	reg	[ 8: 0]				    tune_rxdi_vals	,
	output		[ 4: 0]				    tune_rxdi_good	,	
	
	input							    lvds_fclk_inpp	,
	input							    lvds_fclk_inpn	,
	input							    lvds_fram_inpp	,
	input							    lvds_fram_inpn	,
	input							    lvds_dat0_inpp	,
	input							    lvds_dat0_inpn	,
	input							    lvds_dat1_inpp	,
	input							    lvds_dat1_inpn	,
	input							    lvds_dat2_inpp	,
	input							    lvds_dat2_inpn	,
	input							    lvds_dat3_inpp	,
	input							    lvds_dat3_inpn	,

	output								rxdi_fram_lead	,
	output								rxdi_fram_body	,
	output								rxdi_fram_coda	,
	output		[ 7: 0]					rxdi_dat0_mbdo	,
	output		[ 7: 0]					rxdi_dat1_mbdo	,
	output		[ 7: 0]					rxdi_dat2_mbdo	,
	output		[ 7: 0]					rxdi_dat3_mbdo	,

	input								dlys_cell_rst	,
	input								link_fclk		,
	input								link_clki		,
	input								link_rstn		);
/**********************************************************************************************************/
	IBUFDS							LVDS_FCLK_PAD	(
		.I              				(lvds_fclk_inpp	),
		.IB             				(lvds_fclk_inpn	),
		.O              				(lvds_fclk_w	));
(* keep="true" *)
	BUFG							LVDS_FCLK_BUFG	(
		.I								(lvds_fclk_w	),
		.O								(lvds_fclk		));	

	wire								lvds_fckp		;
	wire								lvds_fckn		;

	assign	lvds_fckp	=				lvds_fclk		;
	assign	lvds_fckn	= ~				lvds_fclk		;
/**********************************************************************************************************/
	wire								lvds_fram_q0	;
	wire								lvds_dat0_q0	;
	wire								lvds_dat1_q0	;
	wire								lvds_dat2_q0	;
	wire								lvds_dat3_q0	;

	wire								lvds_fram_q1	;
	wire								lvds_dat0_q1	;
	wire								lvds_dat1_q1	;
	wire								lvds_dat2_q1	;
	wire								lvds_dat3_q1	;

	wire	[ 1: 0]						lvds_fram_iddr	= {	lvds_fram_q0 , lvds_fram_q1	};
	wire	[ 1: 0]						lvds_dat0_iddr	= {	lvds_dat0_q0 , lvds_dat0_q1	};
	wire	[ 1: 0]						lvds_dat1_iddr	= {	lvds_dat1_q0 , lvds_dat1_q1	};
	wire	[ 1: 0]						lvds_dat2_iddr	= {	lvds_dat2_q0 , lvds_dat2_q1	};
	wire	[ 1: 0]						lvds_dat3_iddr	= {	lvds_dat3_q0 , lvds_dat3_q1	};
//----------------------------------------------------------------------------------------------------------	
	wire								lvds_fram_rxdi	;	
	wire								lvds_dat0_rxdi	;	
	wire								lvds_dat1_rxdi	;	
	wire								lvds_dat2_rxdi	;	
	wire								lvds_dat3_rxdi	;	

	wire								lvds_fram_rxdd	;	
	wire								lvds_dat0_rxdd	;	
	wire								lvds_dat1_rxdd	;	
	wire								lvds_dat2_rxdd	;	
	wire								lvds_dat3_rxdd	;	

	wire	[ 0: 4]						idly_dlys_dsrc	;
	wire	[ 0: 4]						idly_dlys_dout	;

	assign	idly_dlys_dsrc[0]	=		lvds_fram_rxdi		;
	assign	idly_dlys_dsrc[1]	=		lvds_dat3_rxdi		;
	assign	idly_dlys_dsrc[2]	=		lvds_dat2_rxdi		;
	assign	idly_dlys_dsrc[3]	=		lvds_dat1_rxdi		;
	assign	idly_dlys_dsrc[4]	=		lvds_dat0_rxdi		;

	assign	lvds_fram_rxdd		=		idly_dlys_dout[0]	;
	assign	lvds_dat3_rxdd		=		idly_dlys_dout[1]	;
	assign	lvds_dat2_rxdd		=		idly_dlys_dout[2]	;
	assign	lvds_dat1_rxdd		=		idly_dlys_dout[3]	;
	assign	lvds_dat0_rxdd		=		idly_dlys_dout[4]	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						tune_rxdi_vals		<=	0	;
	else if(tune_rxdi_load)				tune_rxdi_vals		<=	tune_rxdi_taps	;

//DELAY IOB-------------------------------------------------------------------------------------------------
	wire	[ 0: 4][ 8: 0]				tune_rxdi_vout	;
	wire								tune_rxdi_reqs	;

	reg									dlys_rstb_sync	= 1'H1				;
	always@(posedge link_fclk )			dlys_rstb_sync	= dlys_cell_rst		;

	gens_asyn_edge 					gens_load_sync_edge(
		.data_edge						(tune_rxdi_reqs	),//output		
		.data_inpp						(tune_rxdi_load	),//input		
		.edge_mode						(1'B1			),//input		TRIGGER FALL EDGE
		.clki							(link_fclk		),//input		
		.rstn							(link_rstn		));//input		
		
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_bus
		IDELAYE3 #(
	    	.CASCADE					("NONE"			),// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
	    	.DELAY_FORMAT				("TIME"		),// Units of the DELAY_VALUE (COUNT, TIME)
	    	.DELAY_SRC					("IDATAIN"		),// Delay input (DATAIN, IDATAIN)
	    	.DELAY_TYPE					("VAR_LOAD"		),// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
	    	.DELAY_VALUE				( 9'H100		),// Input delay value setting
	    	.IS_CLK_INVERTED			( 1'H0			),// Optional inversion for CLK
	    	.IS_RST_INVERTED			( 1'H0			),// Optional inversion for RST
	    	.REFCLK_FREQUENCY			( 320.0			),// IDELAYCTRL clock input frequency in MHz (200.0-800.0)
	    	.SIM_DEVICE					("ULTRASCALE"	),// Set the device version for simulation functionality (ULTRASCALE)
	    	.UPDATE_MODE				("ASYNC"		))// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)

		u_RXDI_IDLY_CELL (
	    	.DATAOUT					(idly_dlys_dout[i] 	),	// 1-bit output: Delayed data output
	    	.IDATAIN					(idly_dlys_dsrc[i]	),	// 1-bit input: Data input from the IOBUF

			.EN_VTC						(tune_rxdi_envt		),	// 1-bit input: Keep delay constant over VT
	    	.LOAD						(tune_rxdi_reqs		),	// 1-bit input: Load DELAY_VALUE input
	    	.CNTVALUEIN					(tune_rxdi_taps		),	// 9-bit input: Counter value input
	    	.CNTVALUEOUT				(tune_rxdi_vout[i]	),	// 9-bit output: Counter value output

			.CASC_OUT					(  					),	// 1-bit output: Cascade delay output to ODELAY input cascade
	    	.CASC_IN					(1'b0   			),	// 1-bit input: Cascade delay input from slave ODELAY CASCADE_OUT
	    	.CASC_RETURN				(1'b0   	    	),	// 1-bit input: Cascade delay returning from slave ODELAY DATAOUT
			.DATAIN						(1'b0           	),	// 1-bit input: Data input from the logic
	    	.INC						(1'b0				),	// 1-bit input: Increment / Decrement tap delay input

	    	.CE							(1'b0				),	// 1-bit input: Active-High enable increment/decrement input
	    	.CLK						( link_fclk			),	// 1-bit input: Clock input
	    	.RST						( dlys_rstb_sync	));// 1-bit input: Asynchronous Reset to the DELAY_VALUE
	end
//FRAME PAD-------------------------------------------------------------------------------------------------	
	IBUFDS							LVDS_FRAM_PAD	(
		.I                  			(lvds_fram_inpp	),
		.IB                 			(lvds_fram_inpn	),
		.O                  			(lvds_fram_rxdi	));

 	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_FRAM_IN	(	
		.C								(lvds_fckp		), // 1-bit input: High-speed clock
		.CB								(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(lvds_fram_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(lvds_fram_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(lvds_fram_q1	));// 1-bit output: Registered parallel output 2
//DATA0 PAD-------------------------------------------------------------------------------------------------	
	IBUFDS							LVDS_DAT0_PAD	(
		.I                  			(lvds_dat0_inpp	),
		.IB                 			(lvds_dat0_inpn	),
		.O                  			(lvds_dat0_rxdi	));

 	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT0_IN	(	
		.C								(lvds_fckp		), // 1-bit input: High-speed clock
		.CB								(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(lvds_dat0_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(lvds_dat0_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(lvds_dat0_q1	));// 1-bit output: Registered parallel output 2
//DATA1 PAD-------------------------------------------------------------------------------------------------	
	IBUFDS							LVDS_DAT1_PAD	(
		.I                  			(lvds_dat1_inpp	),
		.IB                 			(lvds_dat1_inpn	),
		.O                  			(lvds_dat1_rxdi	));
	
	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT1_IN	(	
		.C								(lvds_fckp		), // 1-bit input: High-speed clock
		.CB								(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(lvds_dat1_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(lvds_dat1_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(lvds_dat1_q1	));// 1-bit output: Registered parallel output 2
//DATA2 PAD-------------------------------------------------------------------------------------------------	
	IBUFDS							LVDS_DAT2_PAD	(
		.I                  			(lvds_dat2_inpp	),
		.IB                 			(lvds_dat2_inpn	),
		.O                  			(lvds_dat2_rxdi	));
	
	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT2_IN	(	
		.C								(lvds_fckp		), // 1-bit input: High-speed clock
		.CB								(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(lvds_dat2_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(lvds_dat2_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(lvds_dat2_q1	));// 1-bit output: Registered parallel output 2
//DATA3 PAD-------------------------------------------------------------------------------------------------	
	IBUFDS							LVDS_DAT3_PAD	(
		.I                  			(lvds_dat3_inpp	),
		.IB                 			(lvds_dat3_inpn	),
		.O                  			(lvds_dat3_rxdi	));

	IDDRE1 #(	
    	.DDR_CLK_EDGE					("SAME_EDGE_PIPELINED"), // IDDRE1 mode (OPPOSITE_EDGE, SAME_EDGE, SAME_EDGE_PIPELINED)
    	.IS_CB_INVERTED					(1'b0			), // Optional inversion for CB
    	.IS_C_INVERTED					(1'b0			)) // Optional inversion for C
    IDDRE1_DAT3_IN	(	
		.C								(lvds_fckp		), // 1-bit input: High-speed clock
		.CB								(lvds_fckn		), // 1-bit input: Inversion of High-speed clock C
		.R								(1'B0			), // 1-bit input: Active-High Async Reset
  		.D								(lvds_dat3_rxdd	), // 1-bit input: Serial Data Input
		.Q1								(lvds_dat3_q0	), // 1-bit output: Registered parallel output 1
		.Q2								(lvds_dat3_q1	));// 1-bit output: Registered parallel output 2
/**********************************************************************************************************/
	reg		[ 1: 0]						lvds_fram_m2bo	;
	reg		[ 7: 0]						lvds_fram_mbdi	;
	reg		[ 7: 0]						lvds_dat0_mbdi	;
	reg		[ 7: 0]						lvds_dat1_mbdi	;
	reg		[ 7: 0]						lvds_dat2_mbdi	;
	reg		[ 7: 0]						lvds_dat3_mbdi	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn) 						lvds_fram_m2bo	<=	0	;
	else 								lvds_fram_m2bo	<=	lvds_fram_iddr	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn) begin
		lvds_fram_mbdi	<=				0	;
		lvds_dat0_mbdi	<=				0	;
		lvds_dat1_mbdi	<=				0	;
		lvds_dat2_mbdi	<=				0	;
		lvds_dat3_mbdi	<=				0	;
	end else begin
		lvds_fram_mbdi	<=			{	lvds_fram_mbdi[5:0]	,	lvds_fram_iddr	};
		lvds_dat0_mbdi	<=			{	lvds_dat0_mbdi[5:0]	,	lvds_dat0_iddr	};
		lvds_dat1_mbdi	<=			{	lvds_dat1_mbdi[5:0]	,	lvds_dat1_iddr	};
		lvds_dat2_mbdi	<=			{	lvds_dat2_mbdi[5:0]	,	lvds_dat2_iddr	};
		lvds_dat3_mbdi	<=			{	lvds_dat3_mbdi[5:0]	,	lvds_dat3_iddr	};
	end

	reg		[ 2: 0]						rxdi_tune_samp	;

	wire								rxdi_tune_reqs	;
	wire								rxdi_tune_enab	;

	assign	rxdi_tune_reqs	=			rxdi_tune_samp[1:0]	==	2'B10	;
	assign	rxdi_tune_enab	=			rxdi_tune_samp[1:0]	==	2'B11	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn) 						rxdi_tune_samp	<=	0	;
	else 								rxdi_tune_samp	<= {tune_rxdi_enab ,rxdi_tune_samp[2:1] }	;
//----------------------------------------------------------------------------------------------------------------------
	idly_patn_ctrl					u_idly_patn_ctrl(
		.idly_patn_reqs					(rxdi_tune_reqs	),//input			
		.idly_patn_enab					(rxdi_tune_enab	),//input			
		.idly_patn_good					(tune_rxdi_good	),//output	[4:0]		

		.lvds_fram_mbdi 				(lvds_fram_mbdi ),//input	[7:0]	
		.lvds_dat0_mbdi 				(lvds_dat0_mbdi ),//input	[7:0]	
		.lvds_dat1_mbdi 				(lvds_dat1_mbdi ),//input	[7:0]	
		.lvds_dat2_mbdi 				(lvds_dat2_mbdi ),//input	[7:0]	
		.lvds_dat3_mbdi 				(lvds_dat3_mbdi ),//input	[7:0]	

		.lvds_fclk						(lvds_fckp		),//input			
		.link_clki						(link_clki		),//input			
		.link_rstn						(link_rstn		));//input			
//----------------------------------------------------------------------------------------------------------------------
	reg									lvds_fram_rise	;
	reg									lvds_fram_fall	;
	reg									lvds_fram_csen	;

	wire	lvds_fram_pose	=  		{	rxdi_tune_enab	,	lvds_fram_iddr , lvds_fram_m2bo	}	==	5'HC	;
	wire	lvds_fram_nege	=  		{	rxdi_tune_enab	,	lvds_fram_iddr , lvds_fram_m2bo	}	==	5'H3	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						lvds_fram_rise	<=	0	;
	else								lvds_fram_rise	<=	lvds_fram_pose	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						lvds_fram_fall	<=	0	;
	else								lvds_fram_fall	<=	lvds_fram_nege	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						lvds_fram_csen	<=	0	;
	else if(lvds_fram_rise)				lvds_fram_csen	<=	1	;
	else if(lvds_fram_fall)				lvds_fram_csen	<=	0	;
//----------------------------------------------------------------------
	reg		[ 3: 0]						lvds_fram_shft	= 4'H2	;
	wire								lvds_fram_wrcs		;	
	
	assign	lvds_fram_wrcs	=			lvds_fram_shft[3]	;

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn) 						lvds_fram_shft	<=	4'H2	;
	else if( lvds_fram_rise)			lvds_fram_shft	<=	4'H2	;
	else if( lvds_fram_csen)			lvds_fram_shft	<={ lvds_fram_shft[2:0] , lvds_fram_shft[3]};
	else 								lvds_fram_shft	<=	4'H0	;
//----------------------------------------------------------------------
	reg									lvds_fram_lead	;
	reg									lvds_fram_coda	;

	wire	fram_rxdi_coda	= 			lvds_fram_coda	;
	wire	fram_rxdi_lead	= &{		lvds_fram_lead	,	lvds_fram_wrcs	};
	wire	fram_rxdi_body	= &{	  ~	lvds_fram_lead	,	lvds_fram_wrcs	};
	wire	fram_push_csen	= |{		fram_rxdi_lead	,	fram_rxdi_body	,	fram_rxdi_coda 	};

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						lvds_fram_lead	<=	0	;
	else if( lvds_fram_rise)			lvds_fram_lead	<=	1	;
	else if( lvds_fram_wrcs)			lvds_fram_lead	<=	0	;	

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						lvds_fram_coda	<=	0	;
	else								lvds_fram_coda	<=	lvds_fram_fall	;
	

	wire	[ 1: 0]						fram_push_tags	;
	wire	[31: 0]						fram_push_data	;

	
	assign	fram_push_tags	=			fram_rxdi_lead	?	2'H1	:
										fram_rxdi_coda	?	2'H3	:
										fram_rxdi_body	?	2'H2	:	2'H0	;		

	assign	fram_push_data	=	{	32{	lvds_fram_wrcs	}}& {	lvds_dat3_mbdi	,	
																lvds_dat2_mbdi	,	
																lvds_dat1_mbdi	,	
																lvds_dat0_mbdi 	};
//----------------------------------------------------------------------
	reg		[15: 0]						fram_push_addr	;
	reg									fram_pops_disa	;
	reg		[ 2: 0]						pops_disa_samp	;

	wire	fram_push_clrs	=			pops_disa_samp[1:0]	==	2'B10	;
	wire	fram_push_init	= 			lvds_fram_rise	;
	
	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn)						pops_disa_samp	<=	0	;
	else								pops_disa_samp	<={	fram_pops_disa	,	pops_disa_samp[2:1]};

	always@(posedge lvds_fckp or negedge link_rstn)
	if(~link_rstn) 						fram_push_addr	<=	0	;
	else if(fram_push_init)				fram_push_addr	<=	0	;
	else if(fram_push_csen)				fram_push_addr	<=	fram_push_addr + 1	;
	else if(fram_push_clrs)				fram_push_addr	<=	0	;
//----------------------------------------------------------------------------------------------------------
	reg		[15:0]						fram_pops_addr	;
	wire	[15:0]						fram_push_sync	;

	wire	[ 1:0]						fram_pops_tags	;
	wire	[31:0]						fram_pops_data	;

	trip_port_tags					u_rxdi_port_push_fifo(
		.wport_csen						(fram_push_csen		),
		.wport_addr						(fram_push_addr[2:0]),
		.wport_tags						(fram_push_tags		),
		.wport_data						(fram_push_data		),
		.wport_rstn						(fram_push_init		),
		.wport_clki						(lvds_fckp			),

		.rport_addr						(fram_pops_addr[2:0]),
		.rport_tags						(fram_pops_tags		),
		.rport_data						(fram_pops_data		),
		.rport_clki						(link_clki			));

	gens_sync_gray #(	.MSB (15))	
									u_rxdi_port_push_dptr(
		.data_asyn						(fram_push_addr		),
		.scki							(lvds_fckp			),
		.data_sync						(fram_push_sync		),
		.clki							(link_clki			),
		.rstn							(link_rstn			));
//----------------------------------------------------------------------------------------------------------
	reg		[2: 0]						fram_pops_reqs	;
	reg									fram_pops_ssen	;

	wire								fram_pops_csen	;
	wire								fram_pops_init	;
	wire								fram_pops_vlid	;

	wire	fram_pops_lead	=	{		fram_pops_ssen	,	fram_pops_tags	} ==	3'B101	;
	wire	fram_pops_body	=	{		fram_pops_ssen	,	fram_pops_tags	} ==	3'B110	;
	wire	fram_pops_coda	=	{		fram_pops_ssen	,	fram_pops_tags	} ==	3'B111	;

	assign	fram_pops_init	=			fram_pops_reqs[1:0]	==	2'B10	;
	assign	fram_pops_csen	=			fram_push_sync	>	fram_pops_addr	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						fram_pops_reqs	<=	0	;
	else 								fram_pops_reqs	<={ lvds_fram_csen	,	fram_pops_reqs[2:1]	};

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						fram_pops_ssen	<=	0	;
	else 								fram_pops_ssen	<=	fram_pops_csen	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						fram_pops_disa	<=	1	;
	else if(fram_pops_init)				fram_pops_disa	<=	0	;
	else if(fram_pops_coda)				fram_pops_disa	<=	1	;

	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn) 						fram_pops_addr	<=	0	;
	else if(fram_pops_init)				fram_pops_addr	<=	0	;
	else if(fram_pops_csen)				fram_pops_addr	<=	fram_pops_addr + 1	;
/**********************************************************************************************************/
	assign	rxdi_fram_lead	=			fram_pops_ssen	?	fram_pops_lead			:	0	;
	assign	rxdi_fram_body	=			fram_pops_ssen	?	fram_pops_body 			:	0	;
	assign	rxdi_fram_coda	=			fram_pops_ssen	?	fram_pops_coda			:	0	;
	assign	rxdi_dat3_mbdo	=			fram_pops_ssen	?	fram_pops_data[31:24]	:	0	;
	assign	rxdi_dat2_mbdo	=			fram_pops_ssen	?	fram_pops_data[23:16]	:	0	;
	assign	rxdi_dat1_mbdo	=			fram_pops_ssen	?	fram_pops_data[15: 8]	:	0	;
	assign	rxdi_dat0_mbdo	=			fram_pops_ssen	?	fram_pops_data[ 7: 0]	:	0	;

	
endmodule

