//----------------------------------------------------------------------------------------------------------
module cube_edge_wdma_mfsm(
	input								cube_edge_wdma_enab	,
	output								cube_edge_wdma_done	,
	input		[ 7: 0]					cube_edge_wdma_port	,
	input		[24: 0]					cube_edge_wdma_imag	,
	input								link_clki			,
	input								link_rstn			,
//------------------------------------------------------------------------------	
	input		[ 0: 7]					cube_edge_wdma_ov08	,
	input		[ 0: 7]					cube_edge_wdma_ov04	,
	input		[ 0: 7]					cube_edge_wdma_ov02	,
	input		[ 0: 7]					cube_edge_wdma_ov01	,

	output								cube_edge_wdma_init	,
	output								cube_edge_wdma_pick	,
//	output								cube_edge_wdma_seek	,
	output	reg	[ 0: 7]					cube_edge_wdma_reqs	,
	output	reg	[ 3: 0]					cube_edge_wdma_size	,

	output								ubus_wdma_ddrs_enab	,
	output								ubus_wdma_ddrs_init	,
	input								ubus_wdma_ddrs_done	,

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
//--ASYNC ENABLE & WKDONE
	reg			[ 1: 0]					ubus_wdma_enab_samp	;
	reg			[ 1: 0]					cube_wdma_done_samp	;

	reg			[24: 0]					cube_wdma_page_size	;
	reg			[24: 0]					cube_wdma_page_cnts	;

	wire								cube_ubus_wdma_enab	;
	wire								cube_ubus_wdma_done	;
	wire		[ 3: 0]					cube_wdma_edge_pnum	;
	wire		[ 3: 0]					cube_edge_wdma_leng	;
	wire								ubus_wdma_ddrs_reqs	;
	wire								ubus_wdma_full_done	;

	assign	cube_ubus_wdma_enab	=		ubus_wdma_enab_samp[0]	;
	assign	cube_edge_wdma_done	=		cube_wdma_done_samp[0]	;
	assign	ubus_wdma_full_done	=	&{	cube_ubus_wdma_enab	,	cube_wdma_page_cnts	==	cube_wdma_page_size	};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)						cube_wdma_done_samp	<=	0	;
	else								cube_wdma_done_samp	<={	cube_ubus_wdma_done	,	cube_wdma_done_samp[1]	};			

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_enab_samp	<=	0	;
	else								ubus_wdma_enab_samp	<={	cube_edge_wdma_enab	,	ubus_wdma_enab_samp[1]	};

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						cube_wdma_page_size	<=	0	;
	else if(~cube_ubus_wdma_enab)		cube_wdma_page_size	<=	25'H1FFFFFF	;
	else 								cube_wdma_page_size	<=	cube_wdma_edge_pnum *	cube_edge_wdma_imag	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						cube_wdma_page_cnts	<=	0	;
	else if(~cube_ubus_wdma_enab)		cube_wdma_page_cnts	<=	0	;
	else if( ubus_wdma_ddrs_reqs)		cube_wdma_page_cnts	<=	cube_wdma_page_cnts	+	cube_edge_wdma_size	;

	port_link_numb_accu				u_port_link_numb_accu(	
		.port_link_csen					(cube_edge_wdma_port		),//input		[ 7: 0]
		.port_link_numb					(cube_wdma_edge_pnum		));//input		[ 3: 0]
/**********************************************************************************************************************/
//--DECLARE WDMA MFSM
	reg			[ 2: 0]					ubus_wdma_ddrs_mfsm	;
	
	parameter	UBUS_WDMA_MFSM_IDLE	=	3'H0	;
	parameter	UBUS_WDMA_MFSM_INIT	=	3'H1	;
	parameter	UBUS_WDMA_MFSM_PICK	=	3'H2	;
	parameter	UBUS_WDMA_MFSM_SEEK	=	3'H3	;
	parameter	UBUS_WDMA_MFSM_WRIT	=	3'H4	;
	parameter	UBUS_WDMA_MFSM_VIEW	=	3'H5	;
	parameter	UBUS_WDMA_MFSM_DONE	=	3'H6	;
	
	wire	ubus_wdma_mfsm_idle	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_IDLE	;
	wire	ubus_wdma_mfsm_init	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_INIT	;
	wire	ubus_wdma_mfsm_pick	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_PICK	;
	wire	ubus_wdma_mfsm_seek	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_SEEK	;
	wire	ubus_wdma_mfsm_done	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_DONE	;

	wire								ubus_wdma_seek_ovfl	;

	assign	cube_edge_wdma_init	=		ubus_wdma_mfsm_init	;
	assign	cube_edge_wdma_pick	=		ubus_wdma_mfsm_pick	;
//	assign	cube_edge_wdma_seek	=		ubus_wdma_mfsm_seek	;
	assign	cube_ubus_wdma_done	=		ubus_wdma_mfsm_done	;

	assign	ubus_wdma_ddrs_enab	=	~	ubus_wdma_mfsm_idle	;
	assign	ubus_wdma_ddrs_init	=		ubus_wdma_mfsm_seek	;
	assign	ubus_wdma_ddrs_reqs	=	&{	ubus_wdma_mfsm_seek	,	ubus_wdma_seek_ovfl	};
/**********************************************************************************************************************/
//--EDGE WDMA CONTROL
	wire								ubus_wdma_seek_ov08	;
	wire								ubus_wdma_seek_ov04	;
	wire								ubus_wdma_seek_ov02	;
	wire								ubus_wdma_seek_ov01	;

	wire  		[ 0: 7]					cube_ov08_selx_port	;
	wire  		[ 0: 7]					cube_ov04_selx_port	;
	wire  		[ 0: 7]					cube_ov02_selx_port	;
	wire  		[ 0: 7]					cube_ov01_selx_port	;

	edge_ovfl_port_selx				u_edge_ov08_port_selx(
		.port_ovfl_stat					(cube_edge_wdma_ov08	),
		.port_ovfl_selx					(cube_ov08_selx_port	));

	edge_ovfl_port_selx				u_edge_ov04_port_selx(
		.port_ovfl_stat					(cube_edge_wdma_ov04	),
		.port_ovfl_selx					(cube_ov04_selx_port	));

	edge_ovfl_port_selx				u_edge_ov02_port_selx(
		.port_ovfl_stat					(cube_edge_wdma_ov02	),
		.port_ovfl_selx					(cube_ov02_selx_port	));

	edge_ovfl_port_selx				u_edge_ov01_port_selx(
		.port_ovfl_stat					(cube_edge_wdma_ov01	),
		.port_ovfl_selx					(cube_ov01_selx_port	));

	assign	ubus_wdma_seek_ov08	=	&{ 	ubus_wdma_mfsm_seek	, |	cube_edge_wdma_ov08	};
	assign	ubus_wdma_seek_ov04	=	&{ 	ubus_wdma_mfsm_seek	, |	cube_edge_wdma_ov04	};
	assign	ubus_wdma_seek_ov02	=	&{ 	ubus_wdma_mfsm_seek	, |	cube_edge_wdma_ov02	};
	assign	ubus_wdma_seek_ov01	=	&{ 	ubus_wdma_mfsm_seek	, |	cube_edge_wdma_ov01	};

	assign	ubus_wdma_seek_ovfl	= 	|{	ubus_wdma_seek_ov08	,	ubus_wdma_seek_ov04	,
										ubus_wdma_seek_ov02	,	ubus_wdma_seek_ov01	};

	assign	cube_edge_wdma_size	=		ubus_wdma_seek_ov08	?	4'H8	:
										ubus_wdma_seek_ov04	?	4'H4	:
										ubus_wdma_seek_ov02	?	4'H2	:
										ubus_wdma_seek_ov01	?	4'H1	:	4'H0	;

	assign	cube_edge_wdma_reqs	=		ubus_wdma_seek_ov08	?	cube_ov08_selx_port	:
										ubus_wdma_seek_ov04	?	cube_ov04_selx_port	:
										ubus_wdma_seek_ov02	?	cube_ov02_selx_port	:
										ubus_wdma_seek_ov01	?	cube_ov01_selx_port	:	8'H0	;
/**********************************************************************************************************************/
//MFSM
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)						ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_IDLE	;
	else if(~cube_ubus_wdma_enab)		ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_IDLE	;
	else begin	
		case(ubus_wdma_ddrs_mfsm)		
			UBUS_WDMA_MFSM_IDLE	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_INIT	;

			UBUS_WDMA_MFSM_INIT	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_PICK	;

			UBUS_WDMA_MFSM_PICK	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_SEEK	;
			
			UBUS_WDMA_MFSM_SEEK	:		ubus_wdma_ddrs_mfsm	<=	ubus_wdma_seek_ovfl	?	UBUS_WDMA_MFSM_WRIT	:	UBUS_WDMA_MFSM_PICK	;
			
			UBUS_WDMA_MFSM_WRIT	:	if(~ubus_wdma_ddrs_done)	
										ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_WRIT	;
									else						
										ubus_wdma_ddrs_mfsm	<=	ubus_wdma_full_done	?	UBUS_WDMA_MFSM_DONE	:	UBUS_WDMA_MFSM_PICK	;

			UBUS_WDMA_MFSM_DONE	:		ubus_wdma_ddrs_mfsm	<=	cube_ubus_wdma_enab	?	UBUS_WDMA_MFSM_DONE	:	UBUS_WDMA_MFSM_IDLE;

			default	:					ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_IDLE	;
		endcase
	end


endmodule										

module	edge_ovfl_port_selx(
	input		[ 0: 7]					port_ovfl_stat	,
	output		[ 0: 7]					port_ovfl_selx	);

	assign	port_ovfl_selx	=		port_ovfl_stat[0]	?	8'H80	:	port_ovfl_stat[1]	?	8'H40	:	
									port_ovfl_stat[2]	?	8'H20	:	port_ovfl_stat[3]	?	8'H10	:
									port_ovfl_stat[4]	?	8'H08	:	port_ovfl_stat[5]	?	8'H04	:
									port_ovfl_stat[6]	?	8'H02	:	port_ovfl_stat[7]	?	8'H01	:	8'H00	;

endmodule
//			UBUS_WDMA_MFSM_REQS	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_WRIT	;
//------------------------------------------------------------------------------
//	always@(posedge ubus_clki or negedge ubus_rstn)
//	if(!ubus_rstn)						cube_edge_wdma_size	<=	0	;
//	else if(ubus_wdma_mfsm_seek)		cube_edge_wdma_size	<=	cube_edge_wdma_leng	;
//	
//	always@(posedge ubus_clki or negedge ubus_rstn)	
//	if(!ubus_rstn)						cube_edge_wdma_reqs	<=	8'H0	;
//	else if(ubus_wdma_mfsm_seek)		cube_edge_wdma_reqs	<=	ubus_wdma_seek_ov08	?	cube_ov08_selx_port	:
//																ubus_wdma_seek_ov04	?	cube_ov04_selx_port	:
//																ubus_wdma_seek_ov02	?	cube_ov02_selx_port	:
//																ubus_wdma_seek_ov01	?	cube_ov01_selx_port	:	8'H0	;
//	else								cube_edge_wdma_reqs	<=	8'H0	;
//			UBUS_WDMA_MFSM_WRIT	:		ubus_wdma_ddrs_mfsm	<=	ubus_wdma_ddrs_done	?	UBUS_WDMA_MFSM_VIEW	:	UBUS_WDMA_MFSM_WRIT;
//			
//			UBUS_WDMA_MFSM_VIEW	:		ubus_wdma_ddrs_mfsm	<=	ubus_wdma_full_done	?	UBUS_WDMA_MFSM_DONE	:	UBUS_WDMA_MFSM_PICK;
