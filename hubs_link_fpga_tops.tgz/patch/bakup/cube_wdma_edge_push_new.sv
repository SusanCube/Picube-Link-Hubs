/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	edge_data_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_wdma_edge_push(
	input								this_tpgs_pile_lead	,
	input		[ 4: 0]					this_tpgs_edge_base	,
	
	input		[24 : 0]				llmb_hubs_ddrs_base	,
	input		[19 : 0]				llmb_hubs_imag_cols	,
	input		[19 : 0]				llmb_mtrx_imag_cols	,
	
	input								llmb_edge_imag_even	,//0:ODD 1: EVEN
	input		[24 : 0]				llmb_edge_imag_size	,
	input		[19 : 0]				llmb_edge_imag_cols	,
    input								llmb_edge_imag_row2	,//0:signle Rows 1: dual rows

	input								cube_edge_wdma_enab	,//write enable
	input								cube_edge_wdma_mode	,//0:VECT 1: MTRX
	input								cube_edge_idat_lead	,
	input								cube_edge_idat_wrcs	,
	input		[ 31: 0]				cube_edge_idat_data	,

	output	reg	[ 7: 0]					edge_push_page_dptr	,	//from edge_rxdi_pmau
	output	reg	[24: 0]					edge_push_page_addr	,	//from edge_rxdi_pmau
	output	reg	[255:0]					edge_push_page_data	,	//from edge_rxdi_pmau
	output	reg							edge_push_page_drdy	,	//from edge_rxdi_pmau	
	input								link_clki			,
	input								link_rstn			);
/***********************************************************************************************************************/
	reg			[  3: 0]				edge_data_wdma_samp	;

	wire								edge_data_wdma_disa	;
	wire								edge_data_wdma_prep	;
	wire								edge_data_wdma_init	;

	assign	edge_data_wdma_disa	= 		edge_data_wdma_samp[2:0] ==	3'B000	;	
	assign	edge_data_wdma_prep	= 		edge_data_wdma_samp[2:0] ==	3'B100	;
	assign	edge_data_wdma_init	= 		edge_data_wdma_samp[2:0] ==	3'B110	;

	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)						edge_data_wdma_samp	<=	0	;
	else								edge_data_wdma_samp	<={	cube_edge_wdma_enab	, edge_data_wdma_samp[3:1]	};	

/**********************************************************************************************************/
	reg			[  4: 0]				this_tpgs_edge_indx	;
	
	always@(posedge link_clki or negedge  link_rstn)
	if(~link_rstn)						this_tpgs_edge_indx	<=	0	;
	else if(edge_data_wdma_disa)		this_tpgs_edge_indx	<=	this_tpgs_edge_base	+	llmb_edge_imag_even	;
/**********************************************************************************************************/
	reg			[ 2: 0]                 edge_data_word_cnts	;
	reg			[15: 0]                 edge_data_page_cnts	;

    wire        [15: 0]                 edge_row1_page_cnts	;
    wire        [15: 0]                 edge_row2_page_cnts	;
    wire        [15: 0]                 edge_rows_page_cnts	;

	wire								edge_data_page_wrcs	;
	wire								edge_data_page_last	;
    
	assign  edge_row1_page_cnts =       llmb_edge_imag_cols[19:4]   ;   
    assign  edge_row2_page_cnts =    {  llmb_edge_imag_cols[18:4],  1'B0  };
    assign  edge_rows_page_cnts =       llmb_edge_imag_row2 ?   edge_row2_page_cnts :   edge_row1_page_cnts     ;

    assign	edge_data_page_wrcs	=	&{	cube_edge_idat_wrcs	,	edge_data_word_cnts	};
    assign	edge_data_page_last	=	&{	edge_data_page_wrcs	,	edge_rows_page_cnts ==  edge_data_page_cnts+1	};
	
	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						edge_data_word_cnts	<=	0	;
	else if(edge_data_wdma_disa)		edge_data_word_cnts	<=	0	;
	else if(cube_edge_idat_lead)		edge_data_word_cnts	<=	0	;
	else 								edge_data_word_cnts	<=	edge_data_word_cnts	+	cube_edge_idat_wrcs	;

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						edge_data_page_cnts	<=	0	;
	else if(edge_data_wdma_disa)		edge_data_page_cnts	<=	0	;
	else if(edge_data_page_last)		edge_data_page_cnts	<=	0	;
	else 								edge_data_page_cnts	<=	edge_data_page_cnts	+	edge_data_page_wrcs	;	

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						edge_push_page_data	<=	0	;
	else if(cube_edge_idat_lead)		edge_push_page_data	<=	0	;
	else if(cube_edge_idat_wrcs)		edge_push_page_data	<={	cube_edge_idat_data	,	edge_push_page_data[255:32]};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn) 						edge_push_page_drdy	<=	0	;
	else if(edge_data_wdma_disa)		edge_push_page_drdy	<=	0	;
	else								edge_push_page_drdy	<=	edge_data_page_wrcs	;

	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						edge_push_page_dptr	<=	0	;	
	else if(edge_data_wdma_disa)		edge_push_page_dptr	<=	0	;	
	else if(cube_edge_idat_lead)		edge_push_page_dptr	<=	0	;	
	else 								edge_push_page_dptr	<=	edge_push_page_dptr + edge_push_page_drdy	;	
/**********************************************************************************************************/
	reg			[24: 0]					mtrx_data_wdma_base	;
	reg			[24: 0]					mtrx_data_wdma_ofst	;
		
	wire		[19: 0]					mtrx_meta_edge_bias	;
	wire		[19: 0]					mtrx_meta_rows_dims	;
	wire		[15: 0]					mtrx_meta_rows_page	;
	
	assign	mtrx_meta_edge_bias	=		this_tpgs_edge_indx	*	llmb_edge_imag_cols	;
	assign	mtrx_meta_rows_dims	=		this_tpgs_pile_lead	?	llmb_mtrx_imag_cols	:	llmb_hubs_imag_cols	;
	assign	mtrx_meta_rows_page	=		mtrx_meta_rows_dims[19: 4]	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						mtrx_data_wdma_base	<=	0	;
	else if(edge_data_wdma_disa)		mtrx_data_wdma_base	<=	0	;
	else if(edge_data_wdma_prep)		mtrx_data_wdma_base	<=	llmb_hubs_ddrs_base	+ mtrx_meta_edge_bias[19:4]	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						mtrx_data_wdma_ofst	<=	0	;
	else if(edge_data_wdma_disa)		mtrx_data_wdma_ofst	<=	0	;
	else if(edge_data_wdma_prep)		mtrx_data_wdma_ofst	<=	mtrx_meta_rows_page	;
	else if(edge_data_page_last) 		mtrx_data_wdma_ofst	<=	mtrx_meta_rows_page	+ 	mtrx_data_wdma_ofst ;
//--------------
	reg			[24: 0]					vect_data_wdma_base	;
	
	wire		[24: 0]					vect_meta_edge_bias	;
	
	assign	vect_meta_edge_bias	=		this_tpgs_edge_indx	*	llmb_edge_imag_size	;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						vect_data_wdma_base	<=	0	;
	else if(edge_data_wdma_disa)		vect_data_wdma_base	<=	0	;
	else if(edge_data_wdma_prep)		vect_data_wdma_base	<=	llmb_hubs_ddrs_base	+ vect_meta_edge_bias		;
/**********************************************************************************************************/
	reg			[24: 0]					edge_data_page_addr	;

	wire		[24: 0]					edge_page_line_lead	;
	wire		[24: 0]					edge_page_line_inc1	;

	assign	edge_page_line_lead	=		mtrx_data_wdma_base +	mtrx_data_wdma_ofst	;
	assign	edge_page_line_inc1	=		edge_data_page_addr	+	1					;
	
	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						edge_data_page_addr	<=	0	;
	else if(edge_data_wdma_disa)		edge_data_page_addr	<=	0	;
	else if(edge_data_wdma_prep)		edge_data_page_addr	<=	0	;
	else if(edge_data_wdma_init)		edge_data_page_addr	<=	cube_edge_wdma_mode	?	mtrx_data_wdma_base	:	vect_data_wdma_base	;
	else if(edge_data_page_last)		edge_data_page_addr	<=	cube_edge_wdma_mode	?	edge_page_line_lead	:	edge_page_line_inc1	;
	else if(edge_data_page_wrcs)		edge_data_page_addr	<=	edge_page_line_inc1	;

	always@(posedge link_clki or negedge link_rstn )
	if(!link_rstn)						edge_push_page_addr	<=	0	;
	else								edge_push_page_addr	<=	edge_data_page_addr	;
/***********************************************************************************************************************/

endmodule 

 