module	cube_rimt_wdma_ubus (
	output								ubus_wdma_ddrs_csen	,
	output		[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,

	input		[ 0: 7]	[255: 0]		edge_wdma_page_data	,
	input		[ 0: 7]	[ 24: 0]		edge_wdma_page_addr	,
	input		[ 0: 7]					edge_wdma_page_drdy	,
	input		[ 1: 0]					edge_wdma_rows_page	,

	input								ubus_wdma_ddrs_enab	,
	input								ubus_wdma_ddrs_reqx	,
	input								ubus_wdma_ddrs_req4	,
	output								ubus_wdma_ddrs_done	,

	input								ubus_clki			,
	input								ubus_rstn			);
/***********************************************************************************************************************/
	reg			[ 1: 0]					edge_wdma_tapx_page	;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						edge_wdma_tapx_page	<=	0	;
	else if(~ubus_wdma_ddrs_enab)		edge_wdma_tapx_page	<=	edge_wdma_rows_page	;

/***********************************************************************************************************************/
	reg			[ 24: 0]				edge_muxs_pops_addr	;
	reg			[255: 0]				edge_muxs_pops_data	;
	reg									edge_muxs_pops_drdy	;
	reg									edge_muxs_pops_ddry	;

	reg			[ 0: 3][ 24: 0]			ubus_wdma_addr_memo	;
	reg			[ 0: 3][255: 0]			ubus_wdma_data_memo	;

	wire								ubus_wdma_ddrs_wreq	;

	assign	ubus_wdma_ddrs_wreq	= 	&{	edge_muxs_pops_drdy	, ~	edge_muxs_pops_ddry	};
//MUX_EDGE_IDAT_MISC------------------------------------------------------------
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						edge_muxs_pops_data	<=	0	;
	else if(edge_wdma_page_drdy[0])		edge_muxs_pops_data	<=	edge_wdma_page_data[0]	;
	else if(edge_wdma_page_drdy[1])		edge_muxs_pops_data	<=	edge_wdma_page_data[1]	;
	else if(edge_wdma_page_drdy[2])		edge_muxs_pops_data	<=	edge_wdma_page_data[2]	;
	else if(edge_wdma_page_drdy[3])		edge_muxs_pops_data	<=	edge_wdma_page_data[3]	;
	else if(edge_wdma_page_drdy[4])		edge_muxs_pops_data	<=	edge_wdma_page_data[4]	;
	else if(edge_wdma_page_drdy[5])		edge_muxs_pops_data	<=	edge_wdma_page_data[5]	;
	else if(edge_wdma_page_drdy[6])		edge_muxs_pops_data	<=	edge_wdma_page_data[6]	;
	else if(edge_wdma_page_drdy[7])		edge_muxs_pops_data	<=	edge_wdma_page_data[7]	;
	else 								edge_muxs_pops_data	<=	256'H0					;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						edge_muxs_pops_addr	<=	0	;
	else if(edge_wdma_page_drdy[0])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[0]	;
	else if(edge_wdma_page_drdy[1])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[1]	;
	else if(edge_wdma_page_drdy[2])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[2]	;
	else if(edge_wdma_page_drdy[3])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[3]	;
	else if(edge_wdma_page_drdy[4])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[4]	;
	else if(edge_wdma_page_drdy[5])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[5]	;
	else if(edge_wdma_page_drdy[6])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[6]	;
	else if(edge_wdma_page_drdy[7])		edge_muxs_pops_addr	<=	edge_wdma_page_addr[7]	;
	else 								edge_muxs_pops_addr	<=	25'H0					;

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						edge_muxs_pops_drdy	<=	0	;
	else if(~ubus_wdma_ddrs_enab)		edge_muxs_pops_drdy	<=	0	;
	else 								edge_muxs_pops_drdy	<= |edge_wdma_page_drdy[0:7];

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						edge_muxs_pops_ddry	<=	0	;
	else if(~ubus_wdma_ddrs_enab)		edge_muxs_pops_ddry	<=	0	;
	else 								edge_muxs_pops_ddry	<= 	edge_muxs_pops_drdy		;
//UBUS_WDMA_DDRS_MEMO------------------------------------------------------------------------------
	reg			[ 2: 0]					ubus_wdma_memo_indx	;
	wire		[ 0: 3]					ubus_wdma_memo_wrcs	;

	wire								ubus_wdma_ddrs_reqs	;
	assign	ubus_wdma_ddrs_reqs	=	|{	ubus_wdma_ddrs_reqx	,	ubus_wdma_ddrs_req4	}	;
	
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(~ubus_rstn)						ubus_wdma_memo_indx	<=	0	;
	else if(ubus_wdma_ddrs_reqs)		ubus_wdma_memo_indx	<=	0	;
	else if(edge_muxs_pops_drdy)		ubus_wdma_memo_indx	<=	ubus_wdma_memo_indx	+ 1	;

	for(genvar i = 0 ; i < 4 ; i = i +  1)	begin:gens_rimt_wrcs_memo
	
		assign	ubus_wdma_memo_wrcs[i]	= &{	edge_muxs_pops_drdy	,	ubus_wdma_memo_indx	==	i	};

		always@(posedge ubus_clki or negedge ubus_rstn)
		if(~ubus_rstn)						begin
			ubus_wdma_addr_memo[i]		<=	0	;
			ubus_wdma_data_memo[i]		<=	0	;
		end	else if(ubus_wdma_memo_wrcs[i])	begin
			ubus_wdma_addr_memo[i]		<=	edge_muxs_pops_addr	;
			ubus_wdma_data_memo[i]		<=	edge_muxs_pops_data	;
		end
	end
/***********************************************************************************************************************/
	reg									ubus_wdma_tapx_case	;	
	reg									ubus_wdma_beat_csen	;
	reg		[ 3: 0]						ubus_wdma_beat_cnts	;
	
	wire	[ 3: 0]						ubus_wdma_beat_inc1	;
	wire								ubus_wdma_tapx_done	;
	wire								ubus_wdma_tap4_done	;
	
	assign	ubus_wdma_beat_inc1	=		ubus_wdma_beat_cnts + 1	;
	assign	ubus_wdma_ddrs_csen	= 	&{	ubus_wdma_beat_csen	,	ubus_wdma_ddrs_wrdy	,	ubus_wdma_ddrs_trdy	};
	
	assign	ubus_wdma_tapx_done	=	&{	ubus_wdma_ddrs_csen	,	ubus_wdma_beat_inc1	==	edge_wdma_tapx_page	};										
	assign	ubus_wdma_tap4_done	=	&{	ubus_wdma_ddrs_csen	,	ubus_wdma_beat_cnts	==	4'H3				};										

	assign	ubus_wdma_ddrs_done	=		ubus_wdma_tapx_case	?	ubus_wdma_tapx_done	:	ubus_wdma_tap4_done	;
									
	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_tapx_case	<=	0	;
	else if(ubus_wdma_ddrs_reqx)		ubus_wdma_tapx_case	<=	1	;	
	else if(ubus_wdma_tapx_done)		ubus_wdma_tapx_case	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_csen	<=	0	;
	else if(ubus_wdma_ddrs_wreq)		ubus_wdma_beat_csen	<=	1	;	
	else if(ubus_wdma_ddrs_done)		ubus_wdma_beat_csen	<=	0	;	

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_ddrs_reqs)		ubus_wdma_beat_cnts	<=	0	;
	else if(ubus_wdma_ddrs_csen)		ubus_wdma_beat_cnts	<=	ubus_wdma_beat_inc1	;
//----------------------------------------------------------------------------------------------------------------------
	wire		[ 0 : 3]				ubus_wdma_ddrs_csid	;	

	for	(genvar j = 0 ; j < 4 ; j = j + 1)	begin:gens_ubus_read_memo
		assign	ubus_wdma_ddrs_csid[j]	= &{ubus_wdma_beat_csen	,	ubus_wdma_beat_cnts	== j	};
	end
	
	assign	ubus_wdma_ddrs_addr	=		ubus_wdma_ddrs_csid[0]	?	ubus_wdma_addr_memo[0]	:
										ubus_wdma_ddrs_csid[1]	?	ubus_wdma_addr_memo[1]	:	
										ubus_wdma_ddrs_csid[2]	?	ubus_wdma_addr_memo[2]	:
										ubus_wdma_ddrs_csid[3]	?	ubus_wdma_addr_memo[3]	:	25'H0	;

	assign	ubus_wdma_ddrs_data	=		ubus_wdma_ddrs_csid[0]	?	ubus_wdma_data_memo[0]	:
										ubus_wdma_ddrs_csid[1]	?	ubus_wdma_data_memo[1]	:	
										ubus_wdma_ddrs_csid[2]	?	ubus_wdma_data_memo[2]	:
										ubus_wdma_ddrs_csid[3]	?	ubus_wdma_data_memo[3]	:	256'H0	;

endmodule