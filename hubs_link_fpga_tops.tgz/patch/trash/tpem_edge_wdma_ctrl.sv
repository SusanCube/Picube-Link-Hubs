//	input	[ 4: 0]					cube_idat_gnpu_numb	,
//	output	reg						cube_idat_wdma_done	,

module	tpem_edge_wdma_ctrl(
//add @20250119
	input								tpem_edge_wdma_enab	,
	output								tpem_edge_wdma_done	,
	input		[24: 0]					tpem_edge_wdma_size	,
	input		[ 7: 0]					tpem_edge_rows_page	,
	input								link_clki			,
	input								link_rstn			,

	input		[ 0: 7]					edge_wdma_tapx_issu	,
	input		[ 0: 7]					edge_wdma_tap4_issu	,

	output								edge_wdma_taps_pick	,
	output	reg	[ 0: 7]					edge_wdma_tapx_reqs	,
	output	reg	[ 0: 7]					edge_wdma_tap4_reqs	,

	input		[ 0: 7][255: 0]			tpem_edge_wdma_data	,
	input		[ 0: 7][ 24: 0]			tpem_edge_wdma_addr	,
	input		[ 0: 7]					tpem_edge_wdma_drdy	,				

	output								ubus_wdma_ddrs_csen	,
	output		[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,

	input								ubus_clki			,
	input								ubus_rstn			);

/**********************************************************************************************************************/
	wire								ubus_wdma_ddrs_enab	;
	
	tpem_edge_wdma_mfsm				u_tpem_edge_wdma_mfsm(
		.tpem_edge_wdma_enab			(tpem_edge_wdma_enab	),//input				
		.tpem_edge_wdma_done			(tpem_edge_wdma_done	),//output				
		.tpem_edge_wdma_size			(tpem_edge_wdma_size	),//input		[24: 0]	
		.link_clki						(link_clki				),//input				
		.link_rstn						(link_rstn				),//input				
//------------------------------------------------------------------------------	
		.edge_wdma_taps_pick			(edge_wdma_taps_pick	),//output					
		.edge_wdma_tapx_issu			(edge_wdma_tapx_issu	),//input		[ 0: 7]		
		.edge_wdma_tap4_issu			(edge_wdma_tap4_issu	),//input		[ 0: 7]		
		.edge_wdma_tapx_reqs			(edge_wdma_tapx_reqs	),//output		[ 0: 7]		
		.edge_wdma_tap4_reqs			(edge_wdma_tap4_reqs	),//output		[ 0: 7]		
		
		.ubus_wdma_ddrs_enab			(ubus_wdma_ddrs_enab	),
		.ubus_wdma_ddrs_reqx			(ubus_wdma_ddrs_reqx	),
		.ubus_wdma_ddrs_req4			(ubus_wdma_ddrs_req4	),
		.ubus_wdma_ddrs_wrok			(ubus_wdma_ddrs_csen	),//output	
		.ubus_wdma_ddrs_done			(ubus_wdma_ddrs_done	),//input	
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input		
/***********************************************************************************************************************/
	tpem_edge_wdma_ddrs 			u_tpem_edge_wdma_ddrs(
		.ubus_wdma_ddrs_csen			(ubus_wdma_ddrs_csen		),//output				
		.ubus_wdma_ddrs_addr			(ubus_wdma_ddrs_addr		),//output		[ 24: 0]
		.ubus_wdma_ddrs_data			(ubus_wdma_ddrs_data		),//output		[255: 0]
		.ubus_wdma_ddrs_trdy			(ubus_wdma_ddrs_trdy		),//input				
		.ubus_wdma_ddrs_wrdy			(ubus_wdma_ddrs_wrdy		),//input				

		.edge_wdma_page_data			(tpem_edge_wdma_data		),//input	[ 0: 7]	[255: 0]
		.edge_wdma_page_addr			(tpem_edge_wdma_addr		),//input	[ 0: 7]	[ 24: 0]
		.edge_wdma_page_drdy			(tpem_edge_wdma_drdy		),//input	[ 0: 7]			
		.edge_wdma_rows_page			(tpem_edge_rows_page[1:0]	),//input	[ 0: 7]	[255: 0]

		.ubus_wdma_ddrs_enab			(ubus_wdma_ddrs_enab	),
		.ubus_wdma_ddrs_reqx			(ubus_wdma_ddrs_reqx	),//input	
		.ubus_wdma_ddrs_req4			(ubus_wdma_ddrs_req4	),//input	
		.ubus_wdma_ddrs_done			(ubus_wdma_ddrs_done	),//output	
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input		
 	

endmodule
 