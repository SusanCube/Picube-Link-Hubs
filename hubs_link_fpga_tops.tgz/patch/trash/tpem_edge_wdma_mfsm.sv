//----------------------------------------------------------------------------------------------------------
module tpem_edge_wdma_mfsm(
	input								tpem_edge_wdma_enab	,
	output								tpem_edge_wdma_done	,
	input		[24: 0]					tpem_edge_wdma_size	,
	input								link_clki			,
	input								link_rstn			,
//------------------------------------------------------------------------------	
	output								edge_wdma_taps_pick	,
	input		[ 0: 7]					edge_wdma_tapx_issu	,
	input		[ 0: 7]					edge_wdma_tap4_issu	,
	output		[ 0: 7]					edge_wdma_tapx_reqs	,
	output		[ 0: 7]					edge_wdma_tap4_reqs	,

	output								ubus_wdma_ddrs_enab	,
	output								ubus_wdma_ddrs_reqx	,
	output								ubus_wdma_ddrs_req4	,
	input								ubus_wdma_ddrs_wrok	,
	input								ubus_wdma_ddrs_done	,

	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
//--ASYNC ENABLE & WKDONE
	reg			[ 1: 0]					ubus_wdma_enab_samp	;
	reg			[ 1: 0]					ubus_wdma_done_samp	;

	reg			[24: 0]					ubus_wdma_ddrs_size	;
	reg			[24: 0]					ubus_wdma_ddrs_pcnt	;

	wire								ubus_wdma_work_enab	;
	wire								ubus_wdma_work_done	;
	wire		[ 3: 0]					tpem_edge_wdma_pnum	;
	wire		[ 3: 0]					cube_edge_wdma_leng	;
	wire								ubus_wdma_ddrs_reqs	;
	wire								ubus_wdma_ddrs_over	;

	assign	ubus_wdma_work_enab	=		ubus_wdma_enab_samp[0]	;
	assign	tpem_edge_wdma_done	=		ubus_wdma_done_samp[0]	;
	assign	ubus_wdma_ddrs_over	=	&{	ubus_wdma_work_enab	,	ubus_wdma_ddrs_pcnt	==	ubus_wdma_ddrs_size-1	};

	always@(posedge ubus_clki or negedge ubus_rstn)
	if(!ubus_rstn)						ubus_wdma_enab_samp	<=	0	;
	else								ubus_wdma_enab_samp	<={	tpem_edge_wdma_enab	,	ubus_wdma_enab_samp[1]	};

	always@(posedge link_clki or negedge link_rstn)
	if(!link_rstn)						ubus_wdma_done_samp	<=	0	;
	else								ubus_wdma_done_samp	<={	ubus_wdma_work_done	,	ubus_wdma_done_samp[1]	};			

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_wdma_ddrs_size	<=	0	;
	else if(~ubus_wdma_work_enab)		ubus_wdma_ddrs_size	<=	25'H1FFFFFF	;
	else 								ubus_wdma_ddrs_size	<= {tpem_edge_wdma_size[21:0],3'H0	};

//	else 								ubus_wdma_ddrs_size	<=	tpem_edge_wdma_pnum *	tpem_edge_wdma_size	;

	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(~ubus_rstn)						ubus_wdma_ddrs_pcnt	<=	0	;
	else if(~ubus_wdma_work_enab)		ubus_wdma_ddrs_pcnt	<=	0	;
	else 								ubus_wdma_ddrs_pcnt	<=	ubus_wdma_ddrs_pcnt	+	ubus_wdma_ddrs_wrok	;

/**********************************************************************************************************************/
//--EDGE WDMA CONTROL
	wire								ubus_wdma_ddrs_tapx	;
	wire								ubus_wdma_ddrs_tap4	;
	wire								ubus_wdma_ddrs_vlid	;

	edge_wdma_port_selx				u_edge_tapx_port_selx(
		.port_wdma_disa					(1'B0					),
		.port_wdma_stat					(edge_wdma_tapx_issu	),
		.port_wdma_selx					(edge_wdma_tapx_reqs	));

	edge_wdma_port_selx				u_edge_tap4_port_selx(
		.port_wdma_disa					(ubus_wdma_ddrs_tapx	),
		.port_wdma_stat					(edge_wdma_tap4_issu	),
		.port_wdma_selx					(edge_wdma_tap4_reqs	));

	assign	ubus_wdma_ddrs_tapx	=	|	edge_wdma_tapx_issu	;
	assign	ubus_wdma_ddrs_tap4	=	|	edge_wdma_tap4_issu	;

	assign	ubus_wdma_ddrs_reqx	=		ubus_wdma_ddrs_tapx	;	
	assign	ubus_wdma_ddrs_req4	=	&{ ~ubus_wdma_ddrs_tapx	,	ubus_wdma_ddrs_tap4	};
	assign	ubus_wdma_ddrs_vlid	=	|{	ubus_wdma_ddrs_tapx	,	ubus_wdma_ddrs_tap4	};

/**********************************************************************************************************************/
//--DECLARE WDMA MFSM
	reg			[ 2: 0]					ubus_wdma_ddrs_mfsm	;
	
	parameter	UBUS_WDMA_MFSM_IDLE	=	3'H0	;
	parameter	UBUS_WDMA_MFSM_PICK	=	3'H1	;
	parameter	UBUS_WDMA_MFSM_REQS	=	3'H2	;
	parameter	UBUS_WDMA_MFSM_WRIT	=	3'H3	;
	parameter	UBUS_WDMA_MFSM_VIEW	=	3'H4	;
	parameter	UBUS_WDMA_MFSM_DONE	=	3'H5	;
	
	assign	ubus_wdma_ddrs_enab	=		ubus_wdma_ddrs_mfsm	!=	UBUS_WDMA_MFSM_IDLE	;
	assign	edge_wdma_taps_pick	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_PICK	;
	assign	ubus_wdma_work_done	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_DONE	;
/**********************************************************************************************************************/
//MFSM
	always@(posedge ubus_clki or negedge ubus_rstn)	
	if(!ubus_rstn)						ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_IDLE	;
	else if(~ubus_wdma_work_enab)		ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_IDLE	;
	else begin	
		case(ubus_wdma_ddrs_mfsm)		
			UBUS_WDMA_MFSM_IDLE	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_PICK	;

			UBUS_WDMA_MFSM_PICK	:		ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_REQS	;
			
			UBUS_WDMA_MFSM_REQS	:		ubus_wdma_ddrs_mfsm	<=	ubus_wdma_ddrs_vlid	?	UBUS_WDMA_MFSM_WRIT	:	UBUS_WDMA_MFSM_PICK	;
			
			UBUS_WDMA_MFSM_WRIT	:	
				if(ubus_wdma_ddrs_done)	ubus_wdma_ddrs_mfsm	<=	ubus_wdma_ddrs_over	?	UBUS_WDMA_MFSM_DONE	:	UBUS_WDMA_MFSM_PICK	;
				else					ubus_wdma_ddrs_mfsm	<=	UBUS_WDMA_MFSM_WRIT	;

			UBUS_WDMA_MFSM_DONE	:		ubus_wdma_ddrs_mfsm	<=	ubus_wdma_work_enab	?	UBUS_WDMA_MFSM_DONE	:	UBUS_WDMA_MFSM_IDLE;

			default	:					ubus_wdma_ddrs_mfsm	<=							UBUS_WDMA_MFSM_IDLE	;
		endcase
	end


endmodule										

module	edge_wdma_port_selx(
	input								port_wdma_disa	,
	input		[ 0: 7]					port_wdma_stat	,
	output		[ 0: 7]					port_wdma_selx	);

	assign	port_wdma_selx	=		port_wdma_disa		?	8'H00	:
									port_wdma_stat[0]	?	8'H80	:	port_wdma_stat[1]	?	8'H40	:	
									port_wdma_stat[2]	?	8'H20	:	port_wdma_stat[3]	?	8'H10	:
									port_wdma_stat[4]	?	8'H08	:	port_wdma_stat[5]	?	8'H04	:
									port_wdma_stat[6]	?	8'H02	:	port_wdma_stat[7]	?	8'H01	:	8'H00	;

endmodule
//	wire	ubus_wdma_mfsm_selx	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_REQS	;
//	wire	ubus_wdma_mfsm_done	=		ubus_wdma_ddrs_mfsm	==	UBUS_WDMA_MFSM_DONE	;

//	assign	cube_edge_wdma_init	=		ubus_wdma_mfsm_init	;
//	assign	edge_pops_taps_pick	=		ubus_wdma_mfsm_pick	;
//	assign	ubus_wdma_work_done	=		ubus_wdma_mfsm_done	;
//
//	assign	ubus_wdma_ddrs_enab	=	~	ubus_wdma_mfsm_idle	;
//	assign	ubus_wdma_ddrs_reqs	=	&{	ubus_wdma_mfsm_selx	,	ubus_wdma_selx_ovfl	};
//	port_link_numb_accu				u_port_link_numb_accu(	
//		.port_link_csen					(tpem_edge_wdma_port		),//input		[ 7: 0]
//		.port_link_numb					(tpem_edge_wdma_pnum		));//input		[ 3: 0]
