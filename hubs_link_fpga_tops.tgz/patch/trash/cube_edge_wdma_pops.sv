/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	cube_idat_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_edge_wdma_pops(
	input								edge_push_ddrs_enab	,
	input		[ 7: 0]					edge_push_rows_page	,
	input								edge_push_page_lead	,	//from edge_rxdi_pmau
	input		[24: 0]					edge_push_page_addr	,	//from edge_rxdi_pmau
	input		[255:0]					edge_push_page_data	,	//from edge_rxdi_pmau
	input								edge_push_page_drdy	,	//from edge_rxdi_pmau
	input								edge_clki			,
	input								edge_rstn			,
				
	input								ubus_pops_taps_pick	,	
	output	reg							ubus_pops_tapx_issu	,
	output	reg							ubus_pops_tap4_issu	,
	input								ubus_pops_tapx_reqs	,	//0:TAP4_POPS 1:TAPX_POPS 
	input								ubus_pops_tap4_reqs	,	
	
	output		[ 24: 0]				ubus_pops_page_addr	,
	output		[255: 0]				ubus_pops_page_data	,
	output	reg							ubus_pops_page_drdy	,				
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire								ubus_pops_ddrs_enab	;

	reg			[ 7: 0]					ubus_wdma_rows_size	;

	wire								ubus_wdma_tap4_case	;
	wire								ubus_wdma_tapx_case	;
	wire		[ 1: 0]					ubus_wdma_tapx_size	;
	wire		[ 7: 0]					ubus_wdma_tapx_ovfl	;

	assign	ubus_wdma_tap4_case	=	|	ubus_wdma_rows_size[7:2]	;
	assign	ubus_wdma_tapx_case	= 	|	ubus_wdma_rows_size[1:0]	;
	assign	ubus_wdma_tapx_size	= 		ubus_wdma_rows_size[1:0] - 1;
	assign	ubus_wdma_tapx_ovfl	= {6'H0,ubus_wdma_rows_size[1:0] }	;

	
	wire	ubus_wdma_pure_tapx	=	&{  ubus_wdma_tapx_case	, ~	ubus_wdma_tap4_case	};		
	wire	ubus_wdma_pure_tap4	=	&{ ~ubus_wdma_tapx_case	,	ubus_wdma_tap4_case	};
	wire	ubus_wdma_comb_tap4	=	&{  ubus_wdma_tapx_case	,  	ubus_wdma_tap4_case	};				

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_wdma_rows_size	<=	0	;
	else if(~ubus_pops_ddrs_enab)		ubus_wdma_rows_size	<=	edge_push_rows_page	;
/**********************************************************************************************************************/
	reg			[ 7: 0]					edge_push_page_cnts	;
	wire								edge_push_rows_over	;

	wire								ubus_push_mset_zero	;

	reg			[ 7: 0]					ubus_pops_page_cnts	;
	wire								ubus_pops_rows_over	;

	wire		[ 7: 0]					ubus_push_page_cnts	;
	wire								ubus_push_page_lead	;

	assign	ubus_pops_rows_over	=		ubus_pops_page_cnts	==	ubus_wdma_rows_size	;	
	
	always@(posedge edge_clki or negedge  edge_rstn)
	if(~edge_rstn)						edge_push_page_cnts	<=	0	;
	else if(~edge_push_ddrs_enab)		edge_push_page_cnts	<=	0	;
	else if( edge_push_page_lead)		edge_push_page_cnts	<=	0	;
	else if( edge_push_rows_over)		edge_push_page_cnts	<=	0	;
	else								edge_push_page_cnts	<=	edge_push_page_cnts	+	edge_push_page_drdy	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_cnts	<=	0	;
	else if(~ubus_pops_ddrs_enab)		ubus_pops_page_cnts	<=	0	;
	else if( ubus_push_page_lead)		ubus_pops_page_cnts	<=	0	;
	else if( ubus_pops_rows_over)		ubus_pops_page_cnts	<=	0	;
	else								ubus_pops_page_cnts	<=	ubus_pops_page_cnts	+	ubus_pops_page_drdy	;
/**********************************************************************************************************************/
	gens_sign_slow_fast #( .EXTN(1))
									u_ubus_pops_ddrs_enab(	
		.slow_sign						(edge_push_ddrs_enab	),//input	
		.slow_clki						(edge_clki				),//input	
		.slow_rstn						(edge_rstn				),//input	
		.fast_sign  					(ubus_pops_ddrs_enab	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				));//input	

	gens_edge_fast_slow #(.EXTN( 4 ))
									u_edge_rows_wdma_over(	
		.fast_sign						(ubus_pops_rows_over	),//input	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	

		.slow_edge						(edge_push_rows_over	),//output
		.slow_clki						(edge_clki				),//input
		.slow_rstn						(edge_rstn				));//input

	gens_sign_slow_fast #( .EXTN(1))
									u_ubus_push_mset_zero(	
		.slow_sign						(edge_push_rows_over	),//input	
		.slow_clki						(edge_clki				),//input	
		.slow_rstn						(edge_rstn				),//input	
		.fast_sign  					(ubus_push_mset_zero	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				));//input	

	gens_edge_slow_fast 			u_edge_ubus_lead_edge(	
		.fast_edge						(ubus_push_page_lead	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	

		.slow_sign						(edge_push_page_lead	),//input
		.slow_clki						(edge_clki				),//input
		.slow_rstn						(edge_rstn				));//input

	gens_sync_gray	#( .MSB(7) )	u_ubus_dptr_sync_gens(
		.data_asyn						(edge_push_page_cnts	),//input	[24: 0]	
		.scki							(edge_clki				),

		.data_sync						(ubus_push_page_cnts	),//output	[24: 0]	
		.clki							(ubus_clki				),//input			
		.rstn							(ubus_rstn				));//input			
/**********************************************************************************************************************/
	reg			[ 2: 0]					ubus_pops_taps_mfsm	;
	
	parameter	EDGE_WDMA_WORK_IDLE	=	3'H0	;
	parameter	EDGE_WDMA_TAPX_ISSU	=	3'H1	;
	parameter	EDGE_WDMA_TAPX_POPS	=	3'H2	;
	parameter	EDGE_WDMA_TAP4_ISSU	=	3'H3	;
	parameter	EDGE_WDMA_TAP4_POPS	=	3'H4	;
	parameter	EDGE_WDMA_TAPS_LOOP	=	3'H5	;
	parameter	EDGE_WDMA_TAPS_MUTE	=	3'H6	;
		
	wire								ubus_pops_taps_done	;
	wire								ubus_pops_taps_mute	;
	wire								ubus_pops_mute_done	;
	
	wire								edge_issu_tapx_time	;
	wire								edge_issu_tap4_time	;
	wire								ubus_pops_tapx_time	;
	wire								ubus_pops_tap4_time	;

	assign	edge_issu_tapx_time	=		ubus_pops_taps_mfsm	==	EDGE_WDMA_TAPX_ISSU	;
	assign	edge_issu_tap4_time	=		ubus_pops_taps_mfsm	==	EDGE_WDMA_TAP4_ISSU	;

	assign	ubus_pops_tapx_time	=		ubus_pops_taps_mfsm	==	EDGE_WDMA_TAPX_POPS	;
	assign	ubus_pops_tap4_time	=		ubus_pops_taps_mfsm	==	EDGE_WDMA_TAP4_POPS	;

	assign	ubus_pops_taps_mute	=		ubus_pops_taps_mfsm	==	EDGE_WDMA_TAPS_MUTE	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_taps_mfsm	<=	EDGE_WDMA_WORK_IDLE	;
	else if(~ubus_pops_ddrs_enab)		ubus_pops_taps_mfsm	<=	EDGE_WDMA_WORK_IDLE	;
	else begin
		case(ubus_pops_taps_mfsm)
			EDGE_WDMA_WORK_IDLE	:		
				if(ubus_push_page_lead)	ubus_pops_taps_mfsm	<=	ubus_wdma_pure_tap4	?	EDGE_WDMA_TAP4_ISSU	:	EDGE_WDMA_TAPX_ISSU	;
//				if(edge_push_page_lead)	ubus_pops_taps_mfsm	<=	ubus_wdma_pure_tapx	?	EDGE_WDMA_TAPX_ISSU	:	EDGE_WDMA_TAP4_ISSU	;
				else 					ubus_pops_taps_mfsm	<=	EDGE_WDMA_WORK_IDLE	;

			EDGE_WDMA_TAPX_ISSU	:		ubus_pops_taps_mfsm	<=	ubus_pops_tapx_reqs	?	EDGE_WDMA_TAPX_POPS	:	EDGE_WDMA_TAPX_ISSU	;
			EDGE_WDMA_TAPX_POPS	:		
				if(ubus_wdma_pure_tapx)	ubus_pops_taps_mfsm	<=	ubus_pops_taps_done	?	EDGE_WDMA_WORK_IDLE	:	EDGE_WDMA_TAPX_POPS	;	
				else					ubus_pops_taps_mfsm	<=	ubus_pops_taps_done	? 	EDGE_WDMA_TAP4_ISSU	:	EDGE_WDMA_TAPX_POPS	;

			EDGE_WDMA_TAP4_ISSU	:		ubus_pops_taps_mfsm	<=	ubus_pops_tap4_reqs	?	EDGE_WDMA_TAP4_POPS	:	EDGE_WDMA_TAP4_ISSU	;
			EDGE_WDMA_TAP4_POPS	:		ubus_pops_taps_mfsm	<=	ubus_pops_taps_done	?	EDGE_WDMA_TAPS_LOOP	:	EDGE_WDMA_TAP4_POPS	;
			EDGE_WDMA_TAPS_LOOP	:		ubus_pops_taps_mfsm	<=	ubus_pops_rows_over	?	EDGE_WDMA_TAPS_MUTE	:	EDGE_WDMA_TAP4_ISSU	;
			EDGE_WDMA_TAPS_MUTE	:		ubus_pops_taps_mfsm	<=	ubus_push_mset_zero	?	EDGE_WDMA_WORK_IDLE	:	EDGE_WDMA_TAPS_MUTE	;
			default				:		ubus_pops_taps_mfsm	<=	EDGE_WDMA_WORK_IDLE	;
		endcase
	end
/**********************************************************************************************************************/
	reg			[ 3: 0]					ubus_pops_mute_cnts	;
	assign	ubus_pops_mute_done	=	&	ubus_pops_mute_cnts	;
	
	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_mute_cnts	<=	0	;
	else if(~ubus_pops_taps_mute)		ubus_pops_mute_cnts	<=	0	;
	else								ubus_pops_mute_cnts	<=	ubus_pops_mute_cnts	+ 1	;
/**********************************************************************************************************************/
	reg			[ 2: 0]					ubus_pops_taps_pcnt	;

	wire		[ 7: 0]					ubus_resv_page_cnts	;
	wire								ubus_resv_tapx_true	;
	wire								ubus_resv_tap4_true	;
	wire								ubus_pops_taps_reqs	;


	assign	ubus_resv_page_cnts	=		ubus_push_page_cnts	-	ubus_pops_page_cnts	;
	
	assign	ubus_resv_tapx_true	=		ubus_resv_page_cnts	>= {6'H0,	ubus_wdma_rows_size[1:0]	};
	assign	ubus_resv_tap4_true	=	|	ubus_resv_page_cnts[7:2]	;

	assign	ubus_pops_taps_reqs	=	|{	ubus_pops_tapx_reqs	,	ubus_pops_tap4_reqs	};

	assign	ubus_pops_tapx_done	=	&{	ubus_pops_tapx_time	,	ubus_pops_page_drdy	,	ubus_pops_taps_pcnt	==	ubus_wdma_tapx_size	};
	assign	ubus_pops_tap4_done	=	&{	ubus_pops_tap4_time	,	ubus_pops_page_drdy	,	ubus_pops_taps_pcnt	==	3'H3				};			
	assign	ubus_pops_taps_done	=	|{	ubus_pops_tapx_done	,	ubus_pops_tap4_done	};

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_page_drdy	<=	0	;
	else if(~ubus_pops_ddrs_enab )		ubus_pops_page_drdy	<=	0	;
	else if( ubus_pops_taps_reqs)		ubus_pops_page_drdy	<=	1	;
	else if( ubus_pops_taps_done)		ubus_pops_page_drdy	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_taps_pcnt	<=	0	;
	else if(~ubus_pops_ddrs_enab)		ubus_pops_taps_pcnt	<=	0	;
	else if( ubus_pops_taps_reqs)		ubus_pops_taps_pcnt	<=	0	;
	else if( ubus_pops_page_drdy)		ubus_pops_taps_pcnt	<=	ubus_pops_taps_pcnt	+	1	;
/**********************************************************************************************************/
	wire								edge_issu_tapx_case	;
	wire								edge_issu_tap4_case	;

	assign	edge_issu_tapx_case	=	&{	ubus_pops_taps_pick	,	edge_issu_tapx_time	,	ubus_resv_tapx_true	}	;
	assign	edge_issu_tap4_case	=	&{	ubus_pops_taps_pick	,	edge_issu_tap4_time	,	ubus_resv_tap4_true	}	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_tapx_issu	<=	0	;
	else if(~ubus_pops_ddrs_enab)		ubus_pops_tapx_issu	<=	0	;
	else if( edge_issu_tapx_case)		ubus_pops_tapx_issu	<=	1	;
	else 								ubus_pops_tapx_issu	<=	0	;

	always@(posedge ubus_clki or negedge  ubus_rstn)
	if(~ubus_rstn)						ubus_pops_tap4_issu	<=	0	;
	else if(~ubus_pops_ddrs_enab)		ubus_pops_tap4_issu	<=	0	;
	else if( edge_issu_tap4_case)		ubus_pops_tap4_issu	<=	1	;
	else								ubus_pops_tap4_issu	<=	0	;
/**********************************************************************************************************/
	wire		[ 7: 0]					ubus_pops_page_nxta	;
	wire		[ 7: 0]					ubus_pops_page_dptr	;

	assign	ubus_pops_page_nxta	=		ubus_pops_page_cnts + 1	;
	assign	ubus_pops_page_dptr	=		ubus_pops_page_drdy	?	ubus_pops_page_nxta	:	ubus_pops_page_cnts	;
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 8 	),	
		.DATA_BITS	( 256 	))	
									u_idat_wdma_beat_data (
		.wport_csen						(edge_push_page_drdy	),//input  				 		
		.wport_addr						(edge_push_page_cnts	),//input		[ADDR_BITS-1:0]
		.wport_data						(edge_push_page_data	),//input		[DATA_BITS-1:0]
		.wport_clki						(edge_clki				),//input						

		.rport_addr						(ubus_pops_page_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_pops_page_data	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						


	dual_port_bram	#(	
		.ADDR_BITS	( 8 	),	
		.DATA_BITS	( 25 	))	
									u_idat_wdma_beat_addr (
		.wport_csen						(edge_push_page_drdy	),//input  				 		
		.wport_addr						(edge_push_page_cnts	),//input		[DATA_BITS-1:0]
		.wport_data						(edge_push_page_addr	),//input		[ADDR_BITS-1:0]
		.wport_clki						(edge_clki				),//input						

		.rport_addr						(ubus_pops_page_dptr	),//input		[ADDR_BITS-1:0]
		.rport_data						(ubus_pops_page_addr	),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(ubus_clki				));//input						

endmodule 
 /*
	gens_edge_slow_fast 			u_edge_ubus_drdy_edge(	
		.fast_edge						(ubus_push_page_drdy	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	

		.slow_sign						(edge_push_page_drdy	),//input
		.slow_clki						(edge_clki				),//input
		.slow_rstn						(edge_rstn				));//input
*/
