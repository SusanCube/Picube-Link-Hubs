/*----author edward------
//	wire							cube_idat_wdma_enab	;
//	assign	cube_idat_wdma_enab	= 	edge_data_wdma_samp[2:0] ==	3'B111	;
*/

module	cube_rimt_wdma_arbt(
	output								cube_rimt_wdma_done	,
	input								cube_rimt_wdma_enab	,
	input		[19: 0]					cube_rimt_wdma_rows	,
	
	output		[ 0: 7]					cube_rimt_wdma_acks	,
	input		[ 0: 7]					cube_rimt_wdma_reqs	,
	input		[ 0: 7][25: 0]			cube_rimt_wdma_tags	,
	input								link_clki			,
	input								link_rstn			,
	
	output								ubus_rimt_wdma_reqs	,
	output		[ 2: 0]					ubus_rimt_wdma_edge	,
	output		[25: 0]					ubus_rimt_wdma_tags	,
	input								ubus_rimt_wdma_wrdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/***********************************************************************************************************************/
	reg			[ 2: 0]					cube_rimt_wdma_mfsm	;


	parameter	CUBE_RIMT_WDMA_IDLE	=	3'H0	;	
	parameter	CUBE_RIMT_WDMA_SEEK	=	3'H1	;	
	parameter	CUBE_RIMT_WDMA_ARBT	=	3'H2	;
	parameter	CUBE_RIMT_WDMA_ACKS	=	3'H3	;//insert two cycles state,force gray_code sync to ddrs' clock domain successfully
	parameter	CUBE_RIMT_WDMA_REQS	=	3'H4	;//insert two cycles state,force gray_code sync to ddrs' clock domain successfully
	parameter	CUBE_RIMT_WDMA_WRDY	=	3'H5	;
	parameter	CUBE_RIMT_WDMA_LOOP	=	3'H6	;
	parameter	CUBE_RIMT_WDMA_DONE	=	3'H7	;

	wire								cube_rimt_edge_vlid	;
	wire								cube_rimt_ubus_wrdy	;
	wire								cube_rimt_meta_done	;

	assign		cube_rimt_edge_vlid	= |	cube_rimt_wdma_reqs	;
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)	
	if(~link_rstn)						cube_rimt_wdma_mfsm	<=	CUBE_RIMT_WDMA_IDLE	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_wdma_mfsm	<=	CUBE_RIMT_WDMA_IDLE	;
	else begin	
		case(cube_rimt_wdma_mfsm)		
			CUBE_RIMT_WDMA_IDLE	:		cube_rimt_wdma_mfsm	<=							CUBE_RIMT_WDMA_SEEK	;
			CUBE_RIMT_WDMA_SEEK	:		cube_rimt_wdma_mfsm	<=	cube_rimt_edge_vlid	?	CUBE_RIMT_WDMA_ARBT	:	CUBE_RIMT_WDMA_SEEK	;
			CUBE_RIMT_WDMA_ARBT	:		cube_rimt_wdma_mfsm	<=							CUBE_RIMT_WDMA_ACKS	;
			CUBE_RIMT_WDMA_ACKS	:		cube_rimt_wdma_mfsm	<=							CUBE_RIMT_WDMA_REQS	;
			CUBE_RIMT_WDMA_REQS	:		cube_rimt_wdma_mfsm	<=							CUBE_RIMT_WDMA_WRDY	;
			CUBE_RIMT_WDMA_WRDY	:		cube_rimt_wdma_mfsm	<=	cube_rimt_ubus_wrdy	?	CUBE_RIMT_WDMA_LOOP	:	CUBE_RIMT_WDMA_WRDY	;
			CUBE_RIMT_WDMA_LOOP	:		cube_rimt_wdma_mfsm	<=	cube_rimt_meta_done	?	CUBE_RIMT_WDMA_DONE	:	CUBE_RIMT_WDMA_SEEK	;
			CUBE_RIMT_WDMA_DONE	:		cube_rimt_wdma_mfsm	<=	cube_rimt_wdma_enab	?	CUBE_RIMT_WDMA_DONE	:	CUBE_RIMT_WDMA_IDLE	;
		endcase
	end
//------------------------------------------------------------------------------
//	wire	cube_rimt_wdma_idle	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_IDLE	;	
	wire	cube_rimt_hits_seek	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_SEEK	;	
	wire	cube_rimt_hits_arbt	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_ARBT	;	
	wire	cube_rimt_hits_acks	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_ACKS	;
	wire	cube_rimt_hits_reqs	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_REQS	;
//	wire	cube_rimt_wdma_wrdy	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_WRDY	;
	wire	cube_rimt_hits_loop	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_LOOP	;
	assign	cube_rimt_wdma_done	=		cube_rimt_wdma_mfsm	==	CUBE_RIMT_WDMA_DONE	;
/***********************************************************************************************************************/
	reg			[ 7: 0]					cube_rimt_edge_stat	;
	reg			[25: 0]					cube_rimt_arbt_tags	;
	reg			[ 2: 0]					cube_rimt_arbt_edge	;
	reg			[22: 0]					cube_rimt_rows_numb	;
	reg			[22: 0]					cube_rimt_rows_cnts	;
	reg									cube_rimt_ubus_wreq	;
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_rows_numb	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_rows_numb	<={	cube_rimt_wdma_rows	,	3'H0};
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_rows_cnts	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_rows_cnts	<=	0	;
	else if( cube_rimt_hits_reqs)		cube_rimt_rows_cnts	<=	cube_rimt_rows_cnts + 1	;

	assign		cube_rimt_meta_done	= &{cube_rimt_hits_loop	,	cube_rimt_rows_cnts	==	cube_rimt_rows_numb	};	
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_edge_stat	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_edge_stat	<=	0	;
	else if( cube_rimt_hits_seek)		cube_rimt_edge_stat	<=	cube_rimt_wdma_reqs[0]	?	8'H01	:
																cube_rimt_wdma_reqs[1]	?	8'H02	:
																cube_rimt_wdma_reqs[2]	?	8'H04	:
																cube_rimt_wdma_reqs[3]	?	8'H08	:
																cube_rimt_wdma_reqs[4]	?	8'H10	:
																cube_rimt_wdma_reqs[5]	?	8'H20	:
																cube_rimt_wdma_reqs[6]	?	8'H40	:
																cube_rimt_wdma_reqs[7]	?	8'H80	:	8'H00	;
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_arbt_tags	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_arbt_tags	<=	0	;
	else if( cube_rimt_hits_arbt)		cube_rimt_arbt_tags	<=	cube_rimt_edge_stat[0]	?	cube_rimt_wdma_tags[0]	:
																cube_rimt_edge_stat[1]	?	cube_rimt_wdma_tags[1]	:
																cube_rimt_edge_stat[2]	?	cube_rimt_wdma_tags[2]	:
																cube_rimt_edge_stat[3]	?	cube_rimt_wdma_tags[3]	:
																cube_rimt_edge_stat[4]	?	cube_rimt_wdma_tags[4]	:
																cube_rimt_edge_stat[5]	?	cube_rimt_wdma_tags[5]	:
																cube_rimt_edge_stat[6]	?	cube_rimt_wdma_tags[6]	:
																cube_rimt_edge_stat[7]	?	cube_rimt_wdma_tags[7]	:	0	;
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_arbt_edge	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_arbt_edge	<=	0	;
	else if( cube_rimt_hits_arbt)		cube_rimt_arbt_edge	<=	cube_rimt_edge_stat[0]	?	3'H0	:
																cube_rimt_edge_stat[1]	?	3'H1	:
																cube_rimt_edge_stat[2]	?	3'H2	:
																cube_rimt_edge_stat[3]	?	3'H3	:
																cube_rimt_edge_stat[4]	?	3'H4	:
																cube_rimt_edge_stat[5]	?	3'H5	:
																cube_rimt_edge_stat[6]	?	3'H6	:
																cube_rimt_edge_stat[7]	?	3'H7	:	0	;
//------------------------------------------------------------------------------
	assign	cube_rimt_wdma_acks[0]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H0};
	assign	cube_rimt_wdma_acks[1]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H1};
	assign	cube_rimt_wdma_acks[2]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H2};
	assign	cube_rimt_wdma_acks[3]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H3};
	assign	cube_rimt_wdma_acks[4]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H4};
	assign	cube_rimt_wdma_acks[5]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H5};
	assign	cube_rimt_wdma_acks[6]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H6};
	assign	cube_rimt_wdma_acks[7]	= &{cube_rimt_hits_acks ,	cube_rimt_arbt_edge	==	3'H7};
//------------------------------------------------------------------------------
	always@(posedge link_clki or negedge link_rstn)
	if(~link_rstn)						cube_rimt_ubus_wreq	<=	0	;
	else if(~cube_rimt_wdma_enab)		cube_rimt_ubus_wreq	<=	0	;
	else if( cube_rimt_hits_reqs)		cube_rimt_ubus_wreq	<=	1	;
	else 								cube_rimt_ubus_wreq	<=	0	;
/***********************************************************************************************************************/
	gens_edge_slow_fast				u_gens_ubus_rimt_reqs(
		.fast_edge						(ubus_rimt_wdma_reqs	),//output	
		.fast_clki						(ubus_clki				),//input	
		.fast_rstn						(ubus_rstn				),//input	
		.slow_sign						(cube_rimt_ubus_wreq	),//input	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				));//input	
//------------------------------------------------------------------------------
	gens_edge_fast_slow	#(.EXTN(5)	)
									u_gens_cube_rimt_wrdy(	
		.slow_edge						(cube_rimt_ubus_wrdy	),//output	
		.slow_clki						(link_clki				),//input	
		.slow_rstn						(link_rstn				),//input	

		.fast_sign						(ubus_rimt_wdma_wrdy	),//input
		.fast_clki						(ubus_clki				),//input
		.fast_rstn						(ubus_rstn				));//input
//------------------------------------------------------------------------------
	gens_sync_gray 		#(.MSB (25) )	
									u_gens_ubus_rimt_tags(
		.data_asyn						(cube_rimt_arbt_tags	),//input	[MSB: 0]	
		.scki							(link_clki				),//input				
		.data_sync						(ubus_rimt_wdma_tags	),//output	reg [MSB: 0]
		.clki							(ubus_clki				),//input				
		.rstn							(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	gens_sync_gray 		#(.MSB (2) )	
									u_gens_ubus_rimt_edge(
		.data_asyn						(cube_rimt_arbt_edge	),//input	[MSB: 0]	
		.scki							(link_clki				),//input				
		.data_sync						(ubus_rimt_wdma_edge	),//output	reg [MSB: 0]
		.clki							(ubus_clki				),//input				
		.rstn							(ubus_rstn				));//input				
/***********************************************************************************************************************/

endmodule 
