/*----author edward------
*/
module	cube_rimt_wdma_ctrl(
	output								cube_rimt_wdma_done	,
	input								cube_rimt_wdma_enab	,
	input		[19: 0]					cube_rimt_wdma_rows	,
	input		[19: 0]					cube_rimt_wdma_cols	,

	input		[ 0: 7]					cube_edge_rimt_rank	,
	input		[ 0: 7]					cube_edge_rimt_csen	,
	input		[ 0: 7][ 5: 0]			cube_edge_rimt_addr	,
	input		[ 0: 7][255:0]			cube_edge_rimt_data	,

	output		[ 0: 7]					cube_edge_rimt_acks	,
	input		[ 0: 7]					cube_edge_rimt_reqs	,
	input		[ 0: 7][25: 0]			cube_edge_rimt_tags	,
	input								link_clki			,
	input								link_rstn			,

	output								ubus_wdma_ddrs_csen	,
	output		[ 24: 0]				ubus_wdma_ddrs_addr	,
	output		[255: 0]				ubus_wdma_ddrs_data	,
	input								ubus_wdma_ddrs_trdy	,
	input								ubus_wdma_ddrs_wrdy	,
	input								ubus_clki			,
	input								ubus_rstn			);
/**********************************************************************************************************************/
	wire		[25: 0]					ubus_rimt_wdma_tags	;
	wire		[ 2: 0]					ubus_rimt_wdma_edge	;
		
	cube_rimt_wdma_arbt				u_cube_rimt_wdma_arbt(
		.cube_rimt_wdma_done			(cube_rimt_wdma_done	),//output						
		.cube_rimt_wdma_enab			(cube_rimt_wdma_enab	),//input						
		.cube_rimt_wdma_rows			(cube_rimt_wdma_rows	),//input		[19: 0]			

		.cube_rimt_wdma_acks			(cube_edge_rimt_acks	),//output		[ 0: 7]			
		.cube_rimt_wdma_reqs			(cube_edge_rimt_reqs	),//input		[ 0: 7]			
		.cube_rimt_wdma_tags			(cube_edge_rimt_tags	),//input		[ 0: 7][25: 0]	

		.link_clki						(link_clki				),//input						
		.link_rstn						(link_rstn				),//input						
	
		.ubus_rimt_wdma_reqs			(ubus_rimt_wdma_reqs	),//output				
		.ubus_rimt_wdma_edge			(ubus_rimt_wdma_edge	),//output		[ 2: 0]	
		.ubus_rimt_wdma_tags			(ubus_rimt_wdma_tags	),//output		[25: 0]	
		.ubus_rimt_wdma_wrdy			(ubus_rimt_wdma_wrdy	),//input				
		.ubus_clki						(ubus_clki				),//input				
		.ubus_rstn						(ubus_rstn				));//input				
//------------------------------------------------------------------------------
	cube_rimt_wdma_ubus				u_cube_rimt_wdma_ubus(
		.cube_rimt_wdma_enab			(cube_rimt_wdma_enab	),//input						
		.cube_rimt_wdma_cols			(cube_rimt_wdma_cols	),//input		[19: 0]			
		
		.cube_edge_rimt_rank			(cube_edge_rimt_rank	),//input		[ 0: 7]			
		.cube_edge_rimt_csen			(cube_edge_rimt_csen	),//input		[ 0: 7]			
		.cube_edge_rimt_addr			(cube_edge_rimt_addr	),//input		[ 0: 7][ 9: 0]	
		.cube_edge_rimt_data			(cube_edge_rimt_data	),//input		[ 0: 7][31: 0]	
		.link_clki						(link_clki				),//input						
		.link_rstn						(link_rstn				),//input						
	
		.ubus_rimt_wdma_reqs			(ubus_rimt_wdma_reqs	),//input				
		.ubus_rimt_wdma_edge			(ubus_rimt_wdma_edge	),//input		[ 2: 0]	
		.ubus_rimt_wdma_tags			(ubus_rimt_wdma_tags	),//input		[25: 0]	
		.ubus_rimt_wdma_wrdy			(ubus_rimt_wdma_wrdy	),//output				

		.ubus_wdma_ddrs_csen			(ubus_wdma_ddrs_csen	),//output					
		.ubus_wdma_ddrs_addr			(ubus_wdma_ddrs_addr	),//output	reg	[ 24: 0]	
		.ubus_wdma_ddrs_data			(ubus_wdma_ddrs_data	),//output		[255: 0]	
		.ubus_wdma_ddrs_trdy			(ubus_wdma_ddrs_trdy	),//input					
		.ubus_wdma_ddrs_wrdy			(ubus_wdma_ddrs_wrdy	),//input					
		.ubus_clki						(ubus_clki				),//input					
		.ubus_rstn						(ubus_rstn				));//input					
/**********************************************************************************************************************/
endmodule 
