/**********************************************************************************************************/
module noddr_ku35_fpga_core(
	output								init_bclk				,
	input								chip_clki				,
//-DECLARE MGT-SERDES RXIO----------------------------------------------
	input								mgt1_intf_link_stat		,
	output								mgt1_pmau_init_ctrl		,
	output								mgt1_rstb_push_ctrl		,
	input								mgt1_osde_rdma_trdy		,
	output								mgt1_osde_rdma_drdy		,
	output		[255:0]					mgt1_osde_rdma_data		,
	input								mgt1_clki				,
//-DECLARE TPGL IO------------------------------------------------------	
	input								tpgm_link_rstn_inpp	,
	input								tpgm_link_rstn_inpn	,
	input								tpgm_link_tune_txdo	,
	input								tpgm_link_tune_rxdi	,

	input								tpgm_link_fclk_inpp	,
	input								tpgm_link_fclk_inpn	,
	input								tpgm_link_fram_inpp	,
	input								tpgm_link_fram_inpn	,
	input								tpgm_link_dat0_inpp	,
	input								tpgm_link_dat0_inpn	,
	input								tpgm_link_dat1_inpp	,
	input								tpgm_link_dat1_inpn	,
	input								tpgm_link_dat2_inpp	,
	input								tpgm_link_dat2_inpn	,
	input								tpgm_link_dat3_inpp	,
	input								tpgm_link_dat3_inpn	,

	output								tpgs_link_fclk_outp	,
	output								tpgs_link_fclk_outn	,
	output								tpgs_link_fram_outp	,
	output								tpgs_link_fram_outn	,
	output								tpgs_link_dat0_outp	,
	output								tpgs_link_dat0_outn	,
	output								tpgs_link_dat1_outp	,
	output								tpgs_link_dat1_outn	,
	output								tpgs_link_dat2_outp	,
	output								tpgs_link_dat2_outn	,
	output								tpgs_link_dat3_outp	,
	output								tpgs_link_dat3_outn	,
//-DECLARE TPEL IO-------------------------------------------------
	output		[ 0: 7]					tpem_tune_txdo_mode	,
	output		[ 0: 7]					tpem_tune_rxdi_mode	,

	output		[ 0: 7]					tpem_link_rstn_outp	,
	input		[ 0: 7]					slx9_link_ilas_inpp	,

	output		[ 0: 7]					tpem_link_fclk_outp	,
	output		[ 0: 7]					tpem_link_fclk_outn	,
	output		[ 0: 7]					tpem_link_fram_outp	,
	output		[ 0: 7]					tpem_link_fram_outn	,
	output		[ 0: 7]					tpem_link_dat0_outp	,
	output		[ 0: 7]					tpem_link_dat0_outn	,
	output		[ 0: 7]					tpem_link_dat1_outp	,
	output		[ 0: 7]					tpem_link_dat1_outn	,
	output		[ 0: 7]					tpem_link_dat2_outp	,
	output		[ 0: 7]					tpem_link_dat2_outn	,
	output		[ 0: 7]					tpem_link_dat3_outp	,
	output		[ 0: 7]					tpem_link_dat3_outn	,

	input		[ 0: 7]					tpes_link_fclk_inpp	,
	input		[ 0: 7]					tpes_link_fclk_inpn	,
	input		[ 0: 7]					tpes_link_fram_inpp	,
	input		[ 0: 7]					tpes_link_fram_inpn	,
	input		[ 0: 7]					tpes_link_dat0_inpp	,
	input		[ 0: 7]					tpes_link_dat0_inpn	,
	input		[ 0: 7]					tpes_link_dat1_inpp	,
	input		[ 0: 7]					tpes_link_dat1_inpn	,
	input		[ 0: 7]					tpes_link_dat2_inpp	,
	input		[ 0: 7]					tpes_link_dat2_inpn	,
	input		[ 0: 7]					tpes_link_dat3_inpp	,
	input		[ 0: 7]					tpes_link_dat3_inpn	,

	output		[ 0: 7]					tpem_scfg_prog_outp	,
	output		[ 0: 7]					tpem_scfg_cclk_outp	,
	output		[ 0: 7]					tpem_scfg_data_outp	,
	input		[ 0: 7]					tpem_scfg_init_inpp	,
	input		[ 0: 7]					tpem_scfg_done_inpp	);
/**********************************************************************************************************/
	wire								tpgm_rstn_csen	;
	wire								tpgm_tune_csen	;

	IBUFDS							u_TPGM_RSTN_IPAD (
		.O								(tpgm_rstn_csen			), 
		.I								(tpgm_link_rstn_inpp	),
		.IB								(tpgm_link_rstn_inpn	));	

//	IBUFDS							u_TPGM_TUNE_IPAD (
//		.O								(tpgm_tune_csen			), 
//		.I								(tpgm_link_tune_inpp	),
//		.IB								(tpgm_link_tune_inpn	));	

/**********************************************************************************************************/
	wire								link_fclk	;
	wire								link_strb	;
	wire								link_sclk	;
	wire								link_rstn	;
	wire								chip_rstn	;
	wire								dlys_rstn	;
	wire								ubus_clki	;
	wire								ubus_rstn	;
	

	xcku_sysclk						u_xcku_clks_gens(	
		.link_fclk						(link_fclk				),//output	
		.link_sclk						(link_sclk				),//output	
		.init_bclk						(init_bclk				),//output	

		.link_rstn						(link_rstn				),//output	
		.chip_rstn						(chip_rstn				),//output	
		.dlys_rstn						(dlys_rstn				),//output	

		.ubus_clko						(ubus_clki				),//output	
		.ubus_rstn						(ubus_rstn				),//output	
			
		.auxi_rstn						(1'b1					),//input	
		.cold_rstn						(tpgm_rstn_csen			),//input	
		.chip_clki						(chip_clki				));//input	
//------------------------------------------------------------------------------
	wire								dlys_brst			;
	wire								tpgs_dlys_ctrl_drdy	;

	ku35_dlys_ctrl					u_ku35_dlys_ctrl(
		.dlys_brst						(dlys_brst			),//output		reg	
		.dlys_drdy						(tpgs_dlys_ctrl_drdy),//output			
		.dlys_fclk						(link_fclk			),//input			
		.dlys_sclk						(link_sclk			),//input			
		.dlys_rstn						(dlys_rstn			));//input	
/**********************************************************************************************************/
	(*MARK_DEBUG = "TRUE"*)				reg		[ 0: 7]		ilas_slx9_moni	;//=	slx9_link_ilas_inpp	;
	always@(posedge link_sclk)			ilas_slx9_moni	<=	slx9_link_ilas_inpp	;
/***********************************************************************************************************/
//DECLARE TPGL_SALVE_LINK
	wire		[7:0]					tpgs_port_txdo_fram	;
	wire		[7:0]					tpgs_port_txdo_dat0	;
	wire		[7:0]					tpgs_port_txdo_dat1	;
	wire		[7:0]					tpgs_port_txdo_dat2	;
	wire		[7:0]					tpgs_port_txdo_dat3	;

	wire		[7:0]					tpgs_port_rxdi_fram	;
	wire		[7:0]					tpgs_port_rxdi_dat0	;
	wire		[7:0]					tpgs_port_rxdi_dat1	;
	wire		[7:0]					tpgs_port_rxdi_dat2	;
	wire		[7:0]					tpgs_port_rxdi_dat3	;


	wire		[ 7: 0]					tune_txdo_acks_fram	;
	wire		[ 7: 0]					tune_txdo_acks_dat3	;
	wire		[ 7: 0]					tune_txdo_acks_dat2	;
	wire		[ 7: 0]					tune_txdo_acks_dat1	;
	wire		[ 7: 0]					tune_txdo_acks_dat0	;


	gens_sync_rstn					tpgs_rstn_gens(
    	.rstn_gens						(tpgs_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/***********************************************************************************************************/
	link_hubs_rxdi_pmau				u_tpgs_link_rxdi_pmau(
		.lane_fclk_inpp					(tpgm_link_fclk_inpp	),//input	
		.lane_fclk_inpn					(tpgm_link_fclk_inpn	),//input	
		.lane_fram_inpp					(tpgm_link_fram_inpp	),//input	
		.lane_fram_inpn					(tpgm_link_fram_inpn	),//input	
		.lane_dat0_inpp					(tpgm_link_dat0_inpp	),//input	
		.lane_dat0_inpn					(tpgm_link_dat0_inpn	),//input	
		.lane_dat1_inpp					(tpgm_link_dat1_inpp	),//input	
		.lane_dat1_inpn					(tpgm_link_dat1_inpn	),//input	
		.lane_dat2_inpp					(tpgm_link_dat2_inpp	),//input	
		.lane_dat2_inpn					(tpgm_link_dat2_inpn	),//input	
		.lane_dat3_inpp					(tpgm_link_dat3_inpp	),//input	
		.lane_dat3_inpn					(tpgm_link_dat3_inpn	),//input	

		.root_tune_txdo					(tpgm_link_tune_txdo	),//input

		.pmau_fram_rxdi					(tpgs_port_rxdi_fram 	),//output	reg	[ 7: 0]	
		.pmau_dat0_rxdi					(tpgs_port_rxdi_dat0 	),//output	reg	[ 7: 0]	
		.pmau_dat1_rxdi					(tpgs_port_rxdi_dat1 	),//output	reg	[ 7: 0]	
		.pmau_dat2_rxdi					(tpgs_port_rxdi_dat2 	),//output	reg	[ 7: 0]	
		.pmau_dat3_rxdi					(tpgs_port_rxdi_dat3 	),//output	reg	[ 7: 0]	

		.tune_rack_fram					(tune_txdo_acks_fram	),//output		[ 7: 0]	
		.tune_rack_dat3					(tune_txdo_acks_dat3	),//output		[ 7: 0]	
		.tune_rack_dat2					(tune_txdo_acks_dat2	),//output		[ 7: 0]	
		.tune_rack_dat1					(tune_txdo_acks_dat1	),//output		[ 7: 0]	
		.tune_rack_dat0					(tune_txdo_acks_dat0	),//output		[ 7: 0]	

		.link_sclk						( link_sclk				),//input	
		.link_rstn						( tpgs_rstn				));//input	

	link_hubs_txdo_pmau				u_tpgs_link_txdo_pmau(
		
		.lane_fclk_outp					(tpgs_link_fclk_outp	),//output			
		.lane_fclk_outn					(tpgs_link_fclk_outn	),//output			
		.lane_fram_outp					(tpgs_link_fram_outp	),//output			
		.lane_fram_outn					(tpgs_link_fram_outn	),//output			
		.lane_dat0_outp					(tpgs_link_dat0_outp	),//output			
		.lane_dat0_outn					(tpgs_link_dat0_outn	),//output			
		.lane_dat1_outp					(tpgs_link_dat1_outp	),//output			
		.lane_dat1_outn					(tpgs_link_dat1_outn	),//output			
		.lane_dat2_outp					(tpgs_link_dat2_outp	),//output			
		.lane_dat2_outn					(tpgs_link_dat2_outn	),//output			
		.lane_dat3_outp					(tpgs_link_dat3_outp	),//output			
		.lane_dat3_outn					(tpgs_link_dat3_outn	),//output			

		.root_tune_rxdi					(tpgm_link_tune_rxdi	),//input

		.pmau_fram_txdo					(tpgs_port_txdo_fram	),//input	[7:0]	
		.pmau_dat0_txdo					(tpgs_port_txdo_dat0	),//input	[7:0]	
		.pmau_dat1_txdo					(tpgs_port_txdo_dat1	),//input	[7:0]	
		.pmau_dat2_txdo					(tpgs_port_txdo_dat2	),//input	[7:0]	
		.pmau_dat3_txdo					(tpgs_port_txdo_dat3	),//input	[7:0]	

		.tune_rack_fram					(tune_txdo_acks_fram	),//output		[ 7: 0]	
		.tune_rack_dat3					(tune_txdo_acks_dat3	),//output		[ 7: 0]	
		.tune_rack_dat2					(tune_txdo_acks_dat2	),//output		[ 7: 0]	
		.tune_rack_dat1					(tune_txdo_acks_dat1	),//output		[ 7: 0]	
		.tune_rack_dat0					(tune_txdo_acks_dat0	),//output		[ 7: 0]	

		.link_fclk						( link_fclk				),//input	
		.link_sclk						( link_sclk				),//input	
		.link_rstn						( tpgs_rstn				));//input	
//----------------------------------------------------------------------
//DECLARE TPEL_MASTER_LINK
	wire	[ 0: 7]						tpem_link_port_rstn	;
	wire	[ 0: 7]						tpem_link_port_rxen	;
	
	wire	[ 0: 7]						tpem_port_rxdi_fclk	;
	wire	[ 0: 7]						tpem_port_rxdi_clki	;
	
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_fram	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat3	;

	wire	[ 7: 0]						tpem_port_rxdi_lead	;
	wire	[ 7: 0]						tpem_port_rxdi_body	;
	wire	[ 7: 0]						tpem_port_rxdi_coda	;

	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat3	;

	wire	[ 0: 7]						tpem_tune_txdo_done	;
	wire	[ 0: 7]						tpem_tune_txdo_enab	;
	wire	[ 0: 7][8: 0]				tpem_tune_txdo_taps	;
	
	wire	[ 0: 7]						tpem_tune_rxdi_reqs	;
	wire	[ 0: 7]						tpem_tune_rxdi_done	;
	wire	[ 0: 7]						tpem_tune_rxdi_enab	;
	wire	[ 0: 7][ 8: 0]				tpem_tune_rxdi_taps	;
	wire	[ 0: 7][ 9: 0]				tpem_tune_rxdi_stat	;

	wire								tpem_sync_rxdi_reqs	;
	wire	[ 0: 7]						tpem_sync_rxdi_done	;

	wire	[ 0: 7][ 7: 0]				tpem_idly_fram_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat0_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat1_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat2_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat3_patn	;

	gens_sync_rstn					tpem_rstn_gens(
    	.rstn_gens						(tpem_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/**********************************************************************************************************************/
for(genvar i = 0 ; i < 8 ; i++)		begin:gens_tpem_link_port

	assign	tpem_link_rstn_outp[i]	=	tpem_link_port_rstn[i] & tpem_rstn	;
//	assign	tpem_link_rstn_outn[i]	= ~	tpem_link_rstn_outp[i]	;

	link_edge_rxdi_pmau			u_tpem_link_rxdi_pmau(
		
		.host_tune_rxdi_mode			(tpem_tune_rxdi_reqs[i]	),//input				
		.host_tune_rxdi_enab			(tpem_tune_rxdi_enab[i]	),//input				
		.host_tune_rxdi_taps			(tpem_tune_rxdi_taps[i]	),//input		[ 8: 0]	
		.host_tune_rxdi_done			(tpem_tune_rxdi_done[i]	),//output				
		.host_tune_rxdi_stat			(tpem_tune_rxdi_stat[i]	),//output		[ 9: 0]	

		.host_sync_rxdi_reqs			(tpem_sync_rxdi_reqs	),//output		[10: 0]	
		.host_sync_rxdi_done			(tpem_sync_rxdi_done[i]	),//output				

		.host_data_rxdi_enab			(tpem_link_port_rxen[i]	),//output	[ 0: 7]

		.host_clki						(link_sclk				),//input				
		.host_rstn						(link_rstn				),//input				

		.lane_tune_rxdi					(tpem_tune_rxdi_mode[i]	),//output	to fpga PINS

		.lane_fclk_inpp					(tpes_link_fclk_inpp[i]	),//input	
		.lane_fclk_inpn					(tpes_link_fclk_inpn[i]	),//input	
		.lane_fram_inpp					(tpes_link_fram_inpp[i]	),//input	
		.lane_fram_inpn					(tpes_link_fram_inpn[i]	),//input	
		.lane_dat0_inpp					(tpes_link_dat0_inpp[i]	),//input	
		.lane_dat0_inpn					(tpes_link_dat0_inpn[i]	),//input	
		.lane_dat1_inpp					(tpes_link_dat1_inpp[i]	),//input	
		.lane_dat1_inpn					(tpes_link_dat1_inpn[i]	),//input	
		.lane_dat2_inpp					(tpes_link_dat2_inpp[i]	),//input	
		.lane_dat2_inpn					(tpes_link_dat2_inpn[i]	),//input	
		.lane_dat3_inpp					(tpes_link_dat3_inpp[i]	),//input	
		.lane_dat3_inpn					(tpes_link_dat3_inpn[i]	),//input	

		.pmau_fram_lead					(tpem_port_rxdi_lead[i]	),//output	reg	[ 7: 0]	
		.pmau_fram_body					(tpem_port_rxdi_body[i]	),//output	reg	[ 7: 0]	
		.pmau_fram_coda					(tpem_port_rxdi_coda[i]	),//output	reg	[ 7: 0]	
		.pmau_dat0_mbdo					(tpem_port_rxdi_dat0[i]	),//output	reg	[ 7: 0]	
		.pmau_dat1_mbdo					(tpem_port_rxdi_dat1[i]	),//output	reg	[ 7: 0]	
		.pmau_dat2_mbdo					(tpem_port_rxdi_dat2[i]	),//output	reg	[ 7: 0]	
		.pmau_dat3_mbdo					(tpem_port_rxdi_dat3[i]	),//output	reg	[ 7: 0]	

		.dlys_brst						( dlys_brst				),//output	
		.link_sclk						( link_sclk				),//input	
		.link_rstn						( tpem_rstn				));//input	

	link_edge_txdo_pmau				u_tpem_link_txdo_pmau(
		.host_tune_txdo_enab			(tpem_tune_txdo_enab[i]		),//input				
		.host_tune_txdo_taps			(tpem_tune_txdo_taps[i]		),//input		[ 8: 0]	
		.host_tune_txdo_done			(tpem_tune_txdo_done[i]		),//output				
		.host_clki						(link_sclk				),//input				
		.host_rstn						(link_rstn				),//input				

		.root_tune_txdo					(tpem_tune_txdo_mode[i]	),

		.lane_fclk_outp					(tpem_link_fclk_outp[i]	),//output			
		.lane_fclk_outn					(tpem_link_fclk_outn[i]	),//output			
		.lane_fram_outp					(tpem_link_fram_outp[i]	),//output			
		.lane_fram_outn					(tpem_link_fram_outn[i]	),//output			
		.lane_dat0_outp					(tpem_link_dat0_outp[i]	),//output			
		.lane_dat0_outn					(tpem_link_dat0_outn[i]	),//output			
		.lane_dat1_outp					(tpem_link_dat1_outp[i]	),//output			
		.lane_dat1_outn					(tpem_link_dat1_outn[i]	),//output			
		.lane_dat2_outp					(tpem_link_dat2_outp[i]	),//output			
		.lane_dat2_outn					(tpem_link_dat2_outn[i]	),//output			
		.lane_dat3_outp					(tpem_link_dat3_outp[i]	),//output			
		.lane_dat3_outn					(tpem_link_dat3_outn[i]	),//output		

		.pmau_fram_mbdi					(tpem_port_txdo_fram[i]	),//output	[7:0]	
		.pmau_dat0_mbdi					(tpem_port_txdo_dat0[i]	),//output	[7:0]	
		.pmau_dat1_mbdi					(tpem_port_txdo_dat1[i]	),//output	[7:0]	
		.pmau_dat2_mbdi					(tpem_port_txdo_dat2[i]	),//output	[7:0]	
		.pmau_dat3_mbdi					(tpem_port_txdo_dat3[i]	),//output	[7:0]	

//		.dlys_brst						( dlys_brst				),//output	
		.link_fclk						( link_fclk				),//input	
		.link_sclk						( link_sclk				),//input	
		.link_rstn						( tpem_rstn				));//input	
end
/***********************************************************************************************************/
//LPDDR3 CONTROLLER-----------------------------------------------------------------------------------------
	wire								ddrs_ubus_intf_trdy	;
	wire								ddrs_ubus_intf_wrdy	;

	wire								ddrs_ubus_wdma_csen	;								
	wire		[15: 0]					ddrs_ubus_wdma_addr	;
	wire		[255:0]					ddrs_ubus_wdma_data	;

	wire								ddrs_ubus_rdma_csen	;								
	wire		[15: 0]					ddrs_ubus_rdma_addr	;
	wire		[255:0]					ddrs_ubus_rdma_data	;
	wire								ddrs_ubus_rdma_drdy	;								
	
    XCKU_02MB_URAM 					u_ku35_02mb_bram(
		.uram_trdy      				(ddrs_ubus_intf_trdy		),
        .uram_wrdy	    				(ddrs_ubus_intf_wrdy		),
         
        .uram_wrcs      				(ddrs_ubus_wdma_csen		),
        .uram_wadd	    				(ddrs_ubus_wdma_addr		),
        .uram_wdat	    				(ddrs_ubus_wdma_data		),

        .uram_rdcs      				(ddrs_ubus_rdma_csen		),
        .uram_radd    					(ddrs_ubus_rdma_addr		),
        .uram_rdat    					(ddrs_ubus_rdma_data		),
        .uram_drdy						(ddrs_ubus_rdma_drdy		),
		.uram_clki	       				(ubus_clki					),
        .uram_rstn         				(ubus_rstn					));


	wire								ubus_tpgs_wdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_wdma_addr	;
	wire		[255: 0]				ubus_tpgs_wdma_data	;
	wire								ubus_tpgs_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgs_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpem_wdma_csen	;	
	wire		[ 24: 0]				ubus_tpem_wdma_addr	;	
	wire		[255: 0]				ubus_tpem_wdma_data	;	
	wire								ubus_tpem_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpem_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpgs_rdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_rdma_addr	;
	wire								ubus_tpgs_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpgs_rdma_data	=	ddrs_ubus_rdma_data	;
	wire								ubus_tpgs_rdma_drdy	=	ddrs_ubus_rdma_drdy	;

	wire								ubus_tpem_rdma_csen	;
	wire		[ 24: 0]				ubus_tpem_rdma_addr	;
	wire								ubus_tpem_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpem_rdma_data	=	ddrs_ubus_rdma_data	;
	wire								ubus_tpem_rdma_drdy	=	ddrs_ubus_rdma_drdy	;

	wire								ubus_osde_rdma_csen	;
	wire		[ 24: 0]				ubus_osde_rdma_addr	;
	wire								ubus_osde_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_osde_rdma_data	=	ddrs_ubus_rdma_data	;
	wire								ubus_osde_rdma_drdy	=	ddrs_ubus_rdma_drdy	;
	
	assign	ddrs_ubus_wdma_csen	= 		ubus_tpgs_wdma_csen	|	ubus_tpem_wdma_csen	;
	assign	ddrs_ubus_rdma_csen	= 		ubus_tpgs_rdma_csen	|	ubus_tpem_rdma_csen	|	ubus_osde_rdma_csen	;
	
	assign	ddrs_ubus_wdma_addr	=		ubus_tpgs_wdma_csen	? 	ubus_tpgs_wdma_addr[15:0]	:
										ubus_tpem_wdma_csen	? 	ubus_tpem_wdma_addr[15:0]	:	16'H0	;

	assign	ddrs_ubus_rdma_addr	=		ubus_tpgs_rdma_csen	?	ubus_tpgs_rdma_addr[15:0]	:
										ubus_tpem_rdma_csen	?	ubus_tpem_rdma_addr[15:0]	:
										ubus_osde_rdma_csen	?	ubus_osde_rdma_addr[15:0]	:	16'H0	;	

	assign	ddrs_ubus_wdma_data	=		ubus_tpgs_wdma_csen	?	ubus_tpgs_wdma_data			:
										ubus_tpem_wdma_csen	?	ubus_tpem_wdma_data			:	256'H0	;
/**********************************************************************************************************/
//TPUC CONTROLLER-----------------------------------------------------------------------------------------
	
	gens_sync_rstn					tpus_rstn_gens(
    	.rstn_gens						(tpus_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		

	tpus_hubs_link_unit				u_tpus_hubs_link_unit(
		.tpus_link_ddrs_stat			(tpus_link_ddrs_stat	),//input
		.tpem_link_port_rstn			(tpem_link_port_rstn	),//output	[ 0: 7]
		.tpem_link_port_rxen			(tpem_link_port_rxen	),//output	[ 0: 7]

		.tpem_tune_txdo_mode			(tpem_tune_txdo_mode	),//output	[ 0: 7]			
		.tpem_tune_rxdi_mode			(tpem_tune_rxdi_reqs	),//output	[ 0: 7]			

		.tpem_tune_txdo_done			(tpem_tune_txdo_done	),//input	[ 0: 7]	
		.tpem_tune_txdo_enab			(tpem_tune_txdo_enab	),//output	[ 0: 7]			
		.tpem_tune_txdo_taps			(tpem_tune_txdo_taps	),//output	[ 0: 7][8: 0]	

		.tpem_tune_rxdi_done			(tpem_tune_rxdi_done	),//input	[ 0: 7]
		.tpem_tune_rxdi_enab			(tpem_tune_rxdi_enab	),//output	[ 0: 7]			
		.tpem_tune_rxdi_taps			(tpem_tune_rxdi_taps	),//output	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_stat			(tpem_tune_rxdi_stat	),//input	[ 0: 7][ 9: 0]	

		.tpem_sync_rxdi_reqs			(tpem_sync_rxdi_reqs	),//output	reg			
		.tpem_sync_rxdi_done			(tpem_sync_rxdi_done	),//input		[ 0: 7]	
		
		.tpgs_port_txdo_fram			(tpgs_port_txdo_fram	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat0			(tpgs_port_txdo_dat0	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat1			(tpgs_port_txdo_dat1	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat2			(tpgs_port_txdo_dat2	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat3			(tpgs_port_txdo_dat3	),//output		[ 7: 0]	

		.tpgs_port_rxdi_fram			(tpgs_port_rxdi_fram	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat0			(tpgs_port_rxdi_dat0	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat1			(tpgs_port_rxdi_dat1	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat2			(tpgs_port_rxdi_dat2	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat3			(tpgs_port_rxdi_dat3	),//input		[ 7: 0]	

		.tpem_port_txdo_fram			(tpem_port_txdo_fram	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat0			(tpem_port_txdo_dat0	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat1			(tpem_port_txdo_dat1	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat2			(tpem_port_txdo_dat2	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat3			(tpem_port_txdo_dat3	),//output		[ 0: 7][ 7: 0]	

		.tpem_port_rxdi_lead			(tpem_port_rxdi_lead	),//input		[ 7: 0]	
		.tpem_port_rxdi_body			(tpem_port_rxdi_body	),//input		[ 7: 0]	
		.tpem_port_rxdi_coda			(tpem_port_rxdi_coda	),//input		[ 7: 0]	

		.tpem_port_rxdi_dat0			(tpem_port_rxdi_dat0	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat1			(tpem_port_rxdi_dat1	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat2			(tpem_port_rxdi_dat2	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat3			(tpem_port_rxdi_dat3	),//input		[ 0: 7][ 7: 0]	

		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]			
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]			
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]			
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]			
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	),//input		[ 0: 7]			

		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output				
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output				
		.mgt1_osde_rdma_trdy			(mgt1_osde_rdma_trdy	),//input				
		.mgt1_osde_rdma_drdy			(mgt1_osde_rdma_drdy	),//output				
		.mgt1_osde_rdma_data			(mgt1_osde_rdma_data	),//output		[255: 0]
		.mgt1_clki						(mgt1_clki				),//input				
		.mgt1_rstn						(tpus_rstn				),//input				

		.ubus_tpgs_wdma_csen			(ubus_tpgs_wdma_csen	),//output					
		.ubus_tpgs_wdma_addr			(ubus_tpgs_wdma_addr	),//output		[ 24: 0]	
		.ubus_tpgs_wdma_data			(ubus_tpgs_wdma_data	),//output		[255: 0]	
		.ubus_tpgs_wdma_trdy			(ubus_tpgs_wdma_trdy	),//input					
		.ubus_tpgs_wdma_wrdy			(ubus_tpgs_wdma_wrdy	),//input					

		.ubus_tpgs_rdma_csen			(ubus_tpgs_rdma_csen	),//output	reg				
		.ubus_tpgs_rdma_addr			(ubus_tpgs_rdma_addr	),//output	reg	[ 24: 0]	
		.ubus_tpgs_rdma_trdy			(ubus_tpgs_rdma_trdy	),//input					
		.ubus_tpgs_rdma_data			(ubus_tpgs_rdma_data	),//input		[255: 0]	
		.ubus_tpgs_rdma_drdy			(ubus_tpgs_rdma_drdy	),//input					

		.ubus_tpem_wdma_csen			(ubus_tpem_wdma_csen	),//output					
		.ubus_tpem_wdma_addr			(ubus_tpem_wdma_addr	),//output		[ 24: 0]	
		.ubus_tpem_wdma_data			(ubus_tpem_wdma_data	),//output		[255: 0]	
		.ubus_tpem_wdma_trdy			(ubus_tpem_wdma_trdy	),//input					
		.ubus_tpem_wdma_wrdy			(ubus_tpem_wdma_wrdy	),//input					

		.ubus_tpem_rdma_csen			(ubus_tpem_rdma_csen	),//output					
		.ubus_tpem_rdma_addr			(ubus_tpem_rdma_addr	),//output		[ 24: 0]	
		.ubus_tpem_rdma_trdy			(ubus_tpem_rdma_trdy	),//input					
		.ubus_tpem_rdma_data			(ubus_tpem_rdma_data	),//input		[255: 0]	
		.ubus_tpem_rdma_drdy			(ubus_tpem_rdma_drdy	),//input					

		.ubus_osde_rdma_csen			(ubus_osde_rdma_csen	),//output					
		.ubus_osde_rdma_addr			(ubus_osde_rdma_addr	),//output		[ 24: 0]	
		.ubus_osde_rdma_trdy			(ubus_osde_rdma_trdy	),//input					
		.ubus_osde_rdma_data			(ubus_osde_rdma_data	),//input		[255: 0]	
		.ubus_osde_rdma_drdy			(ubus_osde_rdma_drdy	),//input					

		.tpgs_dlys_ctrl_drdy			(tpgs_dlys_ctrl_drdy	),

		.link_sclk						(link_sclk				),//input
		.ubus_clki						(ubus_clki				),//input
		.link_rstn						(tpus_rstn				),//input
		.ubus_rstn						(tpus_rstn				));//input

endmodule
	
/*

	wire								ddrs_ubus_intf_csen	;			
	wire		[  2: 0]				ddrs_ubus_intf_cmnd	;		
	wire		[ 27: 0]				ddrs_ubus_intf_addr	;		
	wire								ddrs_ubus_writ_enab	;			
	wire		[255: 0]				ddrs_ubus_writ_data	;		
	wire		[ 31: 0]				ddrs_ubus_writ_mask	;		
	wire								ddrs_ubus_writ_last	;			
	wire		[255: 0]				ddrs_ubus_read_data	;		
	wire								ddrs_ubus_read_vlid	;		
	wire								ddrs_ubus_read_last	;		

	wire								ubus_tpgs_wdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_wdma_addr	;
	wire		[255: 0]				ubus_tpgs_wdma_data	;
	wire								ubus_tpgs_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgs_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpgs_rdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_rdma_addr	;
	wire								ubus_tpgs_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpgs_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpgs_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_tpem_wdma_csen	;	
	wire		[ 24: 0]				ubus_tpem_wdma_addr	;	
	wire		[255: 0]				ubus_tpem_wdma_data	;	
	wire								ubus_tpem_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpem_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpem_rdma_csen	;
	wire		[ 24: 0]				ubus_tpem_rdma_addr	;
	wire								ubus_tpem_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpem_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpem_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_osde_rdma_csen	;
	wire		[ 24: 0]				ubus_osde_rdma_addr	;
	wire								ubus_osde_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_osde_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_osde_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_wdma_intf_csen	;
	wire								ubus_rdma_intf_csen	;
	
	assign	ubus_wdma_intf_csen	= 		ubus_tpgs_wdma_csen	|	ubus_tpem_wdma_csen	;
	assign	ubus_rdma_intf_csen	= 		ubus_tpgs_rdma_csen	|	ubus_tpem_rdma_csen	|	ubus_osde_rdma_csen	;
	assign	ddrs_ubus_intf_csen	=		ubus_wdma_intf_csen	|	ubus_rdma_intf_csen	;

	assign	ddrs_ubus_writ_enab	= 		ubus_wdma_intf_csen	;

	assign	ddrs_ubus_intf_addr	=		ubus_tpgs_wdma_csen	? {	ubus_tpgs_wdma_addr	, 3'H0}	:
										ubus_tpem_wdma_csen	? {	ubus_tpem_wdma_addr	, 3'H0}	:
										ubus_tpgs_rdma_csen	? {	ubus_tpgs_rdma_addr	, 3'H0}	:
										ubus_tpem_rdma_csen	? {	ubus_tpem_rdma_addr	, 3'H0}	:
										ubus_osde_rdma_csen	? {	ubus_osde_rdma_addr	, 3'H0}	:	 28'H0	;	

	assign	ddrs_ubus_writ_data	=		ubus_tpgs_wdma_csen	?	ubus_tpgs_wdma_data	:
										ubus_tpem_wdma_csen	?	ubus_tpem_wdma_data	:	256'H0	;

	assign	ddrs_ubus_intf_cmnd	=		ubus_wdma_intf_csen	?	3'H0	:	3'H1	;
	assign	ddrs_ubus_writ_last	= 		ubus_wdma_intf_csen	;
	assign	ddrs_ubus_writ_mask	=		32'H0				;	

	wire								ubus_prst			;
	wire								ubus_rstn	= ~ubus_prst	;


*/