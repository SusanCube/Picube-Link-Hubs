/**********************************************************************************************************/
module ku35_fpga_duts(
	input							chip_clki			,
//-DECLARE AURORA IO----------------------------------------------------
	output							mgt1_osde_rdma_drdy		,
	output		[255:0]				mgt1_osde_rdma_data		,
	input							mgt1_clki				,
//-DECLARE TPGL IO------------------------------------------------------	
	input							tpgm_link_rstn_inpp	,
	input							tpgm_link_rstn_inpn	,
	
	input							tpgm_link_tune_txdo	,
	input							tpgm_link_tune_rxdi	,

	input							tpgm_link_fclk_inpp	,
	input							tpgm_link_fclk_inpn	,
	input							tpgm_link_fram_inpp	,
	input							tpgm_link_fram_inpn	,
	input							tpgm_link_dat0_inpp	,
	input							tpgm_link_dat0_inpn	,
	input							tpgm_link_dat1_inpp	,
	input							tpgm_link_dat1_inpn	,
	input							tpgm_link_dat2_inpp	,
	input							tpgm_link_dat2_inpn	,
	input							tpgm_link_dat3_inpp	,
	input							tpgm_link_dat3_inpn	,

	output							tpgs_link_fclk_outp	,
	output							tpgs_link_fclk_outn	,
	output							tpgs_link_fram_outp	,
	output							tpgs_link_fram_outn	,
	output							tpgs_link_dat0_outp	,
	output							tpgs_link_dat0_outn	,
	output							tpgs_link_dat1_outp	,
	output							tpgs_link_dat1_outn	,
	output							tpgs_link_dat2_outp	,
	output							tpgs_link_dat2_outn	,
	output							tpgs_link_dat3_outp	,
	output							tpgs_link_dat3_outn	);
/***********************************************************************************************************/
	wire		[ 0: 7]					tpem_link_rstn_outp	;

	wire		[ 0: 7]					tpem_tune_txdo_mode	;
	wire		[ 0: 7]					tpem_tune_rxdi_mode	;
	
	wire		[ 0: 7]					tpem_scfg_prog_outp	;
	wire		[ 0: 7]					tpem_scfg_cclk_outp	;
	wire		[ 0: 7]					tpem_scfg_data_outp	;
	wire		[ 0: 7]					tpem_scfg_init_inpp	;
	wire		[ 0: 7]					tpem_scfg_done_inpp	;

	wire		[0:7][3:0]				tpem_scfg_fpga_indx	;

	assign		tpem_scfg_fpga_indx[0]	=	4'H0	;	
	assign		tpem_scfg_fpga_indx[1]	=	4'H1	;	
	assign		tpem_scfg_fpga_indx[2]	=	4'H2	;	
	assign		tpem_scfg_fpga_indx[3]	=	4'H3	;	
	assign		tpem_scfg_fpga_indx[4]	=	4'H4	;	
	assign		tpem_scfg_fpga_indx[5]	=	4'H5	;	
	assign		tpem_scfg_fpga_indx[6]	=	4'H6	;	
	assign		tpem_scfg_fpga_indx[7]	=	4'H7	;	

	
	wire			[ 0: 7]					tpem_link_fclk_outp	;
	wire			[ 0: 7]					tpem_link_fclk_outn	;
	wire			[ 0: 7]					tpem_link_fram_outp	;
	wire			[ 0: 7]					tpem_link_fram_outn	;
	wire			[ 0: 7]					tpem_link_dat0_outp	;
	wire			[ 0: 7]					tpem_link_dat0_outn	;
	wire			[ 0: 7]					tpem_link_dat1_outp	;
	wire			[ 0: 7]					tpem_link_dat1_outn	;
	wire			[ 0: 7]					tpem_link_dat2_outp	;
	wire			[ 0: 7]					tpem_link_dat2_outn	;
	wire			[ 0: 7]					tpem_link_dat3_outp	;
	wire			[ 0: 7]					tpem_link_dat3_outn	;
	
	wire			[ 0: 7]					tpes_link_fclk_inpp	;
	wire			[ 0: 7]					tpes_link_fclk_inpn	;
	wire			[ 0: 7]					tpes_link_fram_inpp	;
	wire			[ 0: 7]					tpes_link_fram_inpn	;
	wire			[ 0: 7]					tpes_link_dat0_inpp	;
	wire			[ 0: 7]					tpes_link_dat0_inpn	;
	wire			[ 0: 7]					tpes_link_dat1_inpp	;
	wire			[ 0: 7]					tpes_link_dat1_inpn	;
	wire			[ 0: 7]					tpes_link_dat2_inpp	;
	wire			[ 0: 7]					tpes_link_dat2_inpn	;
	wire			[ 0: 7]					tpes_link_dat3_inpp	;
	wire			[ 0: 7]					tpes_link_dat3_inpn	;

	wire			[ 0: 7]					tpem_link_fclk_inpp	;
	wire			[ 0: 7]					tpem_link_fclk_inpn	;
	wire			[ 0: 7]					tpem_link_fram_inpp	;
	wire			[ 0: 7]					tpem_link_fram_inpn	;
	wire			[ 0: 7]					tpem_link_dat0_inpp	;
	wire			[ 0: 7]					tpem_link_dat0_inpn	;
	wire			[ 0: 7]					tpem_link_dat1_inpp	;
	wire			[ 0: 7]					tpem_link_dat1_inpn	;
	wire			[ 0: 7]					tpem_link_dat2_inpp	;
	wire			[ 0: 7]					tpem_link_dat2_inpn	;
	wire			[ 0: 7]					tpem_link_dat3_inpp	;
	wire			[ 0: 7]					tpem_link_dat3_inpn	;

	wire			[ 0: 7]					tpes_link_fclk_outp	;
	wire			[ 0: 7]					tpes_link_fclk_outn	;
	wire			[ 0: 7]					tpes_link_fram_outp	;
	wire			[ 0: 7]					tpes_link_fram_outn	;
	wire			[ 0: 7]					tpes_link_dat0_outp	;
	wire			[ 0: 7]					tpes_link_dat0_outn	;
	wire			[ 0: 7]					tpes_link_dat1_outp	;
	wire			[ 0: 7]					tpes_link_dat1_outn	;
	wire			[ 0: 7]					tpes_link_dat2_outp	;
	wire			[ 0: 7]					tpes_link_dat2_outn	;
	wire			[ 0: 7]					tpes_link_dat3_outp	;
	wire			[ 0: 7]					tpes_link_dat3_outn	;


for(genvar i = 0 ; i < 8 ; i++) begin	:	gens_tpgs_tpem_link

//	buf #0.0	buf_00		(	tpes_link_fclk_inpp[i]	,	tpem_link_fclk_outp[i]	);
//	buf #0.0	buf_01		(	tpes_link_fclk_inpn[i]	,	tpem_link_fclk_outn[i]	);

	dlys_inst 	buf_00		(.dlys_sout	(	tpes_link_fclk_inpp[i]	),	.dlys_sdin	(	tpem_link_fclk_outp[i]	)	);
	dlys_inst 	buf_01		(.dlys_sout	(	tpes_link_fclk_inpn[i]	),	.dlys_sdin	(	tpem_link_fclk_outn[i]	)	);

	buf #0.0	buf_02		(	tpes_link_fram_inpp[i]	,	tpem_link_fram_outp[i]	);
	buf #0.0	buf_03		(	tpes_link_fram_inpn[i]	,	tpem_link_fram_outn[i]	);
	buf #0.0	buf_04		(	tpes_link_dat0_inpp[i]	,	tpem_link_dat0_outp[i]	);
	buf #0.0	buf_05		(	tpes_link_dat0_inpn[i]	,	tpem_link_dat0_outn[i]	);
	buf #0.0	buf_06		(	tpes_link_dat1_inpp[i]	,	tpem_link_dat1_outp[i]	);
	buf #0.0	buf_07		(	tpes_link_dat1_inpn[i]	,	tpem_link_dat1_outn[i]	);
	buf #0.0	buf_08		(	tpes_link_dat2_inpp[i]	,	tpem_link_dat2_outp[i]	);
	buf #0.0	buf_09		(	tpes_link_dat2_inpn[i]	,	tpem_link_dat2_outn[i]	);
	buf #0.0	buf_0a		(	tpes_link_dat3_inpp[i]	,	tpem_link_dat3_outp[i]	);
	buf #0.0	buf_0b		(	tpes_link_dat3_inpn[i]	,	tpem_link_dat3_outn[i]	);
			
	buf #500ps	buf_10		(	tpem_link_fclk_inpp[i]	,	tpes_link_fclk_outp[i]	);
	buf #500ps	buf_11		(	tpem_link_fclk_inpn[i]	,	tpes_link_fclk_outn[i]	);
	buf #0.0	buf_12		(	tpem_link_fram_inpp[i]	,	tpes_link_fram_outp[i]	);
	buf #0.0	buf_13		(	tpem_link_fram_inpn[i]	,	tpes_link_fram_outn[i]	);
	buf #0.0	buf_14		(	tpem_link_dat0_inpp[i]	,	tpes_link_dat0_outp[i]	);
	buf #0.0	buf_15		(	tpem_link_dat0_inpn[i]	,	tpes_link_dat0_outn[i]	);
	buf #0.0	buf_16		(	tpem_link_dat1_inpp[i]	,	tpes_link_dat1_outp[i]	);
	buf #0.0	buf_17		(	tpem_link_dat1_inpn[i]	,	tpes_link_dat1_outn[i]	);
	buf #0.0	buf_18		(	tpem_link_dat2_inpp[i]	,	tpes_link_dat2_outp[i]	);
	buf #0.0	buf_19		(	tpem_link_dat2_inpn[i]	,	tpes_link_dat2_outn[i]	);
	buf #0.0	buf_1a		(	tpem_link_dat3_inpp[i]	,	tpes_link_dat3_outp[i]	);
	buf #0.0	buf_1b		(	tpem_link_dat3_inpn[i]	,	tpes_link_dat3_outn[i]	);

	tpes_simu_link_behv			u_tpes_simu_link_behv(
		.scfg_pile_indx				(4'H0						),
		.scfg_fpga_indx				(tpem_scfg_fpga_indx[i]		),//input	[5: 0]	
		
		.scfg_prog_inpp				(tpem_scfg_prog_outp[i]		),//input			
		.scfg_cclk_inpp				(tpem_scfg_cclk_outp[i]		),//input			
		.scfg_data_inpp				(tpem_scfg_data_outp[i]		),//input			
		.scfg_init_outp				(tpem_scfg_init_inpp[i]		),//output			
		.scfg_done_outp				(tpem_scfg_done_inpp[i]		),//output			
		
		.tpem_txdo_tune				(tpem_tune_txdo_mode[i]		),//output		[ 0: 7]	),
		.tpem_rxdi_tune				(tpem_tune_rxdi_mode[i]		),//output		[ 0: 7]	),

		.tpem_rstn_inpp				( tpem_link_rstn_outp[i]		),//input			
		.tpem_rstn_inpn				(~tpem_link_rstn_outp[i]		),//input			

		.tpem_fclk_inpp				(tpes_link_fclk_inpp[i]		),//input			
		.tpem_fclk_inpn				(tpes_link_fclk_inpn[i]		),//input			
		.tpem_fram_inpp				(tpes_link_fram_inpp[i]		),//input			
		.tpem_fram_inpn				(tpes_link_fram_inpn[i]		),//input			
		.tpem_dat0_inpp				(tpes_link_dat0_inpp[i]		),//input			
		.tpem_dat0_inpn				(tpes_link_dat0_inpn[i]		),//input			
		.tpem_dat1_inpp				(tpes_link_dat1_inpp[i]		),//input			
		.tpem_dat1_inpn				(tpes_link_dat1_inpn[i]		),//input			
		.tpem_dat2_inpp				(tpes_link_dat2_inpp[i]		),//input			
		.tpem_dat2_inpn				(tpes_link_dat2_inpn[i]		),//input			
		.tpem_dat3_inpp				(tpes_link_dat3_inpp[i]		),//input			
		.tpem_dat3_inpn				(tpes_link_dat3_inpn[i]		),//input			
		
		.tpes_fclk_outp				(tpes_link_fclk_outp[i]		),//output			
		.tpes_fclk_outn				(tpes_link_fclk_outn[i]		),//output			
		.tpes_fram_outp				(tpes_link_fram_outp[i]		),//output			
		.tpes_fram_outn				(tpes_link_fram_outn[i]		),//output			
		.tpes_dat0_outp				(tpes_link_dat0_outp[i]		),//output			
		.tpes_dat0_outn				(tpes_link_dat0_outn[i]		),//output			
		.tpes_dat1_outp				(tpes_link_dat1_outp[i]		),//output			
		.tpes_dat1_outn				(tpes_link_dat1_outn[i]		),//output			
		.tpes_dat2_outp				(tpes_link_dat2_outp[i]		),//output			
		.tpes_dat2_outn				(tpes_link_dat2_outn[i]		),//output			
		.tpes_dat3_outp				(tpes_link_dat3_outp[i]		),//output			
		.tpes_dat3_outn				(tpes_link_dat3_outn[i]		));//output			
end
/***********************************************************************************************************/
	noddr_ku35_fpga_core			u_ku35_fpga_core_dut(
		.chip_clki					(chip_clki				),
		.init_bclk					(						),
//----------------------------------------------------------------------
		.mgt1_pmau_init_ctrl		(			),//output				
		.mgt1_rstb_push_ctrl		(			),//output				
		.mgt1_intf_link_stat		(1'B1		),//input				
		.mgt1_osde_rdma_trdy		(1'B1		),//input				
		.mgt1_osde_rdma_drdy		(mgt1_osde_rdma_drdy	),//output				
		.mgt1_osde_rdma_data		(mgt1_osde_rdma_data	),//output		[255:0]	
		.mgt1_clki					(mgt1_clki				),//input				
//----------------------------------------------------------------------
		.tpgm_link_rstn_inpp		(tpgm_link_rstn_inpp	),//input
		.tpgm_link_rstn_inpn		(tpgm_link_rstn_inpn	),//input
		
		.tpgm_link_tune_txdo		(tpgm_link_tune_txdo	),
		.tpgm_link_tune_rxdi		(tpgm_link_tune_rxdi	),
		
		.tpgm_link_fclk_inpp		(tpgm_link_fclk_inpp	),//input
		.tpgm_link_fclk_inpn		(tpgm_link_fclk_inpn	),//input
		.tpgm_link_fram_inpp		(tpgm_link_fram_inpp	),//input
		.tpgm_link_fram_inpn		(tpgm_link_fram_inpn	),//input
		.tpgm_link_dat0_inpp		(tpgm_link_dat0_inpp	),//input
		.tpgm_link_dat0_inpn		(tpgm_link_dat0_inpn	),//input
		.tpgm_link_dat1_inpp		(tpgm_link_dat1_inpp	),//input
		.tpgm_link_dat1_inpn		(tpgm_link_dat1_inpn	),//input
		.tpgm_link_dat2_inpp		(tpgm_link_dat2_inpp	),//input
		.tpgm_link_dat2_inpn		(tpgm_link_dat2_inpn	),//input
		.tpgm_link_dat3_inpp		(tpgm_link_dat3_inpp	),//input
		.tpgm_link_dat3_inpn		(tpgm_link_dat3_inpn	),//input

		.tpgs_link_fclk_outp		(tpgs_link_fclk_outp	),//output
		.tpgs_link_fclk_outn		(tpgs_link_fclk_outn	),//output
		.tpgs_link_fram_outp		(tpgs_link_fram_outp	),//output
		.tpgs_link_fram_outn		(tpgs_link_fram_outn	),//output
		.tpgs_link_dat0_outp		(tpgs_link_dat0_outp	),//output
		.tpgs_link_dat0_outn		(tpgs_link_dat0_outn	),//output
		.tpgs_link_dat1_outp		(tpgs_link_dat1_outp	),//output
		.tpgs_link_dat1_outn		(tpgs_link_dat1_outn	),//output
		.tpgs_link_dat2_outp		(tpgs_link_dat2_outp	),//output
		.tpgs_link_dat2_outn		(tpgs_link_dat2_outn	),//output
		.tpgs_link_dat3_outp		(tpgs_link_dat3_outp	),//output
		.tpgs_link_dat3_outn		(tpgs_link_dat3_outn	),//output
//----------------------------------------------------------------------
		.tpem_tune_txdo_mode		(tpem_tune_txdo_mode	),//output		[ 0: 7]	
		.tpem_tune_rxdi_mode		(tpem_tune_rxdi_mode	),//output		[ 0: 7]	

		.tpem_link_rstn_outp		(tpem_link_rstn_outp	),//output		[ 0: 7]	

		.tpem_link_fclk_outp		(tpem_link_fclk_outp	),//output		[ 0: 7]	
		.tpem_link_fclk_outn		(tpem_link_fclk_outn	),//output		[ 0: 7]	
		.tpem_link_fram_outp		(tpem_link_fram_outp	),//output		[ 0: 7]	
		.tpem_link_fram_outn		(tpem_link_fram_outn	),//output		[ 0: 7]	
		.tpem_link_dat0_outp		(tpem_link_dat0_outp	),//output		[ 0: 7]	
		.tpem_link_dat0_outn		(tpem_link_dat0_outn	),//output		[ 0: 7]	
		.tpem_link_dat1_outp		(tpem_link_dat1_outp	),//output		[ 0: 7]	
		.tpem_link_dat1_outn		(tpem_link_dat1_outn	),//output		[ 0: 7]	
		.tpem_link_dat2_outp		(tpem_link_dat2_outp	),//output		[ 0: 7]	
		.tpem_link_dat2_outn		(tpem_link_dat2_outn	),//output		[ 0: 7]	
		.tpem_link_dat3_outp		(tpem_link_dat3_outp	),//output		[ 0: 7]	
		.tpem_link_dat3_outn		(tpem_link_dat3_outn	),//output		[ 0: 7]	

		.tpes_link_fclk_inpp		(tpem_link_fclk_inpp	),//input		[ 0: 7]	
		.tpes_link_fclk_inpn		(tpem_link_fclk_inpn	),//input		[ 0: 7]	
		.tpes_link_fram_inpp		(tpem_link_fram_inpp	),//input		[ 0: 7]	
		.tpes_link_fram_inpn		(tpem_link_fram_inpn	),//input		[ 0: 7]	
		.tpes_link_dat0_inpp		(tpem_link_dat0_inpp	),//input		[ 0: 7]	
		.tpes_link_dat0_inpn		(tpem_link_dat0_inpn	),//input		[ 0: 7]	
		.tpes_link_dat1_inpp		(tpem_link_dat1_inpp	),//input		[ 0: 7]	
		.tpes_link_dat1_inpn		(tpem_link_dat1_inpn	),//input		[ 0: 7]	
		.tpes_link_dat2_inpp		(tpem_link_dat2_inpp	),//input		[ 0: 7]	
		.tpes_link_dat2_inpn		(tpem_link_dat2_inpn	),//input		[ 0: 7]	
		.tpes_link_dat3_inpp		(tpem_link_dat3_inpp	),//input		[ 0: 7]	
		.tpes_link_dat3_inpn		(tpem_link_dat3_inpn	),//input		[ 0: 7]	

		.tpem_scfg_prog_outp		(tpem_scfg_prog_outp	),//output		[ 0: 7]	
		.tpem_scfg_cclk_outp		(tpem_scfg_cclk_outp	),//output		[ 0: 7]	
		.tpem_scfg_data_outp		(tpem_scfg_data_outp	),//output		[ 0: 7]	
		.tpem_scfg_init_inpp		(tpem_scfg_init_inpp	),//input		[ 0: 7]	
		.tpem_scfg_done_inpp		(tpem_scfg_done_inpp	));//input		[ 0: 7]	
/***********************************************************************************************************/
	

endmodule
	
