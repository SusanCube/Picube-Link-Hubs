/**********************************************************************************************************/
module ku35_fpga_core(
	output								init_bclk				,
	input								chip_clki				,
//-DECLARE MGT-SERDES RXIO----------------------------------------------
	input								mgt1_intf_link_stat		,
	output								mgt1_pmau_init_ctrl		,
	output								mgt1_rstb_push_ctrl		,
	input								mgt1_osde_rdma_trdy		,
	output								mgt1_osde_rdma_drdy		,
	output		[255:0]					mgt1_osde_rdma_data		,
	input								mgt1_clki				,
//-DECLARE LPDDR3 IO----------------------------------------------------
   	output 		[ 9: 0]  				c0_lpddr3_ca		,
   	output 		[ 0: 0]  				c0_lpddr3_ck_t		,      
   	output 		[ 0: 0]  				c0_lpddr3_ck_c		,
   	output 		[ 0: 0]  				c0_lpddr3_cs_n		, 
   	output 		[ 0: 0]	 				c0_lpddr3_cke		,
   	output 		[ 0: 0]	 				c0_lpddr3_odt		,
   	inout  		[31: 0]  				c0_lpddr3_dq		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_t		,
   	inout  		[ 3: 0]  				c0_lpddr3_dqs_c		,
   	output 		[ 3: 0]  				c0_lpddr3_dm		,
//-DECLARE TPGL IO------------------------------------------------------	
	input								tpgm_link_rstn_inpp	,
	input								tpgm_link_rstn_inpn	,
	input								tpgm_link_tune_inpp	,
	input								tpgm_link_tune_inpn	,

	input								tpgm_link_fclk_inpp	,
	input								tpgm_link_fclk_inpn	,
	input								tpgm_link_fram_inpp	,
	input								tpgm_link_fram_inpn	,
	input								tpgm_link_dat0_inpp	,
	input								tpgm_link_dat0_inpn	,
	input								tpgm_link_dat1_inpp	,
	input								tpgm_link_dat1_inpn	,
	input								tpgm_link_dat2_inpp	,
	input								tpgm_link_dat2_inpn	,
	input								tpgm_link_dat3_inpp	,
	input								tpgm_link_dat3_inpn	,

	output								tpgs_link_fclk_outp	,
	output								tpgs_link_fclk_outn	,
	output								tpgs_link_fram_outp	,
	output								tpgs_link_fram_outn	,
	output								tpgs_link_dat0_outp	,
	output								tpgs_link_dat0_outn	,
	output								tpgs_link_dat1_outp	,
	output								tpgs_link_dat1_outn	,
	output								tpgs_link_dat2_outp	,
	output								tpgs_link_dat2_outn	,
	output								tpgs_link_dat3_outp	,
	output								tpgs_link_dat3_outn	,
//-DECLARE TPEL IO-------------------------------------------------
	output		[ 0: 7]					tpem_link_tune_txdo	,
	output		[ 0: 7]					tpem_link_tune_rxdi	,

	output		[ 0: 7]					tpem_link_fclk_outp	,
	output		[ 0: 7]					tpem_link_fclk_outn	,
	output		[ 0: 7]					tpem_link_rstn_outp	,
	output		[ 0: 7]					tpem_link_rstn_outn	,
	output		[ 0: 7]					tpem_link_fram_outp	,
	output		[ 0: 7]					tpem_link_fram_outn	,
	output		[ 0: 7]					tpem_link_dat0_outp	,
	output		[ 0: 7]					tpem_link_dat0_outn	,
	output		[ 0: 7]					tpem_link_dat1_outp	,
	output		[ 0: 7]					tpem_link_dat1_outn	,
	output		[ 0: 7]					tpem_link_dat2_outp	,
	output		[ 0: 7]					tpem_link_dat2_outn	,
	output		[ 0: 7]					tpem_link_dat3_outp	,
	output		[ 0: 7]					tpem_link_dat3_outn	,

	input		[ 0: 7]					tpes_link_fclk_inpp	,
	input		[ 0: 7]					tpes_link_fclk_inpn	,
	input		[ 0: 7]					tpes_link_fram_inpp	,
	input		[ 0: 7]					tpes_link_fram_inpn	,
	input		[ 0: 7]					tpes_link_dat0_inpp	,
	input		[ 0: 7]					tpes_link_dat0_inpn	,
	input		[ 0: 7]					tpes_link_dat1_inpp	,
	input		[ 0: 7]					tpes_link_dat1_inpn	,
	input		[ 0: 7]					tpes_link_dat2_inpp	,
	input		[ 0: 7]					tpes_link_dat2_inpn	,
	input		[ 0: 7]					tpes_link_dat3_inpp	,
	input		[ 0: 7]					tpes_link_dat3_inpn	,

	output		[ 0: 7]					tpem_scfg_prog_outp	,
	output		[ 0: 7]					tpem_scfg_cclk_outp	,
	output		[ 0: 7]					tpem_scfg_data_outp	,
	input		[ 0: 7]					tpem_scfg_init_inpp	,
	input		[ 0: 7]					tpem_scfg_done_inpp	);
/**********************************************************************************************************/
	wire								tpgm_rstn	;

	IBUFDS							u_TPGM_RSTN_IPAD (
		.O								(tpgm_rstn				), 
		.I								(tpgm_link_rstn_inpp	),
		.IB								(tpgm_link_rstn_inpn	));	
/**********************************************************************************************************/
	wire								link_fclk	;
	wire								link_strb	;
	wire								link_sclk	;
	wire								link_rstn	;
	wire								chip_rstn	;
	wire								dlys_rstn	;

	xcku_sysclk						u_xcku_clks_gens(	
		.link_fclk						(link_fclk				),//output	
		.link_strb						(link_strb				),//output	
		.link_sclk						(link_sclk				),//output	
		.init_bclk						(init_bclk				),//output	

		.link_rstn						(link_rstn				),//output	
		.chip_rstn						(chip_rstn				),//output	
		.dlys_rstn						(dlys_rstn				),//output	
			
		.auxi_rstn						(1'b1					),//input	
		.cold_rstn						(tpgm_rstn				),//input	
		.chip_clki						(chip_clki				));//input	
//------------------------------------------------------------------------------
	wire								dlys_brst			;
	wire								tpgs_dlys_ctrl_drdy	;

	ku60_dlys_ctrl					u_ku60_dlys_ctrl(
		.dlys_brst						(dlys_brst			),//output		reg	
		.dlys_drdy						(tpgs_dlys_ctrl_drdy),//output			
		.dlys_fclk						(link_fclk			),//input			
		.dlys_sclk						(link_sclk			),//input			
		.dlys_rstn						(dlys_rstn			));//input				
/***********************************************************************************************************/
//DECLARE TPGL_SALVE_LINK
	wire		[7:0]					tpgs_port_txdo_fram	;
	wire		[7:0]					tpgs_port_txdo_dat0	;
	wire		[7:0]					tpgs_port_txdo_dat1	;
	wire		[7:0]					tpgs_port_txdo_dat2	;
	wire		[7:0]					tpgs_port_txdo_dat3	;

	wire		[7:0]					tpgs_port_rxdi_fram	;
	wire		[7:0]					tpgs_port_rxdi_dat0	;
	wire		[7:0]					tpgs_port_rxdi_dat1	;
	wire		[7:0]					tpgs_port_rxdi_dat2	;
	wire		[7:0]					tpgs_port_rxdi_dat3	;

	gens_sync_rstn					tpgs_rstn_gens(
    	.rstn_gens						(tpgs_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/***********************************************************************************************************/
	tpgs_link_rxdi_pmau				u_tpgs_link_rxdi_pmau(
		.lvds_fclk_inpp					(tpgm_link_fclk_inpp	),//input	
		.lvds_fclk_inpn					(tpgm_link_fclk_inpn	),//input	
		.lvds_fram_inpp					(tpgm_link_fram_inpp	),//input	
		.lvds_fram_inpn					(tpgm_link_fram_inpn	),//input	
		.lvds_dat0_inpp					(tpgm_link_dat0_inpp	),//input	
		.lvds_dat0_inpn					(tpgm_link_dat0_inpn	),//input	
		.lvds_dat1_inpp					(tpgm_link_dat1_inpp	),//input	
		.lvds_dat1_inpn					(tpgm_link_dat1_inpn	),//input	
		.lvds_dat2_inpp					(tpgm_link_dat2_inpp	),//input	
		.lvds_dat2_inpn					(tpgm_link_dat2_inpn	),//input	
		.lvds_dat3_inpp					(tpgm_link_dat3_inpp	),//input	
		.lvds_dat3_inpn					(tpgm_link_dat3_inpn	),//input	

		.lvds_fram_mbdo					(tpgs_port_rxdi_fram 	),//output	reg	[ 7: 0]	
		.lvds_dat0_mbdo					(tpgs_port_rxdi_dat0 	),//output	reg	[ 7: 0]	
		.lvds_dat1_mbdo					(tpgs_port_rxdi_dat1 	),//output	reg	[ 7: 0]	
		.lvds_dat2_mbdo					(tpgs_port_rxdi_dat2 	),//output	reg	[ 7: 0]	
		.lvds_dat3_mbdo					(tpgs_port_rxdi_dat3 	),//output	reg	[ 7: 0]	

		.link_clki						( link_sclk				),//input	
		.lvds_rstn						( tpgs_rstn				));//input	

	tpgs_link_txdo_pmau				u_tpgs_link_txdo_pmau(
		.tune_txdo_inpp					(tpgm_link_tune_inpp	),//input
		.tune_txdo_inpn					(tpgm_link_tune_inpn	),//input
		
		.link_fclk_outp					(tpgs_link_fclk_outp	),//output			
		.link_fclk_outn					(tpgs_link_fclk_outn	),//output			
		.link_fram_outp					(tpgs_link_fram_outp	),//output			
		.link_fram_outn					(tpgs_link_fram_outn	),//output			
		.link_dat0_outp					(tpgs_link_dat0_outp	),//output			
		.link_dat0_outn					(tpgs_link_dat0_outn	),//output			
		.link_dat1_outp					(tpgs_link_dat1_outp	),//output			
		.link_dat1_outn					(tpgs_link_dat1_outn	),//output			
		.link_dat2_outp					(tpgs_link_dat2_outp	),//output			
		.link_dat2_outn					(tpgs_link_dat2_outn	),//output			
		.link_dat3_outp					(tpgs_link_dat3_outp	),//output			
		.link_dat3_outn					(tpgs_link_dat3_outn	),//output			

		.link_fram_mbdi					(tpgs_port_txdo_fram	),//input	[7:0]	
		.link_dat0_mbdi					(tpgs_port_txdo_dat0	),//input	[7:0]	
		.link_dat1_mbdi					(tpgs_port_txdo_dat1	),//input	[7:0]	
		.link_dat2_mbdi					(tpgs_port_txdo_dat2	),//input	[7:0]	
		.link_dat3_mbdi					(tpgs_port_txdo_dat3	),//input	[7:0]	

		.link_fclk						( link_fclk				),//input	
		.link_strb						( link_strb				),//input	
		.link_rstn						( tpgs_rstn				));//input	
//----------------------------------------------------------------------
//DECLARE TPEL_MASTER_LINK
	wire	[ 0: 7]						tpem_link_port_rstn	;
	wire	[ 0: 7]						tpem_link_tpes_rstn	;

	wire	[ 0: 7]						tpem_port_rxdi_fclk	;
	wire	[ 0: 7]						tpem_port_rxdi_clki	;
	
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_fram	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_txdo_dat3	;

	wire	[ 7: 0]						tpem_port_rxdi_lead	;
	wire	[ 7: 0]						tpem_port_rxdi_body	;
	wire	[ 7: 0]						tpem_port_rxdi_coda	;

	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat0	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat1	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat2	;
	wire	[ 0: 7][ 7: 0]				tpem_port_rxdi_dat3	;

	wire	[ 0: 7]						tpem_tune_txdo_envt	;
	wire	[ 0: 7]						tpem_tune_txdo_load	;
	wire	[ 0: 7][8: 0]				tpem_tune_txdo_taps	;
	wire	[ 0: 7][8: 0]				tpem_tune_txdo_vals	;

	wire	[ 0: 7]						tpem_tune_rxdi_envt	;
	wire	[ 0: 7]						tpem_tune_rxdi_load	;
	wire	[ 0: 7][ 8: 0]				tpem_tune_rxdi_taps	;
	wire	[ 0: 7][ 8: 0]				tpem_tune_rxdi_vals	;
	wire	[ 0: 7][ 4: 0]				tpem_tune_rxdi_good	;
	

	wire	[ 0: 7][ 7: 0]				tpem_idly_fram_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat0_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat1_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat2_patn	;
	wire	[ 0: 7][ 7: 0]				tpem_idly_dat3_patn	;

	gens_sync_rstn					tpem_rstn_gens(
    	.rstn_gens						(tpem_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		
/**********************************************************************************************************************/
for(genvar i = 0 ; i < 8 ; i++)		begin:gens_tpem_link_port

	assign	tpem_link_tpes_rstn[i]=	tpem_link_port_rstn[i] & tpem_rstn	;

	assign	tpem_link_rstn_outp[i]	=	tpem_link_tpes_rstn[i]	;
	assign	tpem_link_rstn_outn[i]	= ~	tpem_link_tpes_rstn[i]	;


	tpem_link_rxdi_pmau				u_tpem_link_rxdi_pmau(
		.tune_rxdi_enab					(tpem_link_tune_rxdi[i]	),//input		
		.tune_rxdi_envt					(tpem_tune_rxdi_envt[i]	),//input		
		.tune_rxdi_load					(tpem_tune_rxdi_load[i]	),//input		
		.tune_rxdi_taps					(tpem_tune_rxdi_taps[i]	),//input	[8:0]
		.tune_rxdi_vals					(tpem_tune_rxdi_vals[i]	),//output	[8:0]
		.tune_rxdi_good					(tpem_tune_rxdi_good[i]	),//output	[4:0]

		.lvds_fclk_inpp					(tpes_link_fclk_inpp[i]	),//input	
		.lvds_fclk_inpn					(tpes_link_fclk_inpn[i]	),//input	
		.lvds_fram_inpp					(tpes_link_fram_inpp[i]	),//input	
		.lvds_fram_inpn					(tpes_link_fram_inpn[i]	),//input	
		.lvds_dat0_inpp					(tpes_link_dat0_inpp[i]	),//input	
		.lvds_dat0_inpn					(tpes_link_dat0_inpn[i]	),//input	
		.lvds_dat1_inpp					(tpes_link_dat1_inpp[i]	),//input	
		.lvds_dat1_inpn					(tpes_link_dat1_inpn[i]	),//input	
		.lvds_dat2_inpp					(tpes_link_dat2_inpp[i]	),//input	
		.lvds_dat2_inpn					(tpes_link_dat2_inpn[i]	),//input	
		.lvds_dat3_inpp					(tpes_link_dat3_inpp[i]	),//input	
		.lvds_dat3_inpn					(tpes_link_dat3_inpn[i]	),//input	

		.rxdi_fram_lead					(tpem_port_rxdi_lead[i]	)	,//input	[ 7: 0]	
		.rxdi_fram_body					(tpem_port_rxdi_body[i]	)	,//input	[ 7: 0]	
		.rxdi_fram_coda					(tpem_port_rxdi_coda[i]	)	,//input	[ 7: 0]	

		.rxdi_dat0_mbdo					(tpem_port_rxdi_dat0[i]	)	,//output	reg	[ 7: 0]	
		.rxdi_dat1_mbdo					(tpem_port_rxdi_dat1[i]	)	,//output	reg	[ 7: 0]	
		.rxdi_dat2_mbdo					(tpem_port_rxdi_dat2[i]	)	,//output	reg	[ 7: 0]	
		.rxdi_dat3_mbdo					(tpem_port_rxdi_dat3[i]	)	,//output	reg	[ 7: 0]	

		.dlys_cell_rst					(dlys_cell_rst			),//output	

		.link_fclk						( link_fclk				),//input	
		.link_clki						( link_sclk				),//input	
		.link_rstn						( tpem_rstn				));//input	


	tpem_link_txdo_pmau				u_tpem_link_txdo_pmau(
		.tune_txdo_enab					(tpem_link_tune_txdo[i]	),
		
		.lvds_fclk_outp					(tpem_link_fclk_outp[i]	),//output			
		.lvds_fclk_outn					(tpem_link_fclk_outn[i]	),//output			
		.lvds_fram_outp					(tpem_link_fram_outp[i]	),//output			
		.lvds_fram_outn					(tpem_link_fram_outn[i]	),//output			
		.lvds_dat0_outp					(tpem_link_dat0_outp[i]	),//output			
		.lvds_dat0_outn					(tpem_link_dat0_outn[i]	),//output			
		.lvds_dat1_outp					(tpem_link_dat1_outp[i]	),//output			
		.lvds_dat1_outn					(tpem_link_dat1_outn[i]	),//output			
		.lvds_dat2_outp					(tpem_link_dat2_outp[i]	),//output			
		.lvds_dat2_outn					(tpem_link_dat2_outn[i]	),//output			
		.lvds_dat3_outp					(tpem_link_dat3_outp[i]	),//output			
		.lvds_dat3_outn					(tpem_link_dat3_outn[i]	),//output		

		.lvds_fram_mbdi					(tpem_port_txdo_fram[i]	),//output	[7:0]	
		.lvds_dat0_mbdi					(tpem_port_txdo_dat0[i]	),//output	[7:0]	
		.lvds_dat1_mbdi					(tpem_port_txdo_dat1[i]	),//output	[7:0]	
		.lvds_dat2_mbdi					(tpem_port_txdo_dat2[i]	),//output	[7:0]	
		.lvds_dat3_mbdi					(tpem_port_txdo_dat3[i]	),//output	[7:0]	
	

		.link_fclk						( link_fclk				),//input	
		.link_strb						( link_strb				),//input	
		.link_rstn						( tpem_rstn				));//input	

end
/***********************************************************************************************************/
//LPDDR3 CONTROLLER-----------------------------------------------------------------------------------------
	wire								ddrs_ubus_intf_trdy	;		
	wire								ddrs_ubus_intf_wrdy	;		
	wire								ddrs_ubus_intf_csen	;			
	wire		[  2: 0]				ddrs_ubus_intf_cmnd	;		
	wire		[ 27: 0]				ddrs_ubus_intf_addr	;		
	wire								ddrs_ubus_writ_enab	;			
	wire		[255: 0]				ddrs_ubus_writ_data	;		
	wire		[ 31: 0]				ddrs_ubus_writ_mask	;		
	wire								ddrs_ubus_writ_last	;			
	wire		[255: 0]				ddrs_ubus_read_data	;		
	wire								ddrs_ubus_read_vlid	;		
	wire								ddrs_ubus_read_last	;		

	wire								ubus_tpgs_wdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_wdma_addr	;
	wire		[255: 0]				ubus_tpgs_wdma_data	;
	wire								ubus_tpgs_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpgs_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpgs_rdma_csen	;
	wire		[ 24: 0]				ubus_tpgs_rdma_addr	;
	wire								ubus_tpgs_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpgs_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpgs_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_tpem_wdma_csen	;	
	wire		[ 24: 0]				ubus_tpem_wdma_addr	;	
	wire		[255: 0]				ubus_tpem_wdma_data	;	
	wire								ubus_tpem_wdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire								ubus_tpem_wdma_wrdy	=	ddrs_ubus_intf_wrdy	;

	wire								ubus_tpem_rdma_csen	;
	wire		[ 24: 0]				ubus_tpem_rdma_addr	;
	wire								ubus_tpem_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_tpem_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_tpem_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_osde_rdma_csen	;
	wire		[ 24: 0]				ubus_osde_rdma_addr	;
	wire								ubus_osde_rdma_trdy	=	ddrs_ubus_intf_trdy	;
	wire		[255: 0]				ubus_osde_rdma_data	=	ddrs_ubus_read_data	;
	wire								ubus_osde_rdma_drdy	=	ddrs_ubus_read_vlid	;

	wire								ubus_wdma_intf_csen	;
	wire								ubus_rdma_intf_csen	;
	
	assign	ubus_wdma_intf_csen	= 		ubus_tpgs_wdma_csen	|	ubus_tpem_wdma_csen	;
	assign	ubus_rdma_intf_csen	= 		ubus_tpgs_rdma_csen	|	ubus_tpem_rdma_csen	|	ubus_osde_rdma_csen	;
	assign	ddrs_ubus_intf_csen	=		ubus_wdma_intf_csen	|	ubus_rdma_intf_csen	;

	assign	ddrs_ubus_writ_enab	= 		ubus_wdma_intf_csen	;

	assign	ddrs_ubus_intf_addr	=		ubus_tpgs_wdma_csen	? {	ubus_tpgs_wdma_addr	, 3'H0}	:
										ubus_tpem_wdma_csen	? {	ubus_tpem_wdma_addr	, 3'H0}	:
										ubus_tpgs_rdma_csen	? {	ubus_tpgs_rdma_addr	, 3'H0}	:
										ubus_tpem_rdma_csen	? {	ubus_tpem_rdma_addr	, 3'H0}	:
										ubus_osde_rdma_csen	? {	ubus_osde_rdma_addr	, 3'H0}	:	 28'H0	;	

	assign	ddrs_ubus_writ_data	=		ubus_tpgs_wdma_csen	?	ubus_tpgs_wdma_data	:
										ubus_tpem_wdma_csen	?	ubus_tpem_wdma_data	:	256'H0	;

	assign	ddrs_ubus_intf_cmnd	=		ubus_wdma_intf_csen	?	3'H0	:	3'H1	;
	assign	ddrs_ubus_writ_last	= 		ubus_wdma_intf_csen	;
	assign	ddrs_ubus_writ_mask	=		32'H0				;	

	wire								ubus_prst			;
	wire								ubus_rstn	= ~ubus_prst	;

	xcku_lpddr3_256m				u_lpddr3_256m(
    	.sys_rst						(~chip_rstn				),//INPUT
   		.c0_sys_clk_i					( chip_clki				),//INPUT
   		.c0_init_calib_complete			( tpuc_link_ddrs_stat	),//OUTPUT	
		
    	.c0_lpddr3_ca               	(c0_lpddr3_ca			),
    	.c0_lpddr3_ck_t             	(c0_lpddr3_ck_t			),
    	.c0_lpddr3_ck_c             	(c0_lpddr3_ck_c			),
    	.c0_lpddr3_cs_n             	(c0_lpddr3_cs_n			),
    	.c0_lpddr3_cke              	(c0_lpddr3_cke			),
    	.c0_lpddr3_odt              	(c0_lpddr3_odt			),
    	.c0_lpddr3_dq               	(c0_lpddr3_dq			),
    	.c0_lpddr3_dqs_t            	(c0_lpddr3_dqs_t		),
    	.c0_lpddr3_dqs_c            	(c0_lpddr3_dqs_c		),
    	.c0_lpddr3_dm               	(c0_lpddr3_dm			),

    	.c0_lpddr3_app_rdy				(ddrs_ubus_intf_trdy	),
    	.c0_lpddr3_app_addr				(ddrs_ubus_intf_addr	),
		.c0_lpddr3_app_cmd				(ddrs_ubus_intf_cmnd	),
		.c0_lpddr3_app_en				(ddrs_ubus_intf_csen	),
		.c0_lpddr3_app_wdf_rdy			(ddrs_ubus_intf_wrdy	),
    	.c0_lpddr3_app_wdf_wren			(ddrs_ubus_writ_enab	),
    	.c0_lpddr3_app_wdf_data			(ddrs_ubus_writ_data	),
    	.c0_lpddr3_app_wdf_mask			(ddrs_ubus_writ_mask	),
    	.c0_lpddr3_app_wdf_end			(ddrs_ubus_writ_last	),
		.c0_lpddr3_app_rd_data			(ddrs_ubus_read_data	),
		.c0_lpddr3_app_rd_data_valid	(ddrs_ubus_read_vlid	),
		.c0_lpddr3_app_rd_data_end		(ddrs_ubus_read_last	),
	 	.c0_lpddr3_app_hi_pri			(1'b0					),
     	.dbg_clk						(						),
 		.c0_lpddr3_ui_clk				(ubus_clki				),//OUTPUT	
   		.c0_lpddr3_ui_clk_sync_rst		(ubus_prst				));//OUTPUT	
/**********************************************************************************************************/
//TPUC CONTROLLER-----------------------------------------------------------------------------------------
	
	gens_sync_rstn					tpuc_rstn_gens(
    	.rstn_gens						(tpuc_rstn	),//output		
		.rstn_reqs						(link_rstn	),//input		
		.main_clki						(link_sclk	));//input		

	tpuc_slav_link_unit				u_tpus_slav_link_unit(
		.tpuc_link_ddrs_stat			(tpuc_link_ddrs_stat	),//input
		.tpem_link_port_rstn			(tpem_link_port_rstn	),//output	[ 0: 7]

		.tpem_tune_txdo_enab			(tpem_link_tune_txdo	),//output	[ 0: 7]			
		.tpem_tune_txdo_envt			(tpem_tune_txdo_envt	),//output	[ 0: 7]			
		.tpem_tune_txdo_load			(tpem_tune_txdo_load	),//output	[ 0: 7]			
		.tpem_tune_txdo_taps			(tpem_tune_txdo_taps	),//output	[ 0: 7][8: 0]	
		.tpem_tune_txdo_vals			(tpem_tune_txdo_vals	),//input	[ 0: 7][8: 0]	

		.tpem_tune_rxdi_enab			(tpem_link_tune_rxdi	),//output	[ 0: 7]			
		.tpem_tune_rxdi_envt			(tpem_tune_rxdi_envt	),//output	[ 0: 7]			
		.tpem_tune_rxdi_load			(tpem_tune_rxdi_load	),//output	[ 0: 7]			
		.tpem_tune_rxdi_taps			(tpem_tune_rxdi_taps	),//output	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_vals			(tpem_tune_rxdi_vals	),//input	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_good			(tpem_tune_rxdi_good	),//input	[ 0: 7][ 4: 0]	

		.tpgs_port_txdo_fram			(tpgs_port_txdo_fram	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat0			(tpgs_port_txdo_dat0	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat1			(tpgs_port_txdo_dat1	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat2			(tpgs_port_txdo_dat2	),//output		[ 7: 0]	
		.tpgs_port_txdo_dat3			(tpgs_port_txdo_dat3	),//output		[ 7: 0]	

		.tpgs_port_rxdi_fram			(tpgs_port_rxdi_fram	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat0			(tpgs_port_rxdi_dat0	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat1			(tpgs_port_rxdi_dat1	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat2			(tpgs_port_rxdi_dat2	),//input		[ 7: 0]	
		.tpgs_port_rxdi_dat3			(tpgs_port_rxdi_dat3	),//input		[ 7: 0]	

		.tpem_port_txdo_fram			(tpem_port_txdo_fram	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat0			(tpem_port_txdo_dat0	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat1			(tpem_port_txdo_dat1	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat2			(tpem_port_txdo_dat2	),//output		[ 0: 7][ 7: 0]	
		.tpem_port_txdo_dat3			(tpem_port_txdo_dat3	),//output		[ 0: 7][ 7: 0]	

		.tpem_port_rxdi_lead			(tpem_port_rxdi_lead	),//input		[ 7: 0]	
		.tpem_port_rxdi_body			(tpem_port_rxdi_body	),//input		[ 7: 0]	
		.tpem_port_rxdi_coda			(tpem_port_rxdi_coda	),//input		[ 7: 0]	

		.tpem_port_rxdi_dat0			(tpem_port_rxdi_dat0	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat1			(tpem_port_rxdi_dat1	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat2			(tpem_port_rxdi_dat2	),//input		[ 0: 7][ 7: 0]	
		.tpem_port_rxdi_dat3			(tpem_port_rxdi_dat3	),//input		[ 0: 7][ 7: 0]	

		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]			
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]			
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]			
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]			
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	),//input		[ 0: 7]			

		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output				
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output				
		.mgt1_osde_rdma_trdy			(mgt1_osde_rdma_trdy	),//input				
		.mgt1_osde_rdma_drdy			(mgt1_osde_rdma_drdy	),//output				
		.mgt1_osde_rdma_data			(mgt1_osde_rdma_data	),//output		[255: 0]
		.mgt1_clki						(mgt1_clki				),//input				
		.mgt1_rstn						(tpuc_rstn				),//input				

		.ubus_tpgs_wdma_csen			(ubus_tpgs_wdma_csen	),//output					
		.ubus_tpgs_wdma_addr			(ubus_tpgs_wdma_addr	),//output		[ 24: 0]	
		.ubus_tpgs_wdma_data			(ubus_tpgs_wdma_data	),//output		[255: 0]	
		.ubus_tpgs_wdma_trdy			(ubus_tpgs_wdma_trdy	),//input					
		.ubus_tpgs_wdma_wrdy			(ubus_tpgs_wdma_wrdy	),//input					

		.ubus_tpgs_rdma_csen			(ubus_tpgs_rdma_csen	),//output	reg				
		.ubus_tpgs_rdma_addr			(ubus_tpgs_rdma_addr	),//output	reg	[ 24: 0]	
		.ubus_tpgs_rdma_trdy			(ubus_tpgs_rdma_trdy	),//input					
		.ubus_tpgs_rdma_data			(ubus_tpgs_rdma_data	),//input		[255: 0]	
		.ubus_tpgs_rdma_drdy			(ubus_tpgs_rdma_drdy	),//input					

		.ubus_tpem_wdma_csen			(ubus_tpem_wdma_csen	),//output					
		.ubus_tpem_wdma_addr			(ubus_tpem_wdma_addr	),//output		[ 24: 0]	
		.ubus_tpem_wdma_data			(ubus_tpem_wdma_data	),//output		[255: 0]	
		.ubus_tpem_wdma_trdy			(ubus_tpem_wdma_trdy	),//input					
		.ubus_tpem_wdma_wrdy			(ubus_tpem_wdma_wrdy	),//input					

		.ubus_tpem_rdma_csen			(ubus_tpem_rdma_csen	),//output					
		.ubus_tpem_rdma_addr			(ubus_tpem_rdma_addr	),//output		[ 24: 0]	
		.ubus_tpem_rdma_trdy			(ubus_tpem_rdma_trdy	),//input					
		.ubus_tpem_rdma_data			(ubus_tpem_rdma_data	),//input		[255: 0]	
		.ubus_tpem_rdma_drdy			(ubus_tpem_rdma_drdy	),//input					

		.ubus_osde_rdma_csen			(ubus_osde_rdma_csen	),//output					
		.ubus_osde_rdma_addr			(ubus_osde_rdma_addr	),//output		[ 24: 0]	
		.ubus_osde_rdma_trdy			(ubus_osde_rdma_trdy	),//input					
		.ubus_osde_rdma_data			(ubus_osde_rdma_data	),//input		[255: 0]	
		.ubus_osde_rdma_drdy			(ubus_osde_rdma_drdy	),//input					

		.tpgs_dlys_ctrl_drdy			(tpgs_dlys_ctrl_drdy	),

		.link_clki						(link_sclk				),//input
		.ubus_clki						(ubus_clki				),//input
		.link_rstn						(tpuc_rstn				),//input
		.ubus_rstn						(tpuc_rstn				));//input

endmodule
	
