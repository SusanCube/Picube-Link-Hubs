/*
	output							mgt1_rstn			,

*/
module	ku35_mgt1_sdes_txo(
	output	[ 0: 3]						mgt1_txp_io			,
	output	[ 0: 3]						mgt1_txn_io			,
	input								mgt1_rclk_p			,
	input								mgt1_rclk_n			,
	
	output								mgt1_intf_link_stat	,
	input								mgt1_pmau_init_ctrl	,
	input								mgt1_rstb_push_ctrl	,
	input	[255:0]						mgt1_osde_rdma_data	,
    input								mgt1_osde_rdma_drdy	,
    output								mgt1_osde_rdma_trdy	,
	
	output								mgt1_clki			,
	input								link_cclk			);
/**********************************************************************************************************/
	wire  	[ 0: 3]     				mgt1_lane_up		;
	wire 	[ 3: 0]      				mgt1_powr_up		;
	wire            					mgt1_chnl_up		;
	wire            					mgt1_qpll_up		;

	wire            					mgt1_dnot_lock		;
	wire								mgt1_link_rsto		;
	wire            					mgt1_txrx_rsto		;
	wire            					mgt1_msys_rsto		;
	
	wire								mgt1_hard_errs		;
	wire								mgt1_soft_errs		;
	
	assign	mgt1_intf_link_stat	=	&{	mgt1_lane_up		,//15:12
										mgt1_powr_up		,//11: 8
										mgt1_chnl_up		,//7
										mgt1_qpll_up		,//6
									  ~	mgt1_hard_errs		,//5
									  ~	mgt1_soft_errs		,//4
									  ~	mgt1_dnot_lock		,//3
									  ~	mgt1_link_rsto		,//2
									  ~	mgt1_txrx_rsto		,//1
									  ~	mgt1_msys_rsto		};//0
/*********************************************************************************************************/
	ku35_mgth_x0y0_txo				u_mgt1_osde_quad(
        .s_axi_tx_tdata					(mgt1_osde_rdma_data	),//input
        .s_axi_tx_tvalid				(mgt1_osde_rdma_drdy	),//input
        .s_axi_tx_tready				(mgt1_osde_rdma_trdy	),//output

        .txp							(mgt1_txp_io			),
        .txn							(mgt1_txn_io			),

		.gt_refclk1_out					(						),
		.gt_refclk1_p					(mgt1_rclk_p			),
		.gt_refclk1_n					(mgt1_rclk_n			),

		.tx_hard_err					(mgt1_hard_errs			),
		.tx_soft_err					(mgt1_soft_errs			),

		.tx_lane_up						(mgt1_lane_up			),
		.tx_channel_up					(mgt1_chnl_up			),
	
		.pma_init						(mgt1_pmau_init_ctrl	),
        .reset_pb						(mgt1_rstb_push_ctrl	),

        .link_reset_out					(mgt1_link_rsto			),
		.gt_reset_out					(mgt1_txrx_rsto			),
		.sys_reset_out					(mgt1_msys_rsto			),
		.reset2fg						(						),

		.power_down						(1'B0					),
        .gt_rxcdrovrden_in				(1'B0					),

        .gt_powergood					(mgt1_powr_up			),
        .gt_pll_lock					(mgt1_qpll_up			),
		.mmcm_not_locked_out			(mgt1_dnot_lock			),

		.sync_clk_out					(						),//Keep Not Connect
        .tx_out_clk                 	(						),
		.user_clk_out          			(mgt1_clki				),
        .init_clk						(link_cclk				),

		.gt0_drpaddr					(9'H0					),//    input   [8:0]     
		.gt0_drpdi						(16'H0000				),//    input   [15:0]  
		.gt0_drpen						(1'H0					),//    input            
		.gt0_drpwe						(1'H0					),//    input            
		.gt0_drpdo						(),//    output  [15:0]   
		.gt0_drprdy						(),//    output            

		.gt1_drpaddr					(9'H0					),
		.gt1_drpdi						(16'H0000				),
		.gt1_drpen						(1'H0					), 
		.gt1_drpwe						(1'H0					), 
		.gt1_drpdo						(), 
		.gt1_drprdy						(), 

		.gt2_drpaddr					(9'H0					),
		.gt2_drpdi						(16'H0000				),
		.gt2_drpen						(1'H0					), 
		.gt2_drpwe						(1'H0					), 
		.gt2_drpdo						(), 
		.gt2_drprdy						(), 

		.gt3_drpaddr					(9'H0					),
		.gt3_drpdi						(16'H0000				),
		.gt3_drpen						(1'H0					), 
		.gt3_drpwe						(1'H0					), 
		.gt3_drpdo						(						), 
		.gt3_drprdy						(						));//Keep Not Connect
 
endmodule


//        .loopback					(3'H0					),
//		.gt_qpllclk_quad1_out		(						),//output
//		.gt_qpllrefclk_quad1_out	(						),//output
//		.gt_qplllock_quad1_out		(						),//output
//		.gt_qpllrefclklost_quad1_out(						),//output

