#!/bin/csh -f
# cpFromList.csh  LIST_FILE  DEST_DIR  RSRC_ROOT

set rsrcPath    =   /home/home1/yangxg/X11/agile_p4e08/rsrc
set listFile    =   $rsrcPath/fpga_ku35_tops/ku35_fpga_tops.flst

# -----------------------------

set timeStamp   = `date +%Y%m%d%H`

set rootPath    = "ku35_${timeStamp}"

mkdir -p "$rootPath"

if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $rootPath"
    exit 1
endif

cd  "$rootPath"
# -----------------------------
set destPath    = "fpga_rsrc"
set implPath    = "fpga_impl"


mkdir -p "$destPath"
if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $destPath"
    exit 2
endif

mkdir -p "$implPath"
if ( $status != 0 ) then
    echo "ERROR: cannot create destination directory $implPath"
    exit 3
endif



# --------------- each file copy ---------------
foreach fileName (`cat "$listFile"`)
    if ( "$fileName" == "" ) continue

    set thisFile = "$rsrcPath/$fileName"
    if ( ! -e "$thisFile" ) then
        echo "ERROR: source file not found  $thisFile"
        exit 3
    endif

    cp "$thisFile" "$destPath"/
    
    if ( $status != 0 ) then
        echo "ERROR: copy failed �� $thisFile"
        exit 4
    endif
end

echo "All files copied to $destPath"

ls -l "$destPath"/

cd  "$implPath"
pwd

vivado &