/**********************************************************************************************************/
module ku35_fpga_tops(
//-DECLARE AURORA IO----------------------------------------------------
	output			[ 0: 3]				mgt1_txp_io			,
	output			[ 0: 3]				mgt1_txn_io			,
	input								mgt1_rclk_p			,
	input								mgt1_rclk_n			,
//-DECLARE LPDDR3 IO----------------------------------------------------
   	output 			[ 9: 0]  			c0_lpddr3_ca		,
   	output 			[ 0: 0]  			c0_lpddr3_ck_t		,      
   	output 			[ 0: 0]  			c0_lpddr3_ck_c		,
   	output 			[ 0: 0]  			c0_lpddr3_cs_n		, 
   	output 			[ 0: 0]	 			c0_lpddr3_cke		,
   	output 			[ 0: 0]	 			c0_lpddr3_odt		,
   	inout  			[31: 0]  			c0_lpddr3_dq		,
   	inout  			[ 3: 0]  			c0_lpddr3_dqs_t		,
   	inout  			[ 3: 0]  			c0_lpddr3_dqs_c		,
   	output 			[ 3: 0]  			c0_lpddr3_dm		,
//-DECLARE TPGL IO------------------------------------------------------	
	input								tpgm_link_rstn_inpp	,
	input								tpgm_link_rstn_inpn	,

	input								tpgm_link_tune_txdo	,
	input								tpgm_link_tune_rxdi	,

	input								tpgm_link_fclk_inpp	,
	input								tpgm_link_fclk_inpn	,
	input								tpgm_link_fram_inpp	,
	input								tpgm_link_fram_inpn	,
	input								tpgm_link_dat0_inpp	,
	input								tpgm_link_dat0_inpn	,
	input								tpgm_link_dat1_inpp	,
	input								tpgm_link_dat1_inpn	,
	input								tpgm_link_dat2_inpp	,
	input								tpgm_link_dat2_inpn	,
	input								tpgm_link_dat3_inpp	,
	input								tpgm_link_dat3_inpn	,

	output								tpgs_link_fclk_outp	,
	output								tpgs_link_fclk_outn	,
	output								tpgs_link_fram_outp	,
	output								tpgs_link_fram_outn	,
	output								tpgs_link_dat0_outp	,
	output								tpgs_link_dat0_outn	,
	output								tpgs_link_dat1_outp	,
	output								tpgs_link_dat1_outn	,
	output								tpgs_link_dat2_outp	,
	output								tpgs_link_dat2_outn	,
	output								tpgs_link_dat3_outp	,
	output								tpgs_link_dat3_outn	,
//-DECLARE TPEL IO-------------------------------------------------
	output			[ 0: 7]				tpem_link_tune_txdo	,
	output			[ 0: 7]				tpem_link_tune_rxdi	,

	output			[ 0: 7]				tpem_link_rstn_outp	,
//	output			[ 0: 7]				tpem_link_rstn_outn	,
	input			[ 0: 7]				slx9_link_ilas_inpp	,

	output			[ 0: 7]				tpem_link_fclk_outp	,
	output			[ 0: 7]				tpem_link_fclk_outn	,
	output			[ 0: 7]				tpem_link_fram_outp	,
	output			[ 0: 7]				tpem_link_fram_outn	,
	output			[ 0: 7]				tpem_link_dat0_outp	,
	output			[ 0: 7]				tpem_link_dat0_outn	,
	output			[ 0: 7]				tpem_link_dat1_outp	,
	output			[ 0: 7]				tpem_link_dat1_outn	,
	output			[ 0: 7]				tpem_link_dat2_outp	,
	output			[ 0: 7]				tpem_link_dat2_outn	,
	output			[ 0: 7]				tpem_link_dat3_outp	,
	output			[ 0: 7]				tpem_link_dat3_outn	,

	input			[ 0: 7]				tpes_link_fclk_inpp	,
	input			[ 0: 7]				tpes_link_fclk_inpn	,
	input			[ 0: 7]				tpes_link_fram_inpp	,
	input			[ 0: 7]				tpes_link_fram_inpn	,
	input			[ 0: 7]				tpes_link_dat0_inpp	,
	input			[ 0: 7]				tpes_link_dat0_inpn	,
	input			[ 0: 7]				tpes_link_dat1_inpp	,
	input			[ 0: 7]				tpes_link_dat1_inpn	,
	input			[ 0: 7]				tpes_link_dat2_inpp	,
	input			[ 0: 7]				tpes_link_dat2_inpn	,
	input			[ 0: 7]				tpes_link_dat3_inpp	,
	input			[ 0: 7]				tpes_link_dat3_inpn	,

	output			[ 0: 7]				tpem_scfg_prog_outp	,
	output			[ 0: 7]				tpem_scfg_cclk_outp	,
	output			[ 0: 7]				tpem_scfg_data_outp	,
	input			[ 0: 7]				tpem_scfg_init_inpp	,
	input			[ 0: 7]				tpem_scfg_done_inpp	,

	input								chip_clki_inpp		,
	input								chip_clki_inpn		);
/**********************************************************************************************************/
	IBUFDS							u_CHIP_CLKI_IPAD (
		.O								( chip_clki_w				), 
		.I								( chip_clki_inpp		),
		.IB								( chip_clki_inpn		));

	(* KEEP = "TRUE" *)	
	BUFG 							BUFG_CHIP_CLKI(
		.O  						 	(chip_clki     		),
    	.I  						 	(chip_clki_w    	));		
	
/**********************************************************************************************************/
	wire								mgt1_osde_rdma_trdy		;
	wire								mgt1_osde_rdma_drdy		;
	wire		[255:0]					mgt1_osde_rdma_data		;

	ku35_fpga_core					u_ku35_fpga_core(
		.link_cclk						(link_cclk				),//output				
		.chip_clki						(chip_clki				),//output				
//-DECLARE MGT-SERDES RXIO----------------------------------------------
		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output				
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output				
		.mgt1_osde_rdma_trdy			(mgt1_osde_rdma_trdy	),//input				
		.mgt1_osde_rdma_drdy			(mgt1_osde_rdma_drdy	),//output				
		.mgt1_osde_rdma_data			(mgt1_osde_rdma_data	),//output		[255:0]	
		.mgt1_clki						(mgt1_clki				),//input				
//-DECLARE LPDDR3 IO----------------------------------------------------
   		.c0_lpddr3_ca					(c0_lpddr3_ca			),//output 		[ 9: 0] 
   		.c0_lpddr3_ck_t					(c0_lpddr3_ck_t			),//output 		[ 0: 0] 
   		.c0_lpddr3_ck_c					(c0_lpddr3_ck_c			),//output 		[ 0: 0] 
   		.c0_lpddr3_cs_n					(c0_lpddr3_cs_n			), //output 		[ 0: 0] 
   		.c0_lpddr3_cke					(c0_lpddr3_cke			),//output 		[ 0: 0]	
   		.c0_lpddr3_odt					(c0_lpddr3_odt			),//output 		[ 0: 0]	
   		.c0_lpddr3_dq					(c0_lpddr3_dq			),//inout  		[31: 0] 
   		.c0_lpddr3_dqs_t				(c0_lpddr3_dqs_t		),//inout  		[ 3: 0] 
   		.c0_lpddr3_dqs_c				(c0_lpddr3_dqs_c		),//inout  		[ 3: 0] 
   		.c0_lpddr3_dm					(c0_lpddr3_dm			),//output 		[ 3: 0] 
//-DECLARE TPGL IO------------------------------------------------------	
		.tpgm_link_rstn_inpp			(tpgm_link_rstn_inpp	),//input	
		.tpgm_link_rstn_inpn			(tpgm_link_rstn_inpn	),//input	

		.tpgm_link_tune_txdo			(tpgm_link_tune_txdo	),//input	
		.tpgm_link_tune_rxdi			(tpgm_link_tune_rxdi	),//input	

		.tpgm_link_fclk_inpp			(tpgm_link_fclk_inpp	),//input	
		.tpgm_link_fclk_inpn			(tpgm_link_fclk_inpn	),//input	
		.tpgm_link_fram_inpp			(tpgm_link_fram_inpp	),//input	
		.tpgm_link_fram_inpn			(tpgm_link_fram_inpn	),//input	
		.tpgm_link_dat0_inpp			(tpgm_link_dat0_inpp	),//input	
		.tpgm_link_dat0_inpn			(tpgm_link_dat0_inpn	),//input	
		.tpgm_link_dat1_inpp			(tpgm_link_dat1_inpp	),//input	
		.tpgm_link_dat1_inpn			(tpgm_link_dat1_inpn	),//input	
		.tpgm_link_dat2_inpp			(tpgm_link_dat2_inpp	),//input	
		.tpgm_link_dat2_inpn			(tpgm_link_dat2_inpn	),//input	
		.tpgm_link_dat3_inpp			(tpgm_link_dat3_inpp	),//input	
		.tpgm_link_dat3_inpn			(tpgm_link_dat3_inpn	),//input	
		.tpgs_link_fclk_outp			(tpgs_link_fclk_outp	),//output	
		.tpgs_link_fclk_outn			(tpgs_link_fclk_outn	),//output	
		.tpgs_link_fram_outp			(tpgs_link_fram_outp	),//output	
		.tpgs_link_fram_outn			(tpgs_link_fram_outn	),//output	
		.tpgs_link_dat0_outp			(tpgs_link_dat0_outp	),//output	
		.tpgs_link_dat0_outn			(tpgs_link_dat0_outn	),//output	
		.tpgs_link_dat1_outp			(tpgs_link_dat1_outp	),//output	
		.tpgs_link_dat1_outn			(tpgs_link_dat1_outn	),//output	
		.tpgs_link_dat2_outp			(tpgs_link_dat2_outp	),//output	
		.tpgs_link_dat2_outn			(tpgs_link_dat2_outn	),//output	
		.tpgs_link_dat3_outp			(tpgs_link_dat3_outp	),//output	
		.tpgs_link_dat3_outn			(tpgs_link_dat3_outn	),//output	
//-DECLARE TPEL IO-------------------------------------------------
		.tpem_tune_txdo_mode			(tpem_link_tune_txdo	),//output		[ 0: 7]	
		.tpem_tune_rxdi_mode			(tpem_link_tune_rxdi	),//output		[ 0: 7]	
		
		.tpem_link_rstn_outp			(tpem_link_rstn_outp	),//output		[ 0: 7]	
		.slx9_link_ilas_inpp			(slx9_link_ilas_inpp	),//output		[ 0: 7]	

		.tpem_link_fclk_outp			(tpem_link_fclk_outp	),//output		[ 0: 7]	
		.tpem_link_fclk_outn			(tpem_link_fclk_outn	),//output		[ 0: 7]	
		.tpem_link_fram_outp			(tpem_link_fram_outp	),//output		[ 0: 7]	
		.tpem_link_fram_outn			(tpem_link_fram_outn	),//output		[ 0: 7]	
		.tpem_link_dat0_outp			(tpem_link_dat0_outp	),//output		[ 0: 7]	
		.tpem_link_dat0_outn			(tpem_link_dat0_outn	),//output		[ 0: 7]	
		.tpem_link_dat1_outp			(tpem_link_dat1_outp	),//output		[ 0: 7]	
		.tpem_link_dat1_outn			(tpem_link_dat1_outn	),//output		[ 0: 7]	
		.tpem_link_dat2_outp			(tpem_link_dat2_outp	),//output		[ 0: 7]	
		.tpem_link_dat2_outn			(tpem_link_dat2_outn	),//output		[ 0: 7]	
		.tpem_link_dat3_outp			(tpem_link_dat3_outp	),//output		[ 0: 7]	
		.tpem_link_dat3_outn			(tpem_link_dat3_outn	),//output		[ 0: 7]	

		.tpes_link_fclk_inpp			(tpes_link_fclk_inpp	),//input		[ 0: 7]	
		.tpes_link_fclk_inpn			(tpes_link_fclk_inpn	),//input		[ 0: 7]	
		.tpes_link_fram_inpp			(tpes_link_fram_inpp	),//input		[ 0: 7]	
		.tpes_link_fram_inpn			(tpes_link_fram_inpn	),//input		[ 0: 7]	
		.tpes_link_dat0_inpp			(tpes_link_dat0_inpp	),//input		[ 0: 7]	
		.tpes_link_dat0_inpn			(tpes_link_dat0_inpn	),//input		[ 0: 7]	
		.tpes_link_dat1_inpp			(tpes_link_dat1_inpp	),//input		[ 0: 7]	
		.tpes_link_dat1_inpn			(tpes_link_dat1_inpn	),//input		[ 0: 7]	
		.tpes_link_dat2_inpp			(tpes_link_dat2_inpp	),//input		[ 0: 7]	
		.tpes_link_dat2_inpn			(tpes_link_dat2_inpn	),//input		[ 0: 7]	
		.tpes_link_dat3_inpp			(tpes_link_dat3_inpp	),//input		[ 0: 7]	
		.tpes_link_dat3_inpn			(tpes_link_dat3_inpn	),//input		[ 0: 7]	
		.tpem_scfg_prog_outp			(tpem_scfg_prog_outp	),//output		[ 0: 7]	
		.tpem_scfg_cclk_outp			(tpem_scfg_cclk_outp	),//output		[ 0: 7]	
		.tpem_scfg_data_outp			(tpem_scfg_data_outp	),//output		[ 0: 7]	
		.tpem_scfg_init_inpp			(tpem_scfg_init_inpp	),//input		[ 0: 7]	
		.tpem_scfg_done_inpp			(tpem_scfg_done_inpp	));//input		[ 0: 7]	
/**********************************************************************************************************/
//AURORA-SERDES PORT 0
	ku35_mgt1_sdes_txo				u_ku35_mgt1_sdes(
		.mgt1_txp_io					(mgt1_txp_io			),//output	[ 0: 3]	
		.mgt1_txn_io					(mgt1_txn_io			),//output	[ 0: 3]	
		.mgt1_rclk_p					(mgt1_rclk_p			),//input			
		.mgt1_rclk_n					(mgt1_rclk_n			),//input			

		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//output			
		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//input			
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//input			
		.mgt1_osde_rdma_data			(mgt1_osde_rdma_data	),//input	[255:0]	
    	.mgt1_osde_rdma_drdy			(mgt1_osde_rdma_drdy	),//input			
    	.mgt1_osde_rdma_trdy			(mgt1_osde_rdma_trdy	),//output			

		.mgt1_clki						(mgt1_clki				),//output	
		.link_cclk						(link_cclk				));//input	
endmodule
	
