#####################################################################################################################################
	create_clock	-period 10.000	-name chip_100m 			[get_ports chip_clki_inpp]
#####################################################################################################################################
	set    mmcm_clki					[get_pins u_ku35_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKIN1]
	set    mmcm_clko					[get_pins u_ku35_fpga_core/u_xcku_clks_gens/CHIP_MMCM/CLKOUT0]

	create_generated_clock 				-name 			mmcm_320m				[get_pins $mmcm_clko]	\
	                       				-source    			           			[get_pins $mmcm_clki]   \
	                       				-mul    		16          	                               	\ 
	                       				-div    		5               	                           	\
	                       				-master_clock 	chip_100m		  		-add
#####################################################################################################################################
	set	chip_clki_bufg	   				[get_cells BUFG_CHIP_CLKI]
    set	link_fclk_bufg	   				[get_cells u_ku35_fpga_core/u_xcku_clks_gens/BUFG_320M]
	set	link_sclk_bufg	   				[get_cells u_ku35_fpga_core/u_xcku_clks_gens/BUFG_080M]
	set	link_cclk_bufg 	   				[get_cells u_ku35_fpga_core/u_xcku_clks_gens/BUFG_040M]

	set_property CLOCK_REGION X2Y2 [get_cells 		$chip_clki_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 		$link_fclk_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 		$link_sclk_bufg]
	set_property CLOCK_REGION X2Y2 [get_cells 		$link_cclk_bufg]

	create_generated_clock	-name	link_fclk	[get_pins $link_fclk_bufg/O]	-source	[get_pins $link_fclk_bufg/I]	-div 1	-master_clock	mmcm_320m	-add
	create_generated_clock	-name	link_sclk	[get_pins $link_sclk_bufg/O]	-source	[get_pins $link_sclk_bufg/I]	-div 4	-master_clock	mmcm_320m	-add
	create_generated_clock	-name	link_cclk	[get_pins $link_cclk_bufg/O]	-source	[get_pins $link_cclk_bufg/I]	-div 8	-master_clock	mmcm_320m	-add
#####################################################################################################################################
	create_generated_clock	-name 	tpgl_txdo_clko	[get_ports tpgs_link_fclk_outp	 ]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe0_txdo_clko	[get_ports tpem_link_fclk_outp[0]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe1_txdo_clko	[get_ports tpem_link_fclk_outp[1]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe2_txdo_clko	[get_ports tpem_link_fclk_outp[2]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe3_txdo_clko	[get_ports tpem_link_fclk_outp[3]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe4_txdo_clko	[get_ports tpem_link_fclk_outp[4]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe5_txdo_clko	[get_ports tpem_link_fclk_outp[5]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe6_txdo_clko	[get_ports tpem_link_fclk_outp[6]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
	create_generated_clock	-name 	tpe7_txdo_clko	[get_ports tpem_link_fclk_outp[7]]	-source	[get_pins $link_fclk_bufg/O]	-div 1	-master_clock	link_fclk	-add
#####################################################################################################################################
	create_clock -period 10.000 -name mgt1_base_clki   	[get_ports mgt1_rclk_p]
	
	create_clock -period  3.125	-name tpgl_rxdi_clki 	[get_ports tpgm_link_fclk_inpp]

	create_clock -period  6.25 	-name tpe0_rxdi_clki 	[get_ports tpes_link_fclk_inpp[0]]
	create_clock -period  6.25 	-name tpe1_rxdi_clki 	[get_ports tpes_link_fclk_inpp[1]]
	create_clock -period  6.25 	-name tpe2_rxdi_clki 	[get_ports tpes_link_fclk_inpp[2]]
	create_clock -period  6.25 	-name tpe3_rxdi_clki 	[get_ports tpes_link_fclk_inpp[3]]
	create_clock -period  6.25 	-name tpe4_rxdi_clki 	[get_ports tpes_link_fclk_inpp[4]]
	create_clock -period  6.25 	-name tpe5_rxdi_clki 	[get_ports tpes_link_fclk_inpp[5]]
	create_clock -period  6.25 	-name tpe6_rxdi_clki 	[get_ports tpes_link_fclk_inpp[6]]
	create_clock -period  6.25 	-name tpe7_rxdi_clki 	[get_ports tpes_link_fclk_inpp[7]]
#####################################################################################################################################
	set_property CLOCK_REGION X2Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/u_tpgs_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y1 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y0 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y3 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y3 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y1 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y0 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_BUFG/O] ]


	set_property CLOCK_REGION X2Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/u_tpgs_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y1 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y2 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y0 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y3 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y3 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y1 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
	set_property CLOCK_REGION X0Y0 [get_cells -of 	[get_pins u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_SCLK_BUFG/O] ]
#####################################################################################################################################
 	set_property CLOCK_DEDICATED_ROUTE BACKBONE	[get_nets chip_clki]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/u_tpgs_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
	set_property CLOCK_DEDICATED_ROUTE FALSE	[get_nets u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/LVDS_FCLK_PAD/O ]
#####################################################################################################################################
	set	tpgl_ctrl_rxdi	[get_ports tpgm_link_* -filter {NAME =~ "*rstn*" || NAME !~ "*tune*" }]
    set_input_delay 	-clock chip_clki 0.01	[get_ports $tpgl_ctrl_rxdi]
	
	set	tpgl_func_rxdi	[get_ports tpgm_link_*_inp* -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]
	set	tpgl_func_txdo	[get_ports tpgs_link_*_out* -filter {NAME !~ "*fclk*" }]	
	
	set_input_delay 	-clock tpgl_rxdi_clki 0.01	[get_ports $tpgl_func_rxdi]
	set_input_delay 	-clock tpgl_rxdi_clki 0.01	[get_ports $tpgl_func_rxdi] -clock_fall -add_delay

	set_output_delay 	-clock tpgl_txdo_clko 0.01	[get_ports $tpgl_func_txdo ]
	set_output_delay 	-clock tpgl_txdo_clko 0.01	[get_ports $tpgl_func_txdo ] -clock_fall -add_delay
################ TPEL iodelay####################
	set	tpe0_func_rxdi	[get_ports tpes_link_*_inp*[0] -filter {NAME !~ "*fclk*" }]	
	set	tpe1_func_rxdi	[get_ports tpes_link_*_inp*[1] -filter {NAME !~ "*fclk*" }]	
	set	tpe2_func_rxdi	[get_ports tpes_link_*_inp*[2] -filter {NAME !~ "*fclk*" }]	
	set	tpe3_func_rxdi	[get_ports tpes_link_*_inp*[3] -filter {NAME !~ "*fclk*" }]	
	set	tpe4_func_rxdi	[get_ports tpes_link_*_inp*[4] -filter {NAME !~ "*fclk*" }]	
	set	tpe5_func_rxdi	[get_ports tpes_link_*_inp*[5] -filter {NAME !~ "*fclk*" }]	
	set	tpe6_func_rxdi	[get_ports tpes_link_*_inp*[6] -filter {NAME !~ "*fclk*" }]	
	set	tpe7_func_rxdi	[get_ports tpes_link_*_inp*[7] -filter {NAME !~ "*fclk*" }]	

	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi]
	set_input_delay -clock tpe0_rxdi_clki 0.01	[get_ports $tpe0_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi]
	set_input_delay -clock tpe1_rxdi_clki 0.01	[get_ports $tpe1_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi]
	set_input_delay -clock tpe2_rxdi_clki 0.01	[get_ports $tpe2_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi]
	set_input_delay -clock tpe3_rxdi_clki 0.01	[get_ports $tpe3_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi]
	set_input_delay -clock tpe4_rxdi_clki 0.01	[get_ports $tpe4_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi]
	set_input_delay -clock tpe5_rxdi_clki 0.01	[get_ports $tpe5_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi]
	set_input_delay -clock tpe6_rxdi_clki 0.01	[get_ports $tpe6_func_rxdi] -clock_fall -add_delay

	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi]
	set_input_delay -clock tpe7_rxdi_clki 0.01	[get_ports $tpe7_func_rxdi] -clock_fall -add_delay
####################################
	set	tpe0_func_txdo	[get_ports tpem_link_*_out*[0] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe1_func_txdo	[get_ports tpem_link_*_out*[1] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe2_func_txdo	[get_ports tpem_link_*_out*[2] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe3_func_txdo	[get_ports tpem_link_*_out*[3] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe4_func_txdo	[get_ports tpem_link_*_out*[4] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe5_func_txdo	[get_ports tpem_link_*_out*[5] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe6_func_txdo	[get_ports tpem_link_*_out*[6] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	
	set	tpe7_func_txdo	[get_ports tpem_link_*_out*[7] -filter {NAME !~ "*fclk*" && NAME !~ "*rstn*" && NAME !~ "*tune*" }]	

	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo ]
	set_output_delay -clock tpe0_txdo_clko 0.01	[get_ports $tpe0_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo ]
	set_output_delay -clock tpe1_txdo_clko 0.01	[get_ports $tpe1_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo ]
	set_output_delay -clock tpe2_txdo_clko 0.01	[get_ports $tpe2_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo ]
	set_output_delay -clock tpe3_txdo_clko 0.01	[get_ports $tpe3_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo ]
	set_output_delay -clock tpe4_txdo_clko 0.01	[get_ports $tpe4_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo ]
	set_output_delay -clock tpe5_txdo_clko 0.01	[get_ports $tpe5_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo ]
	set_output_delay -clock tpe6_txdo_clko 0.01	[get_ports $tpe6_func_txdo ] -clock_fall -add_delay
	
	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo ]
	set_output_delay -clock tpe7_txdo_clko 0.01	[get_ports $tpe7_func_txdo ] -clock_fall -add_delay
####################################
	set	tpe0_ctrl_txdo	[get_ports tpem_link_*_out*[0] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe1_ctrl_txdo	[get_ports tpem_link_*_out*[1] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe2_ctrl_txdo	[get_ports tpem_link_*_out*[2] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe3_ctrl_txdo	[get_ports tpem_link_*_out*[3] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe4_ctrl_txdo	[get_ports tpem_link_*_out*[4] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe5_ctrl_txdo	[get_ports tpem_link_*_out*[5] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe6_ctrl_txdo	[get_ports tpem_link_*_out*[6] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	
	set	tpe7_ctrl_txdo	[get_ports tpem_link_*_out*[7] -filter {NAME =~ "*tune*" || NAME =~ "*rstn*" }]	

	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe0_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe1_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe2_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe3_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe4_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe5_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe6_ctrl_txdo ]
	set_output_delay -clock	[get_clocks link_sclk]	0.01	[get_ports $tpe7_ctrl_txdo ]

#############################################################################################################################
####	Timing Constraint Exception
#############################################################################################################################
#	set ddrs_uclk_pin	[get_pins u_ku35_fpga_core/u_lpddr3_256m/inst/u_ddr_infrastructure/u_bufg_divClk/O]
#	set	mgt1_uclk_pin	[get_pins u_ku35_mgt1_sdes/u_mgt1_osde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O]
#	set ddrs_uclk		[get_clocks -of_objects $ddrs_uclk_pin]
#	set	mgt1_uclk		[get_clocks -of_objects $mgt1_uclk_pin]
############################################################################################################

	
	set	mgth_uclk	[get_clocks -of [get_pins u_ku35_mgt1_sdes/u_mgt1_osde_quad/inst/clock_module_i/ultrascale_tx_userclk_1/gen_gtwiz_userclk_tx_main.bufg_gt_usrclk2_inst/O]]
	set	ddrs_uclk	[get_clocks -of [get_pins u_ku35_fpga_core/u_lpddr3_256m/inst/u_ddr_infrastructure/gen_mmcme3.u_mmcme_adv_inst/CLKOUT0]]

	set_clock_groups 	-name 	tpgl_asyn_link_fclk -asynchronous	-group	[get_clocks link_fclk  	]	-group 	[get_clocks tpgl_rxdi_clki	]
	set_clock_groups 	-name 	link_asyn_tpxl_rcki -asynchronous	-group	[get_clocks link_sclk	]	-group 	[get_clocks tp*_rxdi_clki 	]	
	set_clock_groups 	-name 	mgth_asyn_init_bclk -asynchronous	-group	[get_clocks link_cclk	]	-group	[get_clocks $mgth_uclk 		]	
	set_clock_groups 	-name 	mgth_asyn_link_sclk -asynchronous	-group	[get_clocks link_sclk	]	-group	[get_clocks $mgth_uclk		]
	set_clock_groups 	-name 	link_asyn_ddrs_uclk -asynchronous	-group	[get_clocks link_sclk	]	-group	[get_clocks $ddrs_uclk		]
	set_clock_groups 	-name 	ddrs_asyn_mgth_uclk -asynchronous	-group  [get_clocks $ddrs_uclk	]	-group	[get_clocks $mgth_uclk		] 	
	set_clock_groups 	-name	link_asyn_lane_sclk	-asynchronous	-group 	[get_clocks link_sclk  	]	-group	[get_clocks lane_sclk* 		] 	
					
	set_false_path      -from   [get_ports  tpgm_link_tune* ]
#####################################################################################################################################
	set_property IODELAY_GROUP "dlygrp_x0y0" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y0]
	set_property IODELAY_GROUP "dlygrp_x0y0" [get_cells u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y0" [get_cells u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y1" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y1]
	set_property IODELAY_GROUP "dlygrp_x0y1" [get_cells u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y1" [get_cells u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y1" [get_cells u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y14" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y14]
	set_property IODELAY_GROUP "dlygrp_x0y14" [get_cells u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y14" [get_cells u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y15" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y15]
	set_property IODELAY_GROUP "dlygrp_x0y15" [get_cells u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y15" [get_cells u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y15" [get_cells u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y16" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y16]
	set_property IODELAY_GROUP "dlygrp_x0y16" [get_cells u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y16" [get_cells u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y17" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y17]
	set_property IODELAY_GROUP "dlygrp_x0y17" [get_cells u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y17" [get_cells u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y17" [get_cells u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y22" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y22]
	set_property IODELAY_GROUP "dlygrp_x0y22" [get_cells u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y22" [get_cells u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y23" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y23]
	set_property IODELAY_GROUP "dlygrp_x0y23" [get_cells u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y23" [get_cells u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y23" [get_cells u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y24" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y24]
	set_property IODELAY_GROUP "dlygrp_x0y24" [get_cells u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y24" [get_cells u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y24" [get_cells u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y25" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y25]
	set_property IODELAY_GROUP "dlygrp_x0y25" [get_cells u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y25" [get_cells u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y30" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y30]
	set_property IODELAY_GROUP "dlygrp_x0y30" [get_cells u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y30" [get_cells u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y31" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y31]
	set_property IODELAY_GROUP "dlygrp_x0y31" [get_cells u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y31" [get_cells u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y31" [get_cells u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y6" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y6]
	set_property IODELAY_GROUP "dlygrp_x0y6" [get_cells u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y6" [get_cells u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y7" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y7]
	set_property IODELAY_GROUP "dlygrp_x0y7" [get_cells u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y7" [get_cells u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y7" [get_cells u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y8" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y8]
	set_property IODELAY_GROUP "dlygrp_x0y8" [get_cells u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[1].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y8" [get_cells u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[2].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y8" [get_cells u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[3].u_RXDI_IDLY_CELL]

	set_property IODELAY_GROUP "dlygrp_x0y9" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y9]
	set_property IODELAY_GROUP "dlygrp_x0y9" [get_cells u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[0].u_RXDI_IDLY_CELL]
	set_property IODELAY_GROUP "dlygrp_x0y9" [get_cells u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_rxdi_pmau/gens_rdxi_idly_cell[4].u_RXDI_IDLY_CELL]


#	set_property IODELAY_GROUP "dlygrp_x0y12" 	[get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y12]
#	set_property IODELAY_GROUP "dlygrp_x0y12" 	[get_cells 	u_ku35_fpga_core/gens_tpem_link_port[0].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y4" 	[get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y4]
#	set_property IODELAY_GROUP "dlygrp_x0y4" 	[get_cells 	u_ku35_fpga_core/gens_tpem_link_port[1].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y11" 	[get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y11]
#	set_property IODELAY_GROUP "dlygrp_x0y11" 	[get_cells 	u_ku35_fpga_core/gens_tpem_link_port[2].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y19" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y19]
#	set_property IODELAY_GROUP "dlygrp_x0y19" [get_cells 	u_ku35_fpga_core/gens_tpem_link_port[3].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y28" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y28]
#	set_property IODELAY_GROUP "dlygrp_x0y28" [get_cells 	u_ku35_fpga_core/gens_tpem_link_port[4].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y20" [get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y20]
#	set_property IODELAY_GROUP "dlygrp_x0y20" [get_cells 	u_ku35_fpga_core/gens_tpem_link_port[5].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y27" 	[get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y27]
#	set_property IODELAY_GROUP "dlygrp_x0y27" 	[get_cells 	u_ku35_fpga_core/gens_tpem_link_port[6].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#	set_property IODELAY_GROUP "dlygrp_x0y3" 	[get_cells u_ku35_fpga_core/u_ku35_dlys_ctrl/u_dlys_ctrl_x0y3]
#	set_property IODELAY_GROUP "dlygrp_x0y3" 	[get_cells 	u_ku35_fpga_core/gens_tpem_link_port[7].u_tpem_link_txdo_pmau/u_FCLK_ODLY_CELL]
#
#
#
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[3]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[5]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat1_outp[7]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_dat3_outp[6]]
#	set_property UNAVAILABLE_DURING_CALIBRATION TRUE [get_ports tpem_link_fram_outp[2]]
															

#####################################################################################################################################
	set_property CONFIG_MODE SPIx4 [current_design]
	set_property BITSTREAM.CONFIG.CONFIGRATE 110 [current_design]
	set_property CONFIG_VOLTAGE 1.8 [current_design]
	set_property CFGBVS GND [current_design]
	set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]
	set_property BITSTREAM.CONFIG.SPI_FALL_EDGE YES [current_design]
	set_property BITSTREAM.CONFIG.CONFIGFALLBACK DISABLE [current_design]
	set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]



