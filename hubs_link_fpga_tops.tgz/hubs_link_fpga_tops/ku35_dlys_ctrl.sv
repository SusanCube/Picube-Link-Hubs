module	ku35_dlys_ctrl(
	output		reg						dlys_brst			,
	output								dlys_drdy			,
	input								dlys_fclk			,
	input								dlys_sclk			,
	input								dlys_rstn			);
/***********************************************************************************************************************/
	reg			[ 4: 0]					dlys_drdy_samp	=	5'H00	;
	reg									dlys_ctrl_drdy	=	1'b0	;
	reg			[ 0:15]					dlys_ctrl_sreg	;
	wire		[ 0:15]					dlys_ctrl_stat	;

	assign	dlys_drdy	=	dlys_ctrl_drdy	;		

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_sreg	<=	0	;
	else 								dlys_ctrl_sreg	<=	dlys_ctrl_stat	;

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_drdy	<=	0	;
	else 								dlys_ctrl_drdy	<= &dlys_ctrl_sreg	;

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_drdy_samp	<= 	0	;
	else 								dlys_drdy_samp	<= 	{dlys_ctrl_drdy	,	dlys_drdy_samp[4:1]};

	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_brst		<=	0	;
	else 								dlys_brst		<= 	dlys_drdy_samp[2:0]	== 3'B100		;
/***********************************************************************************************************************/
	reg									dlys_ctrl_disa	=	1'B1	;
	reg			[15: 0]					dlys_ctrl_time	=	16'H0000;
	reg			[15: 0]					dlys_ctrl_prst	=	16'HFFFF;

	wire								dlys_ctrl_init	;				

`ifdef 	FAST_SIMU
	assign	dlys_ctrl_init	=			dlys_ctrl_time	<= 	16'H00F0;
`else
	assign	dlys_ctrl_init	=			dlys_ctrl_time	<= 	16'HFFF0;
`endif	

//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_time	<=	0	;
	else if( dlys_ctrl_init)			dlys_ctrl_time	<=	1	+	dlys_ctrl_time	;
//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)	
	if(~dlys_rstn)						dlys_ctrl_disa	<=	1'H1	;
	else 								dlys_ctrl_disa	<=	dlys_ctrl_init	;
//------------------------------------------------------------------------------
	always@(posedge dlys_sclk or negedge dlys_rstn)
	if(~dlys_rstn)						dlys_ctrl_prst	<=	16'HFFFF;
	else 								dlys_ctrl_prst	<= {16{dlys_ctrl_disa}	};
/***********************************************************************************************************************/
	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y0" *) (* BEL = "BITSLICE_CONTROL_X0Y0" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y0 (.RDY(dlys_ctrl_stat[ 0]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 0]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y1" *) (* BEL = "BITSLICE_CONTROL_X0Y1" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y1 (.RDY(dlys_ctrl_stat[ 1]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 1]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y6" *) (* BEL = "BITSLICE_CONTROL_X0Y6" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y6 (.RDY(dlys_ctrl_stat[ 2]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 2]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y7" *) (* BEL = "BITSLICE_CONTROL_X0Y7" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y7 (.RDY(dlys_ctrl_stat[ 3]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 3]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y8" *) (* BEL = "BITSLICE_CONTROL_X0Y8" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y8 (.RDY(dlys_ctrl_stat[ 4]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 4]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y9" *) (* BEL = "BITSLICE_CONTROL_X0Y9" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y9 (.RDY(dlys_ctrl_stat[ 5]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 5]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y14" *) (* BEL = "BITSLICE_CONTROL_X0Y14" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y14 (.RDY(dlys_ctrl_stat[ 6]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 6]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y15" *) (* BEL = "BITSLICE_CONTROL_X0Y15" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y15 (.RDY(dlys_ctrl_stat[ 7]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 7]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y16" *) (* BEL = "BITSLICE_CONTROL_X0Y16" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y16 (.RDY(dlys_ctrl_stat[ 8]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 8]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y17" *) (* BEL = "BITSLICE_CONTROL_X0Y17" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y17 (.RDY(dlys_ctrl_stat[ 9]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[ 9]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y22" *) (* BEL = "BITSLICE_CONTROL_X0Y22" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y22 (.RDY(dlys_ctrl_stat[10]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[10]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y23" *) (* BEL = "BITSLICE_CONTROL_X0Y23" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y23 (.RDY(dlys_ctrl_stat[11]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[11]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y24" *) (* BEL = "BITSLICE_CONTROL_X0Y24" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y24 (.RDY(dlys_ctrl_stat[12]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[12]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y25" *) (* BEL = "BITSLICE_CONTROL_X0Y25" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y25 (.RDY(dlys_ctrl_stat[13]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[13]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y30" *) (* BEL = "BITSLICE_CONTROL_X0Y30" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y30 (.RDY(dlys_ctrl_stat[14]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[14]));

	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y31" *) (* BEL = "BITSLICE_CONTROL_X0Y31" *)
	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y31 (.RDY(dlys_ctrl_stat[15]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[15]));
//TXDO
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y12" *) (* BEL = "BITSLICE_CONTROL_X0Y12" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y12 	(.RDY(dlys_ctrl_stat[16]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[16]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y4" *) (* BEL = "BITSLICE_CONTROL_X0Y4" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y4 	(.RDY(dlys_ctrl_stat[17]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[17]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y11" *) (* BEL = "BITSLICE_CONTROL_X0Y11" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y11	(.RDY(dlys_ctrl_stat[18]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[18]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y19" *) (* BEL = "BITSLICE_CONTROL_X0Y19" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y19 	(.RDY(dlys_ctrl_stat[19]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[19]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y28" *) (* BEL = "BITSLICE_CONTROL_X0Y28" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y28 	(.RDY(dlys_ctrl_stat[20]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[20]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y20" *) (* BEL = "BITSLICE_CONTROL_X0Y20" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y20 	(.RDY(dlys_ctrl_stat[21]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[21]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y27" *) (* BEL = "BITSLICE_CONTROL_X0Y27" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y27 	(.RDY(dlys_ctrl_stat[22]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[22]));
//
//	(* DONT_TOUCH = "TRUE" *) (* LOC = "BITSLICE_CONTROL_X0Y3" *) (* BEL = "BITSLICE_CONTROL_X0Y3" *)
//	IDELAYCTRL #(.SIM_DEVICE("ULTRASCALE")) u_dlys_ctrl_x0y3 	(.RDY(dlys_ctrl_stat[23]), .REFCLK(dlys_fclk), .RST(dlys_ctrl_prst[23]));

endmodule







