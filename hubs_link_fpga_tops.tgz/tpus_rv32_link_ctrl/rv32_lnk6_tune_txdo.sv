//**********************************************************************************************************
module	rv32_link_tune_txdo(
	output		[31: 0]					rv32_tune_txdo_rout	,
	input								rv32_tune_txdo_csen	,
	input								rv32_tune_txdo_wrcs	,
	input		[ 3: 0]					rv32_tune_txdo_addr	,
	input		[31: 0]					rv32_tune_txdo_wdin	,
//-------------------------------------------------------
	input		[  0: 7]				tpem_tune_txdo_done	,
	output	reg	[  0: 7]				tpem_tune_txdo_enab	,	
	output	reg	[  0: 7][8: 0]			tpem_tune_txdo_taps	,	
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	wire	[ 0: 7]						rv32_tune_txdo_csid	;
	wire	[ 0: 7]						rv32_tune_txdo_wrid	;
	wire	[ 0: 7][31: 0]				rv32_tune_txdo_word	;

for(genvar i = 0 ; i < 8 ; i++ ) 	begin	:	rv32_tune_txdo_rwcs

	assign	rv32_tune_txdo_csid[i]	= &{rv32_tune_txdo_csen	,	rv32_tune_txdo_addr==i	};
	assign	rv32_tune_txdo_wrid[i]	= &{rv32_tune_txdo_wrcs	,	rv32_tune_txdo_csid[i]	};
			
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tpem_tune_txdo_taps[i]	<=	0	;
	else if(rv32_tune_txdo_wrid[i])		tpem_tune_txdo_taps[i]	<=	rv32_tune_txdo_wdin[8:0];

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						tpem_tune_txdo_enab[i]	<=	0	;
	else if(rv32_tune_txdo_wrid[i])		tpem_tune_txdo_enab[i]	<=	1	;
	else if(tpem_tune_txdo_done[i])		tpem_tune_txdo_enab[i]	<=	0	;


	assign	rv32_tune_txdo_word[i]	={ 	tpem_tune_txdo_enab[i]	,
										16'H00	,		
										7'H0	, 	
										tpem_tune_txdo_taps		};

end	
//----------------------------------------------------------------------------------------------------------
	assign	rv32_tune_txdo_rout	=	rv32_tune_txdo_csid[ 0]	?	rv32_tune_txdo_word[ 0]	:
									rv32_tune_txdo_csid[ 1]	?	rv32_tune_txdo_word[ 1]	:
									rv32_tune_txdo_csid[ 2]	?	rv32_tune_txdo_word[ 2]	:
									rv32_tune_txdo_csid[ 3]	?	rv32_tune_txdo_word[ 3]	:
									rv32_tune_txdo_csid[ 4]	?	rv32_tune_txdo_word[ 4]	:
									rv32_tune_txdo_csid[ 5]	?	rv32_tune_txdo_word[ 5]	:
									rv32_tune_txdo_csid[ 6]	?	rv32_tune_txdo_word[ 6]	:
									rv32_tune_txdo_csid[ 7]	?	rv32_tune_txdo_word[ 7]	:	32'H0	;
									
endmodule
