//**********************************************************************************************************
module	rv32_link_cmnd_argu(
	output		[31: 0]					rv32_cmnd_argu_rout	,
	input								rv32_cmnd_argu_csen	,
	input		[ 3: 0]					rv32_cmnd_argu_addr	,
//-------------------------------------------------------
	input								tpgs_link_cmnd_lead	,
	input								tpgs_link_cmnd_wrcs	,
	input		[31: 0]					tpgs_link_cmnd_data	,
//-------------------------------------------------------
	output	reg	[ 0:15][31: 0]			tpgs_link_cmnd_memo	,
//-------------------------------------------------------
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	reg		[ 3: 0]						tpgs_cmnd_argu_indx	;

	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						tpgs_cmnd_argu_indx	<=	0	;
	else if(tpgs_link_cmnd_lead)		tpgs_cmnd_argu_indx	<=	0	;
	else if(tpgs_link_cmnd_wrcs)		tpgs_cmnd_argu_indx	<=	1 +	tpgs_cmnd_argu_indx	;
	
/**********************************************************************************************************/
//CMND ARGUMENT
	wire	[ 0:15]						tpgs_cmnd_argu_csid	;
	wire	[ 0:15]						rv32_cmnd_argu_csid	;
	wire	[ 0:15]						tpgs_cmnd_argu_wrid	;

for(genvar i = 0 ; i < 16 ; i++) begin	:	rv32_link_cmnd_rwcs

	assign	rv32_cmnd_argu_csid[i]	= &{rv32_cmnd_argu_csen	,	rv32_cmnd_argu_addr ==i	};

	assign	tpgs_cmnd_argu_csid[i]	=	tpgs_cmnd_argu_indx	==	i	;
	assign	tpgs_cmnd_argu_wrid[i]	= &{tpgs_link_cmnd_wrcs	,	tpgs_cmnd_argu_csid[i]	};


	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)					tpgs_link_cmnd_memo[i]	<=	0	;
	else if(tpgs_cmnd_argu_wrid[i])	tpgs_link_cmnd_memo[i]	<=	tpgs_link_cmnd_data	;

end 
/**********************************************************************************************************/
	assign	rv32_cmnd_argu_rout	=	rv32_cmnd_argu_csid[ 0]	?	tpgs_link_cmnd_memo[ 0]	://DEST_PORT_ENAB
									rv32_cmnd_argu_csid[ 1]	?	tpgs_link_cmnd_memo[ 1]	://TPGS_DEST_MARK
									rv32_cmnd_argu_csid[ 2]	?	tpgs_link_cmnd_memo[ 2]	://TPES_DEST_MARK
									rv32_cmnd_argu_csid[ 3]	?	tpgs_link_cmnd_memo[ 3]	://EDGE_DEST_MARK
									rv32_cmnd_argu_csid[ 4]	?	tpgs_link_cmnd_memo[ 4]	://MAST_DDRS_BASE
									rv32_cmnd_argu_csid[ 5]	?	tpgs_link_cmnd_memo[ 5]	://SLAV_DDRS_BASE
									rv32_cmnd_argu_csid[ 6]	?	tpgs_link_cmnd_memo[ 6]	://META_ROWS_NUMB
									rv32_cmnd_argu_csid[ 7]	?	tpgs_link_cmnd_memo[ 7]	://META_COLS_NUMB
									rv32_cmnd_argu_csid[ 8]	?	tpgs_link_cmnd_memo[ 8]	://META_ROWS_PACK
									rv32_cmnd_argu_csid[ 9]	?	tpgs_link_cmnd_memo[ 9]	://META_PACK_PAGE
									rv32_cmnd_argu_csid[10]	?	tpgs_link_cmnd_memo[10]	://DLNK_BULK_PACK
									rv32_cmnd_argu_csid[11]	?	tpgs_link_cmnd_memo[11]	://DLNK_BULK_MULT
									rv32_cmnd_argu_csid[12]	?	tpgs_link_cmnd_memo[12]	://EDGE_AUXI_WRD0
									rv32_cmnd_argu_csid[13]	?	tpgs_link_cmnd_memo[13]	://EDGE_AUXI_WRD1
									rv32_cmnd_argu_csid[14]	?	tpgs_link_cmnd_memo[14]	://EDGE_AUXI_WRD2
									rv32_cmnd_argu_csid[15]	?	tpgs_link_cmnd_memo[15]	://EDGE_AUXI_WRD3
																32'H0	;
/**********************************************************************************************************/

endmodule
