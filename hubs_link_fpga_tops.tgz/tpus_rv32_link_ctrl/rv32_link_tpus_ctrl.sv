//**********************************************************************************************************
//
//	output		[24:0]				ecos_tpus_ddrs_base	,
//	output		[ 7:0]				ecos_tpus_tpem_port	,
//	output		[ 3:0]				ecos_tpus_mgth_port	,
//**********************************************************************************************************
module	rv32_link_tpus_ctrl(
//--------------RV32 RWBUS		
	input								rv32_link_tpus_csen	,
	input		[11: 0]					rv32_link_tpus_addr	,
	input								rv32_link_tpus_wrcs	,
	input		[31: 0]					rv32_link_tpus_wdin	,
	output	reg	[31: 0]					rv32_link_tpus_rout	,

	output		[11: 0]					tpgs_cram_writ_addr	,
	output								tpgs_cram_writ_csen	,
//--------------TUNE CONTROL
	output		[ 7: 0]					tpem_link_port_enab	,
	output		[ 0: 7]					tpem_tune_txdo_mode	,
	output		[ 0: 7]					tpem_tune_rxdi_mode	,
	
	input		[ 0: 7]					tpem_tune_txdo_done	,
	output		[ 0: 7]					tpem_tune_txdo_enab	,
	output		[ 0: 7][8: 0]			tpem_tune_txdo_taps	,
	
	input		[ 0: 7]					tpem_tune_rxdi_done	,
	output		[ 0: 7]					tpem_tune_rxdi_enab	,
	output		[ 0: 7][ 8: 0]			tpem_tune_rxdi_taps	,
	input		[ 0: 7][ 9: 0]			tpem_tune_rxdi_stat	,

	output								tpem_sync_rxdi_reqs	,
	input		[ 0: 7]					tpem_sync_rxdi_done	,
//--------------ECOS CONFIG PARAMETER
	output		[ 7: 0]					ecos_omni_edge_numb	,
	output		[ 4: 0]					ecos_pile_edge_numb	,
	output		[ 4: 0]					ecos_pile_edge_tail	,

	output		[ 3: 0]					this_tpgs_pile_indx	,
	output		[ 4: 0]					this_tpgs_pile_edge	,
	output								this_tpgs_pile_lead	,
	output								this_tpgs_pile_coda	,
//--------------LLM  BLASTER PARAMETER
	output		[24: 0]					llmb_meta_imag_size	,
	output		[19: 0]					llmb_meta_imag_rows	,
	output		[19: 0]					llmb_meta_imag_cols	,
	output		[19: 0]					llmb_mtrx_imag_cols	,

	output		[24: 0]					llmb_edge_imag_size	,
	output		[19: 0]					llmb_edge_imag_rows	,
	output		[19: 0]					llmb_edge_imag_cols	,
	output								llmb_edge_imag_even	,
	output								llmb_edge_imag_row2	,

	output		[24: 0]					llmb_mast_ddrs_base	,
	output		[24: 0]					llmb_devs_ddrs_base	,

	output		[3 : 0]					sdes_link_mgth_csid	,
	output		[24: 0]					sdes_link_ddrs_size	,
	output		[24: 0]					sdes_meta_ddrs_base	,
	output		[15: 0]					sdes_meta_cols_dims	,
	output		[24: 0]					sdes_hubs_ddrs_base	,
	output		[15: 0]					sdes_hubs_cols_dims	,
	output		[15: 0]					sdes_hubs_cols_dumy	,

//--------------XDMA	
	output								xdma_link_meta_mtrx	,
//	output								xdma_link_mgth_init	,
	output								xdma_osde_rdma_enab	,
	input								xdma_osde_rdma_done	,
	output								xdma_isde_wdma_enab	,
	input								xdma_isde_wdma_done	,
	output								xdma_odat_rdma_enab	,
	input								xdma_odat_rdma_done	,
	output								xdma_idat_wdma_enab	,
	input								xdma_idat_wdma_done	,
//----------------------------------MGTH LINK MISC CTRL
	output								mgt1_pmau_init_ctrl	,
	output								mgt1_rstb_push_ctrl	,
	input								mgt1_intf_link_stat	,
	input								mgt1_clki			,

	output								mgt2_pmau_init_ctrl	,
	output								mgt2_rstb_push_ctrl	,
	input								mgt2_intf_link_stat	,
	input								mgt2_clki			,

	output								mgt3_pmau_init_ctrl	,
	output								mgt3_rstb_push_ctrl	,
	input								mgt3_intf_link_stat	,
	input								mgt3_clki			,	
//----------------------------------TPGS LINK MISC CTRL
	input								tpus_link_ddrs_stat	,
	input								tpgs_link_port_idle	,
	output								tpgs_link_port_init	,

	input								tpgs_link_cmnd_lead	,
	input								tpgs_link_cmnd_wrcs	,
	input								tpgs_link_cmnd_coda	,
	input		[31: 0]					tpgs_link_cmnd_data	,

	output								tpgs_link_acks_reqs	,
	output								tpgs_link_resp_reqs	,
	input								tpgs_link_acks_done	,
	input								tpgs_link_resp_done	,
	input		[ 0: 3]					tpgs_link_acks_indx	,
	output		[31: 0]					tpgs_link_acks_data	,

	input								tpgs_trim_cmnd_mark	,//0
	input								tpgs_icfg_cmnd_mark	,//0
	input								tpgs_ocfg_cmnd_mark	,//1
	input								tpgs_nnex_cmnd_mark	,//2
	input								tpgs_ivct_cmnd_mark	,//3
	input								tpgs_ovct_cmnd_mark	,//4
	input								tpgs_imtx_cmnd_mark	,//5
	input								tpgs_omtx_cmnd_mark	,//6
	input								tpgs_rivt_cmnd_mark	,//7
	input								tpgs_rovt_cmnd_mark	,//8
	input								tpgs_rimt_cmnd_mark	,//9
	input								tpgs_romt_cmnd_mark	,//10
	input								tpgs_risv_cmnd_mark	,//11
	input								tpgs_rosv_cmnd_mark	,//12
	input								tpgs_rism_cmnd_mark	,//11
	input								tpgs_rosm_cmnd_mark	,//12
	input								tpgs_aset_cmnd_mark	,//13
	input								tpgs_dnld_cmnd_mark	,//14
	input								tpgs_boot_cmnd_mark	,//15
	input								tpgs_auxi_cmnd_mark	,//16
//----------------------------------TPEM LINK MISC CTRL
	output								tpgs_link_scut_enab	,
	input								tpgs_link_scut_done	,

	output	[ 0: 7]						tpem_link_port_rstn	,
	output	[ 0: 7]						tpem_link_port_rxen	,
	
	output								tpem_link_port_init	,
	input								tpem_link_port_idle	,
	input								tpem_link_acks_coda	,
	input								tpem_link_resp_coda	,

	output								tpem_link_trim_reqs	,
	output								tpem_link_icfg_reqs	,
	output								tpem_link_ocfg_reqs	,
	output								tpem_link_nnex_reqs	,
	output								tpem_link_ivct_reqs	,
	output								tpem_link_ovct_reqs	,
	output								tpem_link_imtx_reqs	,
	output								tpem_link_omtx_reqs	,
	output								tpem_link_aset_reqs	,
	output								tpem_link_dnld_reqs	,
	output								tpem_link_boot_reqs	,
	output								tpem_scfg_aset_reqs	,
	output								tpem_scfg_dnld_reqs	,
	output								tpem_scfg_boot_reqs	,

	input								tpem_link_trim_done	,//BIT 	02
	input								tpem_link_icfg_done	,//BIT 	02
	input								tpem_link_ocfg_done	,//BIT 	03
	input								tpem_link_nnex_done	,//BIT 	04
	input								tpem_link_ivct_done	,//BIT  05
	input								tpem_link_ovct_done	,//BIT  06
	input								tpem_link_imtx_done	,//BIT  07
	input								tpem_link_omtx_done	,//BIT  08
	input								tpem_link_aset_done	,//BIT 	09
	input								tpem_link_dnld_done	,//BIT 	10
	input								tpem_link_boot_done	,//BIT 	11
	input								tpem_scfg_aset_done	,//BIT 	12
	input								tpem_scfg_dnld_done	,//BIT 	13
	input								tpem_scfg_boot_done	,//BIT 	14

	input		[17: 0]					tpem_scfg_tpes_stat	,			

	input		[ 0: 3]					tpem_link_cmnd_indx	,
	output		[31: 0]					tpem_link_cmnd_data	,

	input		[ 0: 3]					tpem_xdat_cmnd_indx	,
	output		[31: 0]					tpem_xdat_cmnd_data	,

	input		[ 0: 3]					tpem_scfg_cmnd_indx	,
	output		[31: 0]					tpem_scfg_cmnd_data	,

	input		[ 0: 7]					tpes_link_acks_wrcs	,
	input		[ 0: 7][31: 0]			tpes_link_acks_data	,

	input		[ 2: 0]					scut_acks_memo_indx	,
	output		[31: 0]					scut_acks_memo_data	,

	input								tpgs_dlys_ctrl_drdy	,
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************/
	wire		[  7: 0]				sdes_link_port_selx	;

	wire		[  7: 0]				rv32_link_tpus_msba	;
	wire		[  3: 0]				rv32_link_tpus_lsba	;

	assign	rv32_link_tpus_msba	=		rv32_link_tpus_addr[11:4]	;
	assign	rv32_link_tpus_lsba	=		rv32_link_tpus_addr[3:0]	;

	wire	rv32_tpgs_ctrl_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H00};
	wire	rv32_tpem_ctrl_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H01};
	wire	rv32_ecos_ctrl_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H02};
	wire	rv32_cmnd_argu_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H03};
	wire	rv32_acks_argu_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H04};
	wire	rv32_tlnk_argu_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H05};
	wire	rv32_tune_txdo_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H06};
	wire	rv32_tune_rxdi_csen	=	&{	rv32_link_tpus_csen	, rv32_link_tpus_msba == 8'H07};
	
	wire		[ 31:0 ]				rv32_tpgs_ctrl_rout	;
	wire		[ 31:0 ]				rv32_tpem_ctrl_rout	;
	wire		[ 31:0 ]				rv32_ecos_ctrl_rout	;
	wire		[ 31:0 ]				rv32_cmnd_argu_rout	;
	wire		[ 31:0 ]				rv32_acks_argu_rout	;
	wire		[ 31:0 ]				rv32_tlnk_argu_rout	;
	wire		[ 31:0 ]				rv32_tune_txdo_rout	;
	wire		[ 31:0 ]				rv32_tune_rxdi_rout	;
		
	always@(posedge link_sclk or negedge link_rstn)
	if(!link_rstn)						rv32_link_tpus_rout	<=	0	;
	else 								rv32_link_tpus_rout	<=	rv32_tpgs_ctrl_csen	? rv32_tpgs_ctrl_rout	:	
																rv32_tpem_ctrl_csen	? rv32_tpem_ctrl_rout	:	
																rv32_ecos_ctrl_csen	? rv32_ecos_ctrl_rout	:	
																rv32_cmnd_argu_csen	? rv32_cmnd_argu_rout	:	
																rv32_acks_argu_csen	? rv32_acks_argu_rout	:	
																rv32_tlnk_argu_csen	? rv32_tlnk_argu_rout	:	
																rv32_tune_txdo_csen	? rv32_tune_txdo_rout	:
																rv32_tune_rxdi_csen	? rv32_tune_rxdi_rout	:	32'H0	;
/*LINK(0)::TPGS CTRL************************************************************************************************/
	rv32_link_tpgs_ctrl				u_rv32_tpgs_ctrl(
		.rv32_tpgs_ctrl_rout			(rv32_tpgs_ctrl_rout	),//output		[ 31:0 ]
		.rv32_tpgs_ctrl_csen			(rv32_tpgs_ctrl_csen	),//input				
		.rv32_tpgs_ctrl_wrcs			(rv32_link_tpus_wrcs	),//input				
		.rv32_tpgs_ctrl_addr			(rv32_link_tpus_lsba	),//input		[  3:0 ]
		.rv32_tpgs_ctrl_wdin			(rv32_link_tpus_wdin	),//input		[ 31:0 ]

		.tpgs_cram_writ_addr			(tpgs_cram_writ_addr	),//output	reg	[11:0]	
		.tpgs_cram_writ_csen			(tpgs_cram_writ_csen	),//output				

		.tpgs_link_ddrs_stat			(tpus_link_ddrs_stat	),//input	
		.tpgs_link_port_idle			(tpgs_link_port_idle	),//input	
		.tpgs_link_port_init			(tpgs_link_port_init	),//output	

		.tpgs_link_scut_done			(tpgs_link_scut_done	),//input				
		.tpgs_link_scut_enab			(tpgs_link_scut_enab	),//output	reg		

		.tpgs_link_cmnd_updt			(tpgs_link_cmnd_updt	),
		.tpem_link_port_enab			(tpem_link_port_enab	),//output	[7:0]

		.xdma_link_meta_mtrx			(xdma_link_meta_mtrx	),//output				
		.xdma_osde_rdma_enab			(xdma_osde_rdma_enab	),//output				
		.xdma_osde_rdma_done			(xdma_osde_rdma_done	),//input				
		.xdma_isde_wdma_enab			(xdma_isde_wdma_enab	),//output				
		.xdma_isde_wdma_done			(xdma_isde_wdma_done	),//input				
		.xdma_odat_rdma_enab			(xdma_odat_rdma_enab	),//output				
		.xdma_odat_rdma_done			(xdma_odat_rdma_done	),//input				
		.xdma_idat_wdma_enab			(xdma_idat_wdma_enab	),//output				
		.xdma_idat_wdma_done			(xdma_idat_wdma_done	),//input		

		.mgt1_pmau_init_ctrl			(mgt1_pmau_init_ctrl	),//output	reg			
		.mgt1_rstb_push_ctrl			(mgt1_rstb_push_ctrl	),//output	reg			
		.mgt1_intf_link_stat			(mgt1_intf_link_stat	),//input				
		.mgt1_clki						(mgt1_clki				),//input		

		.mgt2_pmau_init_ctrl			(mgt2_pmau_init_ctrl	),//output	reg			
		.mgt2_rstb_push_ctrl			(mgt2_rstb_push_ctrl	),//output	reg			
		.mgt2_intf_link_stat			(mgt2_intf_link_stat	),//input				
		.mgt2_clki						(mgt2_clki				),//input		

		.mgt3_pmau_init_ctrl			(mgt3_pmau_init_ctrl	),//output	reg			
		.mgt3_rstb_push_ctrl			(mgt3_rstb_push_ctrl	),//output	reg			
		.mgt3_intf_link_stat			(mgt3_intf_link_stat	),//input				
		.mgt3_clki						(mgt3_clki				),//input		

		.tpgs_link_acks_reqs			(tpgs_link_acks_reqs	),//output	
		.tpgs_link_resp_reqs			(tpgs_link_resp_reqs	),//output	
		.tpgs_link_acks_done			(tpgs_link_acks_done	),//input	
		.tpgs_link_resp_done			(tpgs_link_resp_done	),//input	

		.tpgs_trim_cmnd_mark			(tpgs_trim_cmnd_mark	),
		.tpgs_icfg_cmnd_mark			(tpgs_icfg_cmnd_mark	),//input	
		.tpgs_ocfg_cmnd_mark			(tpgs_ocfg_cmnd_mark	),//input	
		.tpgs_nnex_cmnd_mark			(tpgs_nnex_cmnd_mark	),//input	
		.tpgs_ivct_cmnd_mark			(tpgs_ivct_cmnd_mark	),//input	
		.tpgs_ovct_cmnd_mark			(tpgs_ovct_cmnd_mark	),//input	
		.tpgs_imtx_cmnd_mark			(tpgs_imtx_cmnd_mark	),//input	
		.tpgs_omtx_cmnd_mark			(tpgs_omtx_cmnd_mark	),//input	
		.tpgs_rivt_cmnd_mark			(tpgs_rivt_cmnd_mark	),//input	
		.tpgs_rovt_cmnd_mark			(tpgs_rovt_cmnd_mark	),//input	
		.tpgs_rimt_cmnd_mark			(tpgs_rimt_cmnd_mark	),//input	
		.tpgs_romt_cmnd_mark			(tpgs_romt_cmnd_mark	),//input	
		.tpgs_risv_cmnd_mark			(tpgs_risv_cmnd_mark	),//input	
		.tpgs_rosv_cmnd_mark			(tpgs_rosv_cmnd_mark	),//input	
		.tpgs_rism_cmnd_mark			(tpgs_rism_cmnd_mark	),//input	
		.tpgs_rosm_cmnd_mark			(tpgs_rosm_cmnd_mark	),//input	
		.tpgs_auxi_cmnd_mark			(tpgs_auxi_cmnd_mark	),//input	
		.tpgs_aset_cmnd_mark			(tpgs_aset_cmnd_mark	),//input	
		.tpgs_dnld_cmnd_mark			(tpgs_dnld_cmnd_mark	),//input	
		.tpgs_boot_cmnd_mark			(tpgs_boot_cmnd_mark	),//input	
		.tpgs_link_cmnd_coda			(tpgs_link_cmnd_coda	),//input	

		.tpgs_dlys_ctrl_drdy			(tpgs_dlys_ctrl_drdy	),
		.link_sclk						(link_sclk				),
		.link_rstn						(link_rstn				));
/*LINK(1)::TPEM CTRL************************************************************************************************/
	rv32_link_tpem_ctrl				u_rv32_tpem_misc(
		.rv32_tpem_ctrl_rout			(rv32_tpem_ctrl_rout	),//output		[ 31:0 ]
		.rv32_tpem_ctrl_csen			(rv32_tpem_ctrl_csen	),//input				
		.rv32_tpem_ctrl_wrcs			(rv32_link_tpus_wrcs	),//input				
		.rv32_tpem_ctrl_addr			(rv32_link_tpus_lsba	),//input		[ 3: 0 ]
		.rv32_tpem_ctrl_wdin			(rv32_link_tpus_wdin	),//input		[ 31:0 ]


		.tpem_tune_txdo_mode			(tpem_tune_txdo_mode	),//output		[ 0: 7]
		.tpem_tune_rxdi_mode			(tpem_tune_rxdi_mode	),//output		[ 0: 7]
		.tpem_scfg_tpes_stat			(tpem_scfg_tpes_stat	),

		.tpem_link_port_enab			(tpem_link_port_enab	),//input		[ 7: 0]
		.tpem_link_port_rstn			(tpem_link_port_rstn	),//output reg	[ 0: 7]
		.tpem_link_port_rxen			(tpem_link_port_rxen	),//output reg	[ 0: 7]
		
		.tpem_link_port_init			(tpem_link_port_init	),//output		
		.tpem_link_port_idle			(tpem_link_port_idle	),//input				
		.tpem_link_acks_coda			(tpem_link_acks_coda	),
		.tpem_link_resp_coda			(tpem_link_resp_coda	),

		.tpem_link_trim_reqs			(tpem_link_trim_reqs	),//output				
		.tpem_link_icfg_reqs			(tpem_link_icfg_reqs	),//output				
		.tpem_link_ocfg_reqs			(tpem_link_ocfg_reqs	),//output				
		.tpem_link_nnex_reqs			(tpem_link_nnex_reqs	),//output				
		.tpem_link_ivct_reqs			(tpem_link_ivct_reqs	),//output				
		.tpem_link_ovct_reqs			(tpem_link_ovct_reqs	),//output				
		.tpem_link_imtx_reqs			(tpem_link_imtx_reqs	),//output				
		.tpem_link_omtx_reqs			(tpem_link_omtx_reqs	),//output				
		.tpem_link_aset_reqs			(tpem_link_aset_reqs	),//output				
		.tpem_link_dnld_reqs			(tpem_link_dnld_reqs	),//output				
		.tpem_link_boot_reqs			(tpem_link_boot_reqs	),//output				
		.tpem_scfg_aset_reqs			(tpem_scfg_aset_reqs	),//output				
		.tpem_scfg_dnld_reqs			(tpem_scfg_dnld_reqs	),//output				
		.tpem_scfg_boot_reqs			(tpem_scfg_boot_reqs	),//output				

		.tpem_link_trim_done			(tpem_link_trim_done	),//BIT 	02 input	
		.tpem_link_icfg_done			(tpem_link_icfg_done	),//BIT 	02 input	
		.tpem_link_ocfg_done			(tpem_link_ocfg_done	),//BIT 	03 input	
		.tpem_link_nnex_done			(tpem_link_nnex_done	),//BIT 	04 input	
		.tpem_link_ivct_done			(tpem_link_ivct_done	),//BIT		05 input				
		.tpem_link_ovct_done			(tpem_link_ovct_done	),//BIT		06 input				
		.tpem_link_imtx_done			(tpem_link_imtx_done	),//BIT		07 input				
		.tpem_link_omtx_done			(tpem_link_omtx_done	),//BIT		08 input				
		.tpem_link_aset_done			(tpem_link_aset_done	),//BIT 	09 input	
		.tpem_link_dnld_done			(tpem_link_dnld_done	),//BIT 	0A input	
		.tpem_link_boot_done			(tpem_link_boot_done	),//BIT 	0B input	
		.tpem_scfg_aset_done			(tpem_scfg_aset_done	),//BIT 	0C input	
		.tpem_scfg_dnld_done			(tpem_scfg_dnld_done	),//BIT 	0D input	
		.tpem_scfg_boot_done			(tpem_scfg_boot_done	),//BIT 	0E input	
//		.tpem_scfg_init_fail			(tpem_scfg_init_fail	),//BIT 	0F input	
//		.tpem_scfg_boot_fail			(tpem_scfg_boot_fail	),//BIT 	10 input	

		.link_sclk						(link_sclk				),
		.link_rstn						(link_rstn				));
/*LINK(2)::ECOS CTRL**********************************************************************************************************/
	rv32_link_llmb_ctrl				u_rv32_llmb_ctrl(
		.rv32_ecos_ctrl_rout			(rv32_ecos_ctrl_rout	),//input		[  3: 0]
		.rv32_ecos_ctrl_csen			(rv32_ecos_ctrl_csen	),//input				
		.rv32_ecos_ctrl_wrcs			(rv32_link_tpus_wrcs	),//input				
		.rv32_ecos_ctrl_addr			(rv32_link_tpus_lsba	),//input		[ 31: 0]
		.rv32_ecos_ctrl_wdat			(rv32_link_tpus_wdin	),//output		[ 31: 0]

		.ecos_omni_edge_numb			(ecos_omni_edge_numb	),//output		[ 7: 0]	//		.ecos_omni_pile_numb			(ecos_omni_pile_numb	),//output		[ 3: 0]	
		.ecos_pile_edge_numb			(ecos_pile_edge_numb	),//output		[ 4: 0]	
		.ecos_pile_edge_tail			(ecos_pile_edge_tail	),//output	reg	[ 4: 0]	
		
		.this_tpgs_pile_indx			(this_tpgs_pile_indx	),//output		[ 3: 0]			
		.this_tpgs_pile_edge			(this_tpgs_pile_edge	),//output	reg	[ 4: 0]	
		.this_tpgs_pile_lead			(this_tpgs_pile_lead	),//output				
		.this_tpgs_pile_coda			(this_tpgs_pile_coda	),//output		

		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	
/*LINK(3)::TPGS CMND ARGU**********************************************************************************************************/
	wire	[ 0:15][31: 0]				tpgs_link_cmnd_memo	;

	rv32_link_cmnd_argu				u_rv32_cmnd_argu(
		.rv32_cmnd_argu_rout			(rv32_cmnd_argu_rout	),//output		[31: 0]	
		.rv32_cmnd_argu_csen			(rv32_cmnd_argu_csen	),//input				
		.rv32_cmnd_argu_addr			(rv32_link_tpus_lsba	),//input		[ 3: 0]	

		.tpgs_link_cmnd_lead			(tpgs_link_cmnd_lead	),//input				
		.tpgs_link_cmnd_wrcs			(tpgs_link_cmnd_wrcs	),//input				
		.tpgs_link_cmnd_data			(tpgs_link_cmnd_data	),//input		[31: 0]	
		.tpgs_link_cmnd_memo			(tpgs_link_cmnd_memo	),//output	reg	[ 0:15][31: 0]

		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	
/*LINK(4)::TPEM ACKS ARGU**********************************************************************************************************/
	rv32_link_acks_argu				u_rv32_acks_argu(
		.rv32_acks_argu_rout			(rv32_acks_argu_rout	),//input				
		.rv32_acks_argu_csen			(rv32_acks_argu_csen	),//input				
		.rv32_acks_argu_wrcs			(rv32_link_tpus_wrcs	),//input		[  3: 0]
		.rv32_acks_argu_addr			(rv32_link_tpus_lsba	),//input		[ 31: 0]
		.rv32_acks_argu_wdin			(rv32_link_tpus_wdin	),//output		[ 31: 0]
	
//		.tpem_link_port_init			(tpem_link_port_init	),//output		

		.tpgs_link_acks_indx			(tpgs_link_acks_indx	),//input		[ 3: 0]		
		.tpgs_link_acks_data			(tpgs_link_acks_data	),//output		[31: 0]		
			
		.tpes_link_acks_wrcs			(tpes_link_acks_wrcs	),//input		[ 0: 7]		
		.tpes_link_acks_data			(tpes_link_acks_data	),//input		[ 0: 7][31: 0]
	
		.scut_acks_memo_indx			(scut_acks_memo_indx	),//output	[ 3: 0]		
		.scut_acks_memo_data			(scut_acks_memo_data	),//input	[31: 0]		
	
		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	
/*LINK(5)::TPUC ECOS ARGU**********************************************************************************************************/
	rv32_link_tlnk_argu				u_rv32_tlnk_argu(
		.rv32_tlnk_argu_rout			(rv32_tlnk_argu_rout	),//output		[ 31: 0]
		.rv32_tlnk_argu_csen			(rv32_tlnk_argu_csen	),//input				
		.rv32_tlnk_argu_wrcs			(rv32_link_tpus_wrcs	),//input				
		.rv32_tlnk_argu_addr			(rv32_link_tpus_lsba	),//input		[  3: 0]
		.rv32_tlnk_argu_wdin			(rv32_link_tpus_wdin	),//input		[ 31: 0]

		.tpgs_link_cmnd_memo			(tpgs_link_cmnd_memo	),//input		[  0:15][31: 0]	
		.tpgs_link_cmnd_updt			(tpgs_link_cmnd_updt	),//input						

		.tpem_link_cmnd_indx			(tpem_link_cmnd_indx	),//input		[ 3: 0]	
		.tpem_link_cmnd_data			(tpem_link_cmnd_data	),//output		[31: 0]	

		.tpem_xdat_cmnd_indx			(tpem_xdat_cmnd_indx	),//input		[ 3: 0]	
		.tpem_xdat_cmnd_data			(tpem_xdat_cmnd_data	),//output		[31: 0]	

		.tpem_scfg_cmnd_indx			(tpem_scfg_cmnd_indx	),//input		[ 3: 0]	
		.tpem_scfg_cmnd_data			(tpem_scfg_cmnd_data	),//output		[31: 0]	
//--------------add @20150105	
		.llmb_meta_imag_size			(llmb_meta_imag_size	),//output	reg	[24: 0]	
		.llmb_meta_imag_rows			(llmb_meta_imag_rows	),//output		[19: 0]	
		.llmb_meta_imag_cols			(llmb_meta_imag_cols	),//output		[19: 0]	
		.llmb_mtrx_imag_cols			(llmb_mtrx_imag_cols	),//output		[19: 0]	

		.llmb_edge_imag_size			(llmb_edge_imag_size	),//output	reg	[24: 0]	
		.llmb_edge_imag_rows			(llmb_edge_imag_rows	),//output		[19: 0]	
		.llmb_edge_imag_cols			(llmb_edge_imag_cols	),//output		[19: 0]	
		.llmb_edge_imag_even			(llmb_edge_imag_even	),//output		[19: 0]	
		.llmb_edge_imag_row2			(llmb_edge_imag_row2	),//output		[19: 0]	

		.llmb_mast_ddrs_base			(llmb_mast_ddrs_base	),//output		[24: 0]	
		.llmb_devs_ddrs_base			(llmb_devs_ddrs_base	),//output		[24: 0]	
//--------------add @20151021
		.sdes_link_mgth_csid			(sdes_link_mgth_csid	),//output		[3 : 0]	
		.sdes_link_ddrs_size			(sdes_link_ddrs_size	),//output		[24: 0]	
		.sdes_meta_ddrs_base			(sdes_meta_ddrs_base	),//output		[24: 0]	
		.sdes_meta_cols_dims			(sdes_meta_cols_dims	),//output		[15: 0]	
		.sdes_hubs_ddrs_base			(sdes_hubs_ddrs_base	),//output		[24: 0]	
		.sdes_hubs_cols_dims			(sdes_hubs_cols_dims	),//output		[15: 0]	
		.sdes_hubs_cols_dumy			(sdes_hubs_cols_dumy	),//output		[15: 0]	
		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	
/*LINK(6)::TPEM Odly ARGU**********************************************************************************************************/
	rv32_link_tune_txdo				u_rv32_tune_txdo(
		.rv32_tune_txdo_rout			(rv32_tune_txdo_rout	),//input				
		.rv32_tune_txdo_csen			(rv32_tune_txdo_csen	),//input				
		.rv32_tune_txdo_wrcs			(rv32_link_tpus_wrcs	),//input		[  3: 0]
		.rv32_tune_txdo_addr			(rv32_link_tpus_lsba	),//input		[ 31: 0]
		.rv32_tune_txdo_wdin			(rv32_link_tpus_wdin	),//output		[ 31: 0]

		.tpem_tune_txdo_done			(tpem_tune_txdo_done	),//input		[  0:7]
		.tpem_tune_txdo_enab			(tpem_tune_txdo_enab	),//output	[  0:7]			
		.tpem_tune_txdo_taps			(tpem_tune_txdo_taps	),//output	[  0:7][8: 0]	

		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	

/*LINK(7)::TPEM Idly ARGU**********************************************************************************************************/
	rv32_link_tune_rxdi				u_rv32_tune_rxdi(
		.rv32_tune_rxdi_rout			(rv32_tune_rxdi_rout	),//input				
		.rv32_tune_rxdi_csen			(rv32_tune_rxdi_csen	),//input				
		.rv32_tune_rxdi_wrcs			(rv32_link_tpus_wrcs	),//input		[  3: 0]
		.rv32_tune_rxdi_addr			(rv32_link_tpus_lsba	),//input		[ 31: 0]
		.rv32_tune_rxdi_wdin			(rv32_link_tpus_wdin	),//output		[ 31: 0]

		.tpem_tune_rxdi_done			(tpem_tune_rxdi_done	),//output	[ 0: 7]			
		.tpem_tune_rxdi_enab			(tpem_tune_rxdi_enab	),//output	[ 0: 7]			
		.tpem_tune_rxdi_taps			(tpem_tune_rxdi_taps	),//output	[ 0: 7][ 8: 0]	
		.tpem_tune_rxdi_stat			(tpem_tune_rxdi_stat	),//input	[ 0: 7][ 9: 0]	
		
		.tpem_sync_rxdi_reqs			(tpem_sync_rxdi_reqs	),//output	reg			
		.tpem_sync_rxdi_done			(tpem_sync_rxdi_done	),//input		[ 0: 7]	

		.link_sclk						(link_sclk				),//input	
		.link_rstn						(link_rstn				));//input	


endmodule


	
