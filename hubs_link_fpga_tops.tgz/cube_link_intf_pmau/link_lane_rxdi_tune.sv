
module	link_lane_rxdi_tune(
	input								host_tune_rxdi_enab	,
	input		[ 8: 0]					host_tune_rxdi_taps	,//come from host_clock_domain
	output								host_tune_rxdi_done	,//come from lane_clock_domain
	output		[ 9: 0]					host_tune_rxdi_stat	,//come from lane_clock_domain
	input								host_clki		,
	input								host_rstn		,
		

	output		[ 0: 4]					dlys_cell_envt	,
	output		[ 0: 4]					dlys_cell_load	,
	output		[ 0 :4][ 8: 0]			dlys_cell_taps	,
	input		[ 0 :4][ 8: 0]			dlys_cell_vout	,	

	input		[ 0: 4][ 7: 0]			lane_sdes_prev	,
	input		[ 0: 4][ 7: 0]			lane_sdes_data	,
	output		[ 0: 4][ 7: 0]			lane_slip_data	,
	
	input								lane_sclk		,
	input								lane_rstn		);	
/**********************************************************************************************************************/
	wire								tune_rxdi_enab	;
	wire								tune_rxdi_done	;
	wire		[ 8: 0]					tune_rxdi_taps	;
	wire		[ 9: 0]					tune_rxdi_stat	;

	gens_sign_fast_slow	#( 
		.EXTN ( 8 )	)				
									u_gens_tune_rxdi_enab(
		.fast_sign  					(host_tune_rxdi_enab	),//input	
		.fast_clki						(host_clki		),//input	
		.fast_rstn						(host_rstn		),//input	

		.slow_sign						(tune_rxdi_enab	),//output	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(lane_rstn		));//input	

	gens_sign_slow_fast	#( 
		.EXTN ( 2 )	)				
									u_gens_tune_rxdi_done(
		.slow_sign						(tune_rxdi_done	),//output	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(lane_rstn		),
		
		.fast_sign  					(host_tune_rxdi_done	),//input	
		.fast_clki						(host_clki		),//input	
		.fast_rstn						(host_rstn		));//input	

	gens_sync_gray #(	
		.MSB ( 8 ) )				
									u_sync_tune_rxdi_taps(
		.data_asyn						(host_tune_rxdi_taps	),//input	[MSB: 0]
		.scki							(host_clki		),//input			

		.data_sync						(tune_rxdi_taps	),//
		.clki							(lane_sclk		),//
		.rstn							(lane_rstn		));//

	gens_sync_gray #(	
		.MSB ( 9 ) )				
									u_sync_tune_dlys_stat(
		.data_asyn						(tune_rxdi_stat	),//input	[MSB: 0]
		.scki							(lane_sclk		),//input			

		.data_sync						(host_tune_rxdi_stat	),//
		.clki							(host_clki		),//
		.rstn							(host_rstn		));//

/**********************************************************************************************************************/
	reg			[ 2: 0]					tune_rxdi_mfsm	;

	parameter	TUNE_RXDI_IDLE	=		3'H0	;
	parameter	TUNE_RXDI_DLYS	=		3'H1	;
	parameter	TUNE_RXDI_EYES	=		3'H2	;
	parameter	TUNE_RXDI_SLIP	=		3'H3	;
	parameter	TUNE_RXDI_DONE	=		3'H4	;
//------------------------------------------------------------------------------
	wire		[ 0: 4]					lane_dlys_done	;
	wire		[ 0: 4]					lane_eyes_done	;
	wire		[ 0: 4]					lane_slip_done	;	

	wire		tune_rxdi_dlys	=		tune_rxdi_mfsm	==	TUNE_RXDI_DLYS	;
	wire		tune_rxdi_eyes	=		tune_rxdi_mfsm	==	TUNE_RXDI_EYES	;
	wire		tune_rxdi_slip	=		tune_rxdi_mfsm	==	TUNE_RXDI_SLIP	;
	assign		tune_rxdi_done	=		tune_rxdi_mfsm	==	TUNE_RXDI_DONE	;
	
	wire		tune_dlys_done	=	&	lane_dlys_done	;
	wire		tune_eyes_done	=	&	lane_eyes_done	;
	wire		tune_slip_done	=	&	lane_slip_done	;
//------------------------------------------------------------------------------
	always@(posedge lane_sclk or negedge host_rstn )				
	if(~host_rstn)						tune_rxdi_mfsm	<=	TUNE_RXDI_IDLE	;
	else if(~tune_rxdi_enab)			tune_rxdi_mfsm	<=	TUNE_RXDI_IDLE	;
	else begin
		case(tune_rxdi_mfsm)	
			TUNE_RXDI_IDLE		:		tune_rxdi_mfsm	<=											TUNE_RXDI_DLYS	;
			TUNE_RXDI_DLYS		:		tune_rxdi_mfsm	<=	~tune_dlys_done	?	TUNE_RXDI_DLYS	:	TUNE_RXDI_EYES	;
			TUNE_RXDI_EYES		:		tune_rxdi_mfsm	<=	~tune_eyes_done	?	TUNE_RXDI_EYES	:	TUNE_RXDI_SLIP	;
			TUNE_RXDI_SLIP		:		tune_rxdi_mfsm	<=	~tune_slip_done	?	TUNE_RXDI_SLIP	:	TUNE_RXDI_DONE	;
			TUNE_RXDI_DONE		:		tune_rxdi_mfsm	<=											TUNE_RXDI_DONE	;
			default				:		tune_rxdi_mfsm	<=											TUNE_RXDI_IDLE	;
		endcase
	end
/*******************************************************************************************************************/
	wire		[ 0: 4][ 2: 0]			tune_slip_step	;
	wire		[ 0: 4]					lane_slip_good	;
	wire		[ 0: 4]					lane_eyes_good	;
		
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_tune_misc

		lane_tune_dlys				u_lane_tune_dlys(
			.dlys_cell_envt				(dlys_cell_envt[i]	),//output	reg			
			.dlys_cell_load				(dlys_cell_load[i]	),//output	reg			
			.dlys_cell_taps				(dlys_cell_taps[i]	),//output		[ 8: 0]	
			.dlys_cell_vout				(dlys_cell_vout[i]	),//input		[ 8: 0]	

			.tune_dlys_taps				(tune_rxdi_taps		),//input		[ 8: 0]	
			.tune_dlys_enab				(tune_rxdi_dlys		),//input				
			.tune_dlys_done				(lane_dlys_done[i]	),//output				
			.lane_sclk					(lane_sclk			),//input				
			.lane_rstn					(lane_rstn			));//input				

		lane_tune_eyes				u_lane_tune_eyes(
			.lane_sdes_prev				(lane_sdes_prev[i]	),//input	[ 7: 0]		
			.lane_sdes_data				(lane_sdes_data[i]	),//input	[ 7: 0]		

			.lane_eyes_good				(lane_eyes_good[i]	),//output				
			.lane_eyes_goal				(8'H9A				),//input	[ 7: 0]		
			.tune_eyes_enab				(tune_rxdi_eyes		),//output				
			.tune_eyes_done				(lane_eyes_done[i]		),//input	[ 7: 0]		
			
			.lane_sclk					(lane_sclk			),//input				
			.lane_rstn					(lane_rstn			));//input				

		lane_tune_slip				u_lane_tune_slip(
			.lane_sdes_prev				(lane_sdes_prev[i]	),//input	[ 7: 0]		
			.lane_sdes_data				(lane_sdes_data[i]	),//input		[ 7: 0]	

			.lane_slip_data				(lane_slip_data[i]	),//output	reg	[ 7: 0]	
			.lane_slip_good				(lane_slip_good[i]	),//output	reg			
			.lane_slip_goal				(8'H9A				),//input		[ 7: 0]	

			.lane_slip_enab				(tune_rxdi_slip		),//input				
			.lane_slip_step				(tune_slip_step[i]	),//output	[2: 0]
			.lane_slip_done				(lane_slip_done[i]	),//output				
			
			.lane_sclk					(lane_sclk			),//input				
			.lane_rstn					(lane_rstn			));//input				
	end
/**********************************************************************************************************************/	
	assign	tune_rxdi_stat	=		{	lane_eyes_good	,	lane_slip_good	};
/**********************************************************************************************************************/	

endmodule

  