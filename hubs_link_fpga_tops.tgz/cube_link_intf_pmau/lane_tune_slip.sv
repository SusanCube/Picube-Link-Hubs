
module	lane_tune_slip(
	
	input		[ 7: 0]					lane_sdes_prev	,
	input		[ 7: 0]					lane_sdes_data	,

	output	reg	[ 7: 0]					lane_slip_data	,	
	output	reg							lane_slip_good	,
	input		[ 7: 0]					lane_slip_goal	,

	input								lane_slip_enab	,
	output	reg							lane_slip_done	,
	output	reg	[2: 0]					lane_slip_step	,
	
	input								lane_sclk		,
	input								lane_rstn		);
/**********************************************************************************************************************/
	reg			[ 2: 0]					tune_slip_mfsm	;
	
	wire								tune_slip_init	;
	wire								tune_slip_seek	;
	wire								tune_slip_next	;
	wire								tune_slip_beok	;
	wire								tune_slip_fail	;
	wire								tune_slip_smax	;

	parameter	TUNE_SLIP_IDLE	=		4'H0	;
	parameter	TUNE_SLIP_INIT	=		4'H1	;
	parameter	TUNE_SLIP_SEEK	=		4'H2	;
	parameter	TUNE_SLIP_NEXT	=		4'H3	;
	parameter	TUNE_SLIP_DONE	=		4'H4	;
	
	assign	tune_slip_init		=		tune_slip_mfsm	==	TUNE_SLIP_INIT	;
	assign	tune_slip_seek		=		tune_slip_mfsm	==	TUNE_SLIP_SEEK	;
	assign	tune_slip_next		=		tune_slip_mfsm	==	TUNE_SLIP_NEXT	;
	assign	lane_slip_done		=		tune_slip_mfsm	==	TUNE_SLIP_DONE	;
	
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						tune_slip_mfsm	<=	TUNE_SLIP_IDLE	;
	else if(~lane_slip_enab)			tune_slip_mfsm	<=	TUNE_SLIP_IDLE	;
	else begin
		case(tune_slip_mfsm)	
			TUNE_SLIP_IDLE		:		tune_slip_mfsm	<=											TUNE_SLIP_INIT	;
			TUNE_SLIP_INIT		:		tune_slip_mfsm	<=											TUNE_SLIP_SEEK	;
			
			TUNE_SLIP_SEEK		:		tune_slip_mfsm	<=	tune_slip_fail	?	TUNE_SLIP_NEXT	:	
															tune_slip_beok	?	TUNE_SLIP_DONE	:	TUNE_SLIP_SEEK	;

			TUNE_SLIP_NEXT		:		tune_slip_mfsm	<=	tune_slip_smax	?	TUNE_SLIP_DONE	:	TUNE_SLIP_SEEK	;	
			TUNE_SLIP_DONE		:		tune_slip_mfsm	<=											TUNE_SLIP_DONE	;
			default				:		tune_slip_mfsm	<=											TUNE_SLIP_IDLE	;
		endcase
	end
/**********************************************************************************************************************/
	assign	tune_slip_smax	=		&	lane_slip_step	;
	
	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_slip_step	<=	0	;
	else if( tune_slip_init)			lane_slip_step	<=	0	;
	else if( tune_slip_next)			lane_slip_step	<=	1 +	lane_slip_step	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_slip_data	<=	0	;
	else if(lane_slip_step == 3'H1)		lane_slip_data	<=	{	lane_sdes_prev[ 6: 0]	,	lane_sdes_data[ 7: 7]  };
	else if(lane_slip_step == 3'H2)		lane_slip_data	<=	{	lane_sdes_prev[ 5: 0]	,	lane_sdes_data[ 7: 6]  };
	else if(lane_slip_step == 3'H3)		lane_slip_data	<=	{	lane_sdes_prev[ 4: 0]	,	lane_sdes_data[ 7: 5]  };
	else if(lane_slip_step == 3'H4)		lane_slip_data	<=	{	lane_sdes_prev[ 3: 0]	,	lane_sdes_data[ 7: 4]  };
	else if(lane_slip_step == 3'H5)		lane_slip_data	<=	{	lane_sdes_prev[ 2: 0]	,	lane_sdes_data[ 7: 3]  };
	else if(lane_slip_step == 3'H6)		lane_slip_data	<=	{	lane_sdes_prev[ 1: 0]	,	lane_sdes_data[ 7: 2]  };
	else if(lane_slip_step == 3'H7)		lane_slip_data	<=	{	lane_sdes_prev[ 0: 0]	,	lane_sdes_data[ 7: 1]  };
	else 								lane_slip_data	<=									lane_sdes_data			;
//------------------------------------------------------------------------------
	reg			[ 6: 0]					slip_time_cnts	;
	reg			[ 5: 0]					slip_pass_cnts	;
	
	wire								tune_slip_meet	;
	wire								tune_slip_pass	;
	wire								tune_slip_tmax	;
		
	assign	tune_slip_meet	=			lane_slip_data	==	lane_slip_goal	;
	assign	tune_slip_pass	=	&		slip_pass_cnts	;
	assign	tune_slip_tmax	=	&		slip_time_cnts	;
	assign	tune_slip_fail	=	&	{	tune_slip_tmax	, ~ tune_slip_pass };	
	assign	tune_slip_beok	=	&	{	tune_slip_tmax	,   tune_slip_pass };	
	
	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						slip_pass_cnts	<=	0	;
	else if(~lane_slip_enab)			slip_pass_cnts	<=	0	;
	else if(~tune_slip_meet)			slip_pass_cnts	<=	0	;
	else if(~tune_slip_pass)			slip_pass_cnts	<=	1 +	slip_pass_cnts	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						slip_time_cnts	<=	0	;
	else if(~tune_slip_seek)			slip_time_cnts	<=	0	;
	else 								slip_time_cnts	<=	1 +	slip_time_cnts	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_slip_good	<=	0	;
	else if( tune_slip_init)			lane_slip_good	<=	0	;
	else if( tune_slip_next)			lane_slip_good	<=	0	;
	else if( tune_slip_tmax)			lane_slip_good	<=	tune_slip_pass	;		
	
/**********************************************************************************************************************/

endmodule
 