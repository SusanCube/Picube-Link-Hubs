module  gens_byte_invt(
    output		[ 7: 0]					byte_invt		,
	input		[ 7: 0]					byte_data		);

	for(genvar i = 0; i < 8 ; i = i+1)
		assign	byte_invt[i]	=	byte_data[7-i];


endmodule


 