
module	link_edge_rxdi_pmau(

	input								host_tune_rxdi_mode	,
	input								host_tune_rxdi_enab	,
	input		[ 8: 0]					host_tune_rxdi_taps	,//come from host_clock_domain
	output								host_tune_rxdi_done	,//come from lane_clock_domain
	output		[ 9: 0]					host_tune_rxdi_stat	,//come from lane_clock_domain

	input								host_sync_rxdi_reqs	,
	output								host_sync_rxdi_done	,//come from host_clock_domain
	
	input								host_data_rxdi_enab	,

	input								host_clki		,
	input								host_rstn		,

	output	reg							lane_tune_rxdi	,		

	input							    lane_fclk_inpp	,
	input							    lane_fclk_inpn	,
	input							    lane_fram_inpp	,
	input							    lane_fram_inpn	,
	input							    lane_dat0_inpp	,
	input							    lane_dat0_inpn	,
	input							    lane_dat1_inpp	,
	input							    lane_dat1_inpn	,
	input							    lane_dat2_inpp	,
	input							    lane_dat2_inpn	,
	input							    lane_dat3_inpp	,
	input							    lane_dat3_inpn	,

	output	reg							pmau_fram_lead	,
	output	reg							pmau_fram_body	,
	output	reg							pmau_fram_coda	,
	output	reg	[ 7: 0]					pmau_dat3_mbdo	,
	output	reg	[ 7: 0]					pmau_dat2_mbdo	,
	output	reg	[ 7: 0]					pmau_dat1_mbdo	,
	output	reg	[ 7: 0]					pmau_dat0_mbdo	,

	input								dlys_brst		,
	input								link_sclk		,
	input								link_rstn		);
/***GENS RXDI_RSTN*****************************************************************************************************/
	wire								lane_fclk	;
	wire								lane_sclk	;

	reg									lane_rstn		= 0	;	
	reg		[ 2: 0]						lane_rstn_samp	= 0 ;

	always@(posedge lane_sclk)			lane_rstn_samp	<=	{	link_rstn	,	lane_rstn_samp[ 2: 1]	};
	always@(posedge lane_sclk)			lane_rstn		<=	&	lane_rstn_samp	;
/**********************************************************************************************************************/
	reg		[2: 0]						lane_rxen_samp	= 0 ;
	reg									lane_push_wken	;		

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_rxen_samp	<=	0	;
	else								lane_rxen_samp	<={	host_data_rxdi_enab	,	lane_rxen_samp[2:1]	};

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_push_wken	<=	0	;
	else								lane_push_wken	<= &lane_rxen_samp		;
//------------------------------------------------------------------------------
	reg									lane_pops_wken	=	0;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_wken	<=	0	;
	else 								lane_pops_wken	<=	host_data_rxdi_enab	;
/***RXDI_CLKI**********************************************************************************************************/
	wire								lane_fclk_sbdi	;

	IBUFDS							LVDS_FCLK_PAD	(
		.I              				(lane_fclk_inpp	),
		.IB             				(lane_fclk_inpn	),
		.O              				(lane_fclk_sbdi	));
(* keep="true" *)
	BUFG							LVDS_FCLK_BUFG	(
		.I								(lane_fclk_sbdi	),
		.O								(lane_fclk		));	
(* keep="true" *)
    BUFGCE_DIV #(
        .BUFGCE_DIVIDE        			(4				),
        .IS_CE_INVERTED     			(1'B0			),
        .IS_CLR_INVERTED    			(1'B1			),
        .IS_I_INVERTED      			(1'B0			)) 
	LVDS_SCLK_BUFG (
        .O   							( lane_sclk		), 
		.I  		 					( lane_fclk_sbdi),
//        .CLR 							( link_rstn		),
        .CLR 							( 1'b1			),
        .CE  							( 1'b1			));
//------------------------------------------------------------------------------
	wire								lane_fram_rxdi	;
	wire								lane_dat0_rxdi	;
	wire								lane_dat1_rxdi	;
	wire								lane_dat2_rxdi	;
	wire								lane_dat3_rxdi	;
	
	wire		[ 0: 4]					lane_raws_sbdi	;
	assign	lane_raws_sbdi	=	{		lane_fram_rxdi	,
										lane_dat0_rxdi	,
										lane_dat1_rxdi	,
										lane_dat2_rxdi	,
										lane_dat3_rxdi	};
//--DATYA_BUS_IBUFDS----------------------------------------------------------------------------
	IBUFDS							LVDS_FRAM_PAD	(
		.I                  			(lane_fram_inpp	),
		.IB                 			(lane_fram_inpn	),
		.O                  			(lane_fram_rxdi	));

	IBUFDS							LVDS_DAT0_PAD	(
		.I                  			(lane_dat0_inpp	),
		.IB                 			(lane_dat0_inpn	),
		.O                  			(lane_dat0_rxdi	));

	IBUFDS							LVDS_DAT1_PAD	(
		.I                  			(lane_dat1_inpp	),
		.IB                 			(lane_dat1_inpn	),
		.O                  			(lane_dat1_rxdi	));

	IBUFDS							LVDS_DAT2_PAD	(
		.I                  			(lane_dat2_inpp	),
		.IB                 			(lane_dat2_inpn	),
		.O                  			(lane_dat2_rxdi	));

	IBUFDS							LVDS_DAT3_PAD	(
		.I                  			(lane_dat3_inpp	),
		.IB                 			(lane_dat3_inpn	),
		.O                  			(lane_dat3_rxdi	));
/***lane_idly_tune*******************************************************************************************************/
	reg			[ 0: 4][ 7: 0]			lane_sdes_prev	;
	wire		[ 0: 4][ 7: 0]			lane_sdes_data	;
	wire		[ 0: 4][ 7: 0]			lane_sdes_invt	;
	wire		[ 0: 4][ 7: 0]			lane_slip_data	;
	wire		[ 0: 4][ 7: 0]			lane_sync_data	;
	

	wire		[ 0: 4][ 8: 0]			dlys_cell_vout	;
	wire		[ 0: 4]					dlys_cell_envt	;
	wire		[ 0: 4]					dlys_cell_load	;
	wire		[ 0: 4][ 8: 0]			dlys_cell_taps	;

	wire								lane_sync_scan	;
	wire								lane_sync_mode	;
	
	
	link_lane_rxdi_tune				u_edge_rxdi_lane_tune(
		.host_tune_rxdi_enab			(host_tune_rxdi_enab	),//input					
		.host_tune_rxdi_taps			(host_tune_rxdi_taps	),//input		[ 8: 0]		
		.host_tune_rxdi_done			(host_tune_rxdi_done	),//output					
		.host_tune_rxdi_stat			(host_tune_rxdi_stat	),//output		[ 9: 0]		
		.host_clki						(host_clki		),//input					
		.host_rstn						(host_rstn		),//input					
		
		.dlys_cell_envt					(dlys_cell_envt	),//output		[ 0: 4]		
		.dlys_cell_load					(dlys_cell_load	),//output		[ 0: 4]		
		.dlys_cell_taps					(dlys_cell_taps	),//output		[ 0 :4][ 8: 0]
		.dlys_cell_vout					(dlys_cell_vout	),//input		[ 0 :4][ 8: 0]

		.lane_sdes_prev					(lane_sdes_prev	),//input		[ 0: 4][ 7: 0]	
		.lane_sdes_data					(lane_sdes_data	),//input		[ 0: 4][ 7: 0]	
		.lane_slip_data					(lane_slip_data	),//output		[ 0: 4][ 7: 0]	
		.lane_sclk						(lane_sclk		),//input	
		.lane_rstn						(link_rstn		));	//input	

	lane_tune_sync					u_lane_tune_sync(
		.lane_sync_scan					(lane_sync_scan			),//output						
		.lane_sync_data					(lane_sync_data			),//output	reg	[ 0: 4][ 7: 0]	
		.lane_slip_data					(lane_slip_data			),//input		[ 0: 4][ 7: 0]	
		.lane_sync_reqs					(host_sync_rxdi_reqs	),//input						
		.lane_sync_done					(host_sync_rxdi_done	),//output						
		.link_sclk						(link_sclk				),//input						
		.link_rstn						(link_rstn				),//input						
		.lane_sclk						(lane_sclk				),//input						
		.lane_rstn						(lane_rstn				));//input						

	gens_sign_fast_slow	#( 
		.EXTN ( 8 )	)				
									u_gens_tune_rxdi_enab(
		.fast_sign  					(lane_sync_scan			),//input	
		.fast_clki						(lane_sclk				),//input	
		.fast_rstn						(lane_rstn				),//input	

		.slow_sign						(lane_sync_mode			),//output	
		.slow_clki						(link_sclk				),//input	
		.slow_rstn						(link_rstn				));//input	

//------------------------------------------------------------------------------
	reg			[ 2: 0]					tune_rdly_samp	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						tune_rdly_samp	<=	0	;
	else								tune_rdly_samp	<={	host_tune_rxdi_mode	,	tune_rdly_samp[2:1]	};

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_tune_rxdi	<=	0	;
	else 								lane_tune_rxdi	<=	lane_sync_mode 		| 	tune_rdly_samp[0]	;	
/**********************************************************************************************************/
	wire		[ 0: 4]					lane_dlys_sbdi	;
	
	for(genvar i = 0 ; i < 5 ; i++)	begin:gens_rdxi_idly_cell
	
		IDELAYE3 #(
	    	.CASCADE					("NONE"			),// Cascade setting (MASTER, NONE, SLAVE_END, SLAVE_MIDDLE)
	    	.DELAY_FORMAT				("TIME"		),// Units of the DELAY_VALUE (COUNT, TIME)
	    	.DELAY_SRC					("IDATAIN"		),// Delay input (DATAIN, IDATAIN)
	    	.DELAY_TYPE					("VAR_LOAD"		),// Set the type of tap delay line (FIXED, VARIABLE, VAR_LOAD)
	    	.DELAY_VALUE				( 9'H000		),// Input delay value setting
	    	.IS_CLK_INVERTED			( 1'H0			),// Optional inversion for CLK
	    	.IS_RST_INVERTED			( 1'H0			),// Optional inversion for RST
	    	.REFCLK_FREQUENCY			( 320.0			),// IDELAYCTRL clock input frequency in MHz (200.0-800.0)
	    	.SIM_DEVICE					("ULTRASCALE"	),// Set the device version for simulation functionality (ULTRASCALE)
	    	.UPDATE_MODE				("ASYNC"		))// Determines when updates to the delay will take effect (ASYNC, MANUAL, SYNC)

		u_RXDI_IDLY_CELL (
	    	.DATAOUT					(lane_dlys_sbdi[i] 	),	// 1-bit output: Delayed data output
	    	.IDATAIN					(lane_raws_sbdi[i]	),	// 1-bit input: Data input from the IOBUF

			.EN_VTC						(dlys_cell_envt[i]	),	// 1-bit input: Keep delay constant over VT
	    	.LOAD						(dlys_cell_load[i]	),	// 1-bit input: Load DELAY_VALUE input
	    	.CNTVALUEIN					(dlys_cell_taps[i]	),	// 9-bit input: Counter value input
	    	.CNTVALUEOUT				(dlys_cell_vout[i]	),	// 9-bit output: Counter value output

			.CASC_OUT					(  					),	// 1-bit output: Cascade delay output to ODELAY input cascade
	    	.CASC_IN					(1'B0   			),	// 1-bit input: Cascade delay input from slave ODELAY CASCADE_OUT
	    	.CASC_RETURN				(1'B0   	    	),	// 1-bit input: Cascade delay returning from slave ODELAY DATAOUT
			.DATAIN						(1'B0           	),	// 1-bit input: Data input from the logic
	    	.INC						(1'B0				),	// 1-bit input: Increment / Decrement tap delay input
	    	.CE							(1'B0				),	// 1-bit input: Active-High enable increment/decrement input
	    	.CLK						( lane_sclk			),	// 1-bit input: Clock input
	    	.RST						( dlys_brst			));// 1-bit input: Asynchronous Reset to the DELAY_VALUE
//--------------------------------------
	   	ISERDESE3 #(
	    	.DATA_WIDTH					(8					),// Parallel data width (4,8)
	    	.IS_CLK_B_INVERTED			(1'B1				),// Optional inversion for CLK_B
	    	.IS_CLK_INVERTED			(1'B0				),// Optional inversion for CLK
	    	.IS_RST_INVERTED			(1'B1				),// Optional inversion for RST
	    	.FIFO_ENABLE				("FALSE"			),// Enables the use of the FIFO
	    	.FIFO_SYNC_MODE				("FALSE"			),// Always set to FALSE. TRUE is reserved for later use.
	    	.SIM_DEVICE					("ULTRASCALE"		))// Set the device version for simulation functionality (ULTRASCALE)
	
	   	u_RXDI_ISDE_CELL (
	    	.FIFO_EMPTY					(					),	// 1-bit output: FIFO empty flag
	    	.INTERNAL_DIVCLK			(					),	// 1-bit output: Internally divided down clock used when FIFO is disabled (do not connect)
	    	.Q							(lane_sdes_invt[i]	),	// 8-bit registered output
	    	.D							(lane_dlys_sbdi[i]	),	// 1-bit input: Serial Data Input
	    	.CLK						(lane_fclk			),	// 1-bit input: High-speed clock
	    	.CLK_B						(lane_fclk			),	// 1-bit input: Inversion of High-speed clock CLK
	    	.CLKDIV						(lane_sclk			),	// 1-bit input: Divided Clock
	    	.FIFO_RD_CLK				(1'B0				),	// 1-bit input: FIFO read clock
	    	.FIFO_RD_EN					(1'B0				),	// 1-bit input: Enables reading the FIFO when asserted
	    	.RST						(link_rstn			));	// 1-bit input: Asynchronous Reset
	
		always@(posedge lane_sclk or negedge lane_rstn)
		if(~lane_rstn)					lane_sdes_prev[i]	<=	0	;
		else							lane_sdes_prev[i]	<=	lane_sdes_data[i]	;
		
		gens_byte_invt				u_gens_byte_invt(
    		.byte_invt					(lane_sdes_data[i]	),//output		[ 7: 0]	
			.byte_data					(lane_sdes_invt[i]	));//input		[ 7: 0]	

	end
/**********************************************************************************************************************/
	reg		[ 7: 0]						lane_fram_m2di	;
	wire	[ 7: 0]						lane_fram_mbdi	=	lane_sync_data[0];
	wire	[ 7: 0]						lane_dat0_mbdi	=	lane_sync_data[1];
	wire	[ 7: 0]						lane_dat1_mbdi	=	lane_sync_data[2];
	wire	[ 7: 0]						lane_dat2_mbdi	=	lane_sync_data[3];
	wire	[ 7: 0]						lane_dat3_mbdi	=	lane_sync_data[4];

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn) 						lane_fram_m2di	<=	0	;
	else 								lane_fram_m2di	<=	lane_fram_mbdi	;
//------------------------------------------------------------------------------
	wire								rxdi_fram_csen	;
	wire								rxdi_fram_rise	;
	wire								rxdi_fram_fall	;
	wire								rxdi_fram_body	;
	wire	[31: 0]						rxdi_fram_data	;

	assign	rxdi_fram_rise	=  		{	lane_push_wken	,	~lane_tune_rxdi	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	18'H300FF	;//root_tune_rxen	,
	assign	rxdi_fram_fall	=  		{	lane_push_wken	,	~lane_tune_rxdi	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	18'H3FF00	;//root_tune_rxen	,
	assign	rxdi_fram_body	=  		{ 	lane_push_wken	,	~lane_tune_rxdi	,	lane_fram_m2di	, 	lane_fram_mbdi	}	==	18'H3FFFF	;//root_tune_rxen	,
	assign	rxdi_fram_csen	=	|	{	rxdi_fram_rise	,	rxdi_fram_body	,	rxdi_fram_fall	}	;

	assign	rxdi_fram_data	=		{	lane_dat3_mbdi	,	
										lane_dat2_mbdi	,	
										lane_dat1_mbdi	,	
										lane_dat0_mbdi	};
//------------------------------------------------------------------------------
	reg									lane_push_csen	;

	reg									lane_push_vlid	;
	reg		[31: 0]						lane_push_data	;
	reg		[ 1: 0]						lane_push_tags	;
	reg		[15: 0]						lane_push_addr	;
	
	wire		[15: 0]					lane_pops_dptr	;
	wire								lane_push_init	;
	wire								lane_push_clrs	;
	wire								lane_push_drdy	;
	wire								lane_push_ovfl	;

	assign	lane_push_init	=			rxdi_fram_rise	;
	assign	lane_push_ovfl	=			lane_push_addr	>=	lane_pops_dptr + 2	;	
	assign	lane_push_drdy	=	&{		lane_push_csen	,	lane_push_ovfl	   };	
	
	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)	begin
		lane_push_vlid	<=	0	;
		lane_push_data	<=	0	;
		lane_push_tags	<=	0	;
	end else if(~lane_push_wken)	begin
		lane_push_vlid	<=	0	;
		lane_push_data	<=	0	;
		lane_push_tags	<=	0	;
	end else 		begin
		lane_push_vlid	<=	rxdi_fram_csen	;
		lane_push_data	<=	rxdi_fram_data	;
		lane_push_tags	<=	rxdi_fram_rise	?	2'H1	:
							rxdi_fram_fall	?	2'H3	:
							rxdi_fram_body	?	2'H2	:	2'H0	;
	end	

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn) 						lane_push_csen	<=	0	;
	else if(~lane_push_wken)			lane_push_csen	<=	0	;	
	else if( lane_push_init)			lane_push_csen	<=	1	;
	else if( lane_push_clrs)			lane_push_csen	<=	0	;
	
	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn) 						lane_push_addr	<=	0	;
	else if(~lane_push_wken)			lane_push_addr	<=	0	;	
	else if( lane_push_init)			lane_push_addr	<=	0	;
	else if( lane_push_vlid)			lane_push_addr	<=	lane_push_addr + 1	;
	else if( lane_push_clrs)			lane_push_addr	<=	0	;
/**********************************************************************************************************************/
	reg									lane_pops_csen	;
//	reg									lane_pops_ssen	;

	reg									lane_pops_done	;
	reg			[15: 0]					lane_pops_addr	;

	wire		[15: 0]					lane_push_dptr	;
	wire								lane_pops_reqs	;
	wire		[31: 0]					lane_pops_data	;
	wire		[ 1: 0]					lane_pops_tags	;
	
	wire								lane_pops_lead	;
	wire								lane_pops_body	;
	wire								lane_pops_coda	;
	wire								lane_pops_drdy	;

	wire								lane_pops_udfl	;

	assign	lane_pops_udfl	=			lane_push_dptr	>	lane_pops_addr	;	
	assign	lane_pops_drdy 	=	&	{	lane_pops_csen	,	lane_pops_udfl };

	assign	lane_pops_lead	=		{	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B101		;
	assign	lane_pops_body	=		{	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B110		;
	assign	lane_pops_coda	=		{ 	lane_pops_drdy	,	lane_pops_tags	} 	==	3'B111		;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_csen	<=	0	;
	else if(~lane_pops_wken)			lane_pops_csen	<=	0	;
	else if( lane_pops_reqs)			lane_pops_csen	<=	1	;
	else if( lane_pops_coda)			lane_pops_csen	<=	0	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_done	<=	0	;
	else if(~lane_pops_wken)			lane_pops_done	<=	0	;
	else if( lane_pops_reqs)			lane_pops_done	<=	0	;
	else if( lane_pops_coda)			lane_pops_done	<=	1	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						lane_pops_addr	<=	0	;
	else if(~lane_pops_wken)			lane_pops_addr	<=	0	;
	else if( lane_pops_reqs)			lane_pops_addr	<=	0	;
	else if( lane_pops_coda)			lane_pops_addr	<=	0	;
	else if( lane_pops_drdy)			lane_pops_addr	<=	lane_pops_addr + 1	;
/**********************************************************************************************************************/
	gens_sync_gray #( .MSB (15) )	
									u_rxdi_port_push_dptr(
		.data_asyn						(lane_push_addr		),
		.scki							(lane_sclk			),
		.data_sync						(lane_push_dptr		),
		.clki							(link_sclk			),
		.rstn							(link_rstn			));

	gens_sync_gray #( .MSB (15) )	
									u_rxdi_port_pops_dptr(
		.data_asyn						(lane_pops_addr		),
		.scki							(link_sclk			),
		.data_sync						(lane_pops_dptr		),
		.clki							(lane_sclk			),
		.rstn							(lane_rstn			));

	gens_edge_fast_slow	#( .EXTN (5) )	
									u_fram_pops_done_edge(
		.slow_edge						(lane_push_clrs	),//output	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(lane_rstn		),//input	
		
		.fast_sign  					(lane_pops_done	),//input	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		));//input	

	gens_edge_slow_fast				u_fram_pops_reqs_edge(
		.fast_edge						(lane_pops_reqs	),//output	
		.fast_clki						(link_sclk		),//input	
		.fast_rstn						(link_rstn		),//input	
		.slow_sign  					(lane_push_drdy	),//input	
		.slow_clki						(lane_sclk		),//input	
		.slow_rstn						(lane_rstn		));//input	
	
	trip_port_tags					u_rxdi_port_push_fifo(
		.wport_csen						(lane_push_vlid		),
		.wport_addr						(lane_push_addr[2:0]),
		.wport_tags						(lane_push_tags		),
		.wport_data						(lane_push_data		),
		.wport_rstn						(lane_push_init		),
		.wport_clki						(lane_sclk			),

		.rport_addr						(lane_pops_addr[2:0]),
		.rport_tags						(lane_pops_tags		),
		.rport_data						(lane_pops_data		),
		.rport_clki						(link_sclk			));
/**********************************************************************************************************************/
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn)						begin
		pmau_fram_lead		<=			0	;
		pmau_fram_body		<=			0	;
		pmau_fram_coda		<=			0	;
	
		pmau_dat3_mbdo		<=			0	;
		pmau_dat2_mbdo		<=			0	;
		pmau_dat1_mbdo		<=			0	;
		pmau_dat0_mbdo		<=			0	;
	end else if(~lane_pops_drdy)		begin
		pmau_fram_lead		<=			0	;
		pmau_fram_body		<=			0	;
		pmau_fram_coda		<=			0	;

		pmau_dat3_mbdo		<=			0	;
		pmau_dat2_mbdo		<=			0	;
		pmau_dat1_mbdo		<=			0	;
		pmau_dat0_mbdo		<=			0	;
	end else 							begin
		pmau_fram_lead		<=			lane_pops_tags	==	2'H1	;
		pmau_fram_body		<=			lane_pops_tags	==	2'H2	;
		pmau_fram_coda		<=			lane_pops_tags	==	2'H3	;

		pmau_dat3_mbdo		<=			lane_pops_data[31:24]	;
		pmau_dat2_mbdo		<=			lane_pops_data[23:16]	;
		pmau_dat1_mbdo		<=			lane_pops_data[15: 8]	;
		pmau_dat0_mbdo		<=			lane_pops_data[ 7: 0]	;
	end


endmodule

