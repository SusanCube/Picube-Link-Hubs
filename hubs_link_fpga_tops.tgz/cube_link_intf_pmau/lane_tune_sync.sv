
module	lane_tune_sync(
	output								lane_sync_scan	,
	output	reg	[ 0: 4][ 7: 0]			lane_sync_data	,
	input		[ 0: 4][ 7: 0]			lane_slip_data	,

	input								lane_sync_reqs	,
	output								lane_sync_done	,

	input								link_sclk		,
	input								link_rstn		,
	input								lane_sclk		,
	input								lane_rstn		);
/**********************************************************************************************************************/
	reg			[ 2: 0]					sync_enab_samp=0	;
	assign		lane_sync_enab	=		sync_enab_samp[0]	;

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						sync_enab_samp	<=	0	;		
	else								sync_enab_samp	<= {lane_sync_reqs	,	sync_enab_samp[2:1]	}	;
//------------------------------------------------------------------------------
	wire								lane_sync_deal		;

	reg			[ 2: 0]					sync_done_samp=0	;
	assign		lane_sync_done	=		sync_done_samp[0]	;

	always@(posedge link_sclk or negedge link_rstn)			
	if(~link_rstn)						sync_done_samp	<=	0	;
	else								sync_done_samp	<= {lane_sync_deal	,	sync_done_samp[2:1]	}	;
/**********************************************************************************************************************/
	reg			[ 2: 0]					lane_sync_mfsm	;
	
	parameter	LANE_SYNC_IDLE	=		3'H0	;
	parameter	LANE_SYNC_POLE	=		3'H1	;
	parameter	LANE_SYNC_SCAN	=		3'H2	;
	parameter	LANE_SYNC_SEEK	=		3'H3	;
	parameter	LANE_SYNC_CFIG	=		3'H4	;
	parameter	LANE_SYNC_DEAL	=		3'H5	;

	wire								lane_sync_last	;
	
	wire								lane_sync_idle	;
	wire								lane_sync_pole	;
	wire								lane_sync_seek	;
	wire								lane_sync_cfig	;
	
	assign	lane_sync_idle		=		lane_sync_mfsm	==	LANE_SYNC_IDLE	;
	assign	lane_sync_pole		=		lane_sync_mfsm	==	LANE_SYNC_POLE	;
	assign	lane_sync_scan		=		lane_sync_mfsm	==	LANE_SYNC_SCAN	;
	assign	lane_sync_seek		=		lane_sync_mfsm	==	LANE_SYNC_SEEK	;
	assign	lane_sync_cfig		=		lane_sync_mfsm	==	LANE_SYNC_CFIG	;
	assign	lane_sync_deal		=		lane_sync_mfsm	==	LANE_SYNC_DEAL	;
		
	always@(posedge lane_sclk or negedge lane_rstn )				
	if(~lane_rstn)						lane_sync_mfsm	<=	LANE_SYNC_IDLE	;
	else if(~lane_sync_enab)			lane_sync_mfsm	<=	LANE_SYNC_IDLE	;
	else begin
		case(lane_sync_mfsm)	
			LANE_SYNC_IDLE		:		lane_sync_mfsm	<=											LANE_SYNC_POLE	;
			LANE_SYNC_POLE		:		lane_sync_mfsm	<=											LANE_SYNC_SCAN	;
			LANE_SYNC_SCAN		:		lane_sync_mfsm	<=	lane_sync_last	?	LANE_SYNC_SEEK	:	LANE_SYNC_SCAN	;
			LANE_SYNC_SEEK		:		lane_sync_mfsm	<=											LANE_SYNC_CFIG	;
			LANE_SYNC_CFIG		:		lane_sync_mfsm	<=											LANE_SYNC_DEAL	;
			LANE_SYNC_DEAL		:		lane_sync_mfsm	<=	lane_sync_enab	?	LANE_SYNC_DEAL	:	LANE_SYNC_IDLE	;
			
			default				:		lane_sync_mfsm	<=											LANE_SYNC_IDLE	;
		endcase
	end
/**********************************************************************************************************************/
	reg			[ 0: 4][ 7: 0]			lane_sync_buff	;	
	reg			[ 0: 4][ 7: 0]			lane_sync_posi	;

	reg			[ 7: 0]					lane_sync_time	;	
	reg			[ 7: 0]					lane_sync_tmax	;	

	reg			[ 0: 4]					lane_sync_move	;//lane's lead_posi not be tmax 

	wire		[ 0: 4]					lane_slip_lead	;	

	assign	lane_sync_last	=	&		lane_sync_time	;
//------------------------------------------------------------------------------
	wire		[ 7: 0]					sync_maxi_posi	;

	maxi_vals_seek					u_maxi_sync_time(
		.maxi_data						(sync_maxi_posi	),//output		[ 7: 0]				
		.vals_data						(lane_sync_posi	));//input		[ 0: 4][ 7: 0]		
//------------------------------------------------------------------------------
	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_sync_time	<=	0	;
	else if(~lane_sync_scan)			lane_sync_time	<=	0	;
	else 								lane_sync_time	<=	1 +	lane_sync_time	;	

	always@(posedge lane_sclk or negedge lane_rstn)
	if(~lane_rstn)						lane_sync_tmax	<=	0	;
	else if(lane_sync_pole)				lane_sync_tmax	<=	8'HFF;
	else if(lane_sync_seek)				lane_sync_tmax	<=	sync_maxi_posi	;
//------------------------------------------------------------------------------
	for(genvar i = 0 ; i < 5 ; i ++)	begin:gens_sync_pole_finder

		assign	lane_slip_lead[i]	= {	lane_slip_data[i]	,	lane_sync_buff[i]	}	==	16'H9A00	;

		always@(posedge lane_sclk or negedge lane_rstn)
		if(~lane_rstn)					lane_sync_buff[i]	<=	0	;
		else							lane_sync_buff[i]	<=	lane_slip_data[i]	;	

		always@(posedge lane_sclk or negedge lane_rstn)
		if(~lane_rstn)					lane_sync_posi[i]	<=	0	;
		else if(lane_sync_pole)			lane_sync_posi[i]	<=	0	;
		else if(lane_sync_scan)			lane_sync_posi[i]	<=	lane_slip_lead[i]	?	lane_sync_time	:	lane_sync_posi[i]	;

		always@(posedge lane_sclk or negedge lane_rstn)
		if(~lane_rstn)					lane_sync_move[i]	<=	0	;
		else if(lane_sync_pole)			lane_sync_move[i]	<=	0	;
		else if(lane_sync_cfig)			lane_sync_move[i]	<=	lane_sync_posi[i]	!=	lane_sync_tmax	;

		always@(posedge lane_sclk or negedge lane_rstn)
		if(~lane_rstn)					lane_sync_data[i]	<=	0	;
		else if(lane_sync_idle)			lane_sync_data[i]	<=	lane_sync_move[i] ? lane_sync_buff[i]	:	lane_slip_data[i]	;
	end
	

endmodule
 