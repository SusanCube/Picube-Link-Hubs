
module	link_hubs_tune_acks(
	input								tune_link_pass		,
	input								lane_sclk			,
	
	output	reg	[ 7: 0]					tune_rack_fram		,
	output	reg	[ 7: 0]					tune_rack_dat3		,
	output	reg	[ 7: 0]					tune_rack_dat2		,
	output	reg	[ 7: 0]					tune_rack_dat1		,
	output	reg	[ 7: 0]					tune_rack_dat0		,
	input								link_sclk			,
	input								link_rstn			);
/**********************************************************************************************************************/
	reg									tune_link_pass_sync	;

	always@(posedge lane_sclk or negedge link_rstn)
	if(~link_rstn) 						tune_link_pass_sync	<=		0	;
	else 								tune_link_pass_sync	<=		tune_link_pass	;
/**********************************************************************************************************************/
	reg			[2: 0]					tune_link_pass_samp	;
	reg			[2: 0]					tune_link_resp_time	;
	
	wire	tune_link_resp_issu	=		tune_link_pass_samp[1: 0]	==	2'B10	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						tune_link_pass_samp	<=		0	;
	else 								tune_link_pass_samp	<=	{	tune_link_pass_sync	,	tune_link_pass_samp[2:1]	};
	
	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						tune_link_resp_time	<=		0	;
	else								tune_link_resp_time	<= 	{	tune_link_resp_issu	,	tune_link_resp_time[2:1]};
/**********************************************************************************************************************/
	wire	tune_rack_wrd0	=		tune_link_resp_time	==	3'B010	;
	wire	tune_rack_wrd1	=		tune_link_resp_time	==	3'B001	;

	always@(posedge link_sclk or negedge link_rstn)
	if(~link_rstn) 						begin
		tune_rack_fram		<=		0	;
		tune_rack_dat3		<=		0	;
		tune_rack_dat2		<=		0	;
		tune_rack_dat1		<=		0	;
		tune_rack_dat0		<=		0	;
	end	else if(tune_rack_wrd0)	begin
		tune_rack_fram		<=		8'HFF	;
		tune_rack_dat3		<=		"A"	;
		tune_rack_dat2		<=		"C"	;
		tune_rack_dat1		<=		"K"	;
		tune_rack_dat0		<=		"S"	;
	end	else if(tune_rack_wrd1)	begin
		tune_rack_fram		<=		8'HFF	;
		tune_rack_dat3		<=		"T"	;
		tune_rack_dat2		<=		"X"	;
		tune_rack_dat1		<=		"D"	;
		tune_rack_dat0		<=		"O"	;
	end	else 							begin
		tune_rack_fram		<=		0	;
		tune_rack_dat3		<=		0	;
		tune_rack_dat2		<=		0	;
		tune_rack_dat1		<=		0	;
		tune_rack_dat0		<=		0	;
	end





endmodule
