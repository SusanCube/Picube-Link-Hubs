#include "../common/tpuc_misc.h"
#include "../common/llmb_ecos.h"
#include "../common/tpgs_link.h"
#include "../common/tpem_link.h"


//TPGL->TPES_PORT	=	TLNK_DEST_PORT	;

void main() {

	LLMB->LLMB_STA0	= 0X8888	;
//	tpem_trim_tpes();
	LLMB->LLMB_STA0	= 0X0000	;

	while(1){
		LLMB->LLMB_STA0	= 0X0001	;
		TPGL->TPGM_STAT	=	TPGL->TPGM_LINK ;
		LLMB->LLMB_STA0	= 0X0000	;
		
		if(TPGL->TPGM_STAT & TPGM_CMND_MASK)	{	
			TPGL->ECOS_UPDT	=	0X0		;
			TPGL->TPGM_LINK	=	0X0		;
			TPGL->TPES_PORT	=	TLNK_DEST_PORT	;
			
			if(TPGL->TPGM_STAT & TPGM_NNEX_MASK	){	LLMB->LLMB_STA1	=0x4E4E4558 ; 	llmb_nnex_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_OMTX_MASK	){	LLMB->LLMB_STA1 =0x4F4D5458 ;	llmb_odat_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_RIMT_MASK	){	LLMB->LLMB_STA1	=0x5249534D	; 	llmb_ridt_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_RISM_MASK	){	LLMB->LLMB_STA1	=0x5249534D	; 	llmb_risx_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_IVCT_MASK	){	LLMB->LLMB_STA1 =0x49564354 ;	llmb_idat_parse(0x00);	}
			if(TPGL->TPGM_STAT & TPGM_OVCT_MASK	){	LLMB->LLMB_STA1 =0x4F564354 ;	llmb_odat_parse(0x00);	}

			if(TPGL->TPGM_STAT & TPGM_ACMD_MASK ){	LLMB->LLMB_STA1 =0x41434D44 ;	llmb_acmd_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_ICFG_MASK	){	LLMB->LLMB_STA1 =0x49434647 ;	llmb_icfg_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_OCFG_MASK	){	LLMB->LLMB_STA1 =0x4F434647 ;	llmb_ocfg_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_ROMT_MASK	){	LLMB->LLMB_STA1	=0x524F534D	; 	llmb_rodt_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_RIVT_MASK	){	LLMB->LLMB_STA1	=0x52495356	; 	llmb_ridt_parse(0x00);	}
			if(TPGL->TPGM_STAT & TPGM_ROVT_MASK	){	LLMB->LLMB_STA1	=0x524F5356	; 	llmb_rodt_parse(0x00);	}

			if(TPGL->TPGM_STAT & TPGM_RISV_MASK	){	LLMB->LLMB_STA1	=0x52495356	; 	llmb_risx_parse(0x00);	}
			if(TPGL->TPGM_STAT & TPGM_ROSV_MASK	){	LLMB->LLMB_STA1	=0x524F5356	; 	llmb_rosx_parse(0x00);	}
			if(TPGL->TPGM_STAT & TPGM_ROSM_MASK	){	LLMB->LLMB_STA1	=0x524F534D	; 	llmb_rosx_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_IMTX_MASK	){	LLMB->LLMB_STA1 =0x494D5458 ;	llmb_idat_parse(0x01);	}
			if(TPGL->TPGM_STAT & TPGM_ASET_MASK	){	LLMB->LLMB_STA1 =0x41534554 ;	llmb_aset_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_DNLD_MASK	){	LLMB->LLMB_STA1 =0x444E4C44 ;	llmb_dnld_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_BOOT_MASK	){	LLMB->LLMB_STA1 =0x424F4F54 ;	llmb_boot_parse(	);	}
			if(TPGL->TPGM_STAT & TPGM_TRIM_MASK	){	LLMB->LLMB_STA1 =0x5452494D ;	llmb_trim_parse(	);	}
		}		
	}
}
