/*
 * Copyright (C) 2018 ChipRise Technologies Co.,Ltd. All Rights Reserved.
 * File: rvrcore.h
 * Function: define risc-v core
 */
 
#ifndef  _RVRCORE_H
#define  _RVRCORE_H
#ifdef __cplusplus
extern  "C" {
#endif

#ifndef __ASSEMBLER__
#include <stdint.h>
#endif

#ifdef __cplusplus
#define __I                     volatile
#else
#define __I                     volatile const
#endif
#define __O                     volatile
#define __IO                    volatile

#if defined ( __CC_ARM )
#define __ASM                   __asm
#define __INLINE                __inline
#define __STATIC_INLINE         static __inline
#define NOOPTIMIZE
#elif defined ( __ICCARM__ )
#define __ASM                   __asm
#define __INLINE                inline
#define __STATIC_INLINE         static inline
#define NOOPTIMIZE
#elif defined ( __GNUC__ )
#define __ASM                   __asm
#define __INLINE                inline
#define __STATIC_INLINE         static inline
#define NOOPTIMIZE              __attribute__((optimize("O0")))
#elif defined ( __TASKING__ )
#define __ASM                   __asm
#define __INLINE                inline
#define __STATIC_INLINE         static inline
#define NOOPTIMIZE
#endif

#ifdef __ASSEMBLER__
#define _AC(X,Y)                X
#define _AT(T,X)                X
#else
#define _AC(X,Y)                (X##Y)
#define _AT(T,X)                ((T)(X))
#endif

#if __riscv_xlen == 64
#define SLL32                   sllw
#define STORE                   sd
#define LOAD                    ld
#define LWU                     lwu
#define REGTYPE                 uint64_t
#define LOG_REGBYTES            3
#define UNSIGNED_REGVAL(x)      _AC(x,ULL)
#define _BIT(x)                 (_AC(1,ULL) << (x))
#else
#define SLL32                   sll
#define STORE                   sw
#define LOAD                    lw
#define LWU                     lw
#define REGTYPE                 uint32_t
#define LOG_REGBYTES            2
#define UNSIGNED_REGVAL(x)      _AC(x,UL)
#define _BIT(x)                 (_AC(1,UL) << (x))
#endif

#define REGBYTES                (1 << LOG_REGBYTES)


/* define MStatus */
#define MSTATUS_UIE             UNSIGNED_REGVAL(0x00000001)
#define MSTATUS_SIE             UNSIGNED_REGVAL(0x00000002)
#define MSTATUS_HIE             UNSIGNED_REGVAL(0x00000004)
#define MSTATUS_MIE             UNSIGNED_REGVAL(0x00000008)
#define MSTATUS_UPIE            UNSIGNED_REGVAL(0x00000010)
#define MSTATUS_SPIE            UNSIGNED_REGVAL(0x00000020)
#define MSTATUS_HPIE            UNSIGNED_REGVAL(0x00000040)
#define MSTATUS_MPIE            UNSIGNED_REGVAL(0x00000080)
#define MSTATUS_SPP             UNSIGNED_REGVAL(0x00000100)
#define MSTATUS_HPP             UNSIGNED_REGVAL(0x00000600)
#define MSTATUS_MPP             UNSIGNED_REGVAL(0x00001800)
#define MSTATUS_FS              UNSIGNED_REGVAL(0x00006000)
#define MSTATUS_XS              UNSIGNED_REGVAL(0x00018000)
#define MSTATUS_MPRV            UNSIGNED_REGVAL(0x00020000)
#define MSTATUS_PUM             UNSIGNED_REGVAL(0x00040000)
#define MSTATUS_MXR             UNSIGNED_REGVAL(0x00080000)
#define MSTATUS_VM              UNSIGNED_REGVAL(0x1F000000)
#define MSTATUS32_SD            UNSIGNED_REGVAL(0x80000000)
#define MSTATUS64_SD            _AC(0x8000000000000000,ULL)
#if __riscv_xlen == 64
#define MSTATUS_SD              MSTATUS64_SD
#else
#define MSTATUS_SD              MSTATUS32_SD
#endif

/* define MIP/MIE */
#define IRQ_S_SOFT              1
#define IRQ_H_SOFT              2
#define IRQ_M_SOFT              3
#define IRQ_S_TIMER             5
#define IRQ_H_TIMER             6
#define IRQ_M_TIMER             7
#define IRQ_S_EXT               9
#define IRQ_H_EXT               10
#define IRQ_M_EXT               11

#define MIP_SSIP                _BIT(IRQ_S_SOFT)
#define MIP_HSIP                _BIT(IRQ_H_SOFT)
#define MIP_MSIP                _BIT(IRQ_M_SOFT)
#define MIP_STIP                _BIT(IRQ_S_TIMER)
#define MIP_HTIP                _BIT(IRQ_H_TIMER)
#define MIP_MTIP                _BIT(IRQ_M_TIMER)
#define MIP_SEIP                _BIT(IRQ_S_EXT)
#define MIP_HEIP                _BIT(IRQ_H_EXT)
#define MIP_MEIP                _BIT(IRQ_M_EXT)

#define MIE_SSIE                _BIT(IRQ_S_SOFT)
#define MIE_HSIE                _BIT(IRQ_H_SOFT)
#define MIE_MSIE                _BIT(IRQ_M_SOFT)
#define MIE_STIE                _BIT(IRQ_S_TIMER)
#define MIE_HTIE                _BIT(IRQ_H_TIMER)
#define MIE_MTIE                _BIT(IRQ_M_TIMER)
#define MIE_SEIE                _BIT(IRQ_S_EXT)
#define MIE_HEIE                _BIT(IRQ_H_EXT)
#define MIE_MEIE                _BIT(IRQ_M_EXT)

/* define MCAUSE */
#define CAUSE32_INT             UNSIGNED_REGVAL(0x80000000)
#define CAUSE64_INT             _AC(0x8000000000000000,ULL)
#if __riscv_xlen == 64
#define MCAUSE_INT              CAUSE64_INT
#else
#define MCAUSE_INT              CAUSE32_INT
#endif
#define MCAUSE_U_SOFT_INT       (MCAUSE_INT | UNSIGNED_REGVAL(0x00000000))
#define MCAUSE_S_SOFT_INT       (MCAUSE_INT | UNSIGNED_REGVAL(0x00000001))
#define MCAUSE_H_SOFT_INT       (MCAUSE_INT | UNSIGNED_REGVAL(0x00000002))
#define MCAUSE_M_SOFT_INT       (MCAUSE_INT | UNSIGNED_REGVAL(0x00000003))
#define MCAUSE_U_TIMER_INT      (MCAUSE_INT | UNSIGNED_REGVAL(0x00000004))
#define MCAUSE_S_TIMER_INT      (MCAUSE_INT | UNSIGNED_REGVAL(0x00000005))
#define MCAUSE_H_TIMER_INT      (MCAUSE_INT | UNSIGNED_REGVAL(0x00000006))
#define MCAUSE_M_TIMER_INT      (MCAUSE_INT | UNSIGNED_REGVAL(0x00000007))
#define MCAUSE_U_EXT_INT        (MCAUSE_INT | UNSIGNED_REGVAL(0x00000008))
#define MCAUSE_S_EXT_INT        (MCAUSE_INT | UNSIGNED_REGVAL(0x00000009))
#define MCAUSE_H_EXT_INT        (MCAUSE_INT | UNSIGNED_REGVAL(0x0000000a))
#define MCAUSE_M_EXT_INT        (MCAUSE_INT | UNSIGNED_REGVAL(0x0000000b))
#define MCAUSE_RSVD_INT         (MCAUSE_INT | UNSIGNED_REGVAL(0x0000000c)) /* above all are reserved. */
#define MCAUSE_INSN_MISALIGN                  UNSIGNED_REGVAL(0x00000000)
#define MCAUSE_INSN_ACCESS_FAULT              UNSIGNED_REGVAL(0x00000001)
#define MCAUSE_INSN_ILLEGAL                   UNSIGNED_REGVAL(0x00000002)
#define MCAUSE_BREAKPOINT                     UNSIGNED_REGVAL(0x00000003)
#define MCAUSE_LOAD_MISALIGN                  UNSIGNED_REGVAL(0x00000004)
#define MCAUSE_LOAD_ACCESS_FAULT              UNSIGNED_REGVAL(0x00000005)
#define MCAUSE_STORE_MISALIGN                 UNSIGNED_REGVAL(0x00000006)
#define MCAUSE_STORE_ACCESS_FAULT             UNSIGNED_REGVAL(0x00000007)
#define MCAUSE_ECALL_FROM_U_MODE              UNSIGNED_REGVAL(0x00000008)
#define MCAUSE_ECALL_FROM_S_MODE              UNSIGNED_REGVAL(0x00000009)
#define MCAUSE_ECALL_FROM_H_MODE              UNSIGNED_REGVAL(0x0000000a)
#define MCAUSE_ECALL_FROM_M_MODE              UNSIGNED_REGVAL(0x0000000b)
#define MCAUSE_RSVD_TRAP                      UNSIGNED_REGVAL(0x0000000c)  /* above all are reserved. */

/* sisc-T6 lmsb CSR definition */
#ifdef __ASSEMBLER__
#define CSR_CUSTOMED_MLSB       0xFE1
#define CSR_CUSTOMED_PLSB       0xFE2
#define CSR_CUSTOMED_MRAC       0xFE3
#else
#define CSR_CUSTOMED_MLSB       "0xFE1"
#define CSR_CUSTOMED_PLSB       "0xFE2"
#define CSR_CUSTOMED_MRAC       "0xFE3"
#endif

/* define Bit */
#define DEF_BIT_NONE            UNSIGNED_REGVAL(0x00000000)
#define DEF_BIT_00              _BIT(0)
#define DEF_BIT_01              _BIT(1)
#define DEF_BIT_02              _BIT(2)
#define DEF_BIT_03              _BIT(3)
#define DEF_BIT_04              _BIT(4)
#define DEF_BIT_05              _BIT(5)
#define DEF_BIT_06              _BIT(6)
#define DEF_BIT_07              _BIT(7)

#define DEF_BIT_08              _BIT(8)
#define DEF_BIT_09              _BIT(9)
#define DEF_BIT_10              _BIT(10)
#define DEF_BIT_11              _BIT(11)
#define DEF_BIT_12              _BIT(12)
#define DEF_BIT_13              _BIT(13)
#define DEF_BIT_14              _BIT(14)
#define DEF_BIT_15              _BIT(15)

#define DEF_BIT_16              _BIT(16)
#define DEF_BIT_17              _BIT(17)
#define DEF_BIT_18              _BIT(18)
#define DEF_BIT_19              _BIT(19)
#define DEF_BIT_20              _BIT(20)
#define DEF_BIT_21              _BIT(21)
#define DEF_BIT_22              _BIT(22)
#define DEF_BIT_23              _BIT(23)

#define DEF_BIT_24              _BIT(24)
#define DEF_BIT_25              _BIT(25)
#define DEF_BIT_26              _BIT(26)
#define DEF_BIT_27              _BIT(27)
#define DEF_BIT_28              _BIT(28)
#define DEF_BIT_29              _BIT(29)
#define DEF_BIT_30              _BIT(30)
#define DEF_BIT_31              _BIT(31)
#define DEF_BIT_32              _AC(0x0000000100000000,ULL)
#define DEF_BIT_33              _AC(0x0000000200000000,ULL)
#define DEF_BIT_34              _AC(0x0000000400000000,ULL)
#define DEF_BIT_35              _AC(0x0000000800000000,ULL)
#define DEF_BIT_36              _AC(0x0000001000000000,ULL)
#define DEF_BIT_37              _AC(0x0000002000000000,ULL)
#define DEF_BIT_38              _AC(0x0000004000000000,ULL)
#define DEF_BIT_39              _AC(0x0000008000000000,ULL)

#define DEF_BIT_40              _AC(0x0000010000000000,ULL)
#define DEF_BIT_41              _AC(0x0000020000000000,ULL)
#define DEF_BIT_42              _AC(0x0000040000000000,ULL)
#define DEF_BIT_43              _AC(0x0000080000000000,ULL)
#define DEF_BIT_44              _AC(0x0000100000000000,ULL)
#define DEF_BIT_45              _AC(0x0000200000000000,ULL)
#define DEF_BIT_46              _AC(0x0000400000000000,ULL)
#define DEF_BIT_47              _AC(0x0000800000000000,ULL)

#define DEF_BIT_48              _AC(0x0001000000000000,ULL)
#define DEF_BIT_49              _AC(0x0002000000000000,ULL)
#define DEF_BIT_50              _AC(0x0004000000000000,ULL)
#define DEF_BIT_51              _AC(0x0008000000000000,ULL)
#define DEF_BIT_52              _AC(0x0010000000000000,ULL)
#define DEF_BIT_53              _AC(0x0020000000000000,ULL)
#define DEF_BIT_54              _AC(0x0040000000000000,ULL)
#define DEF_BIT_55              _AC(0x0080000000000000,ULL)

#define DEF_BIT_56              _AC(0x0100000000000000,ULL)
#define DEF_BIT_57              _AC(0x0200000000000000,ULL)
#define DEF_BIT_58              _AC(0x0400000000000000,ULL)
#define DEF_BIT_59              _AC(0x0800000000000000,ULL)
#define DEF_BIT_60              _AC(0x1000000000000000,ULL)
#define DEF_BIT_61              _AC(0x2000000000000000,ULL)
#define DEF_BIT_62              _AC(0x4000000000000000,ULL)
#define DEF_BIT_63              _AC(0x8000000000000000,ULL)

/* define bool */
#define DEF_FAIL                UNSIGNED_REGVAL(0x00000000)
#define DEF_OK                  UNSIGNED_REGVAL(0x00000001)
#define DEF_FALSE               UNSIGNED_REGVAL(0x00000000)
#define DEF_TRUE                UNSIGNED_REGVAL(0x00000001)
#define DEF_NO                  UNSIGNED_REGVAL(0x00000000)
#define DEF_YES                 UNSIGNED_REGVAL(0x00000001)
#ifndef NULL
#define NULL					UNSIGNED_REGVAL(0x00000000)
#endif

/* define macro */
#ifndef __ASSEMBLER__
#define ROUNDUP(a, b)               ((((a) - 1) / (b) + 1) * (b))
#define ROUNDDOWN(a, b)             ((a) / (b) * (b))
#define MAX(a, b)                   ((a) > (b) ? (a) : (b))
#define MIN(a, b)                   ((a) < (b) ? (a) : (b))
#define CLAMP(a, lo, hi)            MIN(MAX(a, lo), hi)

#define DEF_BIT(bit)                (1u << (bit))
#define BIT_SET(val, mask)          ((val) = ((val) | (mask)))
#define BIT_CLR(val, mask)          ((val) = ((val) & ~(mask)))
#define BIT_IS_CLR(val, mask)       (((((val) & (mask)) == 0u) && \
                                        ((mask) !=  0u)) ? (DEF_YES) : (DEF_NO))

#define BIT_IS_SET(val, mask)       (((((val) & (mask)) == (mask)) && \
                                        ((mask) != 0u)) ? (DEF_YES) : (DEF_NO))


#define BIT_IS_SET_ANY(val, mask)   ((((val) & (mask)) ==  0u) ? (DEF_NO ) : (DEF_YES))

#ifdef __GNUC__
#define READ_CSR(reg)               ({  REGTYPE __tmp; \
                                        __ASM volatile ("csrr %0, " #reg : "=r"(__tmp)); \
                                        __tmp; })

#define READ_CUSTOMED_CSR(regstr)   ({  REGTYPE __tmp; \
                                        __ASM volatile ("csrr %0, " regstr : "=r"(__tmp)); \
                                        __tmp; })

#define WRITE_CSR(reg, val)         ({ \
                                        if (__builtin_constant_p(val) && (REGTYPE)(val) < 32) \
                                            __ASM volatile ("csrw " #reg ", %0" :: "i"(val)); \
                                        else \
                                            __ASM volatile ("csrw " #reg ", %0" :: "r"(val)); })

#define WRITE_CUSTOMED_CSR(regstr, val) \
                                    ({  if (__builtin_constant_p(val) && (REGTYPE)(val) < 32) \
                                            __ASM volatile ("csrw " regstr ", %0" :: "i"(val)); \
                                        else \
                                            __ASM volatile ("csrw " regstr ", %0" :: "r"(val)); })

#define SWAP_CSR(reg, val)          ({  REGTYPE __tmp; \
                                        if (__builtin_constant_p(val) && (REGTYPE)(val) < 32) \
                                            __ASM volatile ("csrrw %0, " #reg ", %1" : "=r"(__tmp) : "i"(val)); \
                                        else \
                                            __ASM volatile ("csrrw %0, " #reg ", %1" : "=r"(__tmp) : "r"(val)); \
                                        __tmp; })

#define SET_CSR(reg, bit)           ({  REGTYPE __tmp; \
                                        if (__builtin_constant_p(bit) && (REGTYPE)(bit) < 32) \
                                            __ASM volatile ("csrrs %0, " #reg ", %1" : "=r"(__tmp) : "i"(bit)); \
                                        else \
                                            __ASM volatile ("csrrs %0, " #reg ", %1" : "=r"(__tmp) : "r"(bit)); \
                                        __tmp; })

#define CLEAR_CSR(reg, bit)         ({  REGTYPE __tmp; \
                                        if (__builtin_constant_p(bit) && (REGTYPE)(bit) < 32) \
                                            __ASM volatile ("csrrc %0, " #reg ", %1" : "=r"(__tmp) : "i"(bit)); \
                                        else \
                                            __ASM volatile ("csrrc %0, " #reg ", %1" : "=r"(__tmp) : "r"(bit)); \
                                        __tmp; })
#if defined(RISCV_CUSTOMOP_INSN)
#define CLZW(val)                   ({  REGTYPE __tmp; \
                                        __ASM volatile ("clzw %0, %1" : "=r"(__tmp) : "r"(val)); \
                                        __tmp; })

#define CLZD(val)                   ({  REGTYPE __tmp; \
                                        __ASM volatile ("clzd %0, %1" : "=r"(__tmp) : "r"(val)); \
                                        __tmp; })

#define CLOW(val)                   ({  REGTYPE __tmp; \
                                        __ASM volatile ("clow %0, %1" : "=r"(__tmp) : "r"(val)); \
                                        __tmp; })

#define CLOD(val)                   ({  REGTYPE __tmp; \
                                        __ASM volatile ("clod %0, %1" : "=r"(__tmp) : "r"(val)); \
                                        __tmp; })

#define CPRR(adr)                   ({  REGTYPE __tmp; \
                                        __ASM volatile ("cprr %0, %1" : "=r"(__tmp) : "i"(adr)); \
                                        __tmp; })

#define CPRW(adr, val)              ({\
                                        __ASM volatile ("cprw %0, %1" :: "r"(val) , "i"(adr));  \
                                    })
#endif /* defined(RISCV_CUSTOMOP_INSN) */

#define FENCE_ALL(void)             ({ __ASM volatile ("fence"); })

#define CPU_SETVEC(val)             WRITE_CSR(mtvec, val)

#define CPU_INTEN(void)             SET_CSR(mstatus, MSTATUS_MIE)
#define CPU_INTDIS(void)            CLEAR_CSR(mstatus, MSTATUS_MIE)
#define CPU_EXTINTEN(void)          SET_CSR(mie, MIE_MEIE)

#endif  /* __GNUC__ */
#endif  /* !__ASSEMBLER__ */

#ifdef __cplusplus
}
#endif
#endif

