//#include "tpuc_misc.h"
//#include "cube_link.h"
#include "tpem_link.h"

/**********************************************************************/
void	tpem_link_stat(uint32_t stat_mask){
	TPGL->TPEM_STAT	=	0	;
	while( TPGL->TPEM_STAT	== 0){
		TPGL->TPEM_STAT	=	TPEL->TPEM_LINK & stat_mask	;	
	}	
	TPEL->TPEM_LINK	=	0	;
}
/**********************************************************************/
void	tpem_ocfg_tpes(){
	TPEL->TPEM_LINK = TPES_OCFG_CMND	;
	tpem_link_stat(TPES_OCFG_MASK)		;
};	
/**********************************************************************/
void	tpem_icfg_tpes(){
	TPEL->TPEM_LINK = TPES_ICFG_CMND	;
	tpem_link_stat(TPES_ICFG_MASK)		;
};	
/**********************************************************************/
void	tpem_nnex_tpes(){
	TPEL->TPEM_LINK = TPES_NNEX_CMND	;
	tpem_link_stat(TPES_NNEX_MASK)		;
};	
/**********************************************************************/
void	tpem_trim_tpes(){
	TPEL->TPEM_LINK = TPES_TRIM_CMND	;
	tpem_link_stat(TPES_TRIM_MASK)		;
};	
/**********************************************************************/
//void 	tpes_fpga_aset() {
//	TPEL->TPEM_LINK = FPGA_ASET_CMND	;
//	tpem_link_stat(FPGA_ASET_MASK)		;//	LLMB->LINK_MISC	=	0X301	;
//};
/**********************************************************************/
//void 	tpes_cram_aset() {
//	TPEL->TPEM_LINK = TPES_ASET_CMND	;
//	tpem_link_stat(TPES_ASET_MASK)		;//	tpgs_send_acks();//	LLMB->LINK_MISC	=	0X311	;
//};
/**********************************************************************/
//void 	tpes_ispm_aset() {
//	TPEL->TPEM_LINK = TPES_ASET_CMND	;
//	tpem_link_stat(TPES_ASET_MASK)		;//	tpgs_send_acks();//	LLMB->LINK_MISC	=	0X311	;
//};
/**********************************************************************/
//void 	tpes_fpga_dnld() {
//	TPEL->TPEM_LINK = FPGA_DNLD_CMND	;
//	tpem_link_stat(FPGA_DNLD_MASK)		;//	tpgs_send_acks();//	LLMB->LINK_MISC	=	0X302	;
//};
/**********************************************************************/
//void 	tpes_fpga_boot(){ 
//	TPEL->TPEM_LINK = FPGA_BOOT_CMND	;
//	tpem_link_stat(FPGA_BOOT_MASK)		;//	tpgs_send_acks();	LLMB->LINK_MISC	=	0X303	;
//};
/**********************************************************************/
//void 	tpes_cram_dnld() {
//	TPEL->TPEM_LINK = TPES_DNLD_CMND	;
//	tpem_link_stat(TPES_DNLD_MASK)	;
//};
/**********************************************************************/
//void 	tpes_cram_boot(){ 
//	TPEL->TPEM_LINK = TPES_BOOT_CMND	;
//	tpem_link_stat(TPES_BOOT_MASK)	;
//	tpgs_send_acks();
//	LLMB->LINK_MISC	=	0X331	;
//};

/**********************************************************************/
//void	tpem_odat_tpes(){
//	TPEL->TPEM_LINK = TPES_ODAT_CMND	;
//}

/**********************************************************************/
