#ifndef TPEM_LINK_H_
#define TPEM_LINK_H_

#include "tpuc_misc.h"
#include "tpgs_link.h"

void	tpem_link_stat(uint32_t stat_mask);

void	tpem_icfg_tpes();	
void	tpem_ocfg_tpes();	
void	tpem_nnex_tpes();
void	tpem_trim_tpes();


//void	tpes_fpga_aset();
//void	tpes_fpga_dnld();
//void	tpes_fpga_boot();
//
//void	tpes_cram_aset();
//void	tpes_cram_dnld();
//void	tpes_cram_boot();
//
//void	tpes_ispm_aset();

#endif /*TPEM_LINK_H*/

//void	tpes_ispm_dnld();
//void	tpes_ispm_boot();
//void	tpem_trim_tpes();	



