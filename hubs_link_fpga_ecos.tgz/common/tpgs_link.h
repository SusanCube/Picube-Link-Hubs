#ifndef TPGS_LINK_H_
#define TPGS_LINK_H_

#include "tpuc_misc.h"

void	tpgm_link_stat(uint32_t stat_mask);
void	tpgs_link_stat(uint32_t stat_mask);
void	tpgs_xdma_stat(uint32_t stat_mask);

void	boot_trim_tpgs();
void	boot_aset_cram();
void	boot_dnld_cram();
void	boot_jump_cram();

void	tpgs_send_acks();
void	tpgs_send_resp();





#endif /*TPGS_LINK_H*/



