
#ifndef TPUC_MISC_H_
#define TPUC_MISC_H_

#include <stdint.h>
/**********************************************************************/
	typedef struct _TPGL_CTRL_ {
		volatile uint32_t TPGM_LINK		; // 00_00
		volatile uint32_t TPGS_LINK		; // 01_04
		volatile uint32_t TPGS_XDMA		; // 02_08
		volatile uint32_t TPGS_DDRA		; // 03_0C
		volatile uint32_t TPGS_SCUT		; // 04_10
		volatile uint32_t TPES_PORT		; // 05_14
		volatile uint32_t SDES_PORT		; // 06_18
		volatile uint32_t MGTH_CFIG		; // 07_1C

	    volatile uint32_t ECOS_UPDT		; // 08_20
		volatile uint32_t TPGM_STAT		; // 09_24
		volatile uint32_t TPGS_STAT		; // 0A_28
		volatile uint32_t TPEM_STAT		; // 0B_2C
		volatile uint32_t TPGS_CPLA		; // 0C_30
		volatile uint32_t TPGS_TIME		; // 0D_34
		volatile uint32_t CRAM_ADDR		; // 0E_38
		volatile uint32_t CRAM_DATA		; // 0F_3C
	}	TPGL_CTRL	;
//----------------------------------------------------------------------
	#define TPGL_BASE 	0x0000c000
	#define TPGL 		((TPGL_CTRL *)TPGL_BASE)

	#define	TPGS_XDMA_CMND			TPGL->TPGS_XDMA
	#define	TPGS_XDMA_ADDR			TPGL->TPGS_DDRA

//----------------------------------------------------------------------
//TPGM_LINK_STAT::WORD0
	#define TPGM_CMND_MASK 			0x80000000	//BIT31
	#define TPGM_DDRS_MASK 			0x40000000	//BIT30
	
	#define TPGM_TRIM_MASK 			0x00080000	//BIT19	
	#define TPGM_BOOT_MASK 			0x00040000	//BIT18	
	#define TPGM_DNLD_MASK 			0x00020000	//BIT17
	#define TPGM_ASET_MASK 			0x00010000	//BIT16
	#define TPGM_ACMD_MASK 			0x00008000	//BIT15
	#define TPGM_ROSM_MASK 			0x00004000	//BIT14
	#define TPGM_RISM_MASK 			0x00002000	//BIT13
	#define TPGM_ROSV_MASK 			0x00001000	//BIT12
	#define TPGM_RISV_MASK 			0x00000800	//BIT11
	#define TPGM_ROMT_MASK 			0x00000400	//BIT10
	#define TPGM_RIMT_MASK 			0x00000200	//BIT09
	#define TPGM_ROVT_MASK 			0x00000100	//BIT08
	#define TPGM_RIVT_MASK 			0x00000080	//BIT07
	#define TPGM_OMTX_MASK 			0x00000040	//BIT06
	#define TPGM_IMTX_MASK 			0x00000020	//BIT05
	#define TPGM_OVCT_MASK 			0x00000010	//BIT04
	#define TPGM_IVCT_MASK 			0x00000008	//BIT03
	#define TPGM_NNEX_MASK 			0x00000004	//BIT02
	#define TPGM_OCFG_MASK 			0x00000002	//BIT01
	#define TPGM_ICFG_MASK 			0x00000001	//BIT00
//----------------------------------------------------------------------
//TPGS_LINK_CTRL::WORD1
	#define TPGL_ACKS_CMND 			0x00000071
	#define TPGL_RESP_CMND 			0x00000072
	#define TPGL_TUNE_CMND 			0x00000088
	#define TPGL_NULL_CMND 			0x00000000

	#define TPGS_DDRS_MASK 			0x80000000
	#define TPGS_RESP_MASK 			0x00000002
	#define TPGS_ACKS_MASK 			0x00000001
//----------------------------------------------------------------------
//TPGS_XMDA_STAT::WORD2
	#define TPGS_OSMT_RDMA 			0x00000087
	#define TPGS_ISMT_WDMA 			0x00000086
	#define TPGS_OSVT_RDMA 			0x00000085
	#define TPGS_ISVT_WDMA 			0x00000084
	#define TPGS_OMTX_RDMA 			0x00000083
	#define TPGS_IMTX_WDMA 			0x00000082
	#define TPGS_OVCT_RDMA 			0x00000081
	#define TPGS_IVCT_WDMA 			0x00000080

	#define TPGS_OSDE_MASK			0x00000008
	#define TPGS_ISDE_MASK			0x00000004
	#define TPGS_ODAT_MASK			0x00000002
	#define TPGS_IDAT_MASK			0x00000001
/**********************************************************************/
typedef struct _TPEL_CTRL_ {
    volatile uint32_t TPEM_LINK     ; //10_40
	volatile uint32_t TPEM_TUNE     ; //11_44
	volatile uint32_t TPEM_STAT     ; //12_48
	volatile uint32_t TPEM_SCFG     ; //13_4C
	volatile uint32_t TPEM_RSTN     ; //14_50
	volatile uint32_t TPEM_RXEN     ; //18_54
	
}	TPEL_CTRL	;

	#define TPEL_BASE   0x0000c040
	#define TPEL 		((TPEL_CTRL *)TPEL_BASE)

	#define	TPEL_TPEM_LINK			TPEL->TPEM_LINK
	#define	TPEL_TPEM_TUNE			TPEL->TPEM_TUNE
	#define	TPEL_TPEM_ACKS			TPEL->TPEM_STAT
	#define	TPEL_TPEM_RSTN			TPEL->TPEM_RSTN
	#define	TPEL_TPEM_RXEN			TPEL->TPEM_RXEN

	#define	TPEM_TUNE_ODLY			0x00000088
	#define	TPEM_TUNE_IDLY			0x00000099
	#define	TPEM_TUNE_DONE			0x00000000
//----------------------------------------------------------------------
	#define TPES_TRIM_CMND 			0x00000088
	#define FPGA_BOOT_CMND 			0x00000063
	#define FPGA_DNLD_CMND 			0x00000062
	#define FPGA_ASET_CMND 			0x00000061
	#define TPES_BOOT_CMND 			0x00000053
	#define TPES_DNLD_CMND 			0x00000052
	#define TPES_ASET_CMND 			0x00000051
	#define TPES_OMTX_CMND 			0x00000024
	#define TPES_IMTX_CMND 			0x00000023
	#define TPES_OVCT_CMND 			0x00000022
	#define TPES_IVCT_CMND 			0x00000021
	#define TPES_NNEX_CMND 			0x00000013
	#define TPES_OCFG_CMND 			0x00000012
	#define TPES_ICFG_CMND 			0x00000011
		
	#define FPGA_DNLD_ENAB 			0x000000EA
	#define FPGA_DNLD_DONE 			0x000000EF
	#define TPES_DNLD_ENAB 			0x000000FA
	#define TPES_DNLD_DONE 			0x000000FF
	#define TPEL_ACKS_MASK 			0x00000071
	#define TPEL_RESP_MASK 			0x00000072

	#define TPES_TRIM_MASK 			0x00002000//Bit 13
	#define FPGA_BOOT_MASK 			0x00001000//Bit 12
	#define FPGA_DNLD_MASK 			0x00000800//Bit 11
	#define FPGA_ASET_MASK 			0x00000400//Bit 10
	#define TPES_BOOT_MASK 			0x00000200//Bit 09
	#define TPES_DNLD_MASK 			0x00000100//Bit 08
	#define TPES_ASET_MASK 			0x00000080//Bit 07
	#define TPES_OMTX_MASK 			0x00000040//Bit 06
	#define TPES_IMTX_MASK 			0x00000020//Bit 05
	#define TPES_OVCT_MASK 			0x00000010//Bit 04
	#define TPES_IVCT_MASK 			0x00000008//Bit 03
	#define TPES_NNEX_MASK 			0x00000004//Bit 02
	#define TPES_OCFG_MASK 			0x00000002//Bit 01
	#define TPES_ICFG_MASK 			0x00000001//Bit 00
/**********************************************************************/
typedef struct _LLMB_VARS_ {
	volatile uint32_t LLMB_STA0		; // 20 ~ 80
    volatile uint32_t LLMB_STA1		; // 21 ~ 84
	volatile uint32_t LLMB_STA2		; // 22 ~ 88  
    volatile uint32_t LLMB_STA3		; // 23 ~ 8C
	volatile uint32_t LLMB_STA4		; // 24 ~ 90  
    volatile uint32_t LLMB_STA5		; // 25 ~ 94
	volatile uint32_t LLMB_STA6		; // 26 ~ 98  
    volatile uint32_t LLMB_STA7		; // 27 ~ 9C
    volatile uint32_t DOWN_MODE		; // 28 ~ A0
	volatile uint32_t LLMB_VAR1		; // 29 ~ A4
    volatile uint32_t LLMB_VAR2		; // 2A ~ A8
	volatile uint32_t LLMB_VAR3		; // 2B ~ AC
	volatile uint32_t OMNI_EDGE		; // 2C ~ B0
	volatile uint32_t OMNI_PILE		; // 2D ~ B4
	volatile uint32_t PILE_EDGE		; // 2E ~ B8
	volatile uint32_t PILE_INDX		; // 2F ~ BC
} 	LLMB_VARS	;	

	#define LLMB_BASE 	0x0000c080
	#define LLMB        ((LLMB_VARS *)LLMB_BASE)


	#define	LLMB_SDES_CMND			LLMB->LLMB_VAR1	
	#define	LLMB_SDES_MASK			LLMB->LLMB_VAR2
	#define	LLMB_PILE_INDX			LLMB->PILE_INDX
/**********************************************************************/
typedef struct _TLNK_RCMD_ {
	volatile uint32_t CMND_MEMO[16]		; // 30 ~ C0
} 	TLNK_RCMD	;

	#define TLNK_RCMD_BASE 	0x0000c0C0
	#define TLNK_RCMD     ((TLNK_RCMD *)TLNK_RCMD_BASE)

/**********************************************************************/
typedef struct _TLNK_ACKS_ {
	volatile uint32_t ACKS_MEMO[8]		; // 40 ~ 100
} 	TLNK_ACKS	;

	#define ACKS_BASE 	0x0000c100
	#define ACKS     ((TLNK_ACKS *)ACKS_BASE)

/**********************************************************************/
typedef struct _TLNK_CMND_ {
	volatile uint32_t CMND_MEMO[16]	;//TPES_PORT		; // 50 ~ 140
} 	TLNK_CMND	;

	#define TLNK_BASE 	0x0000c140
	#define TLNK     ((TLNK_CMND *)TLNK_BASE)
	
	#define	TLNK_DEST_PORT			TLNK->CMND_MEMO[0]	
	#define	TLNK_TPGS_MARK			TLNK->CMND_MEMO[1]	
	#define	TLNK_TPES_MARK			TLNK->CMND_MEMO[2]	
	#define	TLNK_EDGE_MARK			TLNK->CMND_MEMO[3]	
	#define	TLNK_DTAR_ADDR			TLNK->CMND_MEMO[4]	
	#define	TLNK_DSRC_ADDR			TLNK->CMND_MEMO[5]	
	#define	TLNK_BULK_PACK			TLNK->CMND_MEMO[6 ]	
	#define	TLNK_BULK_PAGE			TLNK->CMND_MEMO[7 ]	
	#define	TLNK_ROWS_NUMB			TLNK->CMND_MEMO[8 ]	
	#define	TLNK_COLS_NUMB			TLNK->CMND_MEMO[9 ]	
	#define	TLNK_ROWS_PACK			TLNK->CMND_MEMO[10]	
	#define	TLNK_PACK_PAGE			TLNK->CMND_MEMO[11]	
	#define	TLNK_AUXI_WRD0			TLNK->CMND_MEMO[12]	
	#define	TLNK_AUXI_WRD1			TLNK->CMND_MEMO[13]	
	#define	TLNK_AUXI_WRD2			TLNK->CMND_MEMO[14]	
	#define	TLNK_AUXI_WRD3			TLNK->CMND_MEMO[15]	


	#define	TLNK_TPEL_MARK			TLNK->CMND_MEMO[2]	
	

/**********************************************************************/
typedef struct _TPEM_ODLY_ {
	volatile uint32_t ODLY_TAPS[8]	;//TPES_PORT		; // 60 ~ 
} 	TPEM_ODLY	;

	#define ODLY_BASE 	0x0000c180
	#define ODLY     ((TPEM_ODLY *)ODLY_BASE)
	
	#define	TPEM_ODLY_TAP0			ODLY->ODLY_TAPS[0]	
	#define	TPEM_ODLY_TAP1			ODLY->ODLY_TAPS[1]	
	#define	TPEM_ODLY_TAP2			ODLY->ODLY_TAPS[2]	
	#define	TPEM_ODLY_TAP3			ODLY->ODLY_TAPS[3]	
	#define	TPEM_ODLY_TAP4			ODLY->ODLY_TAPS[4]	
	#define	TPEM_ODLY_TAP5			ODLY->ODLY_TAPS[5]	
	#define	TPEM_ODLY_TAP6			ODLY->ODLY_TAPS[6]	
	#define	TPEM_ODLY_TAP7			ODLY->ODLY_TAPS[7]	
/**********************************************************************/
typedef struct _TPEM_IDLY_ {
	volatile uint32_t IDLY_TAPS[8]	;//TPES_PORT		; // 70 ~ 
	volatile uint32_t IDLY_PATN[8]	;//TPES_PORT		; // 70 ~ 
} 	TPEM_IDLY	;

	#define IDLY_BASE 	0x0000c1c0
	#define IDLY     ((TPEM_IDLY *)IDLY_BASE)
	
	#define	TPEM_IDLY_TAP0			IDLY->IDLY_TAPS[0]	
	#define	TPEM_IDLY_TAP1			IDLY->IDLY_TAPS[1]	
	#define	TPEM_IDLY_TAP2			IDLY->IDLY_TAPS[2]	
	#define	TPEM_IDLY_TAP3			IDLY->IDLY_TAPS[3]	
	#define	TPEM_IDLY_TAP4			IDLY->IDLY_TAPS[4]	
	#define	TPEM_IDLY_TAP5			IDLY->IDLY_TAPS[5]	
	#define	TPEM_IDLY_TAP6			IDLY->IDLY_TAPS[6]	
	#define	TPEM_IDLY_TAP7			IDLY->IDLY_TAPS[7]	

	#define	TPEM_IDLY_ALIGN			IDLY->IDLY_PATN[0]	

	#define	TPEM_IDLY_PTN0			IDLY->IDLY_PATN[0]	
	#define	TPEM_IDLY_PTN1			IDLY->IDLY_PATN[1]	
	#define	TPEM_IDLY_PTN2			IDLY->IDLY_PATN[2]	
	#define	TPEM_IDLY_PTN3			IDLY->IDLY_PATN[3]	
	#define	TPEM_IDLY_PTN4			IDLY->IDLY_PATN[4]	
	#define	TPEM_IDLY_PTN5			IDLY->IDLY_PATN[5]	
	#define	TPEM_IDLY_PTN6			IDLY->IDLY_PATN[6]	
	#define	TPEM_IDLY_PTN7			IDLY->IDLY_PATN[7]	
/**********************************************************************/
	#define	TPGS_DEST_SCUT			0x00000000	
	#define	TPGS_DEST_CRAM			0x00000001	
	#define	TPGS_DEST_CFIG			0x00000002	
	#define	TPGS_DEST_DDRS			0x00000003
	#define	TPGS_DEST_ECOS			0x00000004	
	#define	TPGS_DEST_MGTH			0x00000005	
	#define	TPGS_DEST_SCFG			0x00000006
	#define	TPGS_DEST_CNTC			0x00000007

	#define	TPES_DEST_SCUT			0x00000000
	#define	TPES_DEST_CRAM			0x00000001
	#define	TPES_DEST_CFIG			0x00000002
	#define	TPES_DEST_ISPM			0x00000003

	#define	TPEM_LINK_RXEN			0x00000005
	#define	TPEM_LINK_RSTN			0x00000006
	#define	TPEM_SCFG_STAT			0x00000007

	#define	TPEM_IDLY_TUNE			0x00000008
	#define	TPEM_IDLY_STAT			0x00000009
	#define	TPEM_ODLY_TUNE			0x0000000A
	#define	TPEM_ODLY_STAT			0x0000000B
	#define	TPEM_TUNE_STOP			0x0000000C
	#define	TPEM_IDLY_SYNC			0x0000000D
			
	#define	TPEM_TUNE_IDLY_CMND		0x00000088
	#define	TPEM_TUNE_ODLY_CMND		0x00000099
	
	#define	EDGE_DEST_SCUT			0x00000000
	#define	EDGE_DEST_CRAM			0x00000001
	#define	EDGE_DEST_CFIG			0x00000002
	#define	EDGE_DEST_DVP0			0x00000003
	#define	EDGE_DEST_DVP1			0x00000004
	#define	EDGE_DEST_DVPD			0x00000005
	#define	EDGE_DEST_GML0			0x00000006
	#define	EDGE_DEST_GML1			0x00000007
	#define	EDGE_DEST_NNEX			0x00000008

	#define	EXIT_DNLD_MODE			0x00000000
	#define	ISPM_DNLD_MODE			0x00000001
	#define	TPES_DNLD_MODE			0x00000002
	#define	FPGA_DNLD_MODE			0x00000003
	
	#define	LLMB_PASS_CODE			0x50415353
	#define	LLMB_FAIL_CODE			0x4641494c

#endif /*TPUC_MISC_H_*/

