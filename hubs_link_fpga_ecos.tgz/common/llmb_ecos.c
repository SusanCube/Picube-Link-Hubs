#include "llmb_ecos.h"
//--LLMB_ICFG_PARSE-----------------------------------------------------------------------------------------
void    llmb_icfg_parse(){
	LLMB->LLMB_STA2	=	0X0101	;

    if(TLNK_TPGS_MARK == TPGS_DEST_MGTH)    {
		LLMB->LLMB_STA2	=	0X0102	;

		ACKS->ACKS_MEMO[0] =	TPGL->MGTH_CFIG  ;
    }
	else if(TLNK_TPGS_MARK == TPGS_DEST_ECOS)	{
		LLMB->LLMB_STA2	=	0X0103	;

		ACKS->ACKS_MEMO[0] =	LLMB->OMNI_EDGE	;
		ACKS->ACKS_MEMO[1] =	LLMB->OMNI_PILE	;
		ACKS->ACKS_MEMO[2] =	LLMB->PILE_EDGE	;
		ACKS->ACKS_MEMO[3] =	LLMB->PILE_INDX	;
	}
	else if(TLNK_TPEL_MARK == TPEM_SCFG_STAT)	{
		LLMB->LLMB_STA2	=	0X0104	;

		ACKS->ACKS_MEMO[0] =	LLMB_PASS_CODE	;
	}
	else if(	(TLNK_TPEL_MARK == TPEM_IDLY_STAT) ||(TLNK_TPEL_MARK == TPEM_ODLY_STAT) )	{
//		LLMB->LLMB_STA2	=	0X0107	;
//		ACKS->ACKS_MEMO[0]	=	 TPEM_IDLY_TAP0	;
//		ACKS->ACKS_MEMO[1]	=	 TPEM_IDLY_TAP1	;
//		ACKS->ACKS_MEMO[2]	=	 TPEM_IDLY_TAP2	;
//		ACKS->ACKS_MEMO[3]	=	 TPEM_IDLY_TAP3	;
//		ACKS->ACKS_MEMO[4]	=	 TPEM_IDLY_TAP4	;
//		ACKS->ACKS_MEMO[5]	=	 TPEM_IDLY_TAP5	;
//		ACKS->ACKS_MEMO[6]	=	 TPEM_IDLY_TAP6	;
//		ACKS->ACKS_MEMO[7]	=	 TPEM_IDLY_TAP7	;
//	}
//	else if(TLNK_TPEL_MARK == TPEM_ODLY_STAT)	{
//		LLMB->LLMB_STA2	=	0X0108	;
//		ACKS->ACKS_MEMO[0]	=	 TPEM_ODLY_TAP0	;
//		ACKS->ACKS_MEMO[1]	=	 TPEM_ODLY_TAP1	;
//		ACKS->ACKS_MEMO[2]	=	 TPEM_ODLY_TAP2	;
//		ACKS->ACKS_MEMO[3]	=	 TPEM_ODLY_TAP3	;
//		ACKS->ACKS_MEMO[4]	=	 TPEM_ODLY_TAP4	;
//		ACKS->ACKS_MEMO[5]	=	 TPEM_ODLY_TAP5	;
//		ACKS->ACKS_MEMO[6]	=	 TPEM_ODLY_TAP6	;
//		ACKS->ACKS_MEMO[7]	=	 TPEM_ODLY_TAP7	;
	}
    else 
	{
		tpem_icfg_tpes();
	}
    tpgs_send_acks();
}
//--LLMB_OCFG_PARSE-----------------------------------------------------------------------------------------
void    llmb_ocfg_parse(){
    if(TLNK_TPGS_MARK	== TPGS_DEST_MGTH)////initiate aurora
    {
		TPGL->MGTH_CFIG	=	TLNK->CMND_MEMO[12]	;
	}
    else if(TLNK_TPGS_MARK == TPGS_DEST_ECOS)//cfig PILE parameter
    {
		LLMB->OMNI_EDGE	=	TLNK->CMND_MEMO[12]	; 
		LLMB->OMNI_PILE	=	TLNK->CMND_MEMO[13]	; 
		LLMB->PILE_EDGE	=	TLNK->CMND_MEMO[14]	; 
		LLMB->PILE_INDX	=	TLNK->CMND_MEMO[15]	; 
	}
    else if(TLNK_TPGS_MARK == TPGS_DEST_SCUT)
	{
		LLMB->LLMB_STA2	= 0X9999	;
		if((TLNK_TPEL_MARK == TPES_DEST_CFIG) | (TLNK_TPEL_MARK == TPES_DEST_SCUT))
		{
			LLMB->LLMB_STA2	= 0X9999	;
			tpem_ocfg_tpes();
			LLMB->LLMB_STA2	= 0XAAAA	;
		}
		else if(TLNK_TPEL_MARK == TPEM_LINK_RSTN)	{
			TPEL_TPEM_RSTN	=	TLNK_AUXI_WRD0	;
		}
		else if(TLNK_TPEL_MARK == TPEM_LINK_RXEN)	{
			TPEL_TPEM_RXEN	=	TLNK_AUXI_WRD0	;
		}
		
	}
    tpgs_send_acks();
}	
//--LLMB_NNEX_PARSE-----------------------------------------------------------------------------------------
void 	llmb_nnex_parse(){
	LLMB->LLMB_STA2	=	0X0301	;
	tpem_nnex_tpes();	
    tpgs_send_acks();
}
//--LLMB_RISM_PARSE-----------------------------------------------------------------------------------------
void	llmb_risx_parse(uint32_t meta_type)	{
	if(LLMB_PILE_INDX == 0x0000)
	{
		LLMB_SDES_MASK =	TPGS_ISDE_MASK	;

		if((meta_type == 0X01))
			LLMB_SDES_CMND =	TPGS_ISMT_WDMA	;
		else
			LLMB_SDES_CMND =	TPGS_ISVT_WDMA	;
	}
	else
	{
		LLMB_SDES_MASK =	TPGS_OSDE_MASK	;

		if((meta_type == 0X01))
			LLMB_SDES_CMND =	TPGS_OSMT_RDMA	;
		else
			LLMB_SDES_CMND =	TPGS_OSVT_RDMA	;
	}

	tpgs_send_acks();
}
//--LLMB_ROSM_PARSE-----------------------------------------------------------------------------------------
void	llmb_rosx_parse(uint32_t meta_type)	{
	if(LLMB_PILE_INDX == 0x0000)
	{
		LLMB_SDES_MASK =	TPGS_OSDE_MASK	;

		if((meta_type == 0X01))
			LLMB_SDES_CMND =	TPGS_OSMT_RDMA	;
		else
			LLMB_SDES_CMND =	TPGS_OSVT_RDMA	;
	}
	else
	{
		LLMB_SDES_MASK =	TPGS_ISDE_MASK	;

		if((meta_type == 0X01))
			LLMB_SDES_CMND =	TPGS_ISMT_WDMA	;
		else
			LLMB_SDES_CMND =	TPGS_ISVT_WDMA	;
	}
	tpgs_send_acks();
}
//--LLMB_ACMD_PARSE-----------------------------------------------------------------------------------------
void	llmb_acmd_parse(){
	
		TPGS_XDMA_CMND	=	LLMB_SDES_CMND	;
		tpgs_xdma_stat(LLMB_SDES_MASK)	;
		tpgs_send_resp();
}
//--LLMB_RODT_PARSE-----------------------------------------------------------------------------------------
void    llmb_rodt_parse(uint32_t meta_type){
	LLMB->LLMB_STA2	=	0Xa009	;

	if(meta_type == 0x01){
		TPEL_TPEM_LINK	=	TPES_OMTX_CMND	;	
		tpem_link_stat(TPES_OMTX_MASK)	;
	}
	else {
		TPEL_TPEM_LINK	=	TPES_OVCT_CMND	;	
		tpem_link_stat(TPES_OVCT_MASK)	;
	}
        tpgs_send_acks();
}
//--LLMB_RIDT_PARSE-----------------------------------------------------------------------------------------
void    llmb_ridt_parse(uint32_t meta_type){
	LLMB->LLMB_STA2	=	0Xa00a	;
    
	tpgs_send_acks();
	if(meta_type == 0x01){
		TPEL_TPEM_LINK	=	TPES_IMTX_CMND	;	
		tpem_link_stat(TPES_IMTX_MASK)	;
	}
	else {
		TPEL_TPEM_LINK	=	TPES_IVCT_CMND	;	
		tpem_link_stat(TPES_IVCT_MASK)	;
	}	
	tpgs_send_resp();

}
//--LLMB_IDAT_PARSE-----------------------------------------------------------------------------------------
void    llmb_idat_parse(uint32_t meta_type){
	LLMB->LLMB_STA2	=	0X2101	;
	if(TLNK_TPGS_MARK  ==  TPGS_DEST_SCUT)		{
		TPGL->TPGS_SCUT	=	0x01	;
		if(meta_type == 0x01){
			TPEL_TPEM_LINK	=	TPES_IMTX_CMND	;	
			tpem_link_stat(TPES_IMTX_MASK)	;
		}
		else {
			TPEL_TPEM_LINK	=	TPES_IVCT_CMND	;	
			tpem_link_stat(TPES_IVCT_MASK)	;
		}
		TPGL->TPGS_SCUT	=	0x00	;
	}
	else if(TLNK_TPGS_MARK  ==  TPGS_DEST_DDRS){
        tpgs_send_acks();

		TPGS_XDMA_ADDR	=	TLNK_DTAR_ADDR	;
		
		if(meta_type == 0x01){
			TPGS_XDMA_CMND =   TPGS_OMTX_RDMA  ;//MSATER in SLAVE out
		}
		else{
			TPGS_XDMA_CMND =   TPGS_OVCT_RDMA  ;//MSATER in SLAVE out
		}
        tpgs_xdma_stat(0x02);
        tpgs_send_resp();
    }
}
//--LLMB_ODAT_PARSE-----------------------------------------------------------------------------------------
void    llmb_odat_parse(uint32_t meta_type){
	LLMB->LLMB_STA2	=	0X2201	;
    if(TLNK_TPGS_MARK  ==  TPGS_DEST_SCUT)		{
		TPGL->TPGS_SCUT	=	0x01	;

		if(meta_type == 0x01){
			TPEL_TPEM_LINK	=	TPES_OMTX_CMND	;	
			tpem_link_stat(TPES_OMTX_MASK)	;
		}
		else {
			TPEL_TPEM_LINK	=	TPES_OVCT_CMND	;	
			tpem_link_stat(TPES_OVCT_MASK)	;
		}
		TPGL->TPGS_SCUT	=	0x00	;
	}
	else if(TLNK_TPGS_MARK  ==  TPGS_DEST_DDRS){
		TPGS_XDMA_ADDR	=	TLNK_DTAR_ADDR	;

		if(meta_type == 0x01){
			TPGS_XDMA_CMND =   TPGS_IMTX_WDMA  ;//MSATER Out SLAVE In
		}
		else{
			TPGS_XDMA_CMND =   TPGS_IVCT_WDMA  ;//MSATER Out SLAVE In
		}
        tpgs_send_acks();
        tpgs_xdma_stat(0x01);
        tpgs_send_resp();
    }
}
//--LLMB_ASET_PARSE-----------------------------------------------------------------------------------------
void    llmb_aset_parse(){
	LLMB->LLMB_STA2	=	0X3101	;
	TPGL->TPES_PORT	=	TLNK_DEST_PORT	;
    
	if( (TLNK_TPGS_MARK == TPGS_DEST_SCFG) )//&& (LLMB->TPES_MARK == TPES_DEST_SCFG))//FPGA Serial Config
    {
        LLMB->DOWN_MODE =   FPGA_DNLD_MODE  ;//        tpes_fpga_aset();
		TPEL->TPEM_LINK = 	FPGA_ASET_CMND	;
		tpem_link_stat(FPGA_ASET_MASK)		;//	LLMB->LLMB_STA2	=	0X301	;
    } 
	else if((TLNK_TPGS_MARK == TPGS_DEST_SCUT) && (TLNK_TPEL_MARK == TPES_DEST_CRAM))//FPGA CRAM Config
    {
        LLMB->DOWN_MODE =	TPES_DNLD_MODE  ;//        tpes_cram_aset();
		TPEL->TPEM_LINK = 	TPES_ASET_CMND	;
		tpem_link_stat(TPES_ASET_MASK)		;//	tpgs_send_acks();//	LLMB->LLMB_STA2	=	0X311	;

    }
    else if((TLNK_TPGS_MARK == TPGS_DEST_SCUT) && (TLNK_TPEL_MARK == TPES_DEST_ISPM))//FPGA ISPM
    {
        LLMB->DOWN_MODE =   ISPM_DNLD_MODE  ;//        tpes_ispm_aset();
		TPEL->TPEM_LINK = 	TPES_ASET_CMND	;
		tpem_link_stat(TPES_ASET_MASK)		;//	tpgs_send_acks();//	LLMB->LLMB_STA2	=	0X311	;
    }
    tpgs_send_acks();
}
//--LLMB_DNLD_PARSE-----------------------------------------------------------------------------------------
void    llmb_dnld_parse(){
	LLMB->LLMB_STA2	=	0x3201	;
	TPGL->TPES_PORT	=	TLNK_DEST_PORT	;

    if(LLMB->DOWN_MODE ==   FPGA_DNLD_MODE)
    {
		TPEL->TPEM_LINK = 	FPGA_DNLD_CMND	;
		tpem_link_stat(FPGA_DNLD_MASK)		;//	tpgs_send_acks();//	LLMB->LLMB_STA2	=	0X302	;
    }
    else if(LLMB->DOWN_MODE ==  TPES_DNLD_MODE)
    {
        TPEL->TPEM_LINK	= TPES_DNLD_CMND  ;
        tpem_link_stat(TPES_DNLD_MASK);		//		TPEM->LINK_MISC =   0x321   ;
    }
	else if(LLMB->DOWN_MODE ==  ISPM_DNLD_MODE)
    {
    	TPEL->TPEM_LINK	= TPES_DNLD_CMND  ;
		tpem_link_stat(TPES_DNLD_MASK);
	}
    tpgs_send_acks();
}
//--LLMB_BOOT_PARSE-----------------------------------------------------------------------------------------
void    llmb_boot_parse(){
	LLMB->LLMB_STA2	=	0x3301	;
	TPGL->TPES_PORT	=	TLNK_DEST_PORT	;
    
	if(LLMB->DOWN_MODE ==   FPGA_DNLD_MODE)
    {
        TPEL->TPEM_LINK = 	FPGA_BOOT_CMND	;// add by slin|scwu
    	tpem_link_stat(FPGA_BOOT_MASK);		//	TPEM->LINK_MISC =   0x331   ;
    }
    else if(LLMB->DOWN_MODE ==  TPES_DNLD_MODE)
    {
        TPEL->TPEM_LINK = 	TPES_BOOT_CMND	;// add by slin|scwu
    	tpem_link_stat(TPES_BOOT_MASK);		//	TPEM->LINK_MISC =   0x331   ;
    }
	else if(LLMB->DOWN_MODE ==  ISPM_DNLD_MODE)
    {
        TPEL->TPEM_LINK = 	TPES_BOOT_CMND	;// add by slin|scwu
    	tpem_link_stat(TPES_BOOT_MASK);		//	TPEM->LINK_MISC =   0x331   ;
	}
    
	LLMB->DOWN_MODE =   EXIT_DNLD_MODE  ;
	TPGL->TPES_PORT	=	0x0000	;
    tpgs_send_acks();
}
//--LLMB_TRIM_PARSE-----------------------------------------------------------------------------------------
void    llmb_trim_parse(){
	LLMB->LLMB_STA2	=	0X00020002	;   		
	if(TLNK_TPGS_MARK==0x08)	{
		ACKS->ACKS_MEMO[0]	=	 0x1111	;
		ACKS->ACKS_MEMO[1]	=	 0x2222	;
		ACKS->ACKS_MEMO[2]	=	 0x3333	;
		ACKS->ACKS_MEMO[3]	=	 0x4444	;
		ACKS->ACKS_MEMO[4]	=	 0x5555	;
		ACKS->ACKS_MEMO[5]	=	 0x6666	;
		ACKS->ACKS_MEMO[6]	=	 0x7777	;
		ACKS->ACKS_MEMO[7]	=	 0x8888	;
//		tpgs_send_acks();
	} 
	else if(TLNK_TPEL_MARK ==   TPEM_ODLY_TUNE)	
	{
		if(TPGL->TPES_PORT&0x00000001)	TPEM_ODLY_TAP0	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000002)	TPEM_ODLY_TAP1	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000004)	TPEM_ODLY_TAP2	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000008)	TPEM_ODLY_TAP3	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000010)	TPEM_ODLY_TAP4	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000020)	TPEM_ODLY_TAP5	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000040)	TPEM_ODLY_TAP6	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000080)	TPEM_ODLY_TAP7	=	TLNK_AUXI_WRD0	;

		TPEL_TPEM_TUNE	=	0x0088	;//TPEM_TUNE_ODLY_CMND
	}
	else if(TLNK_TPEL_MARK ==   TPEM_IDLY_TUNE)
	{
	
		if(TPGL->TPES_PORT&0x00000001)	TPEM_IDLY_TAP0	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000002)	TPEM_IDLY_TAP1	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000004)	TPEM_IDLY_TAP2	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000008)	TPEM_IDLY_TAP3	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000010)	TPEM_IDLY_TAP4	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000020)	TPEM_IDLY_TAP5	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000040)	TPEM_IDLY_TAP6	=	TLNK_AUXI_WRD0	;
		if(TPGL->TPES_PORT&0x00000080)	TPEM_IDLY_TAP7	=	TLNK_AUXI_WRD0	;

		TPEL_TPEM_TUNE	=	0x0099	;//TPEM_TUNE_IDLY_CMND
	}
	else if(TLNK_TPEL_MARK ==   TPEM_IDLY_STAT)
   	{
		LLMB->LLMB_STA2	=	0X00010001	;   	
   		ACKS->ACKS_MEMO[0]	=	TPEM_IDLY_TAP0	;
		ACKS->ACKS_MEMO[1]	=	TPEM_IDLY_TAP1	;
		ACKS->ACKS_MEMO[2]	=	TPEM_IDLY_TAP2	;
		ACKS->ACKS_MEMO[3]	=	TPEM_IDLY_TAP3	;
		ACKS->ACKS_MEMO[4]	=	TPEM_IDLY_TAP4	;
		ACKS->ACKS_MEMO[5]	=	TPEM_IDLY_TAP5	;
		ACKS->ACKS_MEMO[6]	=	TPEM_IDLY_TAP6	;
		ACKS->ACKS_MEMO[7]	=	TPEM_IDLY_TAP7	;
		LLMB->LLMB_STA2	=	0X00000000	;   	
	}
	else if(TLNK_TPEL_MARK ==   TPEM_IDLY_SYNC)
   	{
		LLMB->LLMB_STA2	=	0X0001000D	;   	
		TPEM_IDLY_ALIGN	=	0X1	;	
	}
	else if(TLNK_TPEL_MARK ==   TPEM_ODLY_STAT)
   	{
//		LLMB->LLMB_STA2	=	0X00010001	;   	   
// 		ACKS->ACKS_MEMO[0]	=	TPEM_ODLY_TAP0	;
//		ACKS->ACKS_MEMO[1]	=	TPEM_ODLY_TAP1	;
//		ACKS->ACKS_MEMO[2]	=	TPEM_ODLY_TAP2	;
//		ACKS->ACKS_MEMO[3]	=	TPEM_ODLY_TAP3	;
//		ACKS->ACKS_MEMO[4]	=	TPEM_ODLY_TAP4	;
//		ACKS->ACKS_MEMO[5]	=	TPEM_ODLY_TAP5	;
//		ACKS->ACKS_MEMO[6]	=	TPEM_ODLY_TAP6	;
//		ACKS->ACKS_MEMO[7]	=	TPEM_ODLY_TAP7	;
		LLMB->LLMB_STA2	=	0X00000000	;   	
	}
	else if(TLNK_TPEL_MARK == TPEM_TUNE_STOP)
	{
		TPEL_TPEM_TUNE	=	0x0000	;//TPEM_TUNE_STOP_CMND

//		ACKS->ACKS_MEMO[0]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[1]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[2]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[3]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[4]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[5]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[6]	=	0x444F4E45	;
//		ACKS->ACKS_MEMO[7]	=	0x444F4E45	;
	}
//	tpgs_send_acks();

}
