#ifndef LLMB_ECOS_H_
#define LLMB_ECOS_H_

#include "tpuc_misc.h"
#include "tpgs_link.h"
#include "tpem_link.h"

void	llmb_icfg_parse();
void	llmb_ocfg_parse();
void	llmb_nnex_parse();

void	llmb_risx_parse(uint32_t meta_type);
void	llmb_rosx_parse(uint32_t meta_type);
void	llmb_acmd_parse();

void	llmb_rodt_parse(uint32_t meta_type);
void	llmb_ridt_parse(uint32_t meta_type);

void	llmb_odat_parse(uint32_t meta_type);
void	llmb_idat_parse(uint32_t meta_type);

void	llmb_boot_parse();
void	llmb_dnld_parse();
void	llmb_aset_parse();

void	llmb_trim_parse();


#endif /*LLMB_ECOS_H*/



