#include "tpuc_misc.h"
#include "tpgs_link.h"
/**********************************************************************/
void	tpgm_link_stat(uint32_t stat_mask){
	TPGL->TPGM_STAT	=	0	;
	while(TPGL->TPGM_STAT	== 0){
		TPGL->TPGM_STAT	=	TPGL->TPGM_LINK & stat_mask	;	
	}	
	TPGL->TPGM_LINK	=	0	;
}
/**********************************************************************/
void	tpgs_link_stat(uint32_t stat_mask){
	TPGL->TPGS_STAT	=	0	;
	while( TPGL->TPGS_STAT	== 0){
		TPGL->TPGS_STAT	=	TPGL->TPGS_LINK & stat_mask	;	
	}	
	TPGL->TPGS_LINK	=	0	;
}
/**********************************************************************/
void	tpgs_xdma_stat(uint32_t stat_mask){
	TPGL->TPGS_STAT	=	0	;
	while( TPGL->TPGS_STAT	== 0){
		TPGL->TPGS_STAT	=	TPGL->TPGS_XDMA & stat_mask	;	
	}	
	TPGL->TPGS_XDMA	=	0	;
}
/**********************************************************************/
void	tpgs_send_acks(){
	LLMB->LLMB_STA3	= 	0X880199	;
	TPGL->TPGS_LINK	=	TPGL_ACKS_CMND	;
	tpgs_link_stat(TPGS_ACKS_MASK );
}
/**********************************************************************/
void	tpgs_send_resp(){
	TPGL->TPGS_LINK	=	TPGL_RESP_CMND	;
	tpgs_link_stat(TPGS_RESP_MASK );
}
/**********************************************************************/
void	boot_aset_cram(){
	TPGL->CRAM_ADDR	=	TLNK->CMND_MEMO[12]	;
	tpgs_send_acks();
}
/**********************************************************************/
void	boot_dnld_cram(){
	LLMB->LLMB_STA3	= 	0X880299	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[ 8]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[ 9]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[10]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[11]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[12]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[13]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[14]	;
	TPGL->CRAM_DATA	=	TLNK->CMND_MEMO[15]	;
	tpgs_send_acks();
}
/****************************************************************Z******/
void	boot_jump_cram(){
	LLMB->LLMB_STA3	= 	0X880399	;
	tpgs_send_acks();
}
/***********************************************************************/
void	boot_trim_tpgs(){
	LLMB->LLMB_STA2	= 	0X880499	;

	if(TLNK_TPGS_MARK==0x08)	{
	LLMB->LLMB_STA2	= 	0X880599	;
		ACKS->ACKS_MEMO[0]	=	 0x1111	;
		ACKS->ACKS_MEMO[1]	=	 0x2222	;
		ACKS->ACKS_MEMO[2]	=	 0x3333	;
		ACKS->ACKS_MEMO[3]	=	 0x4444	;
		ACKS->ACKS_MEMO[4]	=	 0x5555	;
		ACKS->ACKS_MEMO[5]	=	 0x6666	;
		ACKS->ACKS_MEMO[6]	=	 0x7777	;
		ACKS->ACKS_MEMO[7]	=	 0x8888	;
	tpgs_send_acks();

	} 
	LLMB->LLMB_STA2	= 	0X880799	;
		
}
