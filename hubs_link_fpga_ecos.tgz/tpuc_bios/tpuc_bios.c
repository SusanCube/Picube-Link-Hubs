#include "../common/tpuc_misc.h"
#include "../common/tpgs_link.h"

extern jump_to_ram();
void main() {
	LLMB->LLMB_STA0	= 0X88	;
//	tpgs_link_stat(TPGM_DDRS_MASK)	;
	
	while(1){
		TPGL->TPGM_STAT	=	TPGL->TPGM_LINK ;
		if(TPGL->TPGM_STAT & TPGM_CMND_MASK)
		{	
			LLMB->LLMB_STA1	= 	0X01	;
			TPGL->ECOS_UPDT	=	0X00	;
			TPGL->TPGM_LINK	=	0X00 	;

			if(TPGL->TPGM_STAT & TPGM_TRIM_MASK ) {	LLMB->LLMB_STA2 = 0X44	;	boot_trim_tpgs();			}
			if(TPGL->TPGM_STAT & TPGM_ASET_MASK ) {	LLMB->LLMB_STA2 = 0X11	;	boot_aset_cram();			}
			if(TPGL->TPGM_STAT & TPGM_DNLD_MASK ) {	LLMB->LLMB_STA2 = 0X22	;	boot_dnld_cram();			}
			if(TPGL->TPGM_STAT & TPGM_BOOT_MASK ) {	LLMB->LLMB_STA2 = 0X33	;	tpgs_send_acks();	break;	}
		}
	}		
    jump_to_ram();
	
}

 
